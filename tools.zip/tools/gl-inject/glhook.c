// Deep readback hook: intercepts the OpenGL pixel-readback calls that Wine's
// wined3d uses when the browser reads a WebGL/canvas surface back. If our
// injected bytes reach the browser's hash, we have proven we can feed a
// pre-recorded drawing (later: a live engine) at the readback point.
//
// Covers both linkage paths: direct symbol (LD_PRELOAD) AND glX/eglGetProcAddress
// (which Wine typically uses to resolve GL entry points).
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

static void logmsg(const char* m, int a, int b){
    FILE* f=fopen("/root/winelab/glhook.log","a");
    if(f){ fprintf(f,"%s %d %d\n",m,a,b); fclose(f); }
}
static void* real(const char* n){
    static void* h=NULL;
    if(!h){ h=dlopen("libGL.so.1", RTLD_NOW|RTLD_GLOBAL); if(!h) h=dlopen("/usr/lib/x86_64-linux-gnu/libGL.so.1", RTLD_NOW|RTLD_GLOBAL); }
    return h?dlsym(h,n):NULL;
}
// deterministic recorded pattern: makes the resulting hash a fixed, known value
static void inject(void* data, size_t n){
    if(!data||!n) return;
    unsigned char* p=(unsigned char*)data;
    for(size_t i=0;i<n;i++) p[i]=(unsigned char)((i*137u+91u)&0xFF);
}

typedef void(*rp_t)(int,int,int,int,unsigned,unsigned,void*);
void glReadPixels(int x,int y,int w,int h,unsigned fmt,unsigned type,void* data){
    static rp_t r=NULL; if(!r) r=(rp_t)real("glReadPixels");
    if(r) r(x,y,w,h,fmt,type,data);
    logmsg("glReadPixels",w,h);
    inject(data,(size_t)(w>0?w:0)*(h>0?h:0)*4);
}
typedef void(*gti_t)(unsigned,int,unsigned,unsigned,void*);
void glGetTexImage(unsigned t,int l,unsigned fmt,unsigned type,void* data){
    static gti_t r=NULL; if(!r) r=(gti_t)real("glGetTexImage");
    if(r) r(t,l,fmt,type,data);
    logmsg("glGetTexImage",l,fmt);
    // size unknown here; inject a bounded region to shift the hash if this path is used
    inject(data, 256*256*4);
}

static void* pick(const char* name){
    if(!strcmp(name,"glReadPixels")) return (void*)glReadPixels;
    if(!strcmp(name,"glGetTexImage")) return (void*)glGetTexImage;
    return NULL;
}
typedef void*(*gpa_t)(const char*);
void* glXGetProcAddress(const char* n){ void* m=pick(n); if(m){logmsg("gpa-glx",0,0); return m;} static gpa_t r=NULL; if(!r) r=(gpa_t)real("glXGetProcAddress"); return r?r(n):NULL; }
void* glXGetProcAddressARB(const char* n){ return glXGetProcAddress(n); }
void* eglGetProcAddress(const char* n){ void* m=pick(n); if(m){logmsg("gpa-egl",0,0); return m;} static gpa_t r=NULL; if(!r) r=(gpa_t)real("eglGetProcAddress"); return r?r(n):NULL; }
