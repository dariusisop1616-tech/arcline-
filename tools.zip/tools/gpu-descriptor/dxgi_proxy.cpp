// Proxy dxgi.dll for the lab guest.
//
// Chrome/Edge report the WebGL renderer string from ANGLE, which builds it from
// DXGI_ADAPTER_DESC (Description + VendorId + DeviceId). ANGLE does not get its
// adapter from a factory we could wrap - it calls D3D11CreateDevice and then
// IDXGIDevice::GetParent - so wrapping CreateDXGIFactory is not enough. Instead
// we patch the IDXGIAdapter vtable once: every adapter object of that class,
// however obtained, then returns our values.
//
// Installed as System32\dxgi.dll with the real one renamed to dxgi_orig.dll.
// All 19 exports forward there (see the .def); only the CreateDXGIFactory family
// is implemented here, to guarantee an early patch point.
//
// The spoof only activates inside browser processes, so dwm.exe and the rest of
// the guest desktop keep seeing the truth.

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <dxgi1_6.h>
#include <stdio.h>
#include <wchar.h>

// Export table mirroring Windows 10 19041 dxgi.dll, ordinals preserved. The 16
// pass-through entries forward to the renamed original (dxgi_orig.dll); the three
// CreateDXGIFactory functions are implemented below as the patch entry points.
// Using linker pragmas rather than a .def, because this toolchain's .def
// forwarder handling is unreliable.
#pragma comment(linker, "/export:ApplyCompatResolutionQuirking=dxgi_orig.ApplyCompatResolutionQuirking,@1")
#pragma comment(linker, "/export:CompatString=dxgi_orig.CompatString,@2")
#pragma comment(linker, "/export:CompatValue=dxgi_orig.CompatValue,@3")
#pragma comment(linker, "/export:DXGIDumpJournal=dxgi_orig.DXGIDumpJournal,@4")
#pragma comment(linker, "/export:PIXBeginCapture=dxgi_orig.PIXBeginCapture,@5")
#pragma comment(linker, "/export:PIXEndCapture=dxgi_orig.PIXEndCapture,@6")
#pragma comment(linker, "/export:PIXGetCaptureState=dxgi_orig.PIXGetCaptureState,@7")
#pragma comment(linker, "/export:SetAppCompatStringPointer=dxgi_orig.SetAppCompatStringPointer,@8")
#pragma comment(linker, "/export:UpdateHMDEmulationStatus=dxgi_orig.UpdateHMDEmulationStatus,@9")
#pragma comment(linker, "/export:CreateDXGIFactory,@10")
#pragma comment(linker, "/export:CreateDXGIFactory1,@11")
#pragma comment(linker, "/export:CreateDXGIFactory2,@12")
#pragma comment(linker, "/export:DXGID3D10CreateDevice=dxgi_orig.DXGID3D10CreateDevice,@13")
#pragma comment(linker, "/export:DXGID3D10CreateLayeredDevice=dxgi_orig.DXGID3D10CreateLayeredDevice,@14")
#pragma comment(linker, "/export:DXGID3D10GetLayeredDeviceSize=dxgi_orig.DXGID3D10GetLayeredDeviceSize,@15")
#pragma comment(linker, "/export:DXGID3D10RegisterLayers=dxgi_orig.DXGID3D10RegisterLayers,@16")
#pragma comment(linker, "/export:DXGIDeclareAdapterRemovalSupport=dxgi_orig.DXGIDeclareAdapterRemovalSupport,@17")
#pragma comment(linker, "/export:DXGIGetDebugInterface1=dxgi_orig.DXGIGetDebugInterface1,@18")
#pragma comment(linker, "/export:DXGIReportAdapterConfiguration=dxgi_orig.DXGIReportAdapterConfiguration,@19")

static HMODULE          g_orig = nullptr;
static CRITICAL_SECTION g_cs;
static bool             g_csReady = false;
static bool             g_patched = false;
static bool             g_enabled = false;
static bool             g_configLoaded = false;

// defaults; overridden by C:\ProgramData\fplab\gpu.ini
static wchar_t g_name[128] = L"AMD Radeon RX 580";
static UINT    g_vendor    = 0x1002;      // AMD
static UINT    g_device    = 0x67DF;      // Ellesmere / RX 580
static UINT    g_subsys    = 0x21F01462;
static UINT    g_rev       = 0xE7;
static bool    g_log       = false;

static void LogF(const wchar_t* fmt, ...) {
    if (!g_log) return;
    FILE* f = nullptr;
    if (_wfopen_s(&f, L"C:\\ProgramData\\fplab\\dxgi_proxy.log", L"a+, ccs=UTF-8") || !f) return;
    va_list ap; va_start(ap, fmt);
    vfwprintf(f, fmt, ap);
    va_end(ap);
    fputws(L"\n", f);
    fclose(f);
}

// DXGI_ADAPTER_DESC, DESC1, DESC2 and DESC3 all begin with this same prefix,
// so one writer covers every GetDesc variant.
struct DescPrefix {
    WCHAR Description[128];
    UINT  VendorId;
    UINT  DeviceId;
    UINT  SubSysId;
    UINT  Revision;
};

static void LoadConfig() {
    if (g_configLoaded) return;
    g_configLoaded = true;
    FILE* f = nullptr;
    if (_wfopen_s(&f, L"C:\\ProgramData\\fplab\\gpu.ini", L"rt, ccs=UTF-8") || !f) return;
    wchar_t line[512];
    while (fgetws(line, 512, f)) {
        wchar_t* eq = wcschr(line, L'=');
        if (!eq) continue;
        *eq = 0;
        wchar_t* key = line;
        wchar_t* val = eq + 1;
        size_t n = wcslen(val);
        while (n && (val[n - 1] == L'\n' || val[n - 1] == L'\r')) val[--n] = 0;
        if      (_wcsicmp(key, L"Name")     == 0) wcsncpy_s(g_name, 128, val, _TRUNCATE);
        else if (_wcsicmp(key, L"VendorId") == 0) g_vendor = (UINT)wcstoul(val, nullptr, 0);
        else if (_wcsicmp(key, L"DeviceId") == 0) g_device = (UINT)wcstoul(val, nullptr, 0);
        else if (_wcsicmp(key, L"SubSysId") == 0) g_subsys = (UINT)wcstoul(val, nullptr, 0);
        else if (_wcsicmp(key, L"Revision") == 0) g_rev    = (UINT)wcstoul(val, nullptr, 0);
        else if (_wcsicmp(key, L"Log")      == 0) g_log    = (wcstoul(val, nullptr, 0) != 0);
    }
    fclose(f);
}

static void ApplyDesc(void* d) {
    if (!d) return;
    DescPrefix* p = (DescPrefix*)d;
    wcsncpy_s(p->Description, 128, g_name, _TRUNCATE);
    p->VendorId = g_vendor;
    p->DeviceId = g_device;
    p->SubSysId = g_subsys;
    p->Revision = g_rev;
}

typedef HRESULT(STDMETHODCALLTYPE* PFN_Desc)(void*, void*);
static PFN_Desc o_GetDesc = nullptr, o_GetDesc1 = nullptr, o_GetDesc2 = nullptr, o_GetDesc3 = nullptr;

static HRESULT STDMETHODCALLTYPE My_GetDesc (void* s, void* d) { HRESULT hr = o_GetDesc (s, d); if (SUCCEEDED(hr)) ApplyDesc(d); return hr; }
static HRESULT STDMETHODCALLTYPE My_GetDesc1(void* s, void* d) { HRESULT hr = o_GetDesc1(s, d); if (SUCCEEDED(hr)) ApplyDesc(d); return hr; }
static HRESULT STDMETHODCALLTYPE My_GetDesc2(void* s, void* d) { HRESULT hr = o_GetDesc2(s, d); if (SUCCEEDED(hr)) ApplyDesc(d); return hr; }
static HRESULT STDMETHODCALLTYPE My_GetDesc3(void* s, void* d) { HRESULT hr = o_GetDesc3(s, d); if (SUCCEEDED(hr)) ApplyDesc(d); return hr; }

static HMODULE Orig() {
    if (!g_orig) {
        // Bare name -> normal search order. Works both when the proxy sits in the
        // browser's application directory (dxgi_orig.dll beside it) and when it is
        // installed into System32.
        g_orig = LoadLibraryW(L"dxgi_orig.dll");
    }
    return g_orig;
}

static void PatchSlot(void** vt, int idx, void* repl, PFN_Desc* saved) {
    DWORD oldProt;
    if (!VirtualProtect(&vt[idx], sizeof(void*), PAGE_EXECUTE_READWRITE, &oldProt)) return;
    if (!*saved) *saved = (PFN_Desc)vt[idx];
    vt[idx] = repl;
    VirtualProtect(&vt[idx], sizeof(void*), oldProt, &oldProt);
}

// IDXGIAdapter vtable layout:
//   0-2   IUnknown
//   3-6   IDXGIObject
//   7     EnumOutputs      8  GetDesc       9  CheckInterfaceSupport
//   10    GetDesc1 (Adapter1)
//   11    GetDesc2 (Adapter2)
//   12-17 IDXGIAdapter3
//   18    GetDesc3 (Adapter4)
static void EnsurePatched() {
    if (!g_enabled || !g_csReady) return;
    EnterCriticalSection(&g_cs);
    if (!g_patched) {
        LoadConfig();
        HMODULE o = Orig();
        typedef HRESULT(WINAPI* PFN_CF1)(REFIID, void**);
        PFN_CF1 cf1 = o ? (PFN_CF1)GetProcAddress(o, "CreateDXGIFactory1") : nullptr;
        if (cf1) {
            IDXGIFactory1* fac = nullptr;
            if (SUCCEEDED(cf1(__uuidof(IDXGIFactory1), (void**)&fac)) && fac) {
                IDXGIAdapter1* ad = nullptr;
                if (SUCCEEDED(fac->EnumAdapters1(0, &ad)) && ad) {
                    void** vt = *(void***)ad;
                    int depth = 11;                       // through GetDesc1
                    IDXGIAdapter4* a4 = nullptr;
                    IDXGIAdapter2* a2 = nullptr;
                    if (SUCCEEDED(ad->QueryInterface(__uuidof(IDXGIAdapter4), (void**)&a4)) && a4) { depth = 19; a4->Release(); }
                    else if (SUCCEEDED(ad->QueryInterface(__uuidof(IDXGIAdapter2), (void**)&a2)) && a2) { depth = 12; a2->Release(); }

                    PatchSlot(vt, 8, (void*)My_GetDesc, &o_GetDesc);
                    if (depth > 10) PatchSlot(vt, 10, (void*)My_GetDesc1, &o_GetDesc1);
                    if (depth > 11) PatchSlot(vt, 11, (void*)My_GetDesc2, &o_GetDesc2);
                    if (depth > 18) PatchSlot(vt, 18, (void*)My_GetDesc3, &o_GetDesc3);

                    g_patched = true;
                    LogF(L"patched vtable=%p depth=%d name=%s vid=%04X did=%04X", vt, depth, g_name, g_vendor, g_device);
                    ad->Release();
                }
                fac->Release();
            }
        }
        if (!g_patched) LogF(L"patch attempt failed");
    }
    LeaveCriticalSection(&g_cs);
}

extern "C" {

HRESULT WINAPI CreateDXGIFactory(REFIID riid, void** pp) {
    EnsurePatched();
    typedef HRESULT(WINAPI* T)(REFIID, void**);
    HMODULE o = Orig();
    T f = o ? (T)GetProcAddress(o, "CreateDXGIFactory") : nullptr;
    return f ? f(riid, pp) : E_FAIL;
}

HRESULT WINAPI CreateDXGIFactory1(REFIID riid, void** pp) {
    EnsurePatched();
    typedef HRESULT(WINAPI* T)(REFIID, void**);
    HMODULE o = Orig();
    T f = o ? (T)GetProcAddress(o, "CreateDXGIFactory1") : nullptr;
    return f ? f(riid, pp) : E_FAIL;
}

HRESULT WINAPI CreateDXGIFactory2(UINT flags, REFIID riid, void** pp) {
    EnsurePatched();
    typedef HRESULT(WINAPI* T)(UINT, REFIID, void**);
    HMODULE o = Orig();
    T f = o ? (T)GetProcAddress(o, "CreateDXGIFactory2") : nullptr;
    return f ? f(flags, riid, pp) : E_FAIL;
}

} // extern "C"

static DWORD WINAPI PatchThread(LPVOID) {
    Sleep(200);          // let the loader finish before touching COM
    EnsurePatched();
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        InitializeCriticalSection(&g_cs);
        g_csReady = true;

        wchar_t exe[MAX_PATH] = L"";
        GetModuleFileNameW(nullptr, exe, MAX_PATH);
        const wchar_t* base = wcsrchr(exe, L'\\');
        base = base ? base + 1 : exe;
        if (_wcsicmp(base, L"msedge.exe") == 0 || _wcsicmp(base, L"chrome.exe") == 0) {
            g_enabled = true;
            LoadConfig();
            // Do not call into DXGI under loader lock; a thread starts once DllMain returns.
            HANDLE t = CreateThread(nullptr, 0, PatchThread, nullptr, 0, nullptr);
            if (t) CloseHandle(t);
        }
    } else if (reason == DLL_PROCESS_DETACH) {
        if (g_csReady) { DeleteCriticalSection(&g_cs); g_csReady = false; }
    }
    return TRUE;
}
