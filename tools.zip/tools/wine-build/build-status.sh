#!/bin/bash
# Seconds-fast build progress: stage, compiled-object count, RAM, last log lines.
B=/root/build; L=$B/logs
echo "running: $(pgrep -f 'build-wine.sh' >/dev/null && echo yes || echo no)   make jobs: $(pgrep -c -x cc1 2>/dev/null || echo 0) gcc, $(pgrep -fc 'mingw32-gcc' 2>/dev/null) mingw"
[ -d $B/obj64 ] && echo "objects built: $(find $B/obj64 -name '*.o' 2>/dev/null | wc -l)"
free -m | awk 'NR==2{printf "mem used %s/%s MB", $3, $2} NR==3{printf ", swap %s MB\n", $3}'
df -h / | tail -1 | awk '{print "disk free: " $4}'
for f in make configure staging deps; do
  [ -f $L/$f.log ] && { echo "--- $f.log (last 3) ---"; tail -3 $L/$f.log | cut -c1-160; break; }
done
