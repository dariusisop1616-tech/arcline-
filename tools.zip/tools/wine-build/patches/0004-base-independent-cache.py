#!/usr/bin/env python3
"""Patch 0004 - make the image cache base-independent, and stop using 0002.

0002 (return 0 from assign_map_address so every process uses the PE header base)
crashed Edge: with no assigned address Wine has no fallback when that address is
already taken - it maps the image elsewhere and then skips relocation, so the
process runs code relocated for the wrong base (page fault at 0x1700616D8).

Safe alternative: keep Wine's address assignment exactly as it is, store the
cached image UNRELOCATED (as it is in the file) and let Wine's own relocation run
in each process as it normally does. The cache file then depends only on the
file, not on any address, so every process in every workspace maps the same one.
Pages that relocation writes become private per process, as they would anyway;
everything else - the bulk of a 335 MB image - stays shared through the page cache.

usage: 0004-base-independent-cache.py <wine source dir>   (idempotent)
"""
import sys, pathlib

root = pathlib.Path(sys.argv[1])
src = root / "dlls/ntdll/unix/virtual.c"
text = src.read_text()
if "gologin-lab: base-independent cache" in text:
    print("0004 already applied"); sys.exit(0)

def once(old, new):
    global text
    if text.count(old) != 1:
        sys.exit(f"0004: anchor found {text.count(old)} times:\n{old[:200]}")
    text = text.replace(old, new)

# 1. no base in the key, no relocation while building
once("""    ULONG_PTR map_base = view_base;
    INT_PTR delta = (INT_PTR)(view_base - image_info->base);""",
     """    /* gologin-lab: base-independent cache - no address in the key, contents
     * exactly as in the file, so one cache file serves every process. */
    (void)view_base; (void)image_info;""")

once("""    snprintf( path, sizeof(path), "%s/%lx-%lx-%lx-%lx-%lx.img", dir,
              (unsigned long)st->st_dev, (unsigned long)st->st_ino, (unsigned long)st->st_size,
              (unsigned long)st->st_mtime, (unsigned long)map_base );""",
     """    snprintf( path, sizeof(path), "%s/%lx-%lx-%lx-%lx.img", dir,
              (unsigned long)st->st_dev, (unsigned long)st->st_ino,
              (unsigned long)st->st_size, (unsigned long)st->st_mtime );""")

once("""    if (delta && (rdir = get_data_dir( nt, total_size, IMAGE_DIRECTORY_ENTRY_BASERELOC )))
    {
        IMAGE_BASE_RELOCATION *rel = (IMAGE_BASE_RELOCATION *)(map + rdir->VirtualAddress);
        IMAGE_BASE_RELOCATION *end = (IMAGE_BASE_RELOCATION *)((char *)rel + rdir->Size);

        while (rel && rel < end - 1 && rel->SizeOfBlock && rel->VirtualAddress < total_size)
            rel = process_relocation_block( map + rel->VirtualAddress, rel, delta );
    }
""", "")

# the now-unused locals
once("""    IMAGE_DATA_DIRECTORY *rdir;
    char path[512], tmp[600];""",
     """    char path[512], tmp[600];""")

# 2. relocation must run normally again (0001 disabled it when the cache was used)
once("        if (cache_fd < 0 && (dir = get_data_dir( nt, total_size, IMAGE_DIRECTORY_ENTRY_BASERELOC )))",
     "        if ((dir = get_data_dir( nt, total_size, IMAGE_DIRECTORY_ENTRY_BASERELOC )))")

src.write_text(text)

# 3. stop 0002 from being used: it stays in the source but the launcher no longer
#    sets the variable, and the default is off.
srv = root / "server/mapping.c"
t2 = srv.read_text()
t2 = t2.replace('const char *env = getenv( "WINE_STABLE_IMAGE_BASE" );',
                'const char *env = getenv( "WINE_STABLE_IMAGE_BASE_UNSAFE" ); /* 0004: crashed Edge, off */')
srv.write_text(t2)
print("0004 applied to", src, "and", srv)
