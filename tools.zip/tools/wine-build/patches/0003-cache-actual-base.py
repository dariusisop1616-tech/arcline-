#!/usr/bin/env python3
"""Patch 0003 - key the image cache on the ACTUAL mapping address.

0001 derived the address from image_info (map_addr, else the PE header base).
That is a prediction: when an image is mapped somewhere else - which is exactly
what happens with patch 0002, where map_addr is 0 and ntdll places the image
itself - the cached copy would be relocated for an address the image is not at,
and the process would run corrupted code.

view->base is the address the image really occupies, known at this point, so use
it for both the cache file name and the relocation delta. Correct in every case,
and it makes the cache shared whenever two processes really do agree on a base.

usage: 0003-cache-actual-base.py <wine source dir>   (idempotent)
"""
import sys, pathlib

src = pathlib.Path(sys.argv[1]) / "dlls/ntdll/unix/virtual.c"
text = src.read_text()
if "gologin-lab: cache keyed on the actual mapping address" in text:
    print("0003 already applied"); sys.exit(0)
if "gologin-lab: aligned image cache" not in text:
    sys.exit("0003: patch 0001 must be applied first")

def once(old, new):
    global text
    if text.count(old) != 1:
        sys.exit(f"0003: anchor found {text.count(old)} times:\n{old[:160]}")
    text = text.replace(old, new)

# helper takes the real base
once("""static int image_cache_open( int fd, const struct stat *st, IMAGE_NT_HEADERS *nt,
                             const IMAGE_SECTION_HEADER *sec, SIZE_T total_size,
                             SIZE_T align_mask, const struct pe_image_info *image_info,
                             BOOL removable )""",
     """/* gologin-lab: cache keyed on the actual mapping address */
static int image_cache_open( int fd, const struct stat *st, IMAGE_NT_HEADERS *nt,
                             const IMAGE_SECTION_HEADER *sec, SIZE_T total_size,
                             SIZE_T align_mask, const struct pe_image_info *image_info,
                             ULONG_PTR view_base, BOOL removable )""")

once("""    ULONG_PTR map_base = image_info->map_addr ? image_info->map_addr : image_info->base;
    INT_PTR delta = image_info->map_addr ? (INT_PTR)(image_info->map_addr - image_info->base) : 0;""",
     """    ULONG_PTR map_base = view_base;
    INT_PTR delta = (INT_PTR)(view_base - image_info->base);""")

once("    cache_fd = image_cache_open( fd, &st, nt, sec, total_size, align_mask, image_info, removable );",
     "    cache_fd = image_cache_open( fd, &st, nt, sec, total_size, align_mask, image_info,\n"
     "                                 (ULONG_PTR)view->base, removable );")

# the view is already relocated by the cache for its own base, so skip the
# in-process relocation whenever the cache was used (any base, not just map_addr)
once("""        if (cache_fd < 0 && (dir = get_data_dir( nt, total_size, IMAGE_DIRECTORY_ENTRY_BASERELOC )))""",
     """        if (cache_fd < 0 && (dir = get_data_dir( nt, total_size, IMAGE_DIRECTORY_ENTRY_BASERELOC )))""")

src.write_text(text)
print("0003 applied to", src)
