#!/usr/bin/env python3
"""Patch 0005 - go back to the per-address cache (undo 0004).

Measured on two workspaces (ws-scale.sh):
  0001 + 0003 (cache per mapping address, relocation skipped)  448 MB + 372 MB
  0001 + 0004 (one cache file, relocation runs per process)    526 MB + 980 MB
Sharing the file only pays off if relocation can be skipped, and skipping it is
only correct when every process maps the image at the same address. Within a
workspace they do (wineserver assigns one address per file), across workspaces
they do not - and forcing that (0002) crashed Edge.

So: keep the cache keyed on the actual mapping address (0003), which is correct
everywhere and shares between all processes of a workspace. Sharing between
workspaces needs wineserver to assign the same address in every workspace - a
deterministic allocator that reserves the address properly, not 0002's shortcut.

usage: 0005-revert-0004.py <wine source dir>   (idempotent)
"""
import sys, pathlib

src = pathlib.Path(sys.argv[1]) / "dlls/ntdll/unix/virtual.c"
text = src.read_text()
if "gologin-lab: base-independent cache" not in text:
    print("0005: 0004 not applied, nothing to revert"); sys.exit(0)

def once(old, new):
    global text
    if text.count(old) != 1:
        sys.exit(f"0005: anchor found {text.count(old)} times:\n{old[:200]}")
    text = text.replace(old, new)

once("""    /* gologin-lab: base-independent cache - no address in the key, contents
     * exactly as in the file, so one cache file serves every process. */
    (void)view_base; (void)image_info;""",
     """    ULONG_PTR map_base = view_base;
    INT_PTR delta = (INT_PTR)(view_base - image_info->base);""")

once("""    char path[512], tmp[600];""",
     """    IMAGE_DATA_DIRECTORY *rdir;
    char path[512], tmp[600];""")

once("""    snprintf( path, sizeof(path), "%s/%lx-%lx-%lx-%lx.img", dir,
              (unsigned long)st->st_dev, (unsigned long)st->st_ino,
              (unsigned long)st->st_size, (unsigned long)st->st_mtime );""",
     """    snprintf( path, sizeof(path), "%s/%lx-%lx-%lx-%lx-%lx.img", dir,
              (unsigned long)st->st_dev, (unsigned long)st->st_ino, (unsigned long)st->st_size,
              (unsigned long)st->st_mtime, (unsigned long)map_base );""")

# relocate the cache once, while building it
once("""    munmap( map, total_size );
    if ( rename( tmp, path )""".replace("if ( rename", "if (rename"),
     """    if (delta && (rdir = get_data_dir( nt, total_size, IMAGE_DIRECTORY_ENTRY_BASERELOC )))
    {
        IMAGE_BASE_RELOCATION *rel = (IMAGE_BASE_RELOCATION *)(map + rdir->VirtualAddress);
        IMAGE_BASE_RELOCATION *end = (IMAGE_BASE_RELOCATION *)((char *)rel + rdir->Size);

        while (rel && rel < end - 1 && rel->SizeOfBlock && rel->VirtualAddress < total_size)
            rel = process_relocation_block( map + rel->VirtualAddress, rel, delta );
    }
    munmap( map, total_size );
    if (rename( tmp, path )""")

# and not again in every process
once("        if ((dir = get_data_dir( nt, total_size, IMAGE_DIRECTORY_ENTRY_BASERELOC )))",
     "        if (cache_fd < 0 && (dir = get_data_dir( nt, total_size, IMAGE_DIRECTORY_ENTRY_BASERELOC )))")

src.write_text(text)
print("0005 applied to", src)
