#!/usr/bin/env python3
"""Patch 0001 - aligned image cache: share big unaligned DLLs between processes.

Measured problem (2026-09-28): msedge.dll is 335 MB with FileAlignment 0x200.
map_file_into_view() can only mmap() page-aligned file offsets; for every other
section it falls back to pread() into anonymous memory - a full private copy of
the DLL in EVERY Edge process (a 270 MB block of x86 code per renderer).
Windows keeps one shared copy.

Fix: the first process that loads such an image writes a page-aligned copy of
its sections (each at its RVA, exactly the bytes Wine's pread path would place)
into a cache file, already relocated for the address the image is mapped at.
Every process then mmap()s that file copy-on-write, so the pages live once in
the page cache and are shared across processes and workspaces. Pages a process
writes still become private, as on Windows.

  WINE_IMAGE_CACHE=0      disable (stock behaviour, for A/B measurement)
  WINE_IMAGE_CACHE_DIR    cache directory (default /var/tmp/wine-image-cache)

usage: 0001-image-cache.py <wine source dir>     (idempotent)
"""
import sys, pathlib

src = pathlib.Path(sys.argv[1]) / "dlls/ntdll/unix/virtual.c"
text = src.read_text()
MARK = "gologin-lab: aligned image cache"
if MARK in text:
    print("0001 already applied"); sys.exit(0)

def replace_once(old, new):
    global text
    n = text.count(old)
    if n != 1:
        sys.exit(f"0001: anchor found {n} times, expected 1:\n{old[:200]}")
    text = text.replace(old, new)

HELPER = r'''
/* ---- gologin-lab: aligned image cache ----------------------------------------
 * A PE image whose section data is not page-aligned in the file (FileAlignment
 * 0x200, e.g. msedge.dll at 335 MB) cannot be mmap()ed, so map_file_into_view()
 * pread()s a private copy into every process. Build once a page-aligned copy of
 * the sections, relocated for the address the image is mapped at, in a cache
 * file, and mmap() it copy-on-write instead: pages are shared through the page
 * cache by every process mapping the same file at the same base, like Windows.
 * Returns an fd to map sections from, or -1 to use the stock path.
 */
static int image_cache_open( int fd, const struct stat *st, IMAGE_NT_HEADERS *nt,
                             const IMAGE_SECTION_HEADER *sec, SIZE_T total_size,
                             SIZE_T align_mask, const struct pe_image_info *image_info,
                             BOOL removable )
{
    static const SIZE_T sector_align = 0x1ff;
    const char *env = getenv( "WINE_IMAGE_CACHE" ), *dir = getenv( "WINE_IMAGE_CACHE_DIR" );
    ULONG_PTR map_base = image_info->map_addr ? image_info->map_addr : image_info->base;
    INT_PTR delta = image_info->map_addr ? (INT_PTR)(image_info->map_addr - image_info->base) : 0;
    IMAGE_DATA_DIRECTORY *rdir;
    char path[512], tmp[600];
    struct stat cst;
    int i, cfd, unaligned = 0;
    char *map;

    if (env && env[0] == '0') return -1;
    if (removable || total_size < 4 * 1024 * 1024) return -1;
    for (i = 0; i < nt->FileHeader.NumberOfSections; i++)
    {
        if ((sec[i].Characteristics & IMAGE_SCN_MEM_SHARED) &&
            (sec[i].Characteristics & IMAGE_SCN_MEM_WRITE)) return -1;
        if (sec[i].PointerToRawData && sec[i].SizeOfRawData &&
            ((sec[i].PointerToRawData & ~sector_align) & page_mask)) unaligned = 1;
    }
    if (!unaligned) return -1;

    if (!dir) dir = "/var/tmp/wine-image-cache";
    mkdir( dir, 0777 );
    snprintf( path, sizeof(path), "%s/%lx-%lx-%lx-%lx-%lx.img", dir,
              (unsigned long)st->st_dev, (unsigned long)st->st_ino, (unsigned long)st->st_size,
              (unsigned long)st->st_mtime, (unsigned long)map_base );
    if ((cfd = open( path, O_RDONLY | O_CLOEXEC )) >= 0)
    {
        if (!fstat( cfd, &cst ) && cst.st_size == total_size) return cfd;
        close( cfd );
    }

    snprintf( tmp, sizeof(tmp), "%s.%d.tmp", path, (int)getpid() );
    if ((cfd = open( tmp, O_RDWR | O_CREAT | O_TRUNC | O_CLOEXEC, 0644 )) < 0) return -1;
    if (ftruncate( cfd, total_size ) ||
        (map = mmap( NULL, total_size, PROT_READ | PROT_WRITE, MAP_SHARED, cfd, 0 )) == MAP_FAILED)
    {
        close( cfd ); unlink( tmp ); return -1;
    }
    for (i = 0; i < nt->FileHeader.NumberOfSections; i++)
    {
        SIZE_T map_size, file_start, file_size;

        if (!sec[i].PointerToRawData || !sec[i].SizeOfRawData) continue;
        /* same arithmetic as the section loop in map_image_into_view() */
        if (!sec[i].Misc.VirtualSize) map_size = ROUND_SIZE( 0, sec[i].SizeOfRawData, align_mask );
        else map_size = ROUND_SIZE( 0, sec[i].Misc.VirtualSize, align_mask );
        file_start = sec[i].PointerToRawData & ~sector_align;
        file_size = ROUND_SIZE( sec[i].PointerToRawData, sec[i].SizeOfRawData, sector_align );
        if (file_size > map_size) file_size = map_size;
        if (sec[i].VirtualAddress + file_size > total_size || sec[i].PointerToRawData >= st->st_size)
            goto fail;
        pread( fd, map + sec[i].VirtualAddress, file_size, file_start );
    }
    if (delta && (rdir = get_data_dir( nt, total_size, IMAGE_DIRECTORY_ENTRY_BASERELOC )))
    {
        IMAGE_BASE_RELOCATION *rel = (IMAGE_BASE_RELOCATION *)(map + rdir->VirtualAddress);
        IMAGE_BASE_RELOCATION *end = (IMAGE_BASE_RELOCATION *)((char *)rel + rdir->Size);

        while (rel && rel < end - 1 && rel->SizeOfBlock && rel->VirtualAddress < total_size)
            rel = process_relocation_block( map + rel->VirtualAddress, rel, delta );
    }
    munmap( map, total_size );
    if (rename( tmp, path )) unlink( tmp );   /* lost a race: the other copy is identical */
    TRACE_(module)( "image cache %s created\n", path );
    return cfd;

fail:
    munmap( map, total_size );
    close( cfd );
    unlink( tmp );
    return -1;
}

'''

# 1. helper right before map_image_into_view()
replace_once("static NTSTATUS map_image_into_view( struct file_view *view, const UNICODE_STRING *nt_name, int fd,",
             HELPER + "static NTSTATUS map_image_into_view( struct file_view *view, const UNICODE_STRING *nt_name, int fd,")

# 2. local variable
replace_once("    SIZE_T align_mask = max( image_info->alignment - 1, page_mask );\n    INT_PTR delta;\n",
             "    SIZE_T align_mask = max( image_info->alignment - 1, page_mask );\n    INT_PTR delta;\n"
             "    int cache_fd = -1;  /* gologin-lab: aligned image cache */\n")

# 3. open the cache before mapping the sections
replace_once("    /* map all the sections */\n",
             "    cache_fd = image_cache_open( fd, &st, nt, sec, total_size, align_mask, image_info, removable );\n\n"
             "    /* map all the sections */\n")

# 4. map regular sections from the cache (page-aligned offset = RVA)
replace_once(
"""            map_file_into_view( view, fd, sec[i].VirtualAddress, file_size, file_start,
                                VPROT_COMMITTED | VPROT_READ | VPROT_WRITECOPY,
                                removable ) != STATUS_SUCCESS)""",
"""            (cache_fd >= 0
             ? map_file_into_view( view, cache_fd, sec[i].VirtualAddress, map_size, sec[i].VirtualAddress,
                                   VPROT_COMMITTED | VPROT_READ | VPROT_WRITECOPY, FALSE )
             : map_file_into_view( view, fd, sec[i].VirtualAddress, file_size, file_start,
                                   VPROT_COMMITTED | VPROT_READ | VPROT_WRITECOPY,
                                   removable )) != STATUS_SUCCESS)""")

# 5. the cache already holds the zero tail; writing it would make the page private
replace_once("        if (file_size & align_mask)\n",
             "        if (cache_fd < 0 && (file_size & align_mask))\n")

# 6. the cache is already relocated for this base
replace_once(
"""            ((IMAGE_NT_HEADERS32 *)nt)->OptionalHeader.ImageBase = image_info->map_addr;

        if ((dir = get_data_dir( nt, total_size, IMAGE_DIRECTORY_ENTRY_BASERELOC )))""",
"""            ((IMAGE_NT_HEADERS32 *)nt)->OptionalHeader.ImageBase = image_info->map_addr;

        if (cache_fd < 0 && (dir = get_data_dir( nt, total_size, IMAGE_DIRECTORY_ENTRY_BASERELOC )))""")

# 7. release the fd on every exit path
replace_once("done:\n    free( sections );\n    return status;\n}\n",
             "done:\n    if (cache_fd >= 0) close( cache_fd );\n    free( sections );\n    return status;\n}\n")

src.write_text(text)
print("0001 applied to", src)
