#!/usr/bin/env python3
"""Patch 0002 - stable image base, so workspaces share one cached image.

Measured 2026-09-28: with patch 0001 each workspace still kept its OWN 335 MB
copy of msedge.dll, because wineserver assigns every image a randomized load
address per server (one server per workspace) and the cache file is keyed by that
address. ws1 mapped ...9630000, ws2 ...9660000.

assign_map_address() returns 0 when it cannot place an image, and ntdll then maps
it at the address in the PE header. That address is a property of the file, so it
is the same in every workspace: one cache file, shared through the page cache by
every process on the machine - which is also how Windows behaves, where a DLL
normally sits at the same address in every process.

Opt-in, because it removes per-image address randomisation inside the prefix:
  WINE_STABLE_IMAGE_BASE=1   in the workspace environment

usage: 0002-stable-image-base.py <wine source dir>   (idempotent)
"""
import sys, pathlib

src = pathlib.Path(sys.argv[1]) / "server/mapping.c"
text = src.read_text()
MARK = "gologin-lab: stable image base"
if MARK in text:
    print("0002 already applied"); sys.exit(0)

anchor = """    if (!(mapping->image.image_charact & IMAGE_FILE_DLL)) return 0;

    if ((ret = get_fd_map_address( mapping->fd ))) return ret;"""
if text.count(anchor) != 1:
    sys.exit("0002: anchor not found exactly once")

text = text.replace(anchor, """    if (!(mapping->image.image_charact & IMAGE_FILE_DLL)) return 0;

    /* gologin-lab: stable image base. Returning 0 leaves the image at the base in
     * its PE header, identical in every process and every workspace, so the
     * aligned image cache (ntdll) is one file shared through the page cache
     * instead of one copy per workspace. */
    {
        static int stable = -1;
        if (stable < 0)
        {
            const char *env = getenv( "WINE_STABLE_IMAGE_BASE" );
            stable = (env && env[0] == '1');
        }
        if (stable) return 0;
    }

    if ((ret = get_fd_map_address( mapping->fd ))) return ret;""")

src.write_text(text)
print("0002 applied to", src)
