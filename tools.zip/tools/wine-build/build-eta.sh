#!/bin/bash
# Build ETA: objects done vs objects expected (one per .c/.rc/.idl/.S/.l/.y source
# that make will compile), and the rate over the last 60 s.
B=/root/build; SRC=$B/wine-11.18
total=$(find $SRC/dlls $SRC/programs $SRC/libs $SRC/loader $SRC/server $SRC/tools \
          \( -name '*.c' -o -name '*.rc' -o -name '*.S' -o -name '*.l' -o -name '*.y' \) 2>/dev/null \
        | grep -vE '/tests/' | wc -l)
n1=$(find $B/obj64 -name '*.o' 2>/dev/null | wc -l); sleep 60
n2=$(find $B/obj64 -name '*.o' 2>/dev/null | wc -l)
rate=$((n2 - n1))
left=$((total - n2)); [ $left -lt 0 ] && left=0
echo "objects: $n2 / ~$total   rate: $rate per min"
[ $rate -gt 0 ] && echo "ETA: ~$((left / rate)) min for compiling, then linking/install ~5-10 min"
pgrep -f build-wine.sh >/dev/null && echo "build: running" || echo "build: NOT running"
free -m | awk 'NR==2{printf "mem used %s/%s MB\n", $3, $2}'
