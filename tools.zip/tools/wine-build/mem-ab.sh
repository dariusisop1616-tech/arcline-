#!/bin/bash
# RAM A/B/C for one workspace on our Wine build, same page each time.
#   A: image cache off, KSM off  (= stock behaviour)
#   B: image cache on,  KSM off  (patch 0001 alone)
#   C: image cache on,  KSM on   (both)
# Metric: system RAM used after settling, minus RAM used with the workspace stopped.
N="${1:-ws1}"; SETTLE=${SETTLE:-90}
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
T=/root/workspaces/$N/wine-ours
used() { free -m | awk 'NR==2{print $3}'; }
run() {  # label cache ksm
  bash "$REPO/tools/relay/ws-stop.sh" $N >/dev/null 2>&1; sleep 3
  sync; echo 3 > /proc/sys/vm/drop_caches; sleep 1
  local base=$(used)
  WINE_TREE=$T WINE_IMAGE_CACHE=$2 KSM_MERGE=$3 bash "$REPO/tools/relay/ws-start.sh" $N >/dev/null 2>&1
  sleep $SETTLE
  [ "$3" = 1 ] && sleep 60     # KSM at the gentle rate needs time to converge
  local u=$(used)
  local win=$(DISPLAY=:9 wmctrl -l 2>/dev/null | grep -ci edge)
  local pc=$(free -m | awk 'NR==2{print $6}')
  printf '  %-26s +%5d MB   (edge window: %s)\n' "$1" $((u - base)) "$win"
}
echo "[$N on $(basename $T), settle ${SETTLE}s]"
run "A  cache off, KSM off" 0 0
run "B  cache ON,  KSM off" 1 0
run "C  cache ON,  KSM ON " 1 1
echo "image cache files:"; ls -la /var/tmp/wine-image-cache/ 2>/dev/null | tail -n +2 | awk '{printf "  %s %6.0f MB\n", $9, $5/1048576}'
