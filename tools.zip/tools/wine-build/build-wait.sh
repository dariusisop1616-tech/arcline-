#!/bin/bash
# Block until a build stage log exists (or the build stopped), then print status.
#   build-wait.sh configure|make|install [max_minutes]
STAGE="${1:-configure}"; MAX="${2:-25}"; L=/root/build/logs
for i in $(seq 1 $((MAX * 4))); do
  [ -f "$L/$STAGE.log" ] && break
  pgrep -f build-wine.sh >/dev/null || break
  sleep 15
done
bash "/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/wine-build/build-status.sh"
