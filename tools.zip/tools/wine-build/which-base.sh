#!/bin/bash
# Which Edge process mapped msedge.dll from which cache file (= at which base)?
# /proc/<pid>/maps names the backing file of every mapping.
N="${1:-ws1}"; R=/root/workspaces/$N
for p in $(pgrep -f msedge); do
  grep -qz "WINEPREFIX=$R/prefix" /proc/$p/environ 2>/dev/null || continue
  t=$(tr '\0' ' ' < /proc/$p/cmdline | grep -oE -- '--type=[a-z-]+' | head -1 | cut -d= -f2)
  f=$(grep -oE 'wine-image-cache/[^ ]+14d76548[^ ]+\.img' /proc/$p/maps | sort -u | sed 's#.*/##' | tr '\n' ' ')
  printf '  pid %-6s %-14s %s\n' $p "${t:-browser}" "${f:-(no msedge.dll cache mapping)}"
done
