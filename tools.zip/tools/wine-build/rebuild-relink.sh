#!/bin/bash
# Apply patches, rebuild, install, then re-link EVERY workspace tree and verify
# each one really carries the new build (the earlier run silently kept an old tree).
set -u
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
for n in ws1 ws2 ws3; do bash "$REPO/tools/relay/ws-stop.sh" $n >/dev/null 2>&1; done
sleep 2
bash "$REPO/tools/wine-build/apply-patches.sh" || exit 1
rm -f /var/tmp/wine-image-cache/*.img
for n in ws1 ws2 ws3; do
  [ -d /root/workspaces/$n ] || continue
  out=$(bash "$REPO/tools/wine-build/ws-use-ours.sh" $n 2>&1) || { echo "$out"; exit 1; }
  echo "  $n: $(ls -l --time-style=+%H:%M /root/workspaces/$n/wine-ours/bin/wineserver | awk '{print $6}') knob=$(strings /root/workspaces/$n/wine-ours/bin/wineserver | grep -c WINE_STABLE_IMAGE_BASE)"
done
