#!/bin/bash
# Did patch 0002 reach the running wineserver, and does it see the env var?
echo "installed wineserver has the knob : $(strings /opt/wine-ours/bin/wineserver | grep -c WINE_STABLE_IMAGE_BASE)"
echo "ws1 tree wineserver has the knob  : $(strings /root/workspaces/ws1/wine-ours/bin/wineserver | grep -c WINE_STABLE_IMAGE_BASE)"
ls -l --time-style=+%H:%M /opt/wine-ours/bin/wineserver /root/workspaces/ws1/wine-ours/bin/wineserver | sed 's/^/  /'
echo "running wineservers:"
for p in $(pgrep -x wineserver); do
  echo "  pid $p  exe=$(readlink /proc/$p/exe)  env=$(tr '\0' '\n' < /proc/$p/environ | grep WINE_STABLE_IMAGE_BASE)"
done
echo "msedge.dll preferred base from its PE header:"
python3 - <<'EOF'
import struct
p = "/root/workspaces/ws1/prefix/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.dll"
b = open(p, "rb").read(4096)
pe = struct.unpack_from("<I", b, 0x3C)[0]; opt = pe + 24
magic = struct.unpack_from("<H", b, opt)[0]
base = struct.unpack_from("<Q", b, opt + 24)[0] if magic == 0x20b else struct.unpack_from("<I", b, opt + 28)[0]
dllchar = struct.unpack_from("<H", b, opt + 70)[0]
print(f"  ImageBase 0x{base:x}   DllCharacteristics 0x{dllchar:04x}   DYNAMIC_BASE={'yes' if dllchar & 0x40 else 'no'}")
EOF
