#!/bin/bash
# What does the SECOND workspace cost? Start ws1, measure; start ws2, measure the
# delta. If Edge's 335 MB image is shared across workspaces, the second costs much
# less than the first; if each workspace caches its own copy at its own base, it
# costs the same. Also prints which cache file each workspace's processes mapped.
set -u
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
SETTLE=${SETTLE:-100}
used() { free -m | awk 'NR==2{print $3}'; }
cache_of() { # which msedge.dll cache file the workspace's processes mapped
  local R=/root/workspaces/$1
  for p in $(pgrep -f msedge); do
    grep -qz "WINEPREFIX=$R/prefix" /proc/$p/environ 2>/dev/null || continue
    grep -oE 'wine-image-cache/[^ ]+\.img' /proc/$p/maps 2>/dev/null | sed 's#.*/##'
  done | sort -u | awk '{printf "%s ", $0}'
}
for n in ws1 ws2 ws3; do bash "$REPO/tools/relay/ws-stop.sh" $n >/dev/null 2>&1; done
sleep 3; sync; echo 3 > /proc/sys/vm/drop_caches; sleep 2
base=$(used); echo "baseline (no workspace): $base MB"

for n in ws1 ws2; do
  before=$(used)
  WINE_TREE=/root/workspaces/$n/wine-ours bash "$REPO/tools/relay/ws-start.sh" $n >/dev/null 2>&1
  for i in $(seq 1 40); do
    DISPLAY=$(grep -oP 'DISP=\K[0-9]+' /root/workspaces/$n/ws.conf) \
      bash -c 'DISPLAY=:'"$(grep -oP 'DISP=\K[0-9]+' /root/workspaces/$n/ws.conf)"' wmctrl -l 2>/dev/null | grep -qi edge' && break
    sleep 3
  done
  sleep $SETTLE
  after=$(used)
  printf '%s: +%d MB   (total %d MB)   cache: %s\n' "$n" $((after - before)) $((after - base)) "$(cache_of $n)"
done

echo
echo "image cache files on disk:"
ls -la /var/tmp/wine-image-cache/*.img 2>/dev/null | awk '{printf "  %6.0f MB  %s\n", $5/1048576, $9}' | sed 's#/var/tmp/wine-image-cache/##'
echo "page cache holding them: $(free -m | awk 'NR==2{print $6}') MB buff/cache"
echo "KSM: $(( $(cat /sys/kernel/mm/ksm/pages_sharing) * 4 / 1024 )) MB dedup, $(( $(cat /sys/kernel/mm/ksm/ksm_zero_pages) * 4 / 1024 )) MB zero"
