#!/bin/bash
# Apply our patches to the Wine source, rebuild incrementally (only what changed),
# install to /opt/wine-ours. Low-RAM mode as for the full build.
set -u
B=/root/build; SRC=$B/wine-11.18; OBJ=$B/obj64; LOG=$B/logs
P="/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/wine-build/patches"
for p in "$P"/0*.py; do python3 "$p" "$SRC" || exit 1; done
cd "$OBJ"
s=$(date +%s)
nice -n 15 make -j2 >"$LOG/make-patch.log" 2>&1
rc=$?; echo "make exit=$rc after $(( $(date +%s) - s )) s"
if [ $rc != 0 ]; then grep -E "error|Error" "$LOG/make-patch.log" | head -20; exit 1; fi
grep -E "warning:" "$LOG/make-patch.log" | grep -i virtual.c | head -5
nice -n 15 make install >"$LOG/install-patch.log" 2>&1; echo "install exit=$?"
grep -c "gologin-lab: aligned image cache" "$SRC/dlls/ntdll/unix/virtual.c" | sed 's/^/patch markers in source: /'
strings /opt/wine-ours/lib/wine/x86_64-unix/ntdll.so | grep -c "wine-image-cache" | sed 's/^/cache path in installed ntdll.so: /'
