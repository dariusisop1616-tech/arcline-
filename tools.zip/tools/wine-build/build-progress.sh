#!/bin/bash
# Real progress: finished DLL/EXE modules vs modules the build will produce.
B=/root/build; O=$B/obj64
total=$(ls -d $O/dlls/*/ $O/programs/*/ 2>/dev/null | while read d; do [ -f "$d/Makefile" ] || [ -f "$O/Makefile" ] && echo "$d"; done | wc -l)
done_=$(find $O/dlls $O/programs -maxdepth 3 \( -name '*.dll' -o -name '*.exe' -o -name '*.drv' -o -name '*.sys' -o -name '*.ocx' -o -name '*.cpl' -o -name '*.acm' -o -name '*.ax' -o -name '*.tlb' -o -name '*.ds' \) -path '*x86_64-windows*' 2>/dev/null | wc -l)
dirs=$(ls -d $O/dlls/*/ $O/programs/*/ 2>/dev/null | wc -l)
echo "modules linked: $done_ of ~$dirs module dirs ($(( done_ * 100 / (dirs > 0 ? dirs : 1) ))%)"
echo "objects: $(find $O -name '*.o' | wc -l)   running: $(pgrep -f build-wine.sh >/dev/null && echo yes || echo no)"
