#!/bin/bash
# Compile + install only (deps/source/configure already done).
S="/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/wine-build/build-wine.sh"
bash "$S" make && bash "$S" install
