#!/bin/bash
# Full fingerprint probe in a workspace, diffed against native windows.txt.
#   WINE_TREE=/root/workspaces/ws1/wine-ours ws-probe.sh ws1 <label>
N="${1:-ws1}"; LABEL="${2:-probe}"
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
FP=/root/fp; PORT=47800; R=/root/workspaces/$N
mkdir -p /root/linuxlab /root/winelab/out
cp -f "$REPO/tools/fingerprint-probe.html" /root/linuxlab/fp.html
pgrep -f collect.py >/dev/null || ( setsid nohup python3 "$REPO/tools/relay/collect.py" "$FP" "$PORT" \
  /root/linuxlab/fp.html >/root/winelab/out/collect.log 2>&1 & )
sleep 2
bash "$REPO/tools/relay/ws-stop.sh" $N >/dev/null 2>&1
rm -f "$FP/$LABEL.txt"
URL_OVERRIDE="http://127.0.0.1:$PORT/probe?post=/?as=$LABEL" bash "$REPO/tools/relay/ws-start.sh" $N
for i in $(seq 1 45); do [ -s "$FP/$LABEL.txt" ] && break; sleep 4; done
echo "--- which Wine is running this workspace ---"
for p in $(pgrep -x wineserver); do
  grep -qz "WINEPREFIX=$R/prefix" /proc/$p/environ 2>/dev/null && echo "  wineserver: $(readlink /proc/$p/exe)"
done
[ -s "$FP/$LABEL.txt" ] || { echo "NO CAPTURE"; tail -5 $R/logs/edge.log | cut -c1-160; exit 1; }
python3 - "$FP/windows.txt" "$FP/$LABEL.txt" <<'EOF'
import sys
def load(p):
    d = {}
    for line in open(p, encoding='utf-8', errors='replace'):
        if line.startswith('---') or ':' not in line: continue
        k, v = line.split(':', 1); d[k.strip()] = v.strip()
    return d
w, l = load(sys.argv[1]), load(sys.argv[2])
keys = list(dict.fromkeys(list(w) + list(l)))
diff = [k for k in keys if w.get(k, '<absent>') != l.get(k, '<absent>')]
print(f"identical: {len(keys) - len(diff)}   different: {len(diff)}")
for k in diff:
    print(f"  {k}\n     windows: {w.get(k,'<absent>')[:130]}\n     wine   : {l.get(k,'<absent>')[:130]}")
EOF
