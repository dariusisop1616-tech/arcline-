#!/bin/bash
# Build our own Wine: the exact version we run today (11.18 + wine-staging 11.18),
# so the validated 63/63 fingerprint baseline carries over, then our patches on top.
#
# LOW-RAM MODE (host has 12 GB, WSL 6 GB): 2 compile jobs, no debug info (-g0),
# x86_64 only, low CPU priority. Installs to /opt/wine-ours; /opt/wine-staging is
# left untouched so we can always compare against the stock build.
#
#   build-wine.sh deps | source | configure | make | install | all
set -u
VER=11.18
B=/root/build
SRC=$B/wine-$VER
STG=$B/wine-staging-$VER
OBJ=$B/obj64
DEST=/opt/wine-ours
JOBS=${JOBS:-2}
LOG=$B/logs; mkdir -p "$LOG"
step() { echo "[$(date +%H:%M:%S)] $*"; }

deps() {
  step "installing build dependencies (no recommends, to save disk)"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq --no-install-recommends \
    build-essential flex bison gettext pkg-config python3 git ca-certificates wget xz-utils \
    autoconf automake perl \
    mingw-w64 \
    libx11-dev libxext-dev libxrandr-dev libxinerama-dev libxcursor-dev libxi-dev \
    libxcomposite-dev libxfixes-dev libxrender-dev libxxf86vm-dev libxkbcommon-dev \
    libwayland-dev libfreetype-dev libfontconfig-dev libgnutls28-dev \
    libpulse-dev libasound2-dev libvulkan-dev libgl-dev libegl-dev \
    libdbus-1-dev libudev-dev libusb-1.0-0-dev libunwind-dev \
    libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev libsdl2-dev \
    libcups2-dev libkrb5-dev libv4l-dev libpcap-dev libosmesa6-dev \
    libavcodec-dev libavformat-dev libavutil-dev libswscale-dev libswresample-dev \
    wayland-protocols libxkbregistry-dev libegl1-mesa-dev \
    ocl-icd-opencl-dev opencl-headers libpcsclite-dev libsane-dev libgphoto2-dev \
    samba-dev unixodbc-dev \
    >"$LOG/deps.log" 2>&1
  step "deps exit=$? (log $LOG/deps.log)"
  command -v x86_64-w64-mingw32-gcc >/dev/null && step "mingw ok: $(x86_64-w64-mingw32-gcc --version | head -1)"
}

source_() {
  mkdir -p "$B"; cd "$B"
  [ -d "$SRC" ] || { step "downloading wine $VER"
    wget -q "https://dl.winehq.org/wine/source/11.x/wine-$VER.tar.xz" -O wine.tar.xz && tar xf wine.tar.xz && rm wine.tar.xz; }
  [ -d "$STG" ] || { step "downloading wine-staging $VER"
    wget -q "https://github.com/wine-staging/wine-staging/archive/refs/tags/v$VER.tar.gz" -O stg.tgz && tar xzf stg.tgz && rm stg.tgz; }
  if [ ! -f "$SRC/.staging-applied" ]; then
    step "applying wine-staging patches (all, as the WineHQ staging package does)"
    cd "$SRC"
    if [ ! -d .git ]; then
      git init -q && git -c user.email=b@local -c user.name=build add -A >/dev/null \
        && git -c user.email=b@local -c user.name=build commit -qm "wine-$VER" >/dev/null
    fi
    # always start from the pristine tree, so a failed earlier attempt leaves nothing half-applied
    git reset -q --hard && git clean -qfdx
    python3 "$STG/staging/patchinstall.py" DESTDIR="$SRC" --all >"$LOG/staging.log" 2>&1
    rc=$?; step "staging exit=$rc (log $LOG/staging.log)"
    [ $rc = 0 ] && touch .staging-applied || { tail -20 "$LOG/staging.log"; exit 1; }
  fi
}

configure_() {
  # Target: the same unix-module set as the stock /opt/wine-staging build (checked
  # after install). A previous configure without those libs must not be reused.
  rm -rf "$OBJ"
  mkdir -p "$OBJ"; cd "$OBJ"
  step "configure (x86_64 only, -O2 -g0)"
  CFLAGS="-O2 -g0" CROSSCFLAGS="-O2 -g0" \
    "$SRC/configure" --prefix="$DEST" --enable-archs=x86_64 --disable-tests \
    >"$LOG/configure.log" 2>&1
  rc=$?; step "configure exit=$rc"
  echo "--- features configure could not enable ---"
  sed -n '/configure: libraries are not found/,$p;/configure: WARNING/p' "$LOG/configure.log" | head -30
  return $rc
}

make_() {
  cd "$OBJ"
  step "make -j$JOBS at low priority (log $LOG/make.log)"
  s=$(date +%s)
  nice -n 15 make -j"$JOBS" >"$LOG/make.log" 2>&1
  rc=$?; step "make exit=$rc after $(( ($(date +%s) - s) / 60 )) min"
  [ $rc = 0 ] || tail -25 "$LOG/make.log"
  return $rc
}

install_() {
  cd "$OBJ"
  step "install -> $DEST"
  nice -n 15 make install >"$LOG/install.log" 2>&1; step "install exit=$?"
  echo "version: $($DEST/bin/wine --version 2>/dev/null)"
  echo "--- unix modules: stock vs ours (anything only in stock = a missing feature) ---"
  diff <(ls /opt/wine-staging/lib/wine/x86_64-unix/ | sort) <(ls $DEST/lib/wine/x86_64-unix/ | sort) \
    && echo "  identical module set"
}

case "${1:-all}" in
  deps) deps ;; source) source_ ;; configure) configure_ ;; make) make_ ;; install) install_ ;;
  all) deps && source_ && configure_ && make_ && install_ ;;
esac
