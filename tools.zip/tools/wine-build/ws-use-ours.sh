#!/bin/bash
# Give a workspace a hard-linked tree of OUR Wine build (/opt/wine-ours), with its
# own wined3d.dll carrying the workspace's GPU name, like the stock trees.
#   ws-use-ours.sh ws1 ["<table name>" "<new name>"]
N="$1"; FROM="${2:-}"; TO="${3:-}"
R=/root/workspaces/$N
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
# The GPU name lives in ws.conf, so a rebuild/relink can never silently lose it
# (it did once: the tree was re-linked from stock and the rename disappeared).
source "$R/ws.conf"
[ -z "$FROM" ] && FROM="${GPU_NAME_FROM:-}"
[ -z "$TO" ]   && TO="${GPU_NAME_TO:-}"
if [ -n "$2" ]; then
  # quote: card names contain parentheses, which break `source`
  sed -i '/^GPU_NAME_/d' "$R/ws.conf"
  printf 'GPU_NAME_FROM=%q\nGPU_NAME_TO=%q\n' "$2" "$3" >> "$R/ws.conf"
fi
# Always re-link: `make install` replaces files with new inodes, so an old
# hard-linked tree would silently keep running the previous build. Stop that
# workspace's wineserver first - a running one holds the old tree open.
WINEPREFIX="$R/prefix" "$R/wine-ours/bin/wineserver" -k 2>/dev/null
sleep 1
rm -rf "$R/wine-ours" && cp -al /opt/wine-ours "$R/wine-ours"
# fail loudly if the tree is not the freshly installed one
if ! cmp -s /opt/wine-ours/bin/wineserver "$R/wine-ours/bin/wineserver"; then
  echo "ERROR: $N wine tree does not match /opt/wine-ours"; exit 1
fi
F="$R/wine-ours/lib/wine/x86_64-windows/wined3d.dll"
rm -f "$F" && cp /opt/wine-ours/lib/wine/x86_64-windows/wined3d.dll "$F"   # own real file
if [ -n "$FROM" ]; then
  python3 "$REPO/tools/relay/set_gpu_name.py" "$F" "$FROM" "$TO" && rm -f "$F.orig"
fi
# A different build has a different wine.inf timestamp, which would trigger
# `wineboot -u` on first start - that hangs in this lab. Pin the prefix instead.
echo disable > "$R/prefix/.update-timestamp"
echo "$N -> $R/wine-ours ($($R/wine-ours/bin/wine --version))"
