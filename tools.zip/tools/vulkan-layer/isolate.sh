#!/bin/bash
# The gdb stack shows two nested loader vkCreateInstance frames deadlocking on a mutex
# inside libvulkan.so.1, with our layer absent from the stack entirely. So: does ANY
# explicit layer deadlock here, or only ours? Three isolations.
DIR=/root/vklayer
SRC="/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/vulkan-layer"
cd "$DIR" || exit 1

cp "$SRC/stub_layer.c" "$DIR/"
gcc -shared -fPIC -O2 -o "$DIR/libstub.so" "$DIR/stub_layer.c" || exit 1

cat > "$DIR/VK_LAYER_FAKE_stub.json" <<'EOF'
{"file_format_version":"1.1.2","layer":{"name":"VK_LAYER_FAKE_stub","type":"GLOBAL",
 "library_path":"/root/vklayer/libstub.so","api_version":"1.4.0","implementation_version":"1",
 "description":"trivial stub layer for loader isolation",
 "functions":{"vkGetInstanceProcAddr":"vkGetInstanceProcAddr"},
 "instance_extensions":[],"device_extensions":[]}}
EOF

export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json
echo "ICD: lvp (llvmpipe)"
echo

run() {  # run <label> <env...>
  local label="$1"; shift
  local out
  out=$(env "$@" timeout 6 ./vulkan_probe 2>&1 | grep -E 'deviceName' | head -1)
  local rc=$?
  printf '%-58s -> %s\n' "$label" "${out:-<no output / hung>}"
}

echo "=== [T1] is the ICD itself fine? ==="
run "no layer at all"                      VK_LAYER_PATH=/nonexistent

echo
echo "=== [T2] a trivial stub layer of ours ==="
run "stub layer via VK_LAYER_PATH + VK_INSTANCE_LAYERS" \
    VK_LAYER_PATH="$DIR" VK_INSTANCE_LAYERS=VK_LAYER_FAKE_stub
run "stub layer, implicit device_select removed" \
    VK_LAYER_PATH="$DIR" VK_INSTANCE_LAYERS=VK_LAYER_FAKE_stub NODEVICE_SELECT=1

echo
echo "=== [T3] a known-good system implicit layer, enabled explicitly ==="
run "system layer MESA_anti_lag enabled explicitly" \
    VK_INSTANCE_LAYERS=VK_LAYER_MESA_anti_lag
run "system layer MESA_device_select enabled explicitly" \
    VK_INSTANCE_LAYERS=VK_LAYER_MESA_device_select

echo
echo "=== [T4] our real layer, but manifest file_format_version 1.0.0 ==="
sed 's/"file_format_version":"1.1.2"/"file_format_version":"1.0.0"/' \
    "$SRC/VK_LAYER_FAKE_rx580.json" > "$DIR/VK_LAYER_rx580_v1.json"
sed -i 's/VK_LAYER_FAKE_rx580/VK_LAYER_rx580_v1/g' "$DIR/VK_LAYER_rx580_v1.json"
run "real layer, 1.0.0 manifest" \
    VK_LAYER_PATH="$DIR" VK_INSTANCE_LAYERS=VK_LAYER_rx580_v1 NODEVICE_SELECT=1
