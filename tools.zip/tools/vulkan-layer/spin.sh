#!/bin/bash
# The loader hangs after our negotiate returns OK, before ever calling GIPA again.
# Determine whether it is spinning in userland or blocked, and get the syscall / stack.
DIR=/root/vklayer
cd "$DIR" || exit 1
export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json
export VK_LAYER_PATH="$DIR"
export VK_INSTANCE_LAYERS=VK_LAYER_FAKE_rx580
export RX580_LOG=1
NODEVICE_SELECT=1

echo "tools: strace=$(command -v strace || echo no) gdb=$(command -v gdb || echo no)"
echo

rm -f /tmp/rx580.log
NODEVICE_SELECT=1 ./vulkan_probe >/tmp/probe.out 2>&1 &
P=$!
sleep 3

echo "=== is it alive? ==="
if [ -d "/proc/$P" ]; then
  echo "alive, pid=$P"
  grep -E '^(State|Threads)' /proc/$P/status
  echo "wchan      : $(cat /proc/$P/wchan 2>/dev/null)"
  echo "syscall    : $(cat /proc/$P/syscall 2>/dev/null)"
  echo "utime,stime: $(awk '{print $14, $15}' /proc/$P/stat)"
  sleep 2
  echo "utime,stime after 2s: $(awk '{print $14, $15}' /proc/$P/stat)   (big jump = spinning)"
  echo "--- kernel stack ---"
  cat /proc/$P/stack 2>/dev/null | head -12
  echo "--- threads ---"
  ls /proc/$P/task 2>/dev/null | tr '\n' ' '; echo
  kill -9 $P 2>/dev/null
else
  echo "process already gone"
fi

echo
echo "=== probe stdout/stderr so far ==="
cat /tmp/probe.out
echo
echo "=== layer trace ==="
cat /tmp/rx580.log 2>/dev/null

echo
echo "=== strace of the hang (last 30 syscalls) ==="
if command -v strace >/dev/null; then
  rm -f /tmp/rx580.log
  NODEVICE_SELECT=1 timeout 6 strace -f -o /tmp/probe.strace ./vulkan_probe >/dev/null 2>&1
  echo "exit: $?"
  tail -30 /tmp/probe.strace
else
  echo "(strace not installed)"
fi
