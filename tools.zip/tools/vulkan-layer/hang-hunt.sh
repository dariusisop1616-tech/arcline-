#!/bin/bash
# Decisive diagnostic: the probe hangs with the layer enabled but our vkCreateInstance
# is never entered. Two questions to settle:
#   (a) does the loader call our vkGetInstanceProcAddr at all?  -> GIPA trace answers it
#   (b) is the implicit MESA_device_select layer, not us, the thing that hangs?
#       -> run again with NODEVICE_SELECT=1 to take it out of the chain
SRC="/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/vulkan-layer"
DIR=/root/vklayer
cp "$SRC/rx580_layer.c" "$DIR/"
gcc -shared -fPIC -O2 -g -o "$DIR/librx580.so" "$DIR/rx580_layer.c" -ldl || exit 1
echo "built librx580.so $(stat -c%s "$DIR/librx580.so") bytes"
echo

export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json
export VK_LAYER_PATH="$DIR"
export VK_INSTANCE_LAYERS=VK_LAYER_FAKE_rx580
export RX580_LOG=1
cd "$DIR" || exit 1

echo "=== [A] layer enabled, default chain (implicit device_select present) ==="
rm -f /tmp/rx580.log
timeout 8 ./vulkan_probe 2>&1 | tail -5
echo "exit: ${PIPESTATUS[0]}"
echo "--- GIPA trace (first 25) ---"
head -25 /tmp/rx580.log 2>/dev/null || echo "(loader never called us)"
echo

echo "=== [B] layer enabled, implicit device_select REMOVED (NODEVICE_SELECT=1) ==="
rm -f /tmp/rx580.log
NODEVICE_SELECT=1 timeout 8 ./vulkan_probe 2>&1 | grep -E 'deviceName|vendorID|deviceID|deviceType|driverName|driverInfo'
echo "exit: ${PIPESTATUS[0]}"
echo "--- GIPA trace (first 25) ---"
head -25 /tmp/rx580.log 2>/dev/null || echo "(loader never called us)"
echo

echo "=== [C] callstack as the loader sees it, device_select removed ==="
rm -f /tmp/rx580.log
NODEVICE_SELECT=1 VK_LOADER_DEBUG=layer timeout 8 ./vulkan_probe 2>&1 \
  | grep -iE 'callstack|rx580|FAKE|Drivers|Application|Loader|MESA' | head -12
