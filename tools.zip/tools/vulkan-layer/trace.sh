#!/bin/bash
# Rebuild with tracing and find the exact hang point.
SRC="/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/vulkan-layer"
DIR=/root/vklayer
cp "$SRC/rx580_layer.c" "$DIR/"
gcc -shared -fPIC -O2 -o "$DIR/librx580.so" "$DIR/rx580_layer.c" -ldl || exit 1
echo "built."

rm -f /tmp/rx580.log
cd "$DIR" || exit 1
export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json
export VK_LAYER_PATH="$DIR"
export VK_INSTANCE_LAYERS=VK_LAYER_FAKE_rx580
export RX580_LOG=1

echo "=== probe, 10s timeout ==="
timeout 10 ./vulkan_probe
echo "exit code: $?"

echo
echo "=== layer trace ==="
cat /tmp/rx580.log 2>/dev/null || echo "(no trace - layer not entered at all)"
