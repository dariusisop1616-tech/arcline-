// Verifies the layer independently of any browser: asks Vulkan directly what the
// device is, exactly the way ANGLE does before it builds the WebGL renderer string.
#include <stdio.h>
#include <vulkan/vulkan.h>

int main(void)
{
    VkApplicationInfo app = {0};
    app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app.apiVersion = VK_API_VERSION_1_1;

    VkInstanceCreateInfo ci = {0};
    ci.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    ci.pApplicationInfo = &app;

    VkInstance inst;
    VkResult r = vkCreateInstance(&ci, NULL, &inst);
    if (r != VK_SUCCESS) { printf("vkCreateInstance failed: %d\n", r); return 1; }

    uint32_t n = 0;
    vkEnumeratePhysicalDevices(inst, &n, NULL);
    printf("physical devices: %u\n", n);
    if (n == 0) return 1;
    if (n > 8) n = 8;
    VkPhysicalDevice devs[8];
    vkEnumeratePhysicalDevices(inst, &n, devs);

    for (uint32_t i = 0; i < n; i++) {
        printf("--- device %u ---\n", i);

        VkPhysicalDeviceProperties p;
        vkGetPhysicalDeviceProperties(devs[i], &p);
        printf("  deviceName      : %s\n", p.deviceName);
        printf("  vendorID        : 0x%04x\n", p.vendorID);
        printf("  deviceID        : 0x%04x\n", p.deviceID);
        printf("  deviceType      : %d  (2 = DISCRETE_GPU)\n", p.deviceType);
        printf("  apiVersion      : %u.%u.%u\n",
               VK_VERSION_MAJOR(p.apiVersion), VK_VERSION_MINOR(p.apiVersion),
               VK_VERSION_PATCH(p.apiVersion));
        printf("  maxImageDim2D   : %u   <- becomes WebGL MAX_TEXTURE_SIZE\n",
               p.limits.maxImageDimension2D);
        printf("  maxImageDimCube : %u\n", p.limits.maxImageDimensionCube);
        printf("  maxVertexAttrib : %u\n", p.limits.maxVertexInputAttributes);
        printf("  maxColorAttach  : %u\n", p.limits.maxColorAttachments);

        VkPhysicalDeviceDriverProperties dp = {0};
        dp.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DRIVER_PROPERTIES;
        VkPhysicalDeviceProperties2 p2 = {0};
        p2.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2;
        p2.pNext = &dp;
        vkGetPhysicalDeviceProperties2(devs[i], &p2);
        printf("  [via Properties2]\n");
        printf("    deviceName    : %s\n", p2.properties.deviceName);
        printf("    vendorID      : 0x%04x\n", p2.properties.vendorID);
        printf("    deviceID      : 0x%04x\n", p2.properties.deviceID);
        printf("    driverName    : %s\n", dp.driverName);
        printf("    driverInfo    : %s\n", dp.driverInfo);
    }
    return 0;
}
