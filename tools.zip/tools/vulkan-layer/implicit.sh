#!/bin/bash
# Conclusion from isolate.sh: a layer that does NOTHING still hangs the loader when
# activated via VK_LAYER_PATH + VK_INSTANCE_LAYERS. But implicit layers work fine on this
# system (MESA_device_select is one, and it is in the working baseline chain). So activate
# ours implicitly instead.
#
# Two keys matter for an implicit layer:
#   disable_environment  - REQUIRED by the loader; omitting it makes the loader skip the
#                          layer entirely ("doesn't contain required layer object
#                          disable_environment"), which is what defeated the first attempt
#   enable_environment   - makes it activate only when the env var is set, so it stays
#                          per-profile / per-launch instead of machine-wide
DIR=/root/vklayer
SRC="/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/vulkan-layer"
IMP=/usr/share/vulkan/implicit_layer.d
rm -f "$IMP/VK_LAYER_FAKE_rx580.json"

cp "$SRC/rx580_layer.c" "$DIR/"
gcc -shared -fPIC -O2 -o "$DIR/librx580.so" "$DIR/rx580_layer.c" || exit 1
echo "built librx580.so $(stat -c%s "$DIR/librx580.so") bytes"

cat > "$IMP/VK_LAYER_FAKE_rx580.json" <<'EOF'
{"file_format_version":"1.1.2",
 "layer":{
   "name":"VK_LAYER_FAKE_rx580","type":"GLOBAL",
   "library_path":"/root/vklayer/librx580.so",
   "api_version":"1.4.0","implementation_version":"1",
   "description":"Reports an AMD Radeon RX 580 (Polaris 10) instead of the real device",
   "functions":{
     "vkGetInstanceProcAddr":"vkGetInstanceProcAddr",
     "vkGetDeviceProcAddr":"vkGetDeviceProcAddr",
     "vkCreateInstance":"vkCreateInstance",
     "vkCreateDevice":"vkCreateDevice"},
   "instance_extensions":[],"device_extensions":[],
   "disable_environment":{"RX580_DISABLE":"1"},
   "enable_environment":{"RX580":"1"}}}
EOF
echo "installed implicit manifest"
echo

export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json
cd "$DIR" || exit 1

# NOTE: no VK_LAYER_PATH / VK_INSTANCE_LAYERS this time - that path deadlocks.
echo "=== [1] RX580 unset -> layer must stay off (ground truth) ==="
env -u RX580 -u RX580_DISABLE timeout 8 ./vulkan_probe 2>&1 \
  | grep -E 'deviceName|vendorID|deviceID|deviceType|driverName' | head -6
echo "exit: ${PIPESTATUS[0]}"
echo

echo "=== [2] RX580=1 -> layer active, must report the RX 580 ==="
rm -f /tmp/rx580.log
RX580=1 RX580_LOG=1 timeout 8 ./vulkan_probe 2>&1 \
  | grep -E 'deviceName|vendorID|deviceID|deviceType|driverName|driverInfo' | head -8
echo "exit: ${PIPESTATUS[0]}"
echo

echo "=== [3] did the loader insert it? ==="
RX580=1 VK_LOADER_DEBUG=layer timeout 8 ./vulkan_probe 2>&1 \
  | grep -iE 'rx580|FAKE' | head -8

echo
echo "=== [4] layer trace ==="
cat /tmp/rx580.log 2>/dev/null | head -20 || echo "(none)"
