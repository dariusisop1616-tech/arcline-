#!/bin/bash
# Build the RX580 ICD wrapper and prove it standalone before involving Edge:
# the probe must enumerate exactly one device reporting the RX 580 identity.
set -e
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
D=/root/vkicd
mkdir -p "$D"

echo "== build wrapper =="
gcc -shared -fPIC -O2 -o "$D/librx580_icd.so" "$REPO/tools/vulkan-layer/rx580_icd.c" -ldl
echo "  built $D/librx580_icd.so"

cat > "$D/rx580_icd.json" <<'EOF'
{
    "ICD": {
        "api_version": "1.4.335",
        "library_path": "/root/vkicd/librx580_icd.so"
    },
    "file_format_version": "1.0.1"
}
EOF
echo "  wrote $D/rx580_icd.json"

echo "== build standalone probe =="
gcc -O2 -o "$D/probe" "$REPO/tools/vulkan-layer/vulkan_probe.c" -lvulkan
echo "  built probe"

echo "== run probe through the wrapper =="
rm -f /tmp/rx580_icd.log
RX580_LOG=1 VK_DRIVER_FILES="$D/rx580_icd.json" "$D/probe" 2>&1 | head -30
echo
echo "== wrapper log =="
cat /tmp/rx580_icd.log 2>/dev/null || echo "  (no log - nothing intercepted?)"