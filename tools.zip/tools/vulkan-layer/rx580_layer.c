// A Vulkan interposition layer that reports an AMD Radeon RX 580 (Polaris 10).
//
// Why a layer and not a patch: the WebGL renderer string is assembled by ANGLE from
// what the Vulkan driver answers. lavapipe builds its device name at runtime from a
// printf format, so patching one string would leave the vendor, the device id and the
// driver name still saying Mesa/llvmpipe - an inconsistent fake, which is easier to
// flag than the real thing. A layer is the sanctioned place to answer those queries,
// it sits BELOW the browser, and the browser stays completely untouched.
//
// It intercepts only the property queries. Everything else passes straight through to
// the real driver below, so rendering still happens on lavapipe.
//
//   ANGLE turns this into:
//     ANGLE (AMD, Vulkan <api> (<deviceName> (<0xdeviceID>)), <driverName>)
//
#define _GNU_SOURCE
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <vulkan/vulkan.h>
#include <vulkan/vk_layer.h>

// ------------------------------------------------------------------ what we claim
// Values taken from a real RX 580 (Polaris 10) on Mesa radv.
#define RX580_NAME     "AMD Radeon RX 580 Series (RADV POLARIS10)"
#define RX580_VENDOR   0x1002u   // AMD
#define RX580_DEVICE   0x67DFu   // Polaris 10 / RX 580
#define RX580_DRIVER   "radv"
#define RX580_DRIVER_INFO "Mesa 26.0.8"

// ------------------------------------------------------------------ layer state
static VkInstance g_instance = VK_NULL_HANDLE;
static PFN_vkGetInstanceProcAddr g_next_gipa = NULL;
static PFN_vkGetDeviceProcAddr   g_next_gdpa = NULL;

// set RX580_LOG=1 to trace; writes to /tmp/rx580.log
static void lg(const char *m)
{
    if (!getenv("RX580_LOG")) return;
    FILE *f = fopen("/tmp/rx580.log", "a");
    if (f) { fprintf(f, "%s\n", m); fflush(f); fclose(f); }
}

// ------------------------------------------------------------------ chain helpers
static VkLayerInstanceCreateInfo *inst_chain(VkInstanceCreateInfo *ci)
{
    if (!ci) return NULL;
    VkLayerInstanceCreateInfo *c = (VkLayerInstanceCreateInfo *)ci->pNext;
    while (c && !(c->sType == VK_STRUCTURE_TYPE_LOADER_INSTANCE_CREATE_INFO &&
                  c->function == VK_LAYER_LINK_INFO))
        c = (VkLayerInstanceCreateInfo *)c->pNext;
    return c;
}

static VkLayerDeviceCreateInfo *dev_chain(VkDeviceCreateInfo *ci)
{
    if (!ci) return NULL;
    VkLayerDeviceCreateInfo *c = (VkLayerDeviceCreateInfo *)ci->pNext;
    while (c && !(c->sType == VK_STRUCTURE_TYPE_LOADER_DEVICE_CREATE_INFO &&
                  c->function == VK_LAYER_LINK_INFO))
        c = (VkLayerDeviceCreateInfo *)c->pNext;
    return c;
}

// ------------------------------------------------------------------ the answer
static void rx580_identity(VkPhysicalDeviceProperties *p)
{
    if (!p) return;
    p->vendorID   = RX580_VENDOR;
    p->deviceID   = RX580_DEVICE;
    p->deviceType = VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU;

    memset(p->deviceName, 0, sizeof(p->deviceName));
    strncpy(p->deviceName, RX580_NAME, sizeof(p->deviceName) - 1);

    // Only identity is faked. The limits block is left exactly as the real driver
    // reports it, so the capability numbers still match the machine that runs them.
}

static void rx580_driver_props(VkPhysicalDeviceDriverProperties *d)
{
    if (!d) return;
    d->driverID = VK_DRIVER_ID_MESA_RADV;
    memset(d->driverName, 0, sizeof(d->driverName));
    strncpy(d->driverName, RX580_DRIVER, sizeof(d->driverName) - 1);
    memset(d->driverInfo, 0, sizeof(d->driverInfo));
    strncpy(d->driverInfo, RX580_DRIVER_INFO, sizeof(d->driverInfo) - 1);
}

// ------------------------------------------------------------------ intercepted
static PFN_vkGetPhysicalDeviceProperties  next_gpdprops  = NULL;
static PFN_vkGetPhysicalDeviceProperties2 next_gpdprops2 = NULL;

static VKAPI_ATTR void VKAPI_CALL rx580_GetPhysicalDeviceProperties(
        VkPhysicalDevice pd, VkPhysicalDeviceProperties *pProperties)
{
    if (!next_gpdprops && g_next_gipa)
        next_gpdprops = (PFN_vkGetPhysicalDeviceProperties)
            g_next_gipa(g_instance, "vkGetPhysicalDeviceProperties");
    if (next_gpdprops) next_gpdprops(pd, pProperties);
    rx580_identity(pProperties);
}

static VKAPI_ATTR void VKAPI_CALL rx580_GetPhysicalDeviceProperties2(
        VkPhysicalDevice pd, VkPhysicalDeviceProperties2 *pProperties)
{
    if (!next_gpdprops2 && g_next_gipa) {
        next_gpdprops2 = (PFN_vkGetPhysicalDeviceProperties2)
            g_next_gipa(g_instance, "vkGetPhysicalDeviceProperties2");
        if (!next_gpdprops2)
            next_gpdprops2 = (PFN_vkGetPhysicalDeviceProperties2)
                g_next_gipa(g_instance, "vkGetPhysicalDeviceProperties2KHR");
    }
    if (next_gpdprops2) next_gpdprops2(pd, pProperties);
    if (!pProperties) return;

    rx580_identity(&pProperties->properties);

    // Walk the pNext chain: VkPhysicalDeviceDriverProperties is what supplies
    // driverName, which ANGLE prints as the trailing part of the renderer string.
    // (The Vulkan11 struct only carries UUIDs - the name/vendor/device id all come
    // from the base properties block, already patched above.)
    for (VkBaseOutStructure *s = (VkBaseOutStructure *)pProperties->pNext; s; s = s->pNext) {
        if (s->sType == VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DRIVER_PROPERTIES)
            rx580_driver_props((VkPhysicalDeviceDriverProperties *)s);
    }
}

// ------------------------------------------------------------------ lifecycle
VKAPI_ATTR VkResult VKAPI_CALL vkCreateInstance(
        const VkInstanceCreateInfo *pCreateInfo,
        const VkAllocationCallbacks *pAllocator, VkInstance *pInstance)
{
    lg("vkCreateInstance: enter");
    VkLayerInstanceCreateInfo *c = inst_chain((VkInstanceCreateInfo *)pCreateInfo);
    if (!c || !c->u.pLayerInfo) { lg("vkCreateInstance: no link info");
        return VK_ERROR_INITIALIZATION_FAILED; }
    lg("vkCreateInstance: found link info");

    g_next_gipa = c->u.pLayerInfo->pfnNextGetInstanceProcAddr;
    c->u.pLayerInfo = c->u.pLayerInfo->pNext;   // hand the chain down
    lg("vkCreateInstance: chain advanced");

    PFN_vkCreateInstance fp =
        (PFN_vkCreateInstance)g_next_gipa(NULL, "vkCreateInstance");
    lg(fp ? "vkCreateInstance: got next fp" : "vkCreateInstance: next fp NULL");
    if (!fp) return VK_ERROR_INITIALIZATION_FAILED;

    lg("vkCreateInstance: calling down");
    VkResult r = fp(pCreateInfo, pAllocator, pInstance);
    lg("vkCreateInstance: came back");
    if (r == VK_SUCCESS) g_instance = *pInstance;
    return r;
}

VKAPI_ATTR VkResult VKAPI_CALL vkCreateDevice(
        VkPhysicalDevice gpu, const VkDeviceCreateInfo *pCreateInfo,
        const VkAllocationCallbacks *pAllocator, VkDevice *pDevice)
{
    VkLayerDeviceCreateInfo *c = dev_chain((VkDeviceCreateInfo *)pCreateInfo);
    if (!c || !c->u.pLayerInfo) return VK_ERROR_INITIALIZATION_FAILED;

    PFN_vkGetInstanceProcAddr next_gipa = c->u.pLayerInfo->pfnNextGetInstanceProcAddr;
    g_next_gdpa = c->u.pLayerInfo->pfnNextGetDeviceProcAddr;
    c->u.pLayerInfo = c->u.pLayerInfo->pNext;

    PFN_vkCreateDevice fp = (PFN_vkCreateDevice)next_gipa(g_instance, "vkCreateDevice");
    if (!fp) return VK_ERROR_INITIALIZATION_FAILED;
    return fp(gpu, pCreateInfo, pAllocator, pDevice);
}

VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL vkGetDeviceProcAddr(
        VkDevice device, const char *pName)
{
    if (!g_next_gdpa) return NULL;
    return g_next_gdpa(device, pName);
}

VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL vkGetInstanceProcAddr(
        VkInstance instance, const char *pName)
{
    if (!pName) return NULL;

    // trace every name the loader asks us for - proves whether it talks to us at all
    if (getenv("RX580_LOG")) {
        FILE *f = fopen("/tmp/rx580.log", "a");
        if (f) { fprintf(f, "GIPA(%p, %s)\n", (void *)instance, pName); fflush(f); fclose(f); }
    }

    if (!strcmp(pName, "vkGetInstanceProcAddr"))
        return (PFN_vkVoidFunction)vkGetInstanceProcAddr;
    if (!strcmp(pName, "vkCreateInstance"))
        return (PFN_vkVoidFunction)vkCreateInstance;
    if (!strcmp(pName, "vkCreateDevice"))
        return (PFN_vkVoidFunction)vkCreateDevice;
    if (!strcmp(pName, "vkGetDeviceProcAddr"))
        return (PFN_vkVoidFunction)vkGetDeviceProcAddr;

    if (!strcmp(pName, "vkGetPhysicalDeviceProperties"))
        return (PFN_vkVoidFunction)rx580_GetPhysicalDeviceProperties;
    if (!strcmp(pName, "vkGetPhysicalDeviceProperties2") ||
        !strcmp(pName, "vkGetPhysicalDeviceProperties2KHR"))
        return (PFN_vkVoidFunction)rx580_GetPhysicalDeviceProperties2;

    if (instance == NULL) return NULL;
    return g_next_gipa ? g_next_gipa(instance, pName) : NULL;
}

// Physical-device-level dispatch: the loader asks here for functions that take a
// VkPhysicalDevice but no VkDevice, which is exactly our interception target.
static VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL rx580_GetPhysicalDeviceProcAddr(
        VkInstance instance, const char *pName)
{
    (void)instance;
    if (!pName) return NULL;
    if (!strcmp(pName, "vkGetPhysicalDeviceProperties"))
        return (PFN_vkVoidFunction)rx580_GetPhysicalDeviceProperties;
    if (!strcmp(pName, "vkGetPhysicalDeviceProperties2") ||
        !strcmp(pName, "vkGetPhysicalDeviceProperties2KHR"))
        return (PFN_vkVoidFunction)rx580_GetPhysicalDeviceProperties2;
    return NULL;
}

// ------------------------------------------------------------------ interface version
// The loader warned that our vkGetInstanceProcAddr tag is deprecated for
// file_format_version >= 1.1.0, and on that legacy path it asked us for
// vkCreateInstance once and then hung without ever calling it. So speak the current
// interface instead: the loader calls this first to collect our entry points.
VKAPI_ATTR VkResult VKAPI_CALL vkNegotiateLoaderLayerInterfaceVersion(
        VkNegotiateLayerInterface *pVersionStruct)
{
    lg("negotiate: enter");
    if (!pVersionStruct || pVersionStruct->sType != LAYER_NEGOTIATE_INTERFACE_STRUCT)
        return VK_ERROR_INITIALIZATION_FAILED;

    // We only need the v2 layout: the two proc-addr getters plus the physical-device
    // one. Claim it even if the loader offers something newer.
    if (pVersionStruct->loaderLayerInterfaceVersion >= 2) {
        pVersionStruct->loaderLayerInterfaceVersion    = 2;
        pVersionStruct->pfnGetInstanceProcAddr         = vkGetInstanceProcAddr;
        pVersionStruct->pfnGetDeviceProcAddr           = vkGetDeviceProcAddr;
        pVersionStruct->pfnGetPhysicalDeviceProcAddr   = rx580_GetPhysicalDeviceProcAddr;
    }
    lg("negotiate: ok");
    return VK_SUCCESS;
}
