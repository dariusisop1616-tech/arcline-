#!/bin/bash
# Build the RX 580 Vulkan layer and prove it works BEFORE pointing a browser at it.
#
# Activation is EXPLICIT (VK_LAYER_PATH + VK_INSTANCE_LAYERS), not implicit:
# a manifest with enable_environment is implicit-only and the loader skips it for
# explicit use; and an implicit layer would rename the GPU for every Vulkan app on the
# machine. Explicit means one profile, one launch - which is what a SaaS actually needs.
set -e
SRC="/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/vulkan-layer"
DIR="/root/vklayer"
mkdir -p "$DIR"
cp "$SRC/rx580_layer.c" "$SRC/vulkan_probe.c" "$SRC/VK_LAYER_FAKE_rx580.json" "$DIR/"
rm -f /usr/share/vulkan/implicit_layer.d/VK_LAYER_FAKE_rx580.json

echo "=== building ==="
gcc -shared -fPIC -O2 -o "$DIR/librx580.so" "$DIR/rx580_layer.c" -ldl
gcc -O2 -o "$DIR/vulkan_probe" "$DIR/vulkan_probe.c" -lvulkan
echo "  librx580.so   $(stat -c%s "$DIR/librx580.so") bytes"
echo "  vulkan_probe  $(stat -c%s "$DIR/vulkan_probe") bytes"

export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json
ON="VK_LAYER_PATH=$DIR VK_INSTANCE_LAYERS=VK_LAYER_FAKE_rx580"

echo
echo "=== [1] ground truth: no layer ==="
env -u VK_INSTANCE_LAYERS -u VK_LAYER_PATH "$DIR/vulkan_probe" \
  | grep -E 'deviceName|vendorID|deviceID|deviceType|driverName'

echo
echo "=== [2] with the layer ==="
env $ON "$DIR/vulkan_probe" \
  | grep -E 'deviceName|vendorID|deviceID|deviceType|driverName|driverInfo'

echo
echo "=== [3] loader confirmation ==="
env $ON VK_LOADER_DEBUG=layer,warn "$DIR/vulkan_probe" 2>&1 \
  | grep -iE 'rx580|FAKE|Adding|enabled' | head -8
