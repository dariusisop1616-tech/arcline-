#!/bin/bash
# The hang is a futex deadlock (State S, wchan futex_do_wait, 0 CPU, 1 thread), not a spin.
# A futuresque wait with only one thread means something is waiting on a lock/signal that
# nobody will ever provide. Get the actual userspace backtrace with gdb.
set +e
DIR=/root/vklayer
cd "$DIR" || exit 1

export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json
export VK_LAYER_PATH="$DIR"
export VK_INSTANCE_LAYERS=VK_LAYER_FAKE_rx580
export RX580_LOG=1
export NODEVICE_SELECT=1

echo "=== [1] baseline: is the ICD still fine with no layer? ==="
env -u VK_INSTANCE_LAYERS -u VK_LAYER_PATH ./vulkan_probe 2>&1 | grep -E 'deviceName|vendorID' | head -2
echo

echo "=== [2] ensure gdb ==="
if ! command -v gdb >/dev/null; then
  apt-get update -qq >/dev/null 2>&1
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq gdb >/dev/null 2>&1
fi
command -v gdb && gdb --version | head -1 || { echo "gdb unavailable"; exit 0; }
echo

echo "=== [3] run probe, attach gdb, backtrace all threads ==="
rm -f /tmp/rx580.log
./vulkan_probe >/tmp/probe.out 2>&1 &
P=$!
sleep 3
if [ -d "/proc/$P" ]; then
  gdb -p $P -batch \
    -ex "set pagination off" \
    -ex "thread apply all bt" \
    -ex "info sharedlibrary" 2>&1 | grep -vE '^\[New|Reading symbols|no debugging symbols' | head -60
  kill -9 $P 2>/dev/null
else
  echo "(process exited on its own)"
  cat /tmp/probe.out
fi
echo
echo "=== layer trace ==="
cat /tmp/rx580.log 2>/dev/null
