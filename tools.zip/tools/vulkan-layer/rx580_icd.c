// Vulkan ICD wrapper that reports an AMD Radeon RX 580, for the Wine lab.
//
// Why a wrapper and not the LD_PRELOAD interposer (preload_rx580.c): under Wine the
// chain is msedge (PE) -> vulkan-1.dll (winevulkan PE) -> winevulkan.so -> host loader
// -> ICD, and every function pointer along that chain is obtained with dlsym on a
// specific handle or returned through the loader - none of it resolves through the
// global symbol scope, so an LD_PRELOAD interposer is never consulted. The one file in
// the path we fully own is the ICD itself, so we ARE the ICD: dlopen the real driver,
// forward its whole loader interface, and rewrite the answer to "who are you?".
//
// Same rewrite as the proven interposer: vendorID 0x1002, deviceID 0x67DF, the Polaris
// 10 name, DISCRETE_GPU, and radv/driverInfo from the pNext chain. Limits untouched on
// purpose - the machine really renders with them (see RX580-METHOD.md).
//
// The real ICD (Mesa lavapipe) exports exactly three vk_icd* entry points, so that is
// the whole surface to mirror:
//   vk_icdNegotiateLoaderICDInterfaceVersion
//   vk_icdGetInstanceProcAddr
//   vk_icdGetPhysicalDeviceProcAddr
//
// Single-instance assumption: the trampolines resolve their real targets when the
// loader asks us for them (that call carries the instance) and cache the pointers.
// A GPU process hosts one instance in practice; a second instance would re-resolve
// only if its pointer differs - for the lab this is fine and is stated, not hidden.
#define _GNU_SOURCE
#include <dlfcn.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <vulkan/vulkan.h>

/* GTX 1060 identity (2026-09-27). Chosen from Wine's own GPU database
 * (win32u.so carries these descriptions keyed by vendor/device), so the name
 * Wine's dxgi reports and the name our ICD reports agree char-for-char - the
 * lesson from the RX 580 attempt: Wine's db had no 580 entry and served its
 * 480 wording for 0x67DF, and no registry override exists to rename it. The
 * identity moved to a card the db DOES carry. Pascal's last Windows driver
 * branch (580.x) reports Vulkan 1.3, and its real max texture size (16384)
 * matches what llvmpipe reports, so the untouched limits stay coherent. */
#define RX580_NAME        "GeForce GTX 1060"   /* no "NVIDIA " prefix: Wine's
                            * fallback for an unknown ID prepends the vendor word
                            * itself - measured 2026-09-27: "NVIDIA NVIDIA ..." */
#define RX580_VENDOR      0x10DEu   /* NVIDIA */
#define RX580_DEVICE      0x1C03u   /* GTX 1060 6GB (GP106) */
#define RX580_DRIVER      "NVIDIA proprietary driver"
#define RX580_DRIVER_INFO "NVIDIA driver 580.88"
#define RX580_DRIVER_ID   VK_DRIVER_ID_NVIDIA_PROPRIETARY
#define RX580_API_VERSION VK_MAKE_API_VERSION(0, 1, 3, 303)

static int dbg(void)
{
    static int on = -1;
    if (on < 0) on = getenv("RX580_LOG") ? 1 : 0;
    return on;
}

static void note(const char *what)
{
    if (!dbg()) return;
    FILE *f = fopen("/tmp/rx580_icd.log", "a");
    if (f) { fprintf(f, "%s\n", what); fflush(f); fclose(f); }
}

/* ---- the real ICD -------------------------------------------------------- */

static void *real_so;
static PFN_vkGetInstanceProcAddr real_gipa;
static void *(*real_icd_gipa)(void *instance, const char *name);      /* vk_icd variant */
static void *(*real_icd_pdpa)(void *instance, const char *name);      /* physdev variant */
static void *(*real_negotiate)(void *pVersion);

static int load_real(void)
{
    static int done;
    if (done) return real_icd_gipa != NULL;   /* the required export, not the optional one */
    done = 1;
    const char *path = getenv("RX580_REAL_ICD");
    if (!path) path = "libvulkan_lvp.so";
    real_so = dlopen(path, RTLD_NOW | RTLD_LOCAL);
    if (!real_so) {
        note("FAILED to dlopen real ICD");
        return 0;
    }
    real_icd_gipa = dlsym(real_so, "vk_icdGetInstanceProcAddr");
    real_icd_pdpa = dlsym(real_so, "vk_icdGetPhysicalDeviceProcAddr");
    real_negotiate = dlsym(real_so, "vk_icdNegotiateLoaderICDInterfaceVersion");
    /* the plain (non-icd-prefixed) entry points are also valid lookup paths for
     * older loaders; grab them if present */
    real_gipa = (PFN_vkGetInstanceProcAddr)dlsym(real_so, "vkGetInstanceProcAddr");
    note("real ICD loaded");
    return 1;
}

/* ---- identity patching (copied from the proven interposer) --------------- */

static void patch_identity(VkPhysicalDeviceProperties *p)
{
    if (!p) return;
    p->vendorID   = RX580_VENDOR;
    p->deviceID   = RX580_DEVICE;
    p->deviceType = VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU;
    p->apiVersion = RX580_API_VERSION;
    memset(p->deviceName, 0, sizeof(p->deviceName));
    strncpy(p->deviceName, RX580_NAME, sizeof(p->deviceName) - 1);
}

static void patch_driver_props(VkPhysicalDeviceDriverProperties *d)
{
    if (!d) return;
    d->driverID = RX580_DRIVER_ID;
    memset(d->driverName, 0, sizeof(d->driverName));
    strncpy(d->driverName, RX580_DRIVER, sizeof(d->driverName) - 1);
    memset(d->driverInfo, 0, sizeof(d->driverInfo));
    strncpy(d->driverInfo, RX580_DRIVER_INFO, sizeof(d->driverInfo) - 1);
}

/* ---- trampolines the loader receives instead of the real functions ------- */

static PFN_vkGetPhysicalDeviceProperties  t_real_props;
static PFN_vkGetPhysicalDeviceProperties2 t_real_props2;
static void *t_instance;

static void resolve_real_for(void *instance)
{
    if (t_real_props && t_instance == instance) return;
    if (!load_real()) return;
    if (!real_icd_gipa) return;
    t_instance = instance;
    t_real_props  = (PFN_vkGetPhysicalDeviceProperties)
        real_icd_gipa(instance, "vkGetPhysicalDeviceProperties");
    t_real_props2 = (PFN_vkGetPhysicalDeviceProperties2)
        real_icd_gipa(instance, "vkGetPhysicalDeviceProperties2");
    if (!t_real_props2)
        t_real_props2 = (PFN_vkGetPhysicalDeviceProperties2)
            real_icd_gipa(instance, "vkGetPhysicalDeviceProperties2KHR");
    note(t_real_props ? "real property functions resolved"
                      : "WARN: real property functions NOT resolved");
}

VKAPI_ATTR void VKAPI_CALL wrap_GetPhysicalDeviceProperties(
    VkPhysicalDevice pd, VkPhysicalDeviceProperties *pProperties)
{
    if (t_real_props) t_real_props(pd, pProperties);
    else if (pProperties) memset(pProperties, 0, sizeof(*pProperties));
    note("GetPhysicalDeviceProperties intercepted");
    patch_identity(pProperties);
}

VKAPI_ATTR void VKAPI_CALL wrap_GetPhysicalDeviceProperties2(
    VkPhysicalDevice pd, VkPhysicalDeviceProperties2 *pProperties)
{
    if (t_real_props2) t_real_props2(pd, pProperties);
    else if (pProperties) memset(pProperties, 0, sizeof(pProperties->properties));
    note("GetPhysicalDeviceProperties2 intercepted");
    if (!pProperties) return;
    patch_identity(&pProperties->properties);
    for (VkBaseOutStructure *s = (VkBaseOutStructure *)pProperties->pNext; s; s = s->pNext)
        if (s->sType == VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DRIVER_PROPERTIES)
            patch_driver_props((VkPhysicalDeviceDriverProperties *)s);
}

static void *maybe_wrap(const char *name)
{
    if (!strcmp(name, "vkGetPhysicalDeviceProperties"))
        return (void *)&wrap_GetPhysicalDeviceProperties;
    if (!strcmp(name, "vkGetPhysicalDeviceProperties2") ||
        !strcmp(name, "vkGetPhysicalDeviceProperties2KHR"))
        return (void *)&wrap_GetPhysicalDeviceProperties2;
    return NULL;
}

/* ---- the ICD surface the loader talks to --------------------------------- */

void *vk_icdGetInstanceProcAddr(void *instance, const char *name)
{
    void *w;
    char buf[128];
    if (!load_real() || !real_icd_gipa) {
        snprintf(buf, sizeof buf, "gipa(%s) DROPPED - real ICD not loaded", name);
        note(buf);
        return NULL;
    }
    resolve_real_for(instance);
    if ((w = maybe_wrap(name))) {
        snprintf(buf, sizeof buf, "gipa(%s) -> WRAPPED", name);
        note(buf);
        return w;
    }
    snprintf(buf, sizeof buf, "gipa(%s) -> real (%s)", name,
             instance ? "instance" : "NULL-instance");
    note(buf);
    return real_icd_gipa(instance, name);
}

void *vk_icdGetPhysicalDeviceProcAddr(void *instance, const char *name)
{
    void *w;
    char buf[128];
    if (!load_real() || !real_icd_pdpa) {
        snprintf(buf, sizeof buf, "pdpa(%s) DROPPED - real ICD not loaded", name);
        note(buf);
        return NULL;
    }
    resolve_real_for(instance);
    if ((w = maybe_wrap(name))) {
        snprintf(buf, sizeof buf, "pdpa(%s) -> WRAPPED", name);
        note(buf);
        return w;
    }
    snprintf(buf, sizeof buf, "pdpa(%s) -> real", name);
    note(buf);
    return real_icd_pdpa(instance, name);
}

VkResult vk_icdNegotiateLoaderICDInterfaceVersion(void *pVersion)
{
    if (!load_real() || !real_negotiate) {
        note("negotiate DROPPED - real ICD not loaded");
        return VK_ERROR_INITIALIZATION_FAILED;
    }
    VkResult r = (VkResult)real_negotiate(pVersion);
    note("negotiate forwarded");
    return r;
}