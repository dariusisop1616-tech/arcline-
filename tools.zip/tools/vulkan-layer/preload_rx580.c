// LD_PRELOAD interposer that reports an AMD Radeon RX 580.
//
// Why this exists alongside the Vulkan layer: the layer route is blocked by the loader
// on this box. isolate.sh proved a layer that does NOTHING still deadlocks it, and gdb +
// the loader's own log showed why - the loader records its own library path for our
// layer, so the "layer" it calls is libvulkan's vkCreateInstance, which re-enters itself
// and deadlocks on its own global lock. That is a loader bug, not something in our code.
//
// This shim reaches the same place without the loader's layer machinery. ANGLE calls the
// loader's exported vkGetPhysicalDeviceProperties/vkGetPhysicalDeviceProperties2; those
// are ordinary dynamic symbols, so an LD_PRELOAD interposer in the browser process catches
// them before libvulkan does, patches the answer, and calls the real one through.
//
// Still nothing in-page and nothing patched in the browser: the browser asks, we answer.
#define _GNU_SOURCE
#include <dlfcn.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <vulkan/vulkan.h>

// Values from a real RX 580 (Polaris 10) on Mesa radv.
#define RX580_NAME        "AMD Radeon RX 580 Series (RADV POLARIS10)"
#define RX580_VENDOR      0x1002u   // AMD
#define RX580_DEVICE      0x67DFu   // Polaris 10 / RX 580
#define RX580_DRIVER      "radv"
#define RX580_DRIVER_INFO "Mesa 26.0.8"

static int dbg(void)
{
    static int on = -1;
    if (on < 0) on = getenv("RX580_LOG") ? 1 : 0;
    return on;
}

static void note(const char *what)
{
    if (!dbg()) return;
    FILE *f = fopen("/tmp/rx580_preload.log", "a");
    if (f) { fprintf(f, "%s\n", what); fflush(f); fclose(f); }
}

static void patch_identity(VkPhysicalDeviceProperties *p)
{
    if (!p) return;
    p->vendorID   = RX580_VENDOR;
    p->deviceID   = RX580_DEVICE;
    p->deviceType = VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU;
    memset(p->deviceName, 0, sizeof(p->deviceName));
    strncpy(p->deviceName, RX580_NAME, sizeof(p->deviceName) - 1);
    // limits untouched on purpose: the machine really does render with them, so the
    // capability numbers stay self-consistent instead of claiming RX 580 silicon.
}

static void patch_driver_props(VkPhysicalDeviceDriverProperties *d)
{
    if (!d) return;
    d->driverID = VK_DRIVER_ID_MESA_RADV;
    memset(d->driverName, 0, sizeof(d->driverName));
    strncpy(d->driverName, RX580_DRIVER, sizeof(d->driverName) - 1);
    memset(d->driverInfo, 0, sizeof(d->driverInfo));
    strncpy(d->driverInfo, RX580_DRIVER_INFO, sizeof(d->driverInfo) - 1);
}

// Resolve the real function behind us.
//
// dlsym(RTLD_NEXT) is NOT enough. It works for a program that links libvulkan at load
// time (our probe does, which is why this looked fine there), but Chrome's ANGLE dlopens
// libvulkan, so RTLD_NEXT finds nothing. We then skipped the real call and returned with
// ANGLE's VkPhysicalDeviceProperties left uninitialised - which is exactly why ANGLE
// reported "Requires a minimum Vulkan device version of 1.1" and failed with error -9:
// it was reading garbage apiVersion out of a struct nobody had filled in.
//
// So: try RTLD_NEXT, then the default scope (rejecting our own symbol, which sits first
// there and would recurse forever), then an explicit handle on libvulkan.
static void *real_proc(const char *name, void *self)
{
    void *p = dlsym(RTLD_NEXT, name);
    if (!p || p == self) p = dlsym(RTLD_DEFAULT, name);
    if (!p || p == self) {
        static void *vk = NULL;
        static int tried = 0;
        if (!tried) {
            tried = 1;
            vk = dlopen("libvulkan.so.1", RTLD_NOW | RTLD_LOCAL);
            if (!vk) vk = dlopen("libvulkan.so", RTLD_NOW | RTLD_LOCAL);
            note(vk ? "resolved libvulkan via dlopen fallback"
                    : "FAILED to dlopen libvulkan");
        }
        if (vk) p = dlsym(vk, name);
    }
    if (p == self) p = NULL;
    if (!p) note("WARN: real proc not found - struct left unpatched below");
    return p;
}

void vkGetPhysicalDeviceProperties(VkPhysicalDevice pd,
                                   VkPhysicalDeviceProperties *pProperties)
{
    static PFN_vkGetPhysicalDeviceProperties real;
    if (!real) {
        void *p = real_proc("vkGetPhysicalDeviceProperties",
                            (void *)&vkGetPhysicalDeviceProperties);
        if (p) real = (PFN_vkGetPhysicalDeviceProperties)p;
    }
    if (real) real(pd, pProperties);
    note(real ? "vkGetPhysicalDeviceProperties intercepted (real called)"
              : "vkGetPhysicalDeviceProperties intercepted (REAL MISSING)");
    patch_identity(pProperties);
}

void vkGetPhysicalDeviceProperties2(VkPhysicalDevice pd,
                                    VkPhysicalDeviceProperties2 *pProperties)
{
    // Cache only a successful lookup: on the first call libvulkan may not be loaded yet,
    // and caching that NULL would leave every later call skipping the real function.
    static PFN_vkGetPhysicalDeviceProperties2 real;
    if (!real) {
        void *p = real_proc("vkGetPhysicalDeviceProperties2",
                            (void *)&vkGetPhysicalDeviceProperties2);
        if (!p)
            p = real_proc("vkGetPhysicalDeviceProperties2KHR",
                          (void *)&vkGetPhysicalDeviceProperties2);
        if (p) real = (PFN_vkGetPhysicalDeviceProperties2)p;
    }
    if (real) real(pd, pProperties);
    note(real ? "vkGetPhysicalDeviceProperties2 intercepted (real called)"
              : "vkGetPhysicalDeviceProperties2 intercepted (REAL MISSING)");
    if (!pProperties) return;

    patch_identity(&pProperties->properties);

    // driverName lives in a pNext struct, and ANGLE prints it as the tail of the
    // WebGL renderer string.
    for (VkBaseOutStructure *s = (VkBaseOutStructure *)pProperties->pNext; s; s = s->pNext)
        if (s->sType == VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DRIVER_PROPERTIES)
            patch_driver_props((VkPhysicalDeviceDriverProperties *)s);
}
