#!/bin/bash
# Where exactly does the layered probe hang? Unbuffered, with full loader logging.
DIR=/root/vklayer
cd "$DIR" || exit 1

export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json
export VK_LAYER_PATH="$DIR"
export VK_INSTANCE_LAYERS=VK_LAYER_FAKE_rx580
export VK_LOADER_DEBUG=all

echo "=== unbuffered, 12s timeout, full loader log ==="
timeout 12 stdbuf -o0 -e0 ./vulkan_probe >"$DIR/out.log" 2>&1
echo "exit code: $?"

echo
echo "=== last 40 lines before it stopped ==="
tail -40 "$DIR/out.log"

echo
echo "=== any rx580 mentions ==="
grep -in 'rx580\|FAKE' "$DIR/out.log" | head -15
