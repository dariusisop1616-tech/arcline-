// A deliberately trivial layer: one entry point, returns NULL for everything.
// Purpose: is the loader deadlock caused by anything WE do, or does the loader break
// just from having any explicit layer loaded at all? If this stub hangs too, nothing
// in our layer code is implicated.
#include <vulkan/vulkan.h>
#include <vulkan/vk_layer.h>

VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL vkGetInstanceProcAddr(
        VkInstance instance, const char *pName)
{
    (void)instance;
    (void)pName;
    return NULL;
}
