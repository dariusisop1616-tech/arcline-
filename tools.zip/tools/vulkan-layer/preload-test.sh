#!/bin/bash
# (a) What does the WORKING baseline actually load? If it loads a layer and still works,
#     then layers per se are fine and our layer must be tripping something specific.
# (b) Does the LD_PRELOAD route work, bypassing the loader's layer machinery entirely?
DIR=/root/vklayer
SRC="/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/vulkan-layer"
cd "$DIR" || exit 1
export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json

# Remove our implicit manifest so part (a) is a clean baseline.
rm -f /usr/share/vulkan/implicit_layer.d/VK_LAYER_FAKE_rx580.json

echo "=== [a] baseline: which layers does the loader insert, and does it work? ==="
VK_LOADER_DEBUG=layer timeout 8 ./vulkan_probe 2>&1 | grep -iE 'Insert instance layer|Device Name|deviceName' | head -8
echo "exit: ${PIPESTATUS[0]}"
echo

echo "=== [a2] baseline device_select explicitly named ==="
VK_LOADER_DEBUG=layer VK_INSTANCE_LAYERS=VK_LAYER_MESA_device_select \
  timeout 8 ./vulkan_probe 2>&1 | grep -iE 'Insert instance layer|deviceName' | head -6
echo "exit: ${PIPESTATUS[0]}"
echo

echo "=== [b] build the LD_PRELOAD interposer ==="
cp "$SRC/preload_rx580.c" "$DIR/"
gcc -shared -fPIC -O2 -o "$DIR/libvk_rx580_preload.so" "$DIR/preload_rx580.c" -ldl || exit 1
echo "built $(stat -c%s "$DIR/libvk_rx580_preload.so") bytes"
echo

echo "=== [b1] probe with no preload (ground truth) ==="
env -u LD_PRELOAD timeout 8 ./vulkan_probe 2>&1 \
  | grep -E 'deviceName|vendorID|deviceID|deviceType|driverName|driverInfo' | head -6
echo

echo "=== [b2] probe with the interposer loaded ==="
rm -f /tmp/rx580_preload.log
RX580_LOG=1 LD_PRELOAD="$DIR/libvk_rx580_preload.so" timeout 8 ./vulkan_probe 2>&1 \
  | grep -E 'deviceName|vendorID|deviceID|deviceType|driverName|driverInfo' | head -8
echo "exit: ${PIPESTATUS[0]}"
echo
echo "--- interposer trace ---"
cat /tmp/rx580_preload.log 2>/dev/null | sort | uniq -c || echo "(never called)"
