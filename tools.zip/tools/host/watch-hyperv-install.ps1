<#
    Elevated watcher: polls the lab guest until Windows finishes installing.

    Hyper-V has no screenshot cmdlet, so frames come from the WMI thumbnail API
    (Msvm_VirtualSystemManagementService::GetVirtualSystemThumbnailImage), which
    returns raw RGB565 pixels that we wrap in a Bitmap and save as PNG.

    Writes progress to a log the unelevated session can read, so the whole install
    costs exactly one UAC prompt.
#>
param(
    [string]$VmName    = 'fp-hv',
    [string]$OutDir    = 'E:\HyperV\watch',
    [int]   $MaxMinutes = 45
)

$ErrorActionPreference = 'Continue'
Add-Type -AssemblyName System.Drawing
New-Item -ItemType Directory -Force $OutDir | Out-Null
$log = Join-Path $OutDir 'watch.log'
Remove-Item $log -ErrorAction SilentlyContinue
function W($s) { "$(Get-Date -Format HH:mm:ss) $s" | Out-File $log -Append -Encoding utf8 }

$ns = 'root\virtualization\v2'

function Save-VMThumb {
    param([string]$Vm, [string]$Out)
    try {
        $css  = Get-CimInstance -Namespace $ns -ClassName Msvm_ComputerSystem -Filter "ElementName='$Vm'"
        $vssd = Get-CimAssociatedInstance -InputObject $css -ResultClassName Msvm_VirtualSystemSettingData | Select-Object -First 1
        $svc  = Get-CimInstance -Namespace $ns -ClassName Msvm_VirtualSystemManagementService
        $head = Get-CimAssociatedInstance -InputObject $css -ResultClassName Msvm_VideoHead -ErrorAction SilentlyContinue | Select-Object -First 1

        $w = 1024; $h = 768
        if ($head -and $head.CurrentHorizontalResolution) {
            $w = [int]$head.CurrentHorizontalResolution
            $h = [int]$head.CurrentVerticalResolution
        }
        # keep width a multiple of 4 so the bitmap stride matches the raw buffer
        if ($w -gt 1024) { $w = 1024 }
        if ($h -gt 768)  { $h = 768 }
        $w = [int]([math]::Floor($w / 4) * 4)

        $r = Invoke-CimMethod -InputObject $svc -MethodName GetVirtualSystemThumbnailImage `
             -Arguments @{ TargetSystem = [ciminstance]$vssd; WidthPixels = [uint16]$w; HeightPixels = [uint16]$h }
        if ($r.ReturnValue -ne 0 -or -not $r.ImageData) { return "thumb rc=$($r.ReturnValue)" }

        $bytes = [byte[]]$r.ImageData
        $bmp = New-Object System.Drawing.Bitmap($w, $h, [System.Drawing.Imaging.PixelFormat]::Format16bppRgb565)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $w, $h)
        $d = $bmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::WriteOnly, [System.Drawing.Imaging.PixelFormat]::Format16bppRgb565)
        [System.Runtime.InteropServices.Marshal]::Copy($bytes, 0, $d.Scan0, [math]::Min($bytes.Length, $d.Stride * $h))
        $bmp.UnlockBits($d)
        $bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
        $bmp.Dispose()
        return "thumb ${w}x${h}"
    } catch { return "thumb error: $($_.Exception.Message)" }
}

W "START watching $VmName"
$deadline = (Get-Date).AddMinutes($MaxMinutes)
$ready = $false

while ((Get-Date) -lt $deadline) {
    $vm = Get-VM -Name $VmName -ErrorAction SilentlyContinue
    if (-not $vm) { W 'VM not found'; break }

    # KVP exchange exposes guest OS info once the installed OS is running
    $osName = ''
    try {
        $css = Get-CimInstance -Namespace $ns -ClassName Msvm_ComputerSystem -Filter "ElementName='$VmName'"
        $kvp = Get-CimAssociatedInstance -InputObject $css -ResultClassName Msvm_KvpExchangeComponent -ErrorAction SilentlyContinue
        if ($kvp -and $kvp.GuestIntrinsicExchangeItems) {
            foreach ($item in $kvp.GuestIntrinsicExchangeItems) {
                if ($item -match '<PROPERTY NAME="Name"[^>]*>\s*<VALUE>OSName</VALUE>') {
                    if ($item -match '<PROPERTY NAME="Data"[^>]*>\s*<VALUE>([^<]*)</VALUE>') { $osName = $Matches[1] }
                }
            }
        }
    } catch { }

    $shot = Join-Path $OutDir 'latest.png'
    $t = Save-VMThumb -Vm $VmName -Out $shot
    W ("state={0} heartbeat={1} uptime={2} osName='{3}' {4}" -f $vm.State, $vm.Heartbeat, $vm.Uptime, $osName, $t)

    if ($osName) {
        Copy-Item $shot (Join-Path $OutDir 'ready.png') -ErrorAction SilentlyContinue
        W "RESULT: GUEST OS REPORTING - $osName"
        $ready = $true
        break
    }
    Start-Sleep -Seconds 30
}

if (-not $ready) { W 'RESULT: TIMEOUT' }
W 'DONE'
