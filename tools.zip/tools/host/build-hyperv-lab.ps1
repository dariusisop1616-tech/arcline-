<#
    Builds the lab guest on Hyper-V. Must run elevated (or as a member of
    Hyper-V Administrators after a re-logon).

    Gen 2 / UEFI, static memory (GPU partitioning refuses dynamic memory), and the
    MMIO space GPU-PV needs is reserved up front so the GPU can be attached later
    without recreating the VM.
#>
param(
    [string]$VmName      = 'fp-hv',
    [string]$Root        = 'E:\HyperV',
    [string]$Win10Iso    = 'E:\ISO\Win10_22H2_French_x64v1.iso',
    [string]$UnattendIso = 'E:\HyperV\unattend.iso',
    [int64] $MemoryBytes = 4GB,
    [int]   $CpuCount    = 2,
    [int64] $DiskBytes   = 60GB,
    [string]$LogPath     = 'E:\HyperV\build.log'
)

$ErrorActionPreference = 'Continue'
function W($s) { $s | Tee-Object -FilePath $LogPath -Append | Out-Null; Write-Output $s }
Remove-Item $LogPath -ErrorAction SilentlyContinue
W "START $(Get-Date -Format s)  as $(whoami)"

foreach ($p in $Win10Iso, $UnattendIso) {
    if (-not (Test-Path $p)) { W "MISSING: $p"; exit 1 }
}
New-Item -ItemType Directory -Force $Root | Out-Null

if (Get-VM -Name $VmName -ErrorAction SilentlyContinue) {
    W "removing existing VM $VmName"
    Stop-VM $VmName -TurnOff -Force -ErrorAction SilentlyContinue
    Remove-VM $VmName -Force
}
$vhd = Join-Path $Root "$VmName\$VmName.vhdx"
Remove-Item $vhd -Force -ErrorAction SilentlyContinue

# --- network: Windows 10 client Hyper-V ships a NAT-backed "Default Switch" ---
$sw = Get-VMSwitch -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'Default Switch*' } | Select-Object -First 1
if (-not $sw) { $sw = Get-VMSwitch -ErrorAction SilentlyContinue | Select-Object -First 1 }
if ($sw) { W "switch: $($sw.Name) ($($sw.SwitchType))" } else { W 'WARNING: no virtual switch - guest will have no network' }

W 'creating VM...'
$newArgs = @{
    Name               = $VmName
    Generation         = 2
    MemoryStartupBytes = $MemoryBytes
    NewVHDPath         = $vhd
    NewVHDSizeBytes    = $DiskBytes
    Path               = $Root
}
if ($sw) { $newArgs.SwitchName = $sw.Name }
New-VM @newArgs | Out-Null

Set-VMProcessor $VmName -Count $CpuCount
Set-VMMemory   $VmName -DynamicMemoryEnabled $false -StartupBytes $MemoryBytes
Set-VM         $VmName -AutomaticCheckpointsEnabled $false -CheckpointType Standard `
                       -AutomaticStopAction ShutDown

# MMIO window + guest-controlled cache types: prerequisites for GPU partitioning
Set-VM $VmName -GuestControlledCacheTypes $true -LowMemoryMappedIoSpace 3GB -HighMemoryMappedIoSpace 33GB
W 'GPU-PV prerequisites set (static memory, MMIO window, guest cache types)'

# --- media: install ISO first in boot order, answer file on a second DVD ---
Add-VMDvdDrive $VmName -Path $Win10Iso
Add-VMDvdDrive $VmName -Path $UnattendIso
$bootDvd = Get-VMDvdDrive $VmName | Where-Object { $_.Path -eq $Win10Iso }
Set-VMFirmware $VmName -FirstBootDevice $bootDvd
Set-VMFirmware $VmName -EnableSecureBoot On -SecureBootTemplate MicrosoftWindows

Enable-VMIntegrationService $VmName -Name 'Guest Service Interface' -ErrorAction SilentlyContinue

W '--- configuration ---'
Get-VM $VmName | Select-Object Name, Generation, ProcessorCount,
    @{n='MemGB';e={[math]::Round($_.MemoryStartup/1GB,1)}}, State |
    Format-List | Out-String | ForEach-Object { W $_ }
Get-VMDvdDrive $VmName | Select-Object ControllerNumber, ControllerLocation, Path |
    Format-Table -AutoSize | Out-String | ForEach-Object { W $_ }

W 'starting VM...'
Start-VM $VmName
W "state: $((Get-VM $VmName).State)"

# --- get past "Press any key to boot from CD or DVD" ---
# Windows ISOs use the prompting UEFI boot image; without a keypress the firmware
# falls through to an empty disk and the install never begins.
$css = Get-CimInstance -Namespace root\virtualization\v2 -ClassName Msvm_ComputerSystem -Filter "ElementName='$VmName'"
$kb = Get-CimAssociatedInstance -InputObject $css -ResultClassName Msvm_Keyboard -ErrorAction SilentlyContinue
if ($kb) {
    W 'sending keystrokes to clear the boot prompt...'
    for ($i = 0; $i -lt 25; $i++) {
        Invoke-CimMethod -InputObject $kb -MethodName TypeKey -Arguments @{ keyCode = [uint32]0x20 } -ErrorAction SilentlyContinue | Out-Null
        Start-Sleep -Milliseconds 800
    }
    W 'keystrokes sent'
} else {
    W 'WARNING: Msvm_Keyboard not reachable - may stall at the boot prompt'
}

W "DONE $(Get-Date -Format s)"
