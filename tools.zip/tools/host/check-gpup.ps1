<#
    Run this (elevated) AFTER enabling Hyper-V and rebooting.

    Answers the single biggest unknown in the project: can this host slice its
    real GPU into a guest? If yes, a VM's WebGL reports a genuine NVIDIA string
    instead of a software renderer, and the whole VM-per-profile design holds.
    If no, every guest looks like SwiftShader and the design needs rethinking.

    Note: GPU partitioning is officially supported on Windows 11 and Server 2022+.
    On Windows 10 19045 it is unofficial and may simply be absent.
#>

$ErrorActionPreference = 'Continue'

'=== Hyper-V feature state ==='
Get-CimInstance Win32_OptionalFeature -Filter "Name like 'Microsoft-Hyper-V%'" |
    Select-Object Name, InstallState | Sort-Object Name | Format-Table -AutoSize
'(1=Enabled 2=Disabled 3=Absent)'

'=== Hyper-V cmdlets ==='
# Windows 11 / Server 2022 use Get-VMHostPartitionableGpu; Windows 10 used Get-VMPartitionableGpu.
$cmds = 'New-VM', 'Add-VMGpuPartitionAdapter', 'Get-VMHostPartitionableGpu', 'Get-VMPartitionableGpu'
foreach ($c in $cmds) {
    if (Get-Command $c -ErrorAction SilentlyContinue) { "  $c : PRESENT" } else { "  $c : MISSING" }
}

'=== Partitionable GPUs ==='
$found = $false
foreach ($c in 'Get-VMHostPartitionableGpu', 'Get-VMPartitionableGpu') {
    if (Get-Command $c -ErrorAction SilentlyContinue) {
        try {
            $gpus = & $c -ErrorAction Stop
            if ($gpus) {
                $found = $true
                "  via $c :"
                $gpus | Format-List Name, ValidPartitionCounts, PartitionCount
            } else { "  $c returned nothing" }
        } catch { "  $c failed: $($_.Exception.Message)" }
    }
}

'=== Host GPU + driver store path (needed to copy drivers into the guest) ==='
Get-CimInstance Win32_VideoController | Select-Object Name, DriverVersion, PNPDeviceID | Format-List
$inf = Get-ChildItem 'C:\Windows\System32\DriverStore\FileRepository' -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like 'nv*' } | Select-Object -First 3
if ($inf) { '  NVIDIA driver store folders (copied into the guest for GPU-PV):'; $inf.FullName }

'=== VERDICT ==='
if ($found) {
    'GPU partitioning IS available. Next: create the guest, Add-VMGpuPartitionAdapter,'
    'copy the NVIDIA driver store folders into the guest, then run the probe inside it.'
} else {
    'GPU partitioning NOT available on this host. A Hyper-V guest will report a software'
    'renderer (SwiftShader / Microsoft Basic Render Driver). Compare that against'
    'results/host/swiftshader.txt to see exactly how a profile would look without it.'
}
