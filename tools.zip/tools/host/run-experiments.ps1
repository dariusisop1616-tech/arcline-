<#
    Elevated. Runs the fingerprint probe inside the lab guest across several
    ANGLE backends and pulls the results back to the host for diffing against
    results/host/*.txt.

    Tag prefix lets the same sweep be re-run after a change (e.g. -Prefix 'gpu'
    once a GPU partition is attached) so before/after sets sit side by side.
#>
param(
    [string]$VmName    = 'fp-hv',
    [string]$Prefix    = 'vm',
    [string]$Repo      = 'C:\Users\Darkking1\Desktop\similar to gologin',
    [string]$OutDir    = 'E:\HyperV\results',
    [string]$LogPath   = 'E:\HyperV\experiments.log',
    [string]$GuestUser = 'lab',
    [string]$GuestPass = 'Lab12345!'
)

$ErrorActionPreference = 'Continue'
New-Item -ItemType Directory -Force $OutDir | Out-Null
Remove-Item $LogPath -ErrorAction SilentlyContinue
function W($s) { "$(Get-Date -Format HH:mm:ss) $s" | Out-File $LogPath -Append -Encoding utf8 }

W "START as $(whoami)  prefix=$Prefix"
$cred = New-Object PSCredential($GuestUser, (ConvertTo-SecureString $GuestPass -AsPlainText -Force))
try { $s = New-PSSession -VMName $VmName -Credential $cred -ErrorAction Stop }
catch { W "no session: $($_.Exception.Message)"; exit 1 }

# the guest is a disposable lab image; unblock local scripts once
Invoke-Command -Session $s -ScriptBlock {
    Set-ExecutionPolicy Bypass -Scope LocalMachine -Force -ErrorAction SilentlyContinue
    "execution policy: $(Get-ExecutionPolicy -Scope LocalMachine)"
} 2>&1 | ForEach-Object { W $_ }

# re-push tools every run so edits on the host reach the guest
W '--- syncing tools into guest ---'
Invoke-Command -Session $s -ScriptBlock { New-Item -ItemType Directory -Force 'C:\lab','C:\lab\results' | Out-Null }
Copy-Item -ToSession $s -Path (Join-Path $Repo 'tools\fingerprint-probe.html') -Destination 'C:\lab\' -Force
foreach ($f in Get-ChildItem (Join-Path $Repo 'tools\guest') -Filter *.ps1) {
    Copy-Item -ToSession $s -Path $f.FullName -Destination 'C:\lab\' -Force
}
W '  synced'

W '--- guest video adapter ---'
Invoke-Command -Session $s -ScriptBlock {
    Get-CimInstance Win32_VideoController | ForEach-Object { "  $($_.Name) | $($_.DriverVersion) | $($_.PNPDeviceID)" }
} 2>&1 | ForEach-Object { W $_ }

$cases = [ordered]@{
    'default' = @()
    'd3d11'   = @('--use-angle=d3d11')
    'gl'      = @('--use-angle=gl')
    'vulkan'  = @('--use-angle=vulkan')
    'sw'      = @('--use-angle=swiftshader', '--enable-unsafe-swiftshader')
}

foreach ($k in $cases.Keys) {
    $tag = "$Prefix-$k"
    $flags = $cases[$k]
    W "--- probe: $tag  flags=$($flags -join ' ') ---"
    Invoke-Command -Session $s -ArgumentList $tag, $flags -ScriptBlock {
        param($t, $f)
        & 'C:\lab\run-probe.ps1' -Tag $t -ChromeFlags $f | Out-Null
        if (Test-Path "C:\lab\results\$t.txt") { "  wrote $t.txt" } else { "  NO OUTPUT for $t" }
    } 2>&1 | ForEach-Object { W $_ }

    try {
        Copy-Item -FromSession $s -Path "C:\lab\results\$tag.txt" -Destination (Join-Path $OutDir "$tag.txt") -Force -ErrorAction Stop
        W "  pulled $tag.txt"
    } catch { W "  pull failed for ${tag}: $($_.Exception.Message)" }
}

Remove-PSSession $s
W 'DONE'
