<#
    Elevated. Attaches a GPU partition to the lab guest and stages the host's
    NVIDIA driver files inside it.

    GPU-PV does not install a driver in the guest the normal way: the guest loads
    the HOST's driver binaries from C:\Windows\System32\HostDriverStore. Those
    files (2.6 GB) are copied straight into the offline VHDX, which is far faster
    than pushing them over PowerShell Direct.
#>
param(
    [string]$VmName    = 'fp-hv',
    [string]$DriverDir = 'nv_dispi.inf_amd64_adc55ecfca814224',
    [string]$LogPath   = 'E:\HyperV\attach-gpu.log',
    [string]$GuestUser = 'lab',
    [string]$GuestPass = 'Lab12345!'
)

$ErrorActionPreference = 'Continue'
Remove-Item $LogPath -ErrorAction SilentlyContinue
function W($s) { "$(Get-Date -Format HH:mm:ss) $s" | Out-File $LogPath -Append -Encoding utf8 }
W "START as $(whoami)"

$vm = Get-VM -Name $VmName -ErrorAction SilentlyContinue
if (-not $vm) { W "VM $VmName not found"; exit 1 }

# --- 1. shut the guest down cleanly
if ($vm.State -ne 'Off') {
    W "stopping $VmName ..."
    Stop-VM $VmName -Force -ErrorAction SilentlyContinue
    $t = (Get-Date).AddMinutes(4)
    while ((Get-VM $VmName).State -ne 'Off' -and (Get-Date) -lt $t) { Start-Sleep -Seconds 5 }
    if ((Get-VM $VmName).State -ne 'Off') { W 'graceful stop timed out - forcing'; Stop-VM $VmName -TurnOff -Force }
}
W "state: $((Get-VM $VmName).State)"

# --- 2. attach the partition
if (Get-VMGpuPartitionAdapter -VMName $VmName -ErrorAction SilentlyContinue) {
    W 'GPU partition adapter already present'
} else {
    Add-VMGpuPartitionAdapter -VMName $VmName
    W 'Add-VMGpuPartitionAdapter: done'
}
try {
    Set-VMGpuPartitionAdapter -VMName $VmName `
        -MinPartitionVRAM 80000000     -MaxPartitionVRAM 100000000     -OptimalPartitionVRAM 100000000 `
        -MinPartitionEncode 80000000   -MaxPartitionEncode 100000000   -OptimalPartitionEncode 100000000 `
        -MinPartitionDecode 80000000   -MaxPartitionDecode 100000000   -OptimalPartitionDecode 100000000 `
        -MinPartitionCompute 80000000  -MaxPartitionCompute 100000000  -OptimalPartitionCompute 100000000 `
        -ErrorAction Stop
    W 'Set-VMGpuPartitionAdapter: partition sizes set'
} catch { W "Set-VMGpuPartitionAdapter skipped: $($_.Exception.Message)" }
Get-VMGpuPartitionAdapter -VMName $VmName | Format-List | Out-String | ForEach-Object { W $_ }

# --- 3. stage host driver files into the offline VHDX
$vhd = (Get-VMHardDiskDrive -VMName $VmName | Select-Object -First 1).Path
W "vhdx: $vhd"
$mounted = $null
try {
    $mounted = Mount-VHD -Path $vhd -PassThru -ErrorAction Stop
    Start-Sleep -Seconds 3
    $vol = $mounted | Get-Disk | Get-Partition | Get-Volume |
           Where-Object { $_.FileSystemType -eq 'NTFS' -and $_.DriveLetter } |
           Sort-Object Size -Descending | Select-Object -First 1
    if (-not $vol) { throw 'no NTFS volume with a drive letter found in the VHDX' }
    $g = "$($vol.DriveLetter):"
    W "guest windows volume: $g  (label '$($vol.FileSystemLabel)')"

    $srcRepo = "C:\Windows\System32\DriverStore\FileRepository\$DriverDir"
    $dstRepo = "$g\Windows\System32\HostDriverStore\FileRepository\$DriverDir"
    if (-not (Test-Path $srcRepo)) { throw "host driver folder missing: $srcRepo" }
    New-Item -ItemType Directory -Force $dstRepo | Out-Null
    W "copying driver store ($srcRepo -> $dstRepo) ..."
    $rc = robocopy $srcRepo $dstRepo /E /NFL /NDL /NJH /NJS /R:1 /W:1
    W "robocopy exit: $LASTEXITCODE (0-7 = success)"

    W 'copying System32 nv* files ...'
    $n = 0
    foreach ($f in Get-ChildItem 'C:\Windows\System32' -Filter 'nv*' -File -ErrorAction SilentlyContinue) {
        try { Copy-Item $f.FullName "$g\Windows\System32\" -Force -ErrorAction Stop; $n++ } catch { }
    }
    W "copied $n System32 files"

    $chk = Get-ChildItem "$dstRepo" -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum
    W ("staged: {0} files, {1} MB" -f $chk.Count, [math]::Round($chk.Sum/1MB,1))
} catch {
    W "driver staging FAILED: $($_.Exception.Message)"
} finally {
    if ($mounted) { Dismount-VHD -Path $vhd -ErrorAction SilentlyContinue; W 'vhdx dismounted' }
}

# --- 4. boot and see what the guest thinks its GPU is
W 'starting VM ...'
Start-VM $VmName
$cred = New-Object PSCredential($GuestUser, (ConvertTo-SecureString $GuestPass -AsPlainText -Force))
$deadline = (Get-Date).AddMinutes(8)
$s = $null
while ((Get-Date) -lt $deadline) {
    try { $s = New-PSSession -VMName $VmName -Credential $cred -ErrorAction Stop; break }
    catch { Start-Sleep -Seconds 15 }
}
if (-not $s) { W 'guest did not come back up'; exit 1 }
W 'guest reachable'

Invoke-Command -Session $s -ScriptBlock {
    '--- video controllers ---'
    Get-CimInstance Win32_VideoController | ForEach-Object {
        "  $($_.Name) | drv $($_.DriverVersion) | $($_.PNPDeviceID) | status=$($_.Status) cfg=$($_.ConfigManagerErrorCode)"
    }
    '--- HostDriverStore present? ---'
    "  $(Test-Path 'C:\Windows\System32\HostDriverStore\FileRepository')"
} 2>&1 | ForEach-Object { W ($_ | Out-String).TrimEnd() }

Remove-PSSession $s
W 'DONE'
