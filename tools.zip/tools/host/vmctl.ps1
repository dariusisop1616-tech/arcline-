<#
    Host-side control of the lab VM. Dot-source it:  . .\tools\host\vmctl.ps1

    Everything runs through VirtualBox Guest Additions, so the host is never
    modified and the guest needs no network exposure.

      Push-Lab                      copy tools/ into the guest's C:\lab
      Invoke-Lab 'hostname'         run a PowerShell command in the guest
      Get-LabFile 'results\a.txt'   pull a file back to the host
      New-LabSnapshot 'clean'       snapshot before an experiment
      Restore-LabSnapshot 'clean'   roll back after one
      Get-LabShot                   screenshot the guest console
#>

$script:VBM  = "$env:ProgramFiles\Oracle\VirtualBox\VBoxManage.exe"
$script:VM   = 'fp-lab'
$script:User = 'lab'
$script:Pass = 'Lab12345!'
$script:Repo = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$script:Out  = Join-Path $env:TEMP 'fp-lab'

function Invoke-Lab {
    param([Parameter(Mandatory)][string]$Command, [int]$TimeoutMs = 600000)
    & $VBM guestcontrol $VM run --username $User --password $Pass --timeout $TimeoutMs `
        --exe 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -- `
        powershell -NoProfile -ExecutionPolicy Bypass -Command $Command 2>&1
}

function Push-LabFile {
    param([Parameter(Mandatory)][string]$Source, [Parameter(Mandatory)][string]$Dest)
    & $VBM guestcontrol $VM copyto --username $User --password $Pass --target-directory $Dest $Source 2>&1
}

function Push-Lab {
    Invoke-Lab 'New-Item -ItemType Directory -Force C:\lab,C:\lab\results | Out-Null' | Out-Null
    Push-LabFile (Join-Path $Repo 'tools\fingerprint-probe.html') 'C:\lab\'
    foreach ($f in Get-ChildItem (Join-Path $Repo 'tools\guest') -Filter *.ps1) {
        Push-LabFile $f.FullName 'C:\lab\'
    }
    'pushed probe + guest scripts to C:\lab'
}

function Get-LabFile {
    param([Parameter(Mandatory)][string]$GuestRelPath)
    New-Item -ItemType Directory -Force $Out | Out-Null
    $dest = Join-Path $Out (Split-Path $GuestRelPath -Leaf)
    & $VBM guestcontrol $VM copyfrom --username $User --password $Pass `
        --target-directory $Out "C:\lab\$GuestRelPath" 2>&1 | Out-Null
    if (Test-Path $dest) { Get-Content $dest -Raw } else { "<<could not pull $GuestRelPath>>" }
}

function New-LabSnapshot { param([Parameter(Mandatory)][string]$Name) & $VBM snapshot $VM take $Name --pause 2>&1 }
function Restore-LabSnapshot { param([Parameter(Mandatory)][string]$Name)
    & $VBM controlvm $VM poweroff 2>&1 | Out-Null
    & $VBM snapshot $VM restore $Name 2>&1
    & $VBM startvm $VM --type headless 2>&1
}
function Get-LabShot {
    New-Item -ItemType Directory -Force $Out | Out-Null
    $p = Join-Path $Out ('shot-' + (Get-Date -Format HHmmss) + '.png')
    & $VBM controlvm $VM screenshotpng $p 2>&1 | Out-Null
    $p
}
function Set-LabResolution { param([int]$Width, [int]$Height)
    & $VBM controlvm $VM setvideomodehint $Width $Height 32 2>&1
}
