<#
    TASK 1, level (b): install the proxy dxgi.dll into the guest's Edge application
    directory and measure whether WebGL reports the configured GPU.

    Application-directory redirection: msedge.exe loads dxgi.dll from its own folder
    before System32 (dxgi is not a KnownDLL). We drop:
        <EdgeDir>\dxgi.dll        our proxy
        <EdgeDir>\dxgi_orig.dll   copy of the real System32 dxgi.dll
    plus C:\ProgramData\fplab\gpu.ini with the descriptor to report.

    Nothing global is touched; uninstall = delete the two files.
#>
param(
    [string]$VmName    = 'fp-hv',
    [string]$Repo      = 'C:\Users\Darkking1\Desktop\similar to gologin',
    [string]$OutDir    = 'E:\HyperV\results',
    [string]$LogPath   = 'E:\HyperV\task1b.log',
    [string]$GpuName   = 'AMD Radeon RX 580',
    [int]   $VendorId  = 0x1002,
    [int]   $DeviceId  = 0x67DF,
    [string]$GuestUser = 'lab',
    [string]$GuestPass = 'Lab12345!'
)

$ErrorActionPreference = 'Continue'
New-Item -ItemType Directory -Force $OutDir | Out-Null
Remove-Item $LogPath -ErrorAction SilentlyContinue
function W($s) { "$(Get-Date -Format HH:mm:ss) $s" | Out-File $LogPath -Append -Encoding utf8 }
$cred = New-Object PSCredential($GuestUser, (ConvertTo-SecureString $GuestPass -AsPlainText -Force))
function Conn { $t=(Get-Date).AddMinutes(6); while((Get-Date) -lt $t){ try { return New-PSSession -VMName $VmName -Credential $cred -ErrorAction Stop } catch { Start-Sleep 10 } }; $null }

W "START as $(whoami)  gpu='$GpuName' vid=$('0x{0:X4}' -f $VendorId) did=$('0x{0:X4}' -f $DeviceId)"

W 'checkpoint before install'
Checkpoint-VM -Name $VmName -SnapshotName "pre-proxy-$(Get-Date -Format HHmmss)" -ErrorAction SilentlyContinue

$s = Conn
if (-not $s) { W 'no session'; exit 1 }

# locate Edge and its app dir
$edge = Invoke-Command -Session $s -ScriptBlock {
    foreach ($p in 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
                   'C:\Program Files\Microsoft\Edge\Application\msedge.exe') {
        if (Test-Path $p) { return $p }
    }
}
if (-not $edge) { W 'Edge not found in guest'; Remove-PSSession $s; exit 1 }
$edgeDir = Split-Path $edge -Parent
W "edge dir: $edgeDir"

# push proxy DLL
Invoke-Command -Session $s -ScriptBlock { New-Item -ItemType Directory -Force 'C:\lab','C:\ProgramData\fplab' | Out-Null }
Copy-Item -ToSession $s -Path (Join-Path $Repo 'tools\gpu-descriptor\build\dxgi.dll') -Destination 'C:\lab\proxy_dxgi.dll' -Force
Copy-Item -ToSession $s -Path (Join-Path $Repo 'tools\fingerprint-probe.html') -Destination 'C:\lab\' -Force
foreach ($f in Get-ChildItem (Join-Path $Repo 'tools\guest') -Filter *.ps1) { Copy-Item -ToSession $s -Path $f.FullName -Destination 'C:\lab\' -Force }

# write config + install into edge dir
$installOut = Invoke-Command -Session $s -ArgumentList $edgeDir, $GpuName, $VendorId, $DeviceId -ScriptBlock {
    param($dir, $name, $vid, $did)
    # config the proxy reads
    $ini = "Name=$name`r`nVendorId=0x{0:X4}`r`nDeviceId=0x{1:X4}`r`nSubSysId=0x21F01462`r`nRevision=0xE7`r`nLog=1`r`n" -f $vid, $did
    Set-Content 'C:\ProgramData\fplab\gpu.ini' $ini -Encoding UTF8 -NoNewline
    Remove-Item 'C:\ProgramData\fplab\dxgi_proxy.log' -ErrorAction SilentlyContinue

    $sys = 'C:\Windows\System32\dxgi.dll'
    $orig = Join-Path $dir 'dxgi_orig.dll'
    $prox = Join-Path $dir 'dxgi.dll'
    try {
        Copy-Item $sys $orig -Force -ErrorAction Stop           # real dxgi as _orig
        Copy-Item 'C:\lab\proxy_dxgi.dll' $prox -Force -ErrorAction Stop
        "installed: $prox ($(( Get-Item $prox ).Length) bytes), $orig ($(( Get-Item $orig ).Length) bytes)"
    } catch {
        "INSTALL FAILED (need admin on Program Files?): $($_.Exception.Message)"
    }
} 2>&1
$installOut | ForEach-Object { W ($_ | Out-String).TrimEnd() }

# probe edge WITH proxy in place
W '--- probing Edge with proxy ---'
Invoke-Command -Session $s -ScriptBlock {
    & 'C:\lab\run-probe.ps1' -Tag 'proxy-edge' -Browser edge -ChromeFlags @('--use-angle=d3d11') | Out-Null
} 2>&1 | ForEach-Object { W ($_ | Out-String).TrimEnd() }
try {
    Copy-Item -FromSession $s -Path 'C:\lab\results\proxy-edge.txt' -Destination (Join-Path $OutDir 'proxy-edge.txt') -Force
    $t = Get-Content (Join-Path $OutDir 'proxy-edge.txt') -Raw
    foreach ($k in 'webgl\.UNMASKED_VENDOR','webgl\.UNMASKED_RENDERER','webgl\.MAX_TEXTURE_SIZE','webgl\.extHash','webgl2\.UNMASKED_RENDERER') {
        $m = [regex]::Match($t, $k + '\s*:\s*(.*)')
        W ("  " + $k.Replace('\','') + " = " + $(if($m.Success){$m.Groups[1].Value.Trim()}else{'-'}))
    }
} catch { W "pull failed: $($_.Exception.Message)" }

# grab the proxy's own log to see if it patched
W '--- proxy internal log ---'
try {
    Copy-Item -FromSession $s -Path 'C:\ProgramData\fplab\dxgi_proxy.log' -Destination (Join-Path $OutDir 'dxgi_proxy.log') -Force -ErrorAction Stop
    Get-Content (Join-Path $OutDir 'dxgi_proxy.log') | ForEach-Object { W "  $_" }
} catch { W "  (no proxy log written - DLL may not have loaded)" }

Remove-PSSession $s
W 'DONE'
