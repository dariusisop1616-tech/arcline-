<#
    TASK 1, level (a): can the guest registry rename the GPU that WebGL reports?

    Baselines Chrome and Edge, lists the guest's display adapters, rewrites their
    name strings to an AMD card, reboots, and re-probes both browsers.

    Prediction on record before running: this FAILS under GPU-PV, because the guest
    already reports NVIDIA's real device id 0x2489 while Windows enumerates the
    adapter as Microsoft's VEN_1414&DEV_008E - meaning DXGI takes its description
    from the host, not from the guest's PnP registry.
#>
param(
    [string]$VmName    = 'fp-hv',
    [string]$Repo      = 'C:\Users\Darkking1\Desktop\similar to gologin',
    [string]$FakeGpu   = 'AMD Radeon RX 580',
    [string]$OutDir    = 'E:\HyperV\results',
    [string]$LogPath   = 'E:\HyperV\task1.log',
    [string]$GuestUser = 'lab',
    [string]$GuestPass = 'Lab12345!'
)

$ErrorActionPreference = 'Continue'
New-Item -ItemType Directory -Force $OutDir | Out-Null
Remove-Item $LogPath -ErrorAction SilentlyContinue
function W($s) { "$(Get-Date -Format HH:mm:ss) $s" | Out-File $LogPath -Append -Encoding utf8 }
$cred = New-Object PSCredential($GuestUser, (ConvertTo-SecureString $GuestPass -AsPlainText -Force))

function Connect-Guest {
    param([int]$Minutes = 8)
    $t = (Get-Date).AddMinutes($Minutes)
    while ((Get-Date) -lt $t) {
        try { return New-PSSession -VMName $VmName -Credential $cred -ErrorAction Stop } catch { Start-Sleep -Seconds 15 }
    }
    return $null
}

function Sync-Tools($s) {
    Invoke-Command -Session $s -ScriptBlock { New-Item -ItemType Directory -Force 'C:\lab','C:\lab\results' | Out-Null }
    Copy-Item -ToSession $s -Path (Join-Path $Repo 'tools\fingerprint-probe.html') -Destination 'C:\lab\' -Force
    foreach ($f in Get-ChildItem (Join-Path $Repo 'tools\guest') -Filter *.ps1) {
        Copy-Item -ToSession $s -Path $f.FullName -Destination 'C:\lab\' -Force
    }
}

function Probe($s, $tag, $browser) {
    Invoke-Command -Session $s -ArgumentList $tag, $browser -ScriptBlock {
        param($t, $b)
        & 'C:\lab\run-probe.ps1' -Tag $t -Browser $b -ChromeFlags @('--use-angle=d3d11') | Out-Null
    } 2>&1 | ForEach-Object { W ($_ | Out-String).TrimEnd() }
    try {
        Copy-Item -FromSession $s -Path "C:\lab\results\$tag.txt" -Destination (Join-Path $OutDir "$tag.txt") -Force -ErrorAction Stop
        $t = Get-Content (Join-Path $OutDir "$tag.txt") -Raw
        $m = [regex]::Match($t, 'webgl\.UNMASKED_RENDERER\s*:\s*(.*)')
        W ("  $tag => " + $(if ($m.Success) { $m.Groups[1].Value.Trim() } else { 'NO WEBGL' }))
    } catch { W "  pull failed for ${tag}: $($_.Exception.Message)" }
}

W "START as $(whoami)  fake='$FakeGpu'"
$s = Connect-Guest
if (-not $s) { W 'guest unreachable'; exit 1 }
Sync-Tools $s

W '=== is Edge present? ==='
Invoke-Command -Session $s -ScriptBlock {
    foreach ($p in 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
                   'C:\Program Files\Microsoft\Edge\Application\msedge.exe') {
        if (Test-Path $p) { "  FOUND $p  v$((Get-Item $p).VersionInfo.ProductVersion)" }
    }
} 2>&1 | ForEach-Object { W ($_ | Out-String).TrimEnd() }

W '=== guest display adapters BEFORE ==='
Invoke-Command -Session $s -ScriptBlock { & 'C:\lab\apply-profile.ps1' -ListAdapters } 2>&1 |
    ForEach-Object { W ($_ | Out-String).TrimEnd() }

W '=== baseline probes ==='
Probe $s 'rn-before-chrome' 'chrome'
Probe $s 'rn-before-edge'   'edge'

W "=== renaming NVIDIA adapters to '$FakeGpu' ==="
Invoke-Command -Session $s -ArgumentList $FakeGpu -ScriptBlock {
    param($n)
    & 'C:\lab\apply-profile.ps1' -GpuName $n -MatchDriverDesc 'NVIDIA|Radeon|Hyper-V'
} 2>&1 | ForEach-Object { W ($_ | Out-String).TrimEnd() }

Remove-PSSession $s
W '=== rebooting guest ==='
Restart-VM $VmName -Force -Wait -ErrorAction SilentlyContinue
$s = Connect-Guest
if (-not $s) { W 'guest did not come back'; exit 1 }
W 'guest back up'
Sync-Tools $s

W '=== guest display adapters AFTER ==='
Invoke-Command -Session $s -ScriptBlock {
    & 'C:\lab\apply-profile.ps1' -ListAdapters
    '--- what Windows reports ---'
    Get-CimInstance Win32_VideoController | ForEach-Object { "  $($_.Name) | $($_.PNPDeviceID)" }
} 2>&1 | ForEach-Object { W ($_ | Out-String).TrimEnd() }

W '=== probes AFTER rename ==='
Probe $s 'rn-after-chrome' 'chrome'
Probe $s 'rn-after-edge'   'edge'

Remove-PSSession $s
W 'DONE'
