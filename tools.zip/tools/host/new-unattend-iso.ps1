<#
    Builds a small data ISO carrying autounattend.xml, using the IMAPI2 COM component
    that ships with Windows - no Windows ADK / oscdimg required.

    Windows Setup scans attached media for autounattend.xml, so mounting this as a
    second DVD is enough to drive an unattended install on Hyper-V, which has no
    equivalent of "VBoxManage unattended install".
#>
param(
    [string]$SourceFile = (Join-Path $PSScriptRoot 'autounattend.xml'),
    [string]$OutIso     = 'E:\HyperV\unattend.iso',
    [string]$VolumeName = 'UNATTEND'
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path $SourceFile)) { throw "answer file not found: $SourceFile" }
New-Item -ItemType Directory -Force (Split-Path $OutIso -Parent) | Out-Null

# staging folder holding exactly what lands on the disc
$stage = Join-Path $env:TEMP ('isostage-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force $stage | Out-Null
Copy-Item $SourceFile (Join-Path $stage 'autounattend.xml')

if (-not ('ISOFile' -as [type])) {
    $cs = @'
public class ISOFile {
    public unsafe static void Create(string Path, object Stream, int BlockSize, int TotalBlocks) {
        int bytes = 0;
        byte[] buf = new byte[BlockSize];
        var ptr = (System.IntPtr)(&bytes);
        var o = System.IO.File.OpenWrite(Path);
        var i = Stream as System.Runtime.InteropServices.ComTypes.IStream;
        if (o != null) {
            while (TotalBlocks-- > 0) { i.Read(buf, BlockSize, ptr); o.Write(buf, 0, bytes); }
            o.Flush(); o.Close();
        }
    }
}
'@
    $cp = New-Object CodeDom.Compiler.CompilerParameters
    $cp.CompilerOptions = '/unsafe'
    $cp.WarningLevel = 4
    Add-Type -CompilerParameters $cp -TypeDefinition $cs
}

$fsi = New-Object -ComObject IMAPI2FS.MsftFileSystemImage
$fsi.FileSystemsToCreate = 3          # ISO9660 + Joliet
$fsi.VolumeName = $VolumeName
$fsi.Root.AddTree($stage, $false)

$img = $fsi.CreateResultImage()
Remove-Item $OutIso -ErrorAction SilentlyContinue
[ISOFile]::Create($OutIso, $img.ImageStream, $img.BlockSize, $img.TotalBlocks)

Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue

if (Test-Path $OutIso) {
    "created: $OutIso  ({0} KB)" -f [math]::Round((Get-Item $OutIso).Length / 1KB, 1)
} else {
    throw 'ISO creation produced no file'
}
