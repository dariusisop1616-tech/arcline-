<#
    TASK 1, level (c): install the proxy dxgi.dll into the guest's System32.

    Chromium forces LOAD_LIBRARY_SEARCH_SYSTEM32 for system DLLs, so the proxy must
    live in System32 to be seen. We rename the in-use original to dxgi_orig.dll
    (NTFS allows renaming a mapped binary) and drop the proxy in as dxgi.dll.

    The proxy forwards all exports and only rewrites the adapter descriptor inside
    msedge.exe / chrome.exe, so dwm.exe and the rest of the desktop are unaffected.
    A checkpoint is taken first; if the guest fails to return after reboot the
    script restores it automatically.
#>
param(
    [string]$VmName    = 'fp-hv',
    [string]$Repo      = 'C:\Users\Darkking1\Desktop\similar to gologin',
    [string]$OutDir    = 'E:\HyperV\results',
    [string]$LogPath   = 'E:\HyperV\task1c.log',
    [string]$GpuName   = 'AMD Radeon RX 580',
    [int]   $VendorId  = 0x1002,
    [int]   $DeviceId  = 0x67DF,
    [string]$GuestUser = 'lab',
    [string]$GuestPass = 'Lab12345!'
)

$ErrorActionPreference = 'Continue'
New-Item -ItemType Directory -Force $OutDir | Out-Null
Remove-Item $LogPath -ErrorAction SilentlyContinue
function W($s) { "$(Get-Date -Format HH:mm:ss) $s" | Out-File $LogPath -Append -Encoding utf8 }
$cred = New-Object PSCredential($GuestUser, (ConvertTo-SecureString $GuestPass -AsPlainText -Force))
function Conn { $t=(Get-Date).AddMinutes(6); while((Get-Date) -lt $t){ try { return New-PSSession -VMName $VmName -Credential $cred -ErrorAction Stop } catch { Start-Sleep 10 } }; $null }

W "START as $(whoami)  gpu='$GpuName'"
$snap = "pre-sys32-$(Get-Date -Format HHmmss)"
Checkpoint-VM -Name $VmName -SnapshotName $snap -ErrorAction SilentlyContinue
W "checkpoint: $snap"

$s = Conn
if (-not $s) { W 'no session'; exit 1 }

# clean up the earlier app-dir attempt so results are unambiguous
Invoke-Command -Session $s -ScriptBlock {
    foreach ($p in 'C:\Program Files (x86)\Microsoft\Edge\Application\dxgi.dll',
                   'C:\Program Files (x86)\Microsoft\Edge\Application\dxgi_orig.dll') {
        Remove-Item $p -Force -ErrorAction SilentlyContinue
    }
} 2>&1 | Out-Null

# push proxy + config + tools
Invoke-Command -Session $s -ScriptBlock { New-Item -ItemType Directory -Force 'C:\lab','C:\ProgramData\fplab' | Out-Null }
Copy-Item -ToSession $s -Path (Join-Path $Repo 'tools\gpu-descriptor\build\dxgi.dll') -Destination 'C:\lab\proxy_dxgi.dll' -Force
Copy-Item -ToSession $s -Path (Join-Path $Repo 'tools\fingerprint-probe.html') -Destination 'C:\lab\' -Force
foreach ($f in Get-ChildItem (Join-Path $Repo 'tools\guest') -Filter *.ps1) { Copy-Item -ToSession $s -Path $f.FullName -Destination 'C:\lab\' -Force }

$install = Invoke-Command -Session $s -ArgumentList $GpuName, $VendorId, $DeviceId -ScriptBlock {
    param($name, $vid, $did)
    $ini = "Name=$name`r`nVendorId=0x{0:X4}`r`nDeviceId=0x{1:X4}`r`nSubSysId=0x21F01462`r`nRevision=0xE7`r`nLog=1`r`n" -f $vid, $did
    Set-Content 'C:\ProgramData\fplab\gpu.ini' $ini -Encoding UTF8 -NoNewline
    Remove-Item 'C:\ProgramData\fplab\dxgi_proxy.log' -ErrorAction SilentlyContinue

    $sys = 'C:\Windows\System32'
    $dxgi = Join-Path $sys 'dxgi.dll'
    $orig = Join-Path $sys 'dxgi_orig.dll'
    if (Test-Path $orig) { "already installed (dxgi_orig.dll present) - refreshing proxy only" }
    else {
        # seize the file from TrustedInstaller
        & takeown.exe /f $dxgi | Out-Null
        & icacls.exe $dxgi /grant "*S-1-5-32-544:F" | Out-Null   # BUILTIN\Administrators
        try {
            Rename-Item $dxgi 'dxgi_orig.dll' -ErrorAction Stop   # rename in-use mapped binary
            "renamed original -> dxgi_orig.dll"
        } catch { return "RENAME FAILED: $($_.Exception.Message)" }
    }
    try {
        Copy-Item 'C:\lab\proxy_dxgi.dll' $dxgi -Force -ErrorAction Stop
        "proxy in place: $((Get-Item $dxgi).Length) bytes; orig: $((Get-Item $orig).Length) bytes"
    } catch { "COPY FAILED: $($_.Exception.Message)" }
} 2>&1
$install | ForEach-Object { W ($_ | Out-String).TrimEnd() }

Remove-PSSession $s
W 'rebooting guest so all processes reload dxgi'
Restart-VM $VmName -Force -Wait -ErrorAction SilentlyContinue

$s = Conn
if (-not $s) {
    W 'GUEST DID NOT RETURN - restoring checkpoint'
    Stop-VM $VmName -TurnOff -Force -ErrorAction SilentlyContinue
    Restore-VMCheckpoint -Name $snap -VMName $VmName -Confirm:$false -ErrorAction SilentlyContinue
    Start-VM $VmName -ErrorAction SilentlyContinue
    W 'checkpoint restored; guest reverted to pre-install state'
    exit 1
}
W 'guest back up after System32 swap'

Invoke-Command -Session $s -ScriptBlock { New-Item -ItemType Directory -Force 'C:\lab\results' | Out-Null }
W '--- probing Edge with System32 proxy ---'
Invoke-Command -Session $s -ScriptBlock {
    & 'C:\lab\run-probe.ps1' -Tag 'sys32-edge'   -Browser edge   -ChromeFlags @('--use-angle=d3d11') | Out-Null
    & 'C:\lab\run-probe.ps1' -Tag 'sys32-chrome' -Browser chrome -ChromeFlags @('--use-angle=d3d11') | Out-Null
} 2>&1 | ForEach-Object { W ($_ | Out-String).TrimEnd() }

foreach ($tag in 'sys32-edge','sys32-chrome') {
    try {
        Copy-Item -FromSession $s -Path "C:\lab\results\$tag.txt" -Destination (Join-Path $OutDir "$tag.txt") -Force
        $t = Get-Content (Join-Path $OutDir "$tag.txt") -Raw
        W "  [$tag]"
        foreach ($k in 'webgl\.UNMASKED_VENDOR','webgl\.UNMASKED_RENDERER','webgl\.MAX_TEXTURE_SIZE','webgl\.extHash','webgl\.renderHash') {
            $m = [regex]::Match($t, $k + '\s*:\s*(.*)')
            W ("     " + $k.Replace('\','') + " = " + $(if($m.Success){$m.Groups[1].Value.Trim()}else{'-'}))
        }
    } catch { W "  pull failed ${tag}: $($_.Exception.Message)" }
}

W '--- desktop still healthy? (dwm running) ---'
Invoke-Command -Session $s -ScriptBlock {
    "  dwm: $((Get-Process dwm -ErrorAction SilentlyContinue | Measure-Object).Count) proc"
    "  explorer: $((Get-Process explorer -ErrorAction SilentlyContinue | Measure-Object).Count) proc"
} 2>&1 | ForEach-Object { W ($_ | Out-String).TrimEnd() }

W '--- proxy internal log ---'
try {
    Copy-Item -FromSession $s -Path 'C:\ProgramData\fplab\dxgi_proxy.log' -Destination (Join-Path $OutDir 'dxgi_proxy.log') -Force -ErrorAction Stop
    Get-Content (Join-Path $OutDir 'dxgi_proxy.log') | ForEach-Object { W "  $_" }
} catch { W "  (no proxy log)" }

Remove-PSSession $s
W "DONE (checkpoint $snap retained for rollback)"
