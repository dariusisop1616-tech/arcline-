<#
    Elevated. Waits for the lab guest to finish OOBE, then provisions it over
    PowerShell Direct (VMBus - no network, no guest agent required), installs
    stock Chrome, and runs the baseline fingerprint probe.

    One UAC prompt covers the whole run; results land on the host for the
    unelevated session to read.
#>
param(
    [string]$VmName   = 'fp-hv',
    [string]$Repo     = 'C:\Users\Darkking1\Desktop\similar to gologin',
    [string]$OutDir   = 'E:\HyperV\results',
    [string]$LogPath  = 'E:\HyperV\provision.log',
    [string]$GuestUser = 'lab',
    [string]$GuestPass = 'Lab12345!',
    [int]   $WaitMinutes = 15
)

$ErrorActionPreference = 'Continue'
New-Item -ItemType Directory -Force $OutDir | Out-Null
Remove-Item $LogPath -ErrorAction SilentlyContinue
function W($s) { "$(Get-Date -Format HH:mm:ss) $s" | Out-File $LogPath -Append -Encoding utf8 }

W "START as $(whoami)"

$cred = New-Object PSCredential($GuestUser, (ConvertTo-SecureString $GuestPass -AsPlainText -Force))

# --- 1. wait for PowerShell Direct to answer (means OOBE is done and the user is logged on)
$s = $null
$deadline = (Get-Date).AddMinutes($WaitMinutes)
while ((Get-Date) -lt $deadline) {
    try {
        $s = New-PSSession -VMName $VmName -Credential $cred -ErrorAction Stop
        W 'PowerShell Direct session established'
        break
    } catch {
        W "waiting for guest... ($($_.Exception.Message.Split([Environment]::NewLine)[0]))"
        Start-Sleep -Seconds 20
    }
}
if (-not $s) { W 'FAILED: guest never became reachable'; exit 1 }

# --- 2. what did we actually install?
W '--- guest identity ---'
Invoke-Command -Session $s -ScriptBlock {
    $ci = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    "edition      : $($ci.ProductName) / $($ci.EditionID)"
    "build        : $($ci.CurrentBuild).$($ci.UBR)"
    "computername : $env:COMPUTERNAME"
    "timezone     : $((Get-TimeZone).Id)"
    "locale       : $((Get-WinSystemLocale).Name)"
    "cpu count    : $((Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors)"
    "RAM GB       : $([math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,1))"
    '--- video controllers ---'
    Get-CimInstance Win32_VideoController | ForEach-Object { "  $($_.Name) | $($_.DriverVersion) | $($_.PNPDeviceID)" }
    '--- internet? ---'
    try { $r = Invoke-WebRequest -UseBasicParsing -Uri 'http://www.msftconnecttest.com/connecttest.txt' -TimeoutSec 15; "connectivity : OK ($($r.StatusCode))" }
    catch { "connectivity : FAILED - $($_.Exception.Message)" }
} 2>&1 | ForEach-Object { W $_ }

# --- 3. push the probe and guest scripts
W '--- pushing tools ---'
Invoke-Command -Session $s -ScriptBlock { New-Item -ItemType Directory -Force 'C:\lab','C:\lab\results' | Out-Null }
Copy-Item -ToSession $s -Path (Join-Path $Repo 'tools\fingerprint-probe.html') -Destination 'C:\lab\' -Force
foreach ($f in Get-ChildItem (Join-Path $Repo 'tools\guest') -Filter *.ps1) {
    Copy-Item -ToSession $s -Path $f.FullName -Destination 'C:\lab\' -Force
}
Invoke-Command -Session $s -ScriptBlock { Get-ChildItem C:\lab | Select-Object Name,Length } 2>&1 |
    ForEach-Object { W ($_ | Out-String).Trim() }

# --- 4. install stock Chrome
W '--- installing Chrome (stock, unmodified) ---'
Invoke-Command -Session $s -ScriptBlock {
    $chrome = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
    if (Test-Path $chrome) { return "already installed: $((Get-Item $chrome).VersionInfo.ProductVersion)" }
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $msi = 'C:\lab\chrome.msi'
        Invoke-WebRequest -UseBasicParsing -OutFile $msi 'https://dl.google.com/dl/chrome/install/googlechromestandaloneenterprise64.msi'
        Start-Process msiexec.exe -Wait -ArgumentList '/i', "`"$msi`"", '/qn', '/norestart'
        if (Test-Path $chrome) { "installed: $((Get-Item $chrome).VersionInfo.ProductVersion)" } else { 'INSTALL FAILED' }
    } catch { "download/install error: $($_.Exception.Message)" }
} 2>&1 | ForEach-Object { W $_ }

# --- 5. baseline probe
W '--- running baseline probe ---'
Invoke-Command -Session $s -ScriptBlock {
    & 'C:\lab\run-probe.ps1' -Tag 'vm-baseline'
} 2>&1 | ForEach-Object { W $_ }

# --- 6. pull results back
try {
    Copy-Item -FromSession $s -Path 'C:\lab\results\vm-baseline.txt' -Destination (Join-Path $OutDir 'vm-baseline.txt') -Force
    W "pulled results -> $OutDir\vm-baseline.txt"
} catch { W "pull failed: $($_.Exception.Message)" }

Remove-PSSession $s
W 'DONE'
