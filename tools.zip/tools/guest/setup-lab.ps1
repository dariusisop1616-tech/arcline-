<#
    Runs INSIDE the lab VM, once, elevated.
    Installs stock Chrome (no patching anywhere in this project) and prepares C:\lab.
#>
param([string]$LabDir = 'C:\lab')

$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force $LabDir, "$LabDir\results" | Out-Null

$chrome = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
if (-not (Test-Path $chrome)) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $msi = "$LabDir\chrome.msi"
    Invoke-WebRequest -UseBasicParsing -OutFile $msi `
        'https://dl.google.com/dl/chrome/install/googlechromestandaloneenterprise64.msi'
    Start-Process msiexec.exe -Wait -ArgumentList '/i', "`"$msi`"", '/qn', '/norestart'
    Remove-Item $msi -ErrorAction SilentlyContinue
}

if (Test-Path $chrome) {
    'chrome: ' + (Get-Item $chrome).VersionInfo.ProductVersion
} else {
    'chrome: INSTALL FAILED'
}

# what the guest thinks its graphics hardware is, before we touch anything
Get-CimInstance Win32_VideoController |
    Select-Object Name, DriverVersion, PNPDeviceID |
    Format-List

'timezone: ' + (Get-TimeZone).Id
'locale  : ' + (Get-WinSystemLocale).Name
