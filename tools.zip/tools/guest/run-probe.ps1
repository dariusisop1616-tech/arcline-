<#
    Runs INSIDE the lab VM. Launches a stock browser headless against the probe
    page and saves the extracted results under C:\lab\results\<Tag>.txt.

      .\run-probe.ps1 -Tag d3d11
      .\run-probe.ps1 -Tag edge-base -Browser edge -ChromeFlags '--use-angle=d3d11'
#>
param(
    [string]$Tag = 'baseline',
    [ValidateSet('chrome', 'edge')]
    [string]$Browser = 'chrome',
    [string[]]$ChromeFlags = @(),
    [string]$LabDir = 'C:\lab'
)

$exe = switch ($Browser) {
    'chrome' { 'C:\Program Files\Google\Chrome\Application\chrome.exe' }
    'edge'   { 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe' }
}
if (-not (Test-Path $exe)) {
    # Edge is 64-bit on some builds
    $alt = 'C:\Program Files\Microsoft\Edge\Application\msedge.exe'
    if ($Browser -eq 'edge' -and (Test-Path $alt)) { $exe = $alt }
    else { throw "$Browser not found at $exe" }
}

$page = 'file:///' + ($LabDir -replace '\\', '/') + '/fingerprint-probe.html'
$raw  = Join-Path $LabDir "raw_$Tag.html"
Remove-Item $raw -ErrorAction SilentlyContinue

$argList = @(
    '--headless=new', '--dump-dom', '--virtual-time-budget=12000',
    '--no-first-run', '--no-default-browser-check', '--disable-extensions',
    "--user-data-dir=$LabDir\cd_$Tag"
) + $ChromeFlags + @($page)

# chrome.exe / msedge.exe are GUI-subsystem binaries. Run from a context with no
# console - a PowerShell Direct session, a service, a scheduled task - their
# --dump-dom output goes to a stdout that does not exist and is silently lost.
# Redirecting to a real file handle is what makes it capturable.
$p = Start-Process -FilePath $exe -ArgumentList $argList `
        -RedirectStandardOutput $raw -NoNewWindow -PassThru -Wait

$text = if (Test-Path $raw) { Get-Content $raw -Raw } else { '' }
$m = [regex]::Match($text, '(?s)<pre id="out">(.*?)</pre>')
$out = if ($m.Success) { $m.Groups[1].Value }
       else { "<<no pre captured; raw bytes=$($text.Length); exit=$($p.ExitCode); exe=$exe>>" }

New-Item -ItemType Directory -Force "$LabDir\results" | Out-Null
$out | Set-Content "$LabDir\results\$Tag.txt" -Encoding utf8
$out
