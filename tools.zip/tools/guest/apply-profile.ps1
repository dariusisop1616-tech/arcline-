<#
    Runs INSIDE the lab VM, elevated. Applies one profile's OS-level fingerprint
    levers and reports what changed. GPU name edits are backed up so the guest can
    be restored without a snapshot rollback.

    Examples:
      .\apply-profile.ps1 -ListAdapters
      .\apply-profile.ps1 -GpuName 'AMD Radeon RX 580' -MatchDriverDesc 'NVIDIA'
      .\apply-profile.ps1 -RestoreGpu
#>
param(
    [switch]$ListAdapters,     # just show every display-class subkey and its strings
    [string]$GpuName,          # new adapter name to write
    [string]$MatchDriverDesc,  # only touch adapters whose DriverDesc matches this (regex)
    [switch]$RestoreGpu,
    [string]$TimeZone,
    [string]$Locale,
    [string[]]$UnregisterFont,
    [string]$LabDir = 'C:\lab'
)

$ErrorActionPreference = 'Stop'
$DisplayClass = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
$BackupFile = Join-Path $LabDir 'gpu-name-backup.json'
$Names = 'DriverDesc', 'HardwareInformation.AdapterString', 'HardwareInformation.ChipType',
         'HardwareInformation.DacType', 'HardwareInformation.BiosString'

function Read-Strings($path) {
    $p = Get-ItemProperty $path -ErrorAction SilentlyContinue
    $o = [ordered]@{}
    foreach ($n in $Names) {
        $v = $p.$n
        if ($v -is [byte[]]) { $o[$n] = ([Text.Encoding]::Unicode.GetString($v)).Trim([char]0) }
        elseif ($null -ne $v) { $o[$n] = [string]$v }
    }
    $o
}

# every subkey that actually describes a display adapter
$adapters = Get-ChildItem $DisplayClass -ErrorAction SilentlyContinue | Where-Object {
    $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
    $p.PSObject.Properties.Name -contains 'DriverDesc'
}

if ($ListAdapters -or (-not $GpuName -and -not $RestoreGpu -and -not $TimeZone -and -not $Locale -and -not $UnregisterFont)) {
    foreach ($a in $adapters) {
        "[$($a.PSChildName)]"
        (Read-Strings $a.PSPath).GetEnumerator() | ForEach-Object { "   $($_.Key) = $($_.Value)" }
        $mp = (Get-ItemProperty $a.PSPath -ErrorAction SilentlyContinue).MatchingDeviceId
        if ($mp) { "   MatchingDeviceId = $mp" }
    }
    if ($ListAdapters) { return }
}

if ($GpuName) {
    $targets = $adapters
    if ($MatchDriverDesc) {
        $targets = $adapters | Where-Object {
            (Get-ItemProperty $_.PSPath).DriverDesc -match $MatchDriverDesc
        }
    }
    if (-not $targets) { throw "no display adapter matched '$MatchDriverDesc'" }

    if (-not (Test-Path $BackupFile)) {
        New-Item -ItemType Directory -Force $LabDir | Out-Null
        $backup = @{}
        foreach ($t in $targets) { $backup[$t.PSChildName] = Read-Strings $t.PSPath }
        $backup | ConvertTo-Json -Depth 4 | Set-Content $BackupFile -Encoding utf8
        "backed up original names -> $BackupFile"
    }

    # HardwareInformation.* are REG_BINARY UTF-16; DriverDesc is REG_SZ
    $bytes = [Text.Encoding]::Unicode.GetBytes($GpuName + [char]0)
    foreach ($t in $targets) {
        foreach ($n in 'HardwareInformation.AdapterString', 'HardwareInformation.ChipType') {
            Set-ItemProperty $t.PSPath -Name $n -Value $bytes -Type Binary -ErrorAction SilentlyContinue
        }
        Set-ItemProperty $t.PSPath -Name 'DriverDesc' -Value $GpuName -Type String -ErrorAction SilentlyContinue
        "renamed [$($t.PSChildName)] -> $GpuName"
    }
    'reboot the guest for DXGI to re-read these'
}

if ($RestoreGpu) {
    if (-not (Test-Path $BackupFile)) { throw "no backup at $BackupFile" }
    $b = Get-Content $BackupFile -Raw | ConvertFrom-Json
    foreach ($prop in $b.PSObject.Properties) {
        $path = Join-Path $DisplayClass $prop.Name
        foreach ($n in 'HardwareInformation.AdapterString', 'HardwareInformation.ChipType') {
            $v = $prop.Value.$n
            if ($v) { Set-ItemProperty $path -Name $n -Value ([Text.Encoding]::Unicode.GetBytes($v + [char]0)) -Type Binary -ErrorAction SilentlyContinue }
        }
        if ($prop.Value.DriverDesc) { Set-ItemProperty $path -Name 'DriverDesc' -Value $prop.Value.DriverDesc -Type String -ErrorAction SilentlyContinue }
        "restored [$($prop.Name)]"
    }
}

if ($TimeZone) { Set-TimeZone -Id $TimeZone; "timezone -> $TimeZone" }

if ($Locale) {
    Set-WinSystemLocale -SystemLocale $Locale
    Set-WinUILanguageOverride -Language $Locale
    Set-Culture $Locale
    Set-WinUserLanguageList (New-WinUserLanguageList $Locale) -Force
    "locale -> $Locale (reboot to apply)"
}

foreach ($f in $UnregisterFont) {
    $fk = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts'
    foreach ($p in (Get-ItemProperty $fk).PSObject.Properties | Where-Object { $_.Name -like "$f*" }) {
        Remove-ItemProperty $fk -Name $p.Name -ErrorAction SilentlyContinue
        "unregistered font: $($p.Name)"
    }
}
