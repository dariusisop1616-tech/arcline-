#!/bin/bash
# One line per workspace: display, noVNC health, Edge window title. Seconds-fast.
# With "wait", keep polling (max ~6 min) until every workspace has an Edge window.
MODE="${1:-once}"
show() {
  up=0
  for ws in ws1 ws2 ws3; do
    source /root/workspaces/$ws/ws.conf
    t=$(DISPLAY=:$DISP wmctrl -l 2>/dev/null | grep -i edge | head -1 | cut -c32-120)
    rfb=$(timeout 2 bash -c "exec 3<>/dev/tcp/127.0.0.1/$VNC; head -c 3 <&3" 2>/dev/null)
    [ -n "$t" ] && up=$((up+1))
    printf '  %s  :%-3s %sx%s  vnc=%-3s  http://localhost:%s/vnc.html  %s\n' \
      $ws $DISP $SCREEN_W $SCREEN_H "${rfb:-no}" $WEB "${t:-(no Edge window yet)}"
  done
  free -m | awk 'NR==2{printf "  mem %s/%s MB", $3, $2} NR==3{printf "  swap %s MB\n", $3}'
  grep zram /proc/swaps | awk '{printf "  zram used %d MB\n", $4/1024}'
  return $((3 - up))
}
if [ "$MODE" = wait ]; then
  for i in $(seq 1 36); do show >/tmp/ws-status.txt && break; sleep 10; done
  cat /tmp/ws-status.txt
else
  show
fi
