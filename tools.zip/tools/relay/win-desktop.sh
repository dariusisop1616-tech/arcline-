#!/bin/bash
# A Windows-10-like desktop for one workspace: fluxbox manages windows WITHOUT
# its own toolbar, and tint2 draws a real taskbar (Start button, running-window
# buttons, clock) in a fixed 40px bar at the bottom. The browser still maximizes
# to exactly the area above the bar, so availHeight is unchanged.
N="${1:-ws1}"; R=/root/workspaces/$N; source $R/ws.conf
export DISPLAY=:$DISP
BAR=40; AVAIL=$((SCREEN_H - BAR))

# --- fluxbox: keep a 40px toolbar ONLY to reserve the taskbar strut, so
# browsers report availHeight = screen-40 (tint2's own strut is not honoured
# here). tint2 sits on top of it (panel_layer top) and provides the Windows look;
# fluxbox's bar is emptied of tools and colored to match, so it is not seen. ---
sed -i '/^session.screen0.toolbar/d' $R/fluxbox/init
cat >> $R/fluxbox/init <<EOF
session.screen0.toolbar.visible:	true
session.screen0.toolbar.height:	$BAR
session.screen0.toolbar.placement:	BottomCenter
session.screen0.toolbar.widthPercent:	100
session.screen0.toolbar.maxOver:	false
session.screen0.toolbar.tools:
session.screen0.toolbar.layer:	Bottom
EOF
# empty + same dark color as tint2, so fluxbox's strut bar is invisible under it
grep -q 'toolbar.color' $R/fluxbox/styles/win 2>/dev/null || \
  printf 'toolbar:\tflat solid\ntoolbar.color:\t#1f1f1f\n' >> $R/fluxbox/styles/win

# --- Start menu (an .desktop-free menu tint2 opens via a command) ---
cat > $R/startmenu.sh <<EOF
#!/bin/bash
# a tiny Windows-like Start menu using fluxbox's rootmenu at the pointer
DISPLAY=:$DISP xdotool key --clearmodifiers super 2>/dev/null
DISPLAY=:$DISP fluxbox-remote rootmenu 2>/dev/null || \
  DISPLAY=:$DISP $R/open.sh edge
EOF
chmod +x $R/startmenu.sh

# --- tint2 config: dark Windows 10 taskbar ---
cat > $R/tint2rc <<EOF
# background 1 = taskbar, 2 = active button, 3 = Start button
rounded = 0
border_width = 0
background_color = #1f1f1f 100
border_color = #1f1f1f 100

rounded = 0
border_width = 0
background_color = #2b2b2b 100
border_color = #0078d4 100

rounded = 0
border_width = 0
background_color = #0078d4 100
border_color = #0078d4 100

panel_monitor = all
panel_position = bottom center horizontal
panel_size = 100% $BAR
panel_margin = 0 0
panel_padding = 0 0 0
panel_background_id = 1
panel_items = LTSC
wm_menu = 0
panel_layer = top
# reserve the bar's space from the work area, so browsers report
# availHeight = screen - 40 exactly like the Windows taskbar does
strut_policy = follow_size
autohide = 0

# L = launcher (Start button)
launcher_padding = 8 0 8
launcher_background_id = 3
launcher_icon_size = 22
launcher_item_app = /usr/share/applications/tint2-start.desktop
launcher_icon_theme = hicolor

# T = taskbar (window buttons), left aligned like Windows
taskbar_mode = single_desktop
taskbar_padding = 4 0 4
taskbar_background_id = 1
task_align = left
task_maximum_size = 200 40
task_padding = 6 2 6
task_background_id = 1
task_active_background_id = 2
task_font = sans 9
task_font_color = #ffffff 100
task_active_font_color = #ffffff 100
task_icon = 1
task_text = 1

# S = system tray
systray_padding = 4 0 4
systray_background_id = 1
systray_icon_size = 18

# C = clock, right side like Windows
time1_format = %H:%M
time2_format = %d/%m/%Y
time1_font = sans 9
time2_font = sans 8
clock_font_color = #ffffff 100
clock_padding = 8 0
clock_background_id = 1
EOF

# Start button launcher entry -> opens the fluxbox root menu (Edge, Explorer)
mkdir -p /usr/share/applications
cat > /usr/share/applications/tint2-start.desktop <<EOF
[Desktop Entry]
Type=Application
Name=Start
Icon=start-here
Exec=$R/startmenu.sh
EOF

# --- restart the desktop stack ---
pkill -9 -f "tint2.*$N" 2>/dev/null
pkill -9 -f "fluxbox -display :$DISP" 2>/dev/null; sleep 1
command -v xsetroot >/dev/null && xsetroot -solid "#0b2545"
( setsid nohup fluxbox -display :$DISP -rc "$R/fluxbox/init" >"$R/logs/fluxbox.log" 2>&1 & )
sleep 2
( setsid nohup env TINT2_WS=$N tint2 -c $R/tint2rc >"$R/logs/tint2.log" 2>&1 & )
sleep 3
echo "[$N] tint2 taskbar up; availHeight target $AVAIL"
xdotool search --class tint2 >/dev/null 2>&1 && echo "  tint2 running" || echo "  tint2 NOT running: $(tail -2 $R/logs/tint2.log)"
