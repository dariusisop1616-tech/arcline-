#!/usr/bin/env python3
"""Rename one entry of Wine's GPU description table inside a wined3d.dll copy.

usage: set_gpu_name.py <wined3d.dll> "<current full name>" "<new name>"

Wine picks the adapter description from a table keyed by PCI vendor/device id
(the ids themselves come from the VideoPciVendorID/VideoPciDeviceID registry
overrides). Each prefix has its own copy of wined3d.dll in system32, so renaming
the entry in that copy gives each workspace its own name without touching the
shared Wine install or the browser.

The entry is a NUL-terminated string in the data section; the new name is
written in place and padded with NULs, so the file size and every offset stay
the same. The new name must not be longer than the old one.
"""
import sys, shutil, os

dll, old, new = sys.argv[1], sys.argv[2].encode(), sys.argv[3].encode()
if len(new) > len(old):
    sys.exit(f"new name is {len(new)} bytes, slot holds {len(old)}")
data = bytearray(open(dll, "rb").read())
needle = b"\x00" + old + b"\x00"          # the whole string, not a substring
hits = []
i = data.find(needle)
while i >= 0:
    hits.append(i + 1)
    i = data.find(needle, i + 1)
if not hits:
    sys.exit("entry not found (already renamed? check the .orig backup)")
if not os.path.exists(dll + ".orig"):
    shutil.copy2(dll, dll + ".orig")
for off in hits:
    data[off:off + len(old)] = new + b"\x00" * (len(old) - len(new))
tmp = dll + ".tmp"
open(tmp, "wb").write(data)
os.replace(tmp, dll)                     # atomic: never a half-written dll
print(f"renamed {len(hits)} entr{'y' if len(hits) == 1 else 'ies'} at {hits}: {old.decode()!r} -> {new.decode()!r}")
