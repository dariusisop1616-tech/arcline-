#!/bin/bash
# Does the file-upload dialog work, and does the site see the same fields as on
# Windows? Opens the probe, clicks the button, drives the dialog that appears
# with real keystrokes, and reports what the page received.
N="${1:-ws1}"; LABEL="${2:-upload_wine}"
R=/root/workspaces/$N; source $R/ws.conf
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
export DISPLAY=:$DISP
PORT=47800
# a file with known content, reachable from inside the prefix
mkdir -p $R/prefix/drive_c/upload
printf 'gologin upload test 12345\n' > $R/prefix/drive_c/upload/test.txt
touch -d '2026-01-02 03:04:05' $R/prefix/drive_c/upload/test.txt
cp -f "$REPO/tools/relay/upload.html" /root/linuxlab/ 2>/dev/null
pgrep -f collect.py >/dev/null || ( setsid nohup python3 "$REPO/tools/relay/collect.py" /root/fp $PORT \
  /root/linuxlab/fp.html >/root/winelab/out/collect.log 2>&1 & )
sleep 1
rm -f /root/fp/$LABEL.txt
bash "$REPO/tools/relay/ws-stop.sh" $N >/dev/null 2>&1
WINE_TREE=$R/wine-ours URL_OVERRIDE="http://127.0.0.1:$PORT/page/upload.html?post=/?as=$LABEL" \
  bash "$REPO/tools/relay/ws-start.sh" $N >/dev/null 2>&1
for i in $(seq 1 40); do wmctrl -l 2>/dev/null | grep -qi edge && break; sleep 3; done
sleep 10
W=$(wmctrl -l | grep -i edge | head -1 | awk '{print $1}')
xdotool windowactivate --sync "$W"; sleep 1
eval $(xdotool getwindowgeometry --shell "$W")
# the "choose file" button sits next to the input, near the top-left of the page
xdotool mousemove $((X + 240)) $((Y + 95)); sleep 0.5; xdotool click 1
sleep 6
echo "  windows after clicking (a dialog should have appeared):"
wmctrl -l | cut -c32-120 | sed 's/^/    /'
# type the path into the dialog's file-name field and confirm
xdotool type --delay 30 'C:\upload\test.txt'; sleep 1
xdotool key Return; sleep 5
echo "  title: $(xdotool getwindowname "$W" 2>/dev/null)"
for i in $(seq 1 10); do [ -s /root/fp/$LABEL.txt ] && break; sleep 2; done
echo "  === what the site received (Wine) ==="
cat /root/fp/$LABEL.txt 2>/dev/null | sed 's/^/  /' || echo "  (nothing posted)"
import -window root /root/winelab/out/upload.png 2>/dev/null && \
  cp -f /root/winelab/out/upload.png "$REPO/results/vm-display/upload-$N.png" && echo "  screenshot saved"
