#!/bin/bash
# Which table is live on the GL path: wined3d.dll's or win32u.so's?
# Rename the entry in ONE shared file at a time (atomic replace, backup kept),
# ask DXGI, and revert straight away if that file was not the source.
export DISPLAY=:9 WINEPREFIX=/root/.wine WINEDEBUG=-all GALLIUM_DRIVER=d3d12
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml="
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OLD="NVIDIA GeForce RTX 3060 Ti (GA104, Low Hash Rate)"
NEW="NVIDIA GeForce RTX 3060 Ti"
cd /root/relay
adapter() { timeout 90 wine d3d11_test.exe 2>/dev/null | grep -a "^adapter" | tr -d '\r'; }

for F in /opt/wine-staging/lib/wine/x86_64-windows/wined3d.dll \
         /opt/wine-staging/lib/wine/x86_64-unix/win32u.so; do
  pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
  pkill -9 -x wineserver 2>/dev/null; sleep 1
  cp -a "$F" "$F.bak-name"
  python3 "$REPO/tools/relay/set_gpu_name.py" "$F" "$OLD" "$NEW" >/dev/null
  rm -f "$F.orig"
  r=$(adapter)
  echo "[$(basename $F) renamed] ${r:-<app failed>}"
  case "$r" in
    *"RTX 3060 Ti (0x10DE"*) echo "   >>> $(basename $F) IS the live table (kept)"; rm -f "$F.bak-name"; break ;;
    *) wineserver -k 2>/dev/null; sleep 1
       cp -a "$F.bak-name" "$F.t" && mv -f "$F.t" "$F" && rm -f "$F.bak-name"
       echo "   reverted $(basename $F)" ;;
  esac
done
