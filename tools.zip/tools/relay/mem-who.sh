#!/bin/bash
# What holds the VM's memory right now? (leftovers from tests vs the live Edge)
echo "top RSS:"
ps -eo rss,comm,args --sort=-rss | head -14 | awk '{printf "  %6d MB  %-16s %s\n", $1/1024, $2, substr($0, index($0,$3), 70)}'
echo "counts: msedge=$(pgrep -fc msedge) wineserver=$(pgrep -xc wineserver) Xvfb=$(pgrep -fc Xvfb) pulseaudio=$(pgrep -xc pulseaudio) winedevice=$(pgrep -fc winedevice)"
echo "old test profiles in the golden prefix:"
du -sh /root/.wine/drive_c/t[0-9]* /root/.wine/drive_c/tb /root/.wine/drive_c/rtx 2>/dev/null | sort -h | tail -6 | sed 's/^/  /'
echo "total in old test profiles: $(du -shc /root/.wine/drive_c/t[0-9]* /root/.wine/drive_c/tb 2>/dev/null | tail -1 | cut -f1)"
