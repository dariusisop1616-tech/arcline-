# Native Windows memory of ONE browser instance: launch with its own fresh profile,
# let it settle, then sum every process whose command line carries that profile.
#   measure-native.ps1 -Browser edge|chrome -Url <url>
param([string]$Browser = "edge", [string]$Url = "https://browserleaks.com/webgl", [int]$Settle = 45)
$exe = if ($Browser -eq "chrome") { "C:\Program Files\Google\Chrome\Application\chrome.exe" }
       else { "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" }
$prof = Join-Path $env:TEMP ("memtest_" + $Browser)
Remove-Item $prof -Recurse -Force -ErrorAction SilentlyContinue
$flags = @("--user-data-dir=$prof","--no-first-run","--no-default-browser-check","--disable-extensions",
           "--disable-sync","--disable-component-update","--renderer-process-limit=1",
           "--in-process-gpu","--use-angle=d3d11","--new-window","--window-size=1920,1040",$Url)
Start-Process $exe -ArgumentList $flags
Start-Sleep -Seconds $Settle
$procs = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like "*$prof*" }
$ws = ($procs | Measure-Object WorkingSetSize -Sum).Sum
$pv = ($procs | Measure-Object PrivatePageCount -Sum).Sum
"{0,-7} native : {1,2} processes  working set {2,6:N0} MB  private {3,6:N0} MB" -f $Browser, $procs.Count, ($ws/1MB), ($pv/1MB)
$procs | Sort-Object WorkingSetSize -Descending | Select-Object -First 6 | ForEach-Object {
  $t = if ($_.CommandLine -match "--type=([a-z-]+)") { $matches[1] } else { "browser" }
  "          {0,-14} {1,6:N0} MB" -f $t, ($_.WorkingSetSize/1MB)
}
$procs | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
