#!/bin/bash
# Short and verifiable: kill the stale wineservers (a wedged one makes every
# `wine` call hang, which is why the previous attempt produced no output at all),
# then run wineboot -u to re-register C:\windows\Fonts, then count.
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDEBUG=-all
OUT=/root/winelab/out; mkdir -p "$OUT"
echo "[1] stop wine"
pkill -9 -f msedge 2>/dev/null
wineserver -k 2>/dev/null; sleep 2; pkill -9 -x wineserver 2>/dev/null; sleep 1
echo "    wineservers left: $(pgrep -c wineserver 2>/dev/null || echo 0)"
echo "[2] wineboot -u (max 150s)"
timeout 150 wineboot -u >"$OUT/wineboot.log" 2>&1
echo "    exit=$? log=$(stat -c%s "$OUT/wineboot.log" 2>/dev/null)B"
echo "[3] count registered fonts (max 30s)"
n=$(timeout 30 wine reg query 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Fonts' 2>/dev/null | grep -c REG_SZ)
echo "    registered: $n"
if [ "$n" -gt 0 ]; then
  timeout 30 wine reg query 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Fonts' 2>/dev/null \
    | grep REG_SZ | sed -E 's/^[[:space:]]*//; s/[[:space:]]+REG_SZ.*//' | sort -u > /tmp/regf.txt
  for f in "Segoe UI" Calibri Consolas Georgia Verdana; do
    grep -qi "^$f" /tmp/regf.txt && echo "    OK   $f" || echo "    MISS $f"
  done
  echo -n "    linux families: "; grep -icE "dejavu|liberation|c059|nimbus|ubuntu|roboto" /tmp/regf.txt
fi
