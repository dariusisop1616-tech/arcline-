#!/bin/bash
# A real Windows-style taskbar using tint2 (a few MB), with fluxbox kept only as
# the window manager. fluxbox 1.3.7's own toolbar has a fixed set of tools -
# "button.start" is silently ignored - so a Start button is not possible there.
#
# The panel reserves exactly BAR pixels at the bottom, so screen.availHeight (part
# of the fingerprint) is unchanged; fluxbox's own toolbar is switched off.
N="${1:-ws1}"; R=/root/workspaces/$N; source $R/ws.conf
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
export DISPLAY=:$DISP

command -v tint2 >/dev/null || {
  echo "installing tint2..."
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq tint2 >/dev/null 2>&1
}
command -v tint2 >/dev/null || { echo "tint2 not available"; exit 1; }

mkdir -p $R/tint2 $R/apps
# Start menu entries (tint2's launcher takes .desktop files)
cat > $R/apps/edge.desktop <<EOF
[Desktop Entry]
Type=Application
Name=Microsoft Edge
Exec=$R/open.sh edge
Icon=$R/apps/edge.png
EOF
cat > $R/apps/start.desktop <<EOF
[Desktop Entry]
Type=Application
Name=Start
Exec=$R/open.sh edge
Icon=$R/apps/start.png
EOF
# icons: Edge's own,