#!/bin/bash
# Self-contained control: read GPU memory, allocate a known amount from inside
# the workspace, read again, let it exit, read again. nvidia-smi inside WSL
# reports the same pool as Windows, so this settles whether WSL allocations are
# visible at all - and therefore whether "a workspace costs ~0 VRAM" is real.
N="${1:-ws1}"; COUNT="${2:-40}"
R=/root/workspaces/$N; source $R/ws.conf
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
SMI=/usr/lib/wsl/lib/nvidia-smi
export DISPLAY=:$DISP WINEPREFIX=$R/prefix WINEDEBUG=-all GALLIUM_DRIVER=d3d12
export PATH="$R/wine-ours/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml="
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
mkdir -p /root/relay; cp -f "$REPO/tools/relay/vram_alloc.exe" /root/relay/
cd /root/relay
v() { $SMI --query-gpu=memory.used --format=csv,noheader,nounits; }
b=$(v); echo "  before            : $b MiB"
setsid nohup wine vram_alloc.exe "$COUNT" 60 > /root/relay/vram.log 2>&1 &
sleep 20
d=$(v)
echo "  app says          : $(grep -a allocated /root/relay/vram.log || echo '(no line yet)')"
echo "  during            : $d MiB   delta $((d - b)) MiB   (requested $((COUNT * 16)) MB)"
sleep 50
a=$(v); echo "  after exit        : $a MiB   delta $((a - b)) MiB"
