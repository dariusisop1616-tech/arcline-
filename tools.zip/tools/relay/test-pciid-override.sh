#!/bin/bash
# Can we name the card exactly? ANGLE composes its string as
#   ANGLE (<vendor from VendorId>, <Description> (0x<DeviceId>) Direct3D11 ...)
# so the target is what Wine's dxgi reports in DXGI_ADAPTER_DESC.
# Step 1 (cheap): the documented registry overrides VideoPciVendorID/VideoPciDeviceID.
# Step 2 (exact): a PE dxgi.dll of ours that rewrites GetDesc - only if step 1 is not enough.
export LC_ALL=C.UTF-8 DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
export GALLIUM_DRIVER=d3d12
OUT=/root/winelab/out
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

echo "== does this Wine build support a description override at all? =="
for f in /opt/wine-staging/lib/wine/x86_64-unix/win32u.so \
         /opt/wine-staging/lib/wine/x86_64-windows/wined3d.dll \
         /opt/wine-staging/lib/wine/x86_64-windows/dxgi.dll; do
  printf '  %-22s ' "$(basename $f)"
  strings -a "$f" | grep -oE "Video(Description|PciVendorID|PciDeviceID|MemorySize)" \
    | sort -u | tr '\n' ' '; echo
done

echo
echo "== which db entry owns 0x2489? =="
strings /opt/wine-staging/lib/wine/x86_64-unix/win32u.so | grep -c "RTX 3060 Ti" | sed 's/^/  RTX 3060 Ti entries: /'

echo
echo "== set the PCI id override to the real card (0x10DE:0x2489) =="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v VideoPciVendorID /t REG_DWORD /d 4318 /f >/dev/null 2>&1
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v VideoPciDeviceID /t REG_DWORD /d 9353 /f >/dev/null 2>&1
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d gl /f >/dev/null 2>&1
wine reg query "HKCU\\Software\\Wine\\Direct3D" 2>/dev/null | sed 's/^/  /'

echo
echo "== relaunch Edge on the real GPU with the override =="
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 1
pkill -9 -x wineserver 2>/dev/null; sleep 1
rm -rf /root/.wine/drive_c/t20 2>/dev/null
xdpyinfo >/dev/null 2>&1 || { setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 & sleep 3; }
pgrep -x fluxbox >/dev/null || { setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & sleep 2; }
( setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t20' --new-window \
    "file:///Z:/root/linuxlab/rx580-check.html#rx580" >"$OUT/edge-pciid.log" 2>&1 & )
for i in $(seq 1 40); do
  t=$(wmctrl -l 2>/dev/null | grep -i rx580check | tail -1)
  [ -n "$t" ] && break
  left=$(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}')
  [ "$left" -lt 700 ] && { echo "  watchdog"; pkill -9 -f msedge; break; }
  sleep 3
done
echo
echo "=== RESULT ==="
wmctrl -l 2>/dev/null | grep -i rx580 | grep -oE "ANGLE \([^|]*" | cut -c1-200
echo "target       : ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Ti (0x00002489) Direct3D11 vs_5_0 ps_5_0, D3D11)"
