#!/bin/bash
# Get the BACKTRACE of the GPU-process breakpoint (exit_code 0x80000003).
#
# Trick: --in-process-gpu puts the GPU code in the browser process, so an
# unhandled breakpoint is no longer swallowed by Chromium's child-process
# reaper - Wine itself prints "Unhandled exception" plus a symbolised backtrace
# to stderr, which names the module and function that asserted.
# Wine's d3d11 is ours to patch, so the failing call is the fix target.
export LC_ALL=C.UTF-8 DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml="
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
export GALLIUM_DRIVER=d3d12
OUT=/root/winelab/out; mkdir -p "$OUT"
LOG="$OUT/gpu-crash.log"
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
ANGLE="${1:-d3d11}"

pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 1
pkill -9 -x wineserver 2>/dev/null; sleep 1
rm -rf /root/.wine/drive_c/t18 2>/dev/null; : > "$LOG"
xdpyinfo >/dev/null 2>&1 || { setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 & sleep 3; }

echo "== wined3d -> gl, real GPU; --in-process-gpu --use-angle=$ANGLE =="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d gl /f >/dev/null 2>&1

# +seh shows the exception as Wine raises it; d3d11/dxgi traces name the last
# calls before it. WINEDEBUG is noisy on purpose - this is a one-shot capture.
( export WINEDEBUG="+seh,+d3d11,+dxgi"
  setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle="$ANGLE" --disable-gpu-watchdog \
    --window-size=900,600 --user-data-dir='C:\t18' --new-window \
    "file:///Z:/root/linuxlab/rx580-check.html#rx580" >"$LOG" 2>&1 & )

for i in $(seq 1 30); do
  left=$(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}')
  printf '  t=%-3ss left=%-5s procs=%-2s log=%sKB\n' "$((i*2))" "$left" \
     "$(pgrep -fc msedge)" "$(( $(stat -c%s "$LOG" 2>/dev/null || echo 0) / 1024 ))"
  grep -aq "Unhandled exception" "$LOG" && { echo "  >>> exception captured"; break; }
  [ "$left" -lt 900 ] && { echo "  watchdog"; pkill -9 -f msedge; break; }
  sleep 2
done
sleep 2; pkill -9 -f msedge 2>/dev/null

echo
echo "=== the exception + backtrace ==="
grep -a -A28 "Unhandled exception" "$LOG" | head -40 | cut -c1-200

echo
echo "=== last d3d11/dxgi calls before it (the fix target) ==="
grep -aE "trace:d3d11|trace:dxgi|fixme:d3d11|fixme:dxgi" "$LOG" | tail -30 \
  | sed -E 's/^[0-9a-f]+:[0-9a-f]+://' | cut -c1-170

echo
echo "log: $LOG ($(stat -c%s "$LOG" 2>/dev/null) bytes)"
