// d3d11_test - the measuring stick for the D3D11 relay.
//
// Renders one fixed triangle offscreen through D3D11, reads the pixels back and
// prints their FNV-1a hash plus timings. The SAME .exe is run three ways:
//   1. native Windows        -> the truth (real RTX 3060 Ti, real d3d11.dll)
//   2. Wine, Wine's d3d11    -> the known-wrong answer (wined3d translation)
//   3. Wine, our relay d3d11 -> must equal (1) byte for byte
// Shader bytecode is precompiled with fxc and embedded, so all three runs feed
// the GPU identical bytes and the only variable is the driver path.
#include <windows.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "vs_bytecode.h"
#include "ps_bytecode.h"

static const UINT W = 256, H = 256;

static uint32_t fnv1a(const uint8_t *p, size_t n)
{
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 16777619u; }
    return h;
}

static double ms(LARGE_INTEGER a, LARGE_INTEGER b, LARGE_INTEGER f)
{
    return (double)(b.QuadPart - a.QuadPart) * 1000.0 / (double)f.QuadPart;
}

#define CK(hr, what) do { HRESULT _h = (hr); if (FAILED(_h)) { \
    printf("FAIL %-28s hr=0x%08X\n", what, (unsigned)_h); return 2; } } while (0)

struct Vtx { float x, y; float r, g, b, a; };

int main(int argc, char **argv)
{
    int iters = 1;
    for (int i = 1; i < argc; i++)
        if (!strcmp(argv[i], "--iters") && i + 1 < argc) iters = atoi(argv[++i]);

    typedef const char *(CDECL *pfn_wine)(void);
    pfn_wine wv = (pfn_wine)GetProcAddress(GetModuleHandleA("ntdll.dll"), "wine_get_version");
    printf("host        : %s\n", wv ? "Wine" : "native Windows");

    LARGE_INTEGER f, t0, t1, t2, t3, t4; QueryPerformanceFrequency(&f);

    // ---- device ----------------------------------------------------------
    QueryPerformanceCounter(&t0);
    ID3D11Device *dev = nullptr; ID3D11DeviceContext *ctx = nullptr;
    D3D_FEATURE_LEVEL want[] = { D3D_FEATURE_LEVEL_11_0 }, got{};
    CK(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
                         want, 1, D3D11_SDK_VERSION, &dev, &got, &ctx),
       "D3D11CreateDevice");
    QueryPerformanceCounter(&t1);

    IDXGIDevice *dxdev = nullptr; IDXGIAdapter *ad = nullptr; DXGI_ADAPTER_DESC adesc{};
    if (SUCCEEDED(dev->QueryInterface(__uuidof(IDXGIDevice), (void **)&dxdev)) &&
        SUCCEEDED(dxdev->GetAdapter(&ad)) && SUCCEEDED(ad->GetDesc(&adesc)))
        printf("adapter     : %ls (0x%04X:0x%04X)\n", adesc.Description,
               adesc.VendorId, adesc.DeviceId);
    else
        printf("adapter     : <unavailable>\n");
    printf("featurelevel: 0x%04X\n", (unsigned)got);

    // ---- resources -------------------------------------------------------
    D3D11_TEXTURE2D_DESC td{};
    td.Width = W; td.Height = H; td.MipLevels = 1; td.ArraySize = 1;
    td.Format = DXGI_FORMAT_R8G8B8A8_UNORM; td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_DEFAULT; td.BindFlags = D3D11_BIND_RENDER_TARGET;
    ID3D11Texture2D *rt = nullptr;
    CK(dev->CreateTexture2D(&td, nullptr, &rt), "CreateTexture2D(rt)");

    D3D11_TEXTURE2D_DESC sd = td;
    sd.Usage = D3D11_USAGE_STAGING; sd.BindFlags = 0;
    sd.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    ID3D11Texture2D *stage = nullptr;
    CK(dev->CreateTexture2D(&sd, nullptr, &stage), "CreateTexture2D(staging)");

    ID3D11RenderTargetView *rtv = nullptr;
    CK(dev->CreateRenderTargetView(rt, nullptr, &rtv), "CreateRenderTargetView");

    const Vtx verts[3] = {
        { -0.85f, -0.75f, 1.0f, 0.25f, 0.10f, 1.0f },
        {  0.00f,  0.90f, 0.15f, 1.0f, 0.35f, 1.0f },
        {  0.80f, -0.65f, 0.20f, 0.30f, 1.0f, 1.0f },
    };
    D3D11_BUFFER_DESC bd{};
    bd.ByteWidth = sizeof(verts); bd.Usage = D3D11_USAGE_IMMUTABLE;
    bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
    D3D11_SUBRESOURCE_DATA srd{}; srd.pSysMem = verts;
    ID3D11Buffer *vb = nullptr;
    CK(dev->CreateBuffer(&bd, &srd, &vb), "CreateBuffer(vb)");

    ID3D11VertexShader *vs = nullptr; ID3D11PixelShader *ps = nullptr;
    CK(dev->CreateVertexShader(g_VSMain, sizeof(g_VSMain), nullptr, &vs), "CreateVertexShader");
    CK(dev->CreatePixelShader(g_PSMain, sizeof(g_PSMain), nullptr, &ps), "CreatePixelShader");

    D3D11_INPUT_ELEMENT_DESC ied[] = {
        { "POSITION", 0, DXGI_FORMAT_R32G32_FLOAT,       0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        { "COLOR",    0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 8, D3D11_INPUT_PER_VERTEX_DATA, 0 },
    };
    ID3D11InputLayout *il = nullptr;
    CK(dev->CreateInputLayout(ied, 2, g_VSMain, sizeof(g_VSMain), &il), "CreateInputLayout");
    QueryPerformanceCounter(&t2);

    // ---- draw + readback -------------------------------------------------
    uint32_t hash = 0; double first_ms = 0.0;
    for (int it = 0; it < iters; it++) {
        LARGE_INTEGER a, b; QueryPerformanceCounter(&a);
        const float clear[4] = { 0.10f, 0.20f, 0.30f, 1.0f };
        D3D11_VIEWPORT vp{ 0.0f, 0.0f, (float)W, (float)H, 0.0f, 1.0f };
        UINT stride = sizeof(Vtx), off = 0;

        ctx->OMSetRenderTargets(1, &rtv, nullptr);
        ctx->RSSetViewports(1, &vp);
        ctx->ClearRenderTargetView(rtv, clear);
        ctx->IASetInputLayout(il);
        ctx->IASetVertexBuffers(0, 1, &vb, &stride, &off);
        ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        ctx->VSSetShader(vs, nullptr, 0);
        ctx->PSSetShader(ps, nullptr, 0);
        ctx->Draw(3, 0);
        ctx->CopyResource(stage, rt);

        D3D11_MAPPED_SUBRESOURCE map{};
        CK(ctx->Map(stage, 0, D3D11_MAP_READ, 0, &map), "Map(staging)");
        // hash row by row: RowPitch may exceed W*4 and the padding is not ours
        uint32_t h = 2166136261u;
        for (UINT y = 0; y < H; y++) {
            const uint8_t *row = (const uint8_t *)map.pData + (size_t)y * map.RowPitch;
            for (UINT i = 0; i < W * 4; i++) { h ^= row[i]; h *= 16777619u; }
        }
        ctx->Unmap(stage, 0);
        hash = h;
        QueryPerformanceCounter(&b);
        if (it == 0) first_ms = ms(a, b, f);
    }
    QueryPerformanceCounter(&t3);

    // ---- corner pixels: a human-readable cross-check ---------------------
    D3D11_MAPPED_SUBRESOURCE map{};
    if (SUCCEEDED(ctx->Map(stage, 0, D3D11_MAP_READ, 0, &map))) {
        const uint8_t *p = (const uint8_t *)map.pData;
        const uint8_t *mid = p + (size_t)(H / 2) * map.RowPitch + (W / 2) * 4;
        printf("px(0,0)     : %02X %02X %02X %02X\n", p[0], p[1], p[2], p[3]);
        printf("px(128,128) : %02X %02X %02X %02X\n", mid[0], mid[1], mid[2], mid[3]);
        ctx->Unmap(stage, 0);
    }

    QueryPerformanceCounter(&t4);
    printf("PIXEL_FNV   : %08x (%u)\n", hash, hash);
    printf("t_device    : %.2f ms\n", ms(t0, t1, f));
    printf("t_resources : %.2f ms\n", ms(t1, t2, f));
    printf("t_frame1    : %.2f ms\n", first_ms);
    if (iters > 1)
        printf("t_frame_avg : %.3f ms over %d iters\n", ms(t2, t3, f) / iters, iters);
    printf("t_total     : %.2f ms\n", ms(t0, t4, f));
    return 0;
}
