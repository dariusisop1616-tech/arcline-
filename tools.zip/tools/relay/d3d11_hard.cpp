// d3d11_hard - the demanding identity probe.
//
// d3d11_test proved one plain triangle is byte-identical on Wine->Mesa->RTX.
// One shader is not a proof, so this exercises the units that actually differ
// between implementations, and that the other Claude's CPU engine listed as its
// two open gaps (interpolator plane constants, anisotropic filtering above 1x):
//   1. mipmap generation      (GenerateMips - a driver-internal downsample)
//   2. anisotropic filtering  (a skewed quad, D3D11_FILTER_ANISOTROPIC, max 16)
//   3. alpha blending         (SRC_ALPHA / INV_SRC_ALPHA over a cleared target)
//   4. MSAA 4x + resolve      (ResolveSubresource - driver-defined sample positions)
// Each stage is hashed separately, so a mismatch names the unit that differs.
#include <windows.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "vs_bytecode.h"
#include "ps_bytecode.h"
#include "vsq_bytecode.h"
#include "pst_bytecode.h"

static const UINT W = 256, H = 256, TW = 64;

#define CK(hr, what) do { HRESULT _h = (hr); if (FAILED(_h)) { \
    printf("FAIL %-30s hr=0x%08X\n", what, (unsigned)_h); return 2; } } while (0)

struct QVtx { float x, y, u, v; };

static ID3D11Device *dev; static ID3D11DeviceContext *ctx;
static ID3D11Texture2D *stage;

// hash the staging copy of a texture, row by row (RowPitch padding is not ours)
static uint32_t hash_tex(ID3D11Texture2D *src)
{
    ctx->CopyResource(stage, src);
    D3D11_MAPPED_SUBRESOURCE m{};
    if (FAILED(ctx->Map(stage, 0, D3D11_MAP_READ, 0, &m))) return 0;
    uint32_t h = 2166136261u;
    for (UINT y = 0; y < H; y++) {
        const uint8_t *row = (const uint8_t *)m.pData + (size_t)y * m.RowPitch;
        for (UINT i = 0; i < W * 4; i++) { h ^= row[i]; h *= 16777619u; }
    }
    ctx->Unmap(stage, 0);
    return h;
}

int main(void)
{
    typedef const char *(CDECL *pfn_wine)(void);
    pfn_wine wv = (pfn_wine)GetProcAddress(GetModuleHandleA("ntdll.dll"), "wine_get_version");
    printf("host        : %s\n", wv ? "Wine" : "native Windows");

    D3D_FEATURE_LEVEL want[] = { D3D_FEATURE_LEVEL_11_0 }, got{};
    CK(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
                         want, 1, D3D11_SDK_VERSION, &dev, &got, &ctx), "CreateDevice");
    IDXGIDevice *dxdev = nullptr; IDXGIAdapter *ad = nullptr; DXGI_ADAPTER_DESC adesc{};
    if (SUCCEEDED(dev->QueryInterface(__uuidof(IDXGIDevice), (void **)&dxdev)) &&
        SUCCEEDED(dxdev->GetAdapter(&ad)) && SUCCEEDED(ad->GetDesc(&adesc)))
        printf("adapter     : %ls (0x%04X:0x%04X)\n", adesc.Description,
               adesc.VendorId, adesc.DeviceId);

    // ---- targets ---------------------------------------------------------
    D3D11_TEXTURE2D_DESC td{};
    td.Width = W; td.Height = H; td.MipLevels = 1; td.ArraySize = 1;
    td.Format = DXGI_FORMAT_R8G8B8A8_UNORM; td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_DEFAULT; td.BindFlags = D3D11_BIND_RENDER_TARGET;
    ID3D11Texture2D *rt = nullptr;
    CK(dev->CreateTexture2D(&td, nullptr, &rt), "CreateTexture2D(rt)");
    ID3D11RenderTargetView *rtv = nullptr;
    CK(dev->CreateRenderTargetView(rt, nullptr, &rtv), "CreateRTV");

    D3D11_TEXTURE2D_DESC sd = td;
    sd.Usage = D3D11_USAGE_STAGING; sd.BindFlags = 0;
    sd.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    CK(dev->CreateTexture2D(&sd, nullptr, &stage), "CreateTexture2D(staging)");

    // MSAA 4x target + its resolve destination
    D3D11_TEXTURE2D_DESC md = td; md.SampleDesc.Count = 4;
    UINT q = 0;
    dev->CheckMultisampleQualityLevels(md.Format, 4, &q);
    md.SampleDesc.Quality = 0;
    ID3D11Texture2D *msaa = nullptr; ID3D11RenderTargetView *msaaRtv = nullptr;
    bool haveMsaa = q > 0 && SUCCEEDED(dev->CreateTexture2D(&md, nullptr, &msaa)) &&
                    SUCCEEDED(dev->CreateRenderTargetView(msaa, nullptr, &msaaRtv));
    printf("msaa4x      : %s (quality levels %u)\n", haveMsaa ? "yes" : "NO", q);

    // ---- a mipmapped source texture, mips made BY THE DRIVER --------------
    D3D11_TEXTURE2D_DESC ttd{};
    ttd.Width = TW; ttd.Height = TW; ttd.MipLevels = 0; ttd.ArraySize = 1;
    ttd.Format = DXGI_FORMAT_R8G8B8A8_UNORM; ttd.SampleDesc.Count = 1;
    ttd.Usage = D3D11_USAGE_DEFAULT;
    ttd.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
    ttd.MiscFlags = D3D11_RESOURCE_MISC_GENERATE_MIPS;
    ID3D11Texture2D *tex = nullptr;
    CK(dev->CreateTexture2D(&ttd, nullptr, &tex), "CreateTexture2D(tex)");
    ID3D11ShaderResourceView *srv = nullptr;
    CK(dev->CreateShaderResourceView(tex, nullptr, &srv), "CreateSRV");

    static uint8_t px[TW * TW * 4];
    for (UINT y = 0; y < TW; y++)
        for (UINT x = 0; x < TW; x++) {
            uint8_t *p = px + ((size_t)y * TW + x) * 4;
            bool chk = ((x / 4) ^ (y / 4)) & 1;          // high-frequency checker
            p[0] = chk ? 240 : 12;
            p[1] = (uint8_t)(x * 4 + 3);
            p[2] = (uint8_t)(y * 4 + 7);
            p[3] = 255;
        }
    ctx->UpdateSubresource(tex, 0, nullptr, px, TW * 4, 0);
    ctx->GenerateMips(srv);                              // driver's own downsample

    // ---- quad skewed hard in u vs v -> anisotropy > 1 --------------------
    const QVtx qv[6] = {
        { -0.95f, -0.30f,  0.0f,  0.0f }, { 0.95f, -0.42f, 14.0f,  0.0f },
        { -0.95f,  0.30f,  0.0f,  1.2f }, { 0.95f, -0.42f, 14.0f,  0.0f },
        {  0.95f,  0.42f, 14.0f,  1.2f }, { -0.95f,  0.30f, 0.0f,  1.2f },
    };
    D3D11_BUFFER_DESC bd{};
    bd.ByteWidth = sizeof(qv); bd.Usage = D3D11_USAGE_IMMUTABLE;
    bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
    D3D11_SUBRESOURCE_DATA srd{}; srd.pSysMem = qv;
    ID3D11Buffer *qvb = nullptr;
    CK(dev->CreateBuffer(&bd, &srd, &qvb), "CreateBuffer(quad)");

    ID3D11VertexShader *vsq = nullptr; ID3D11PixelShader *pst = nullptr;
    CK(dev->CreateVertexShader(g_VSQuad, sizeof(g_VSQuad), nullptr, &vsq), "CreateVS(quad)");
    CK(dev->CreatePixelShader(g_PSTex, sizeof(g_PSTex), nullptr, &pst), "CreatePS(tex)");
    D3D11_INPUT_ELEMENT_DESC qied[] = {
        { "POSITION", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 8, D3D11_INPUT_PER_VERTEX_DATA, 0 },
    };
    ID3D11InputLayout *qil = nullptr;
    CK(dev->CreateInputLayout(qied, 2, g_VSQuad, sizeof(g_VSQuad), &qil), "CreateInputLayout(quad)");

    D3D11_SAMPLER_DESC smd{};
    smd.Filter = D3D11_FILTER_ANISOTROPIC; smd.MaxAnisotropy = 16;
    smd.AddressU = smd.AddressV = smd.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
    smd.ComparisonFunc = D3D11_COMPARISON_NEVER; smd.MinLOD = 0; smd.MaxLOD = D3D11_FLOAT32_MAX;
    ID3D11SamplerState *aniso = nullptr;
    CK(dev->CreateSamplerState(&smd, &aniso), "CreateSamplerState(aniso)");

    D3D11_BLEND_DESC bld{};
    bld.RenderTarget[0].BlendEnable = TRUE;
    bld.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
    bld.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
    bld.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    bld.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    bld.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
    bld.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    bld.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    ID3D11BlendState *blend = nullptr;
    CK(dev->CreateBlendState(&bld, &blend), "CreateBlendState");

    D3D11_VIEWPORT vp{ 0.0f, 0.0f, (float)W, (float)H, 0.0f, 1.0f };
    const float clear[4] = { 0.10f, 0.20f, 0.30f, 1.0f };
    UINT qstride = sizeof(QVtx), off = 0;

    // ---- stage 1: mip + anisotropic sample, alpha-blended ----------------
    ctx->OMSetRenderTargets(1, &rtv, nullptr);
    ctx->RSSetViewports(1, &vp);
    ctx->ClearRenderTargetView(rtv, clear);
    ctx->OMSetBlendState(blend, nullptr, 0xFFFFFFFF);
    ctx->IASetInputLayout(qil);
    ctx->IASetVertexBuffers(0, 1, &qvb, &qstride, &off);
    ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    ctx->VSSetShader(vsq, nullptr, 0);
    ctx->PSSetShader(pst, nullptr, 0);
    ctx->PSSetShaderResources(0, 1, &srv);
    ctx->PSSetSamplers(0, 1, &aniso);
    ctx->Draw(6, 0);
    printf("FNV_aniso_blend : %08x\n", hash_tex(rt));

    // ---- stage 2: the same quad into a 4x MSAA target, then resolve -------
    if (haveMsaa) {
        ctx->OMSetRenderTargets(1, &msaaRtv, nullptr);
        ctx->ClearRenderTargetView(msaaRtv, clear);
        ctx->Draw(6, 0);
        ctx->ResolveSubresource(rt, 0, msaa, 0, td.Format);
        printf("FNV_msaa4_resolve: %08x\n", hash_tex(rt));
    }

    // ---- stage 3: the original math triangle, for continuity -------------
    struct Vtx { float x, y, r, g, b, a; };
    const Vtx tv[3] = {
        { -0.85f, -0.75f, 1.0f, 0.25f, 0.10f, 1.0f },
        {  0.00f,  0.90f, 0.15f, 1.0f, 0.35f, 1.0f },
        {  0.80f, -0.65f, 0.20f, 0.30f, 1.0f, 1.0f },
    };
    D3D11_BUFFER_DESC tbd{};
    tbd.ByteWidth = sizeof(tv); tbd.Usage = D3D11_USAGE_IMMUTABLE;
    tbd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
    D3D11_SUBRESOURCE_DATA tsrd{}; tsrd.pSysMem = tv;
    ID3D11Buffer *tvb = nullptr;
    CK(dev->CreateBuffer(&tbd, &tsrd, &tvb), "CreateBuffer(tri)");
    ID3D11VertexShader *vs = nullptr; ID3D11PixelShader *ps = nullptr;
    CK(dev->CreateVertexShader(g_VSMain, sizeof(g_VSMain), nullptr, &vs), "CreateVS(tri)");
    CK(dev->CreatePixelShader(g_PSMain, sizeof(g_PSMain), nullptr, &ps), "CreatePS(tri)");
    D3D11_INPUT_ELEMENT_DESC tied[] = {
        { "POSITION", 0, DXGI_FORMAT_R32G32_FLOAT,       0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
        { "COLOR",    0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 8, D3D11_INPUT_PER_VERTEX_DATA, 0 },
    };
    ID3D11InputLayout *til = nullptr;
    CK(dev->CreateInputLayout(tied, 2, g_VSMain, sizeof(g_VSMain), &til), "CreateInputLayout(tri)");
    UINT tstride = sizeof(Vtx);
    ctx->OMSetRenderTargets(1, &rtv, nullptr);
    ctx->ClearRenderTargetView(rtv, clear);
    ctx->OMSetBlendState(nullptr, nullptr, 0xFFFFFFFF);
    ctx->IASetInputLayout(til);
    ctx->IASetVertexBuffers(0, 1, &tvb, &tstride, &off);
    ctx->VSSetShader(vs, nullptr, 0);
    ctx->PSSetShader(ps, nullptr, 0);
    ctx->Draw(3, 0);
    printf("FNV_math_tri    : %08x\n", hash_tex(rt));
    return 0;
}
