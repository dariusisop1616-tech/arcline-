#!/bin/bash
# THE test: --in-process-gpu + --use-angle=d3d11 on the real GPU.
#
# Why this should work where the default process model does not: the crash
# (STATUS_BREAKPOINT) only happens when the GPU lives in its OWN process, which
# forces Chromium to share GPU textures across processes via D3D11 shared
# handles / DXGI keyed mutexes - something Wine's d3d11 does not provide. With
# the GPU in-process there are no shared handles to open, and the d3d11 trace
# shows textures and views being created and released normally.
#
# Success looks like the page title reporting:
#   ANGLE (..., Direct3D11 vs_5_0 ps_5_0, D3D11)   <- native Windows format
# on the real GPU, which is the whole "Group A" leak cluster fixed at once.
export LC_ALL=C.UTF-8 DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
export GALLIUM_DRIVER=d3d12
OUT=/root/winelab/out; mkdir -p "$OUT"
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
ANGLE="${1:-d3d11}"
EXTRA="${2:-}"

pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 1
pkill -9 -x wineserver 2>/dev/null; sleep 1
rm -rf /root/.wine/drive_c/t19 2>/dev/null

echo "== display (keep the noVNC view alive) =="
xdpyinfo >/dev/null 2>&1 || { rm -f /tmp/.X11-unix/X9 /tmp/.X9-lock
  setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 & sleep 3; }
pgrep -x fluxbox >/dev/null || { setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & sleep 2; }
timeout 2 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 7 <&3' >/dev/null 2>&1 || {
  pkill -9 -x x11vnc; sleep 1
  ( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR
    setsid nohup x11vnc -display :9 -forever -shared -nopw -quiet -rfbport 5901 \
      -noxdamage -xkb -o "$OUT/x11vnc.log" >/dev/null 2>&1 & ); sleep 2; }
pgrep -f websockify >/dev/null || { setsid nohup websockify --web=/usr/share/novnc 6080 \
  localhost:5901 >"$OUT/websockify.log" 2>&1 & sleep 2; }

echo "== host GL must be the real GPU =="
glxinfo -B 2>&1 | grep -E "OpenGL renderer|Accelerated" | sed 's/^/  /'

echo "== wined3d -> gl =="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d gl /f >/dev/null 2>&1

echo "== launch: --in-process-gpu --use-angle=$ANGLE $EXTRA =="
( setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle="$ANGLE" --disable-gpu-watchdog $EXTRA \
    --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t19' --new-window \
    "file:///Z:/root/linuxlab/rx580-check.html#rx580" >"$OUT/edge-inproc.log" 2>&1 & )

for i in $(seq 1 45); do
  left=$(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}')
  t=$(wmctrl -l 2>/dev/null | grep -iE "microsoft|identity|rx580" | tail -1 | cut -c1-300)
  printf '  t=%-4ss left=%-5s procs=%-2s %s\n' "$((i*3))" "$left" "$(pgrep -fc msedge)" "${t:-no-window}"
  case "$t" in *RX580CHECK*) break ;; esac
  [ "$left" -lt 700 ] && { echo "  watchdog"; pkill -9 -f msedge; break; }
  sleep 3
done

echo
echo "=== VERDICT ==="
t=$(wmctrl -l 2>/dev/null | grep -i rx580 | cut -c1-420)
echo "${t:-NO TITLE}"
case "$t" in
  *Direct3D11*)  echo "  >>> NATIVE WINDOWS FORMAT ON THE REAL GPU - Group A cracked" ;;
  *"no context"*) echo "  >>> still no WebGL context" ;;
  *Vulkan*)      echo "  >>> fell back to the Vulkan/software ICD" ;;
  *)             echo "  >>> inconclusive" ;;
esac
grep -acE "GPU process exited|shared context" "$OUT/edge-inproc.log" 2>/dev/null \
  | sed 's/^/  gpu-crash lines: /'
