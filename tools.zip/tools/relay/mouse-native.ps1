# Same mouse experiment on native Windows: open the probe in the host's Edge,
# move the real cursor along the same circular path with the same spacing, click
# twice, press F8 so the page reports. Run it with the mouse left alone.
param([string]$Label = "mouse_native", [int]$Steps = 200)
Add-Type -AssemblyName System.Windows.Forms
$edge = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
$prof = Join-Path $env:TEMP "mousetest"
$url  = "http://localhost:47800/page/mouse.html?post=/?as=$Label"
Start-Process $edge -ArgumentList @("--user-data-dir=$prof","--no-first-run","--no-default-browser-check",
  "--new-window","--window-position=0,0","--window-size=1920,1040",$url)
Start-Sleep -Seconds 14

$b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
$cx = [int]($b.Width / 2); $cy = [int]($b.Height / 2)
$r  = [int]([Math]::Min($b.Width, $b.Height) / 3)
# focus the page first
[System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($cx, $cy)
Start-Sleep -Milliseconds 300
for ($i = 0; $i -lt $Steps; $i++) {
  $a = 2 * [Math]::PI * $i / $Steps
  $x = [int]($cx + $r * [Math]::Cos($a)); $y = [int]($cy + $r * [Math]::Sin($a))
  [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($x, $y)
  Start-Sleep -Milliseconds 5
}
Start-Sleep -Milliseconds 500
# two real clicks through the OS input API
Add-Type -Namespace W -Name M -MemberDefinition @'
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint d, System.IntPtr e);
'@
for ($i = 0; $i -lt 2; $i++) { [W.M]::mouse_event(0x0002,0,0,0,[IntPtr]::Zero); Start-Sleep -Milliseconds 60
                               [W.M]::mouse_event(0x0004,0,0,0,[IntPtr]::Zero); Start-Sleep -Milliseconds 300 }
Start-Sleep -Milliseconds 800
[System.Windows.Forms.SendKeys]::SendWait("{F8}")
Start-Sleep -Seconds 3
Write-Output "native run done (label $Label)"
