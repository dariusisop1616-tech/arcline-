#!/bin/bash
# Which of the new launcher changes kills Edge? Start from the proven config
# (fp-full.sh, captured fine) and add ONE change per run; report survival at 20s.
export DISPLAY=:9 WINEPREFIX=/root/.wine WINEDEBUG=-all GALLIUM_DRIVER=d3d12
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml=;dwrite=n"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES LC_ALL LANG FONTCONFIG_FILE LD_PRELOAD
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
BASE="--no-sandbox --no-first-run --no-default-browser-check --disable-extensions --disable-sync --disable-component-update --renderer-process-limit=1 --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog"

try() { # $1 label, $2 env assignments, $3 extra flags
  pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
  rm -rf /root/.wine/drive_c/tb
  ( eval "export $2"; setsid nohup wine "$EDGE" $BASE $3 --user-data-dir='C:\tb' about:blank \
      >/root/winelab/out/bisect.log 2>&1 & )
  sleep 22
  n=$(pgrep -fc msedge); w=$(wmctrl -l 2>/dev/null | grep -ci edge)
  printf '  %-34s procs=%-3s window=%s\n' "$1" "$n" "$w"
}
try "baseline (proven)"            "DUMMY=1"                                  ""
try "+ LANG=fr_FR.UTF-8"           "LANG=fr_FR.UTF-8"                         ""
try "+ LD_PRELOAD memshim"         "LD_PRELOAD=/root/winelab/mem/memshim.so"  ""
try "+ FONTCONFIG_FILE restricted" "FONTCONFIG_FILE=/root/winelab/fontconfig/fonts.conf" ""
try "+ --lang=fr --start-maximized" "DUMMY=1"                                 "--lang=fr --start-maximized"
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null
