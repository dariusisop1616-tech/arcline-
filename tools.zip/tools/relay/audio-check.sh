#!/bin/bash
# AudioContext.sampleRate = the mix rate Wine's audio driver reports, which for
# winepulse follows the PulseAudio sink it is connected to (WSLg's server now).
echo "PULSE_SERVER=$PULSE_SERVER"
for b in pulseaudio pipewire pipewire-pulse pactl; do
  printf '  %-15s %s\n' "$b" "$(command -v $b || echo missing)"
done
echo "wine audio driver setting:"
WINEPREFIX=/root/.wine WINEDEBUG=-all PATH="/opt/wine-staging/bin:/usr/bin:/bin" \
  timeout 20 wine reg query 'HKCU\Software\Wine\Drivers' 2>/dev/null | sed 's/^/  /'
echo "WSLg pulse socket: $(ls -l /mnt/wslg/PulseServer 2>/dev/null | cut -c1-80)"
echo "camera on the host? (answered from Windows side)"
