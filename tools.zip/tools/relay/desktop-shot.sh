#!/bin/bash
# Relaunch Edge in the workspace (fits above the taskbar), open the Start menu,
# and take two screenshots: the full desktop, and a crop of just the taskbar.
N="${1:-ws1}"; R=/root/workspaces/$N; source $R/ws.conf
REL="/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/relay"
OUTD="/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/vm-display"
export DISPLAY=:$DISP
BAR=40; AVAIL=$((SCREEN_H - BAR))

# make sure the browser occupies exactly the area above the taskbar
W=$(wmctrl -l | grep -iE 'edge|opera|chrome' | head -1 | awk '{print $1}')
if [ -z "$W" ]; then
  WINE_TREE=$R/wine-ours URL_OVERRIDE=https://www.bing.com bash "$REL/ws-start.sh" $N >/dev/null 2>&1
  for i in $(seq 1 30); do wmctrl -l 2>/dev/null | grep -qi edge && break; sleep 3; done
  W=$(wmctrl -l | grep -i edge | head -1 | awk '{print $1}')
fi
[ -n "$W" ] && { wmctrl -i -r "$W" -e 0,0,0,$SCREEN_W,$AVAIL 2>/dev/null; wmctrl -i -a "$W"; }
sleep 4

import -window root "$OUTD/win-desktop-$N.png" 2>/dev/null && echo "full: results/vm-display/win-desktop-$N.png"
import -window root -crop 520x${BAR}+0+$AVAIL "$OUTD/win-taskbar-$N.png" 2>/dev/null && echo "taskbar-left: results/vm-display/win-taskbar-$N.png"
import -window root -crop 260x${BAR}+$((SCREEN_W-260))+$AVAIL "$OUTD/win-tray-$N.png" 2>/dev/null && echo "taskbar-right: results/vm-display/win-tray-$N.png"
echo "geometry: $(xdotool getwindowgeometry "$W" 2>/dev/null | tr '\n' ' ')"
