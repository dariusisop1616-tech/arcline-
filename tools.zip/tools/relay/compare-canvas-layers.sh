#!/bin/bash
# WHO produces canvas pixels? Test it instead of asserting it.
#
# All captures are native Windows Edge 154.0.4258.37 on the same machine, same
# probe, differing only in which layer is allowed to do the work:
#   windows    - full GPU (the reference)
#   win_nogpu  - --disable-gpu                    (no GPU anywhere)
#   win_no2d   - --disable-accelerated-2d-canvas  (GPU for WebGL, CPU for canvas2d)
# Plus the two Wine captures for contrast:
#   wine       - software renderer (llvmpipe)
#   wine2      - the real RTX through wined3d/Mesa
#
# Reading the table:
#  * a canvas2d hash that is the SAME in windows and win_nogpu => that pixel work
#    does not involve the GPU at all (pure CPU / DirectWrite).
#  * a hash that CHANGES when the GPU is removed => the GPU composited it.
FP=/root/fp
cd "$FP" || exit 1
ls *.txt 2>/dev/null | sed 's/^/  have: /'
echo
python3 - <<'EOF'
import os
FP = "/root/fp"
order = ["windows", "win_nogpu", "win_no2d", "wine", "wine2"]
def load(n):
    p = os.path.join(FP, n + ".txt")
    if not os.path.exists(p): return None
    d = {}
    for line in open(p, encoding="utf-8", errors="replace"):
        if line.startswith("---") or ":" not in line: continue
        k, v = line.split(":", 1); d[k.strip()] = v.strip()
    return d
caps = {n: load(n) for n in order}
have = [n for n in order if caps[n]]
keys = ["canvas2d.toDataURLHash", "canvas2d.imageDataHash", "canvas2d.textBandHash",
        "canvas2d.gradientHash", "canvas2d.textMetrics", "fonts.count",
        "webgl.UNMASKED_RENDERER", "webgl.renderHash"]
w = 26
print("  " + "signal".ljust(w) + "".join(n.ljust(20) for n in have))
print("  " + "-" * (w + 20 * len(have)))
for k in keys:
    row = "  " + k.ljust(w)
    for n in have:
        v = caps[n].get(k, "<absent>")
        row += (v[:18] if len(v) <= 18 else v[:15] + "...").ljust(20)
    print(row)
print()
ref = caps.get("windows")
ng = caps.get("win_nogpu")
if ref and ng:
    print("  === VERDICT: windows(GPU) vs windows(--disable-gpu) ===")
    for k in keys:
        if k.startswith(("canvas2d", "fonts")):
            a, b = ref.get(k), ng.get(k)
            same = "SAME  -> CPU-produced, GPU not involved" if a == b else "DIFFERS -> the GPU took part"
            print(f"    {k:<26} {same}")
EOF
