// Does the CDP engine method still work with our patched Wine?
// The engine drives a stock browser over --remote-debugging-port and injects a
// script (via Page.addScriptToEvaluateOnNewDocument) that overrides canvas
// readback to return chosen pixels. This test proves the two things that must
// hold under Wine:
//   1. CDP can attach to Edge running in the workspace
//   2. an injected override actually changes what the page reads back
// If both pass, plugging the real engine in later is the same code path.
const PORT = process.env.DBG_PORT || 9333;
const HOST = '127.0.0.1';

async function main() {
  // discover the page target
  const list = await (await fetch(`http://${HOST}:${PORT}/json/list`)).json();
  const page = list.find(t => t.type === 'page');
  if (!page) throw new Error('no page target (CDP not reachable)');
  console.log('  CDP page target:', page.url.slice(0, 60));

  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((r, j) => { ws.onopen = r; ws.onerror = () => j(new Error('ws fail')); });
  let id = 0; const pend = new Map();
  ws.onmessage = e => { const m = JSON.parse(e.data); if (pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
  const send = (method, params = {}) => new Promise(res => { const i = ++id; pend.set(i, res); ws.send(JSON.stringify({ id: i, method, params })); });

  await send('Page.enable');
  await send('Runtime.enable');

  // the injected override: force getImageData to report a known marker pixel.
  // The real engine returns the captured GPU's bytes here instead of a marker.
  const override = `
    (() => {
      const proto = CanvasRenderingContext2D.prototype;
      const real = proto.getImageData;
      proto.getImageData = function (...a) {
        const img = real.apply(this, a);
        // stamp the engine marker so we can prove the override ran
        for (let i = 0; i < Math.min(img.data.length, 16); i += 4) {
          img.data[i] = 123; img.data[i+1] = 45; img.data[i+2] = 67; img.data[i+3] = 255;
        }
        window.__ENGINE_HIT__ = (window.__ENGINE_HIT__ || 0) + 1;
        return img;
      };
    })();
  `;
  // inject for any future navigation (what the real engine uses) ...
  await send('Page.addScriptToEvaluateOnNewDocument', { source: override });
  // ... and once into the current document, so we can test without reloading
  await send('Runtime.evaluate', { expression: override });

  // now read a canvas in the page and check the override took effect
  const check = `
    (() => {
      const c = document.createElement('canvas'); c.width = 4; c.height = 4;
      const x = c.getContext('2d');
      x.fillStyle = '#ffffff'; x.fillRect(0, 0, 4, 4);
      const d = x.getImageData(0, 0, 4, 4).data;
      return JSON.stringify({
        hits: window.__ENGINE_HIT__ || 0,
        firstPixel: [d[0], d[1], d[2], d[3]],
        overrideWorked: d[0] === 123 && d[1] === 45 && d[2] === 67
      });
    })();
  `;
  const res = await send('Runtime.evaluate', { expression: check, returnByValue: true });
  const out = JSON.parse(res.result.result.value);
  console.log('  engine override hits :', out.hits);
  console.log('  first pixel returned :', out.firstPixel.join(','), '(white canvas would be 255,255,255)');
  console.log('  OVERRIDE WORKED      :', out.overrideWorked ? 'YES - browser returned engine pixels' : 'NO');
  ws.close();
  process.exit(out.overrideWorked ? 0 : 1);
}
main().catch(e => { console.log('  FAILED:', e.message); process.exit(2); });
