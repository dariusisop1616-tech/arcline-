#!/bin/bash
# Does the host's Opera GX just work under Wine, with the same environment that
# makes Edge match Windows? Runs it in a workspace on our Wine build, with the
# real-GPU flags, and reports: does it map a window, and what memory does it use.
# Opera GX is Chromium 136, so the same ANGLE/D3D11 path applies.
N="${1:-ws1}"; R=/root/workspaces/$N; source $R/ws.conf
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
export DISPLAY=:$DISP WINEPREFIX=$R/prefix WINEDEBUG=-all GALLIUM_DRIVER=d3d12
export PATH="$R/wine-ours/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml=;dwrite=n" LANG=$LANG_WS FAKE_MEM_KB=$MEM_KB
export FONTCONFIG_FILE=$R/fontconfig/fonts.conf PULSE_SERVER=unix:$R/pulse/native
export WINE_IMAGE_CACHE=1 KSM_MERGE=1
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES LC_ALL
OPERA="/mnt/c/Users/Darkking1/AppData/Local/Programs/Opera GX/opera.exe"
[ -f "$OPERA" ] || { echo "opera.exe not reachable at $OPERA"; exit 1; }
mkdir -p $R/logs

# match the EXEs only: a pattern like 'opera' also matches this script's own
# command line, and pkill -9 would kill the script before it launches anything
pkill -9 -f 'msedge\.exe' 2>/dev/null; pkill -9 -f 'opera\.exe' 2>/dev/null
wineserver -k 2>/dev/null; sleep 2
rm -rf $R/prefix/drive_c/opera-test
( export LD_PRELOAD=/root/winelab/mem/memshim_env.so
  setsid nohup wine "$OPERA" --no-sandbox --no-first-run --disable-sync \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --user-data-dir='C:\opera-test' \
    "http://127.0.0.1:47800/probe?post=/?as=opera" >$R/logs/opera.log 2>&1 & )

for i in $(seq 1 40); do
  w=$(wmctrl -l 2>/dev/null | grep -icE "opera")
  [ "$w" -gt 0 ] && { echo "  window mapped at t=$((i*3))s"; break; }
  sleep 3
done
sleep 10
echo "  windows: $(wmctrl -l 2>/dev/null | grep -iE 'opera' | cut -c32-110)"
tot=0; cnt=0
for p in $(pgrep -f 'opera\.exe'); do
  grep -qz "WINEPREFIX=$R/prefix" /proc/$p/environ 2>/dev/null || continue
  r=$(awk '/^VmRSS/{print $2}' /proc/$p/status 2>/dev/null); s=$(awk '/^VmSwap/{print $2}' /proc/$p/status 2>/dev/null)
  tot=$((tot + ${r:-0} + ${s:-0})); cnt=$((cnt+1))
done
echo "  opera processes: $cnt   resident+swap: $((tot/1024)) MB"
echo "  errors:"; grep -aiE "err:|Unhandled|not implemented|fatal" $R/logs/opera.log | head -5 | cut -c1-150 | sed 's/^/    /'
[ -s /root/fp/opera.txt ] && { echo "  probe captured; GPU line:"; grep -E "UNMASKED_RENDERER" /root/fp/opera.txt | head -1 | sed 's/^/    /'; } || echo "  (probe did not post)"
