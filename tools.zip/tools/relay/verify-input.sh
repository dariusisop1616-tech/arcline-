#!/bin/bash
# Restart a workspace on the click probe, then send REAL X11 input. The page puts
# the click count in the window title, so the result is machine-readable:
# CLICKS=n means the browser received n trusted clicks at the right coordinates.
N="${1:-ws1}"; R=/root/workspaces/$N; source $R/ws.conf
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
export DISPLAY=:$DISP
PORT=47800
cp -f "$REPO/tools/relay/click.html" "$REPO/tools/relay/"/../relay/click.html 2>/dev/null
pgrep -f collect.py >/dev/null || ( setsid nohup python3 "$REPO/tools/relay/collect.py" /root/fp $PORT \
  /root/linuxlab/fp.html >/root/winelab/out/collect.log 2>&1 & )
sleep 1
bash "$REPO/tools/relay/ws-stop.sh" $N >/dev/null 2>&1
WINE_TREE=$R/wine-ours URL_OVERRIDE="http://127.0.0.1:$PORT/page/click.html" \
  bash "$REPO/tools/relay/ws-start.sh" $N >/dev/null 2>&1
for i in $(seq 1 40); do wmctrl -l 2>/dev/null | grep -qi edge && break; sleep 3; done
sleep 8
W=$(wmctrl -l | grep -i edge | head -1 | awk '{print $1}')
[ -z "$W" ] && { echo "no Edge window"; exit 1; }
eval $(xdotool getwindowgeometry --shell "$W")
echo "  window ${WIDTH}x${HEIGHT} at ${X},${Y}   decorations: $(xprop -id $W _MOTIF_WM_HINTS 2>/dev/null | grep -c 0x2 || echo '?')"
xdotool windowactivate --sync "$W"; sleep 1
cx=$((X + WIDTH / 2)); cy=$((Y + 90))
for i in 1 2 3; do xdotool mousemove $cx $((cy + i * 5)); sleep 0.3; xdotool click 1; sleep 0.8; done
sleep 2
echo "  title: $(xdotool getwindowname "$W")"
import -window "$W" /root/winelab/out/input.png 2>/dev/null && \
  cp -f /root/winelab/out/input.png "$REPO/results/vm-display/input-$N.png" && echo "  saved results/vm-display/input-$N.png"
