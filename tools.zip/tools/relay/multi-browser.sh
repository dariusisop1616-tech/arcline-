#!/bin/bash
# Is a SECOND browser inside one workspace cheaper than a second workspace?
# Same page, same flags; only the profile directory differs. Compare the delta
# with the measured cost of a second workspace (~385 MB).
N="${1:-ws1}"; R=/root/workspaces/$N; source $R/ws.conf
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
export DISPLAY=:$DISP WINEPREFIX=$R/prefix WINEDEBUG=-all GALLIUM_DRIVER=d3d12
export PATH="$R/wine-ours/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml=;dwrite=n" LANG=$LANG_WS FAKE_MEM_KB=$MEM_KB
export FONTCONFIG_FILE=$R/fontconfig/fonts.conf PULSE_SERVER=unix:$R/pulse/native
export KSM_MERGE=1
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES LC_ALL
EDGE="$R/prefix/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
URL2="https://browserleaks.com/webgl"
used() { free -m | awk 'NR==2{print $3}'; }

echo "  workspace $N already running Edge #1: $(pgrep -fc msedge) processes, mem $(used) MB"
b=$(used)
rm -rf $R/prefix/drive_c/ws2nd
( export LD_PRELOAD=/root/winelab/mem/memshim_env.so
  setsid nohup wine "$EDGE" --no-sandbox --no-first-run --no-default-browser-check \
    --disable-extensions --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --window-position=40,40 --window-size=1200,700 \
    --user-data-dir='C:\ws2nd' "$URL2" > $R/logs/edge2.log 2>&1 & )
for i in $(seq 1 40); do
  [ "$(wmctrl -l | grep -ci edge)" -ge 2 ] && { echo "  second browser window at t=$((i*3))s"; break; }
  sleep 3
done
sleep 60
a=$(used)
echo "  after second browser: $(pgrep -fc msedge) processes, mem $a MB"
echo "  SECOND BROWSER IN THE SAME WORKSPACE COSTS: $((a - b)) MB"
echo "  (a second WORKSPACE costs ~385 MB)"
echo "  windows now:"; wmctrl -l | grep -i edge | cut -c32-110 | sed 's/^/    /'
