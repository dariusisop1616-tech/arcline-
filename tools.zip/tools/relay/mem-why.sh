#!/bin/bash
# Hypothesis to verify: most of each Edge process's RAM under Wine is not browser
# data but Wine's page-tracking table. Chromium *reserves* enormous address
# ranges (PartitionAlloc pools, V8 cages) - free on Windows. Wine keeps one
# protection byte per 4 KB page it manages, so a reservation of V bytes costs
# about V/4096 bytes of real RAM. If the hypothesis holds, RssAnon ~ VmSize/4096.
printf '%-8s %-14s %10s %10s %12s\n' pid type VmSize_GB RssAnon_MB vprot_est_MB
for p in $(pgrep -f msedge); do
  s=/proc/$p/status; [ -r $s ] || continue
  vm=$(awk '/^VmSize/{print $2}' $s); an=$(awk '/^RssAnon/{print $2}' $s)
  [ -z "$vm" ] && continue
  t=$(tr '\0' ' ' < /proc/$p/cmdline | grep -oE -- '--type=[a-z-]+' | head -1 | cut -d= -f2)
  printf '%-8s %-14s %10.0f %10.0f %12.0f\n' $p "${t:-browser}" "$(echo "$vm/1048576" | bc -l)" \
    "$(echo "$an/1024" | bc -l)" "$(echo "$vm/4096/1024" | bc -l)"
done | sort -k4 -nr | head -12
echo
echo "compressed-memory support in this kernel:"
echo "  zswap: $(cat /sys/module/zswap/parameters/enabled 2>/dev/null || echo 'not available')  compressor: $(cat /sys/module/zswap/parameters/compressor 2>/dev/null)"
echo "  zram : $( (modprobe -n zram 2>/dev/null && echo module-available) || (ls /sys/block/ | grep -q zram && echo present) || echo 'not available')"
echo "  ksm  : $(cat /sys/kernel/mm/ksm/run 2>/dev/null || echo 'not available')"
