#!/bin/bash
# Report the Opera capture if it arrived, else show what the window is doing.
export DISPLAY=:9
for i in $(seq 1 12); do [ -s /root/fp/opera.txt ] && break; sleep 6; done
if [ -s /root/fp/opera.txt ]; then
  echo "=== Opera GX under Wine ==="
  grep -E "^(userAgent|platform|webgl\.UNMASKED_RENDERER|webgl\.renderHash|canvas2d\.toDataURLHash|canvas2d\.gradientHash|fonts\.count|screen|deviceMemory|audio\.sampleRate)" /root/fp/opera.txt | sed 's/^/  /'
  echo "=== native Windows Edge (reference) ==="
  grep -E "^(webgl\.UNMASKED_RENDERER|webgl\.renderHash|canvas2d\.toDataURLHash|canvas2d\.gradientHash|fonts\.count)" /root/fp/windows.txt | sed 's/^/  /'
else
  echo "no capture"
  wmctrl -l | sed 's/^/  win: /'
  echo "  opera procs: $(pgrep -fc 'opera\.exe')"
fi
