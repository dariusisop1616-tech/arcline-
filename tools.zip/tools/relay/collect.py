#!/usr/bin/env python3
"""Collector for fingerprint-probe.html POST-backs.

Runs inside WSL and is reachable BOTH from the Wine browser (127.0.0.1 in the
VM) and from native Windows Edge (localhost:PORT is forwarded into the VM) - so
one collector captures both sides of the comparison and the two files are
directly diffable.  Each POST is saved as <outdir>/<label>.txt, where the label
is the ?as= query parameter.
"""
import sys, os
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

OUT = sys.argv[1] if len(sys.argv) > 1 else "/root/fp"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 47800
PROBE = sys.argv[3] if len(sys.argv) > 3 else "/root/linuxlab/fp.html"
os.makedirs(OUT, exist_ok=True)


class H(BaseHTTPRequestHandler):
    def _label(self):
        q = parse_qs(urlparse(self.path).query)
        return (q.get("as", ["unknown"])[0] or "unknown").replace("/", "_")[:40]

    def _save(self, body):
        p = os.path.join(OUT, self._label() + ".txt")
        with open(p, "wb") as f:
            f.write(body)
        print(f"saved {p} ({len(body)} bytes)", flush=True)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        self._save(self.rfile.read(n))
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

    def do_GET(self):
        # Serve the probe page itself over http. A file:// page cannot POST to
        # http://localhost (Chromium blocks the null origin), so BOTH browsers
        # load the probe from here and post same-origin.
        path = urlparse(self.path).path
        # /page/<name>.html serves any test page from this script's directory
        if path.startswith("/page/"):
            name = os.path.basename(path)
            p = os.path.join(os.path.dirname(os.path.abspath(__file__)), name)
            if name.endswith(".html") and os.path.isfile(p):
                body = open(p, "rb").read()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404); self.end_headers()
            return
        if path.startswith("/probe"):
            try:
                with open(PROBE, "rb") as f:
                    body = f.read()
            except OSError as e:
                self.send_response(500); self.end_headers()
                self.wfile.write(str(e).encode()); return
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        # the probe's fallback path: data smuggled in an <img> query string
        q = parse_qs(urlparse(self.path).query)
        if "d" in q:
            self._save(q["d"][0].encode())
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Type", "image/gif")
        self.end_headers()
        self.wfile.write(b"GIF89a")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.end_headers()

    def log_message(self, *a):
        pass


print(f"collector on 0.0.0.0:{PORT} -> {OUT}", flush=True)
HTTPServer(("0.0.0.0", PORT), H).serve_forever()
