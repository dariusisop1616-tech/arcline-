#!/bin/bash
# Per-component verdict: native Windows Edge vs Wine (Wine dwrite) vs Wine (MS dwrite).
FP=/root/fp
for f in split_win split_wine_builtin split_wine_native; do
  [ -s "$FP/$f.txt" ] || echo "  MISSING $f.txt"
done
python3 - <<'EOF'
import os
FP = "/root/fp"
def load(n):
    p = os.path.join(FP, n + ".txt")
    if not os.path.exists(p): return {}
    d = {}
    for line in open(p, encoding="utf-8", errors="replace"):
        if ":" in line and not line.startswith("STATUS"):
            k, v = line.split(":", 1); d[k.strip()] = v.strip()
    return d
w, b, n = load("split_win"), load("split_wine_builtin"), load("split_wine_native")
print(f"  {'component':<18} {'WINDOWS (truth)':<28} {'wine+wine dwrite':<28} {'wine+MS dwrite':<28}")
for k in w:
    a = w.get(k, "-"); x = b.get(k, "-"); y = n.get(k, "-")
    mx = "OK" if x == a else "--"; my = "OK" if y == a else "--"
    print(f"  {k:<18} {a[:26]:<28} {mx} {x[:24]:<25} {my} {y[:24]}")
EOF
