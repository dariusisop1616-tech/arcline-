#!/bin/bash
# Fast facts needed for the environment fixes (seconds).
D=/root/.wine/drive_c/windows/Fonts
echo "[fonts] linux-named files already in the prefix (came from the host Windows):"
ls "$D" | grep -iE "dejavu|liberation|roboto|ubuntu" | head -8 | sed 's/^/  /'
echo "[fonts] where Ubuntu comes from:"
fc-list 2>/dev/null | grep -i "ubuntu" | head -2 | cut -d: -f1 | sed 's/^/  /'
echo "[locale] fr_FR available?"
locale -a 2>/dev/null | grep -iE "^fr_FR" | sed 's/^/  /' || echo "  no"
echo "[unshare/mount] available as root?"
command -v unshare >/dev/null && echo "  unshare: yes" ; id -u | sed 's/^/  uid: /'
echo "[audio] pulse server / default rate:"
echo "  PULSE_SERVER=${PULSE_SERVER:-unset}"
pactl info 2>/dev/null | grep -iE "Default Sample|Server Name" | sed 's/^/  /'
echo "[video] capture devices:"
ls /dev/video* 2>/dev/null | sed 's/^/  /' || echo "  none"
echo "[fluxbox] toolbar config:"
grep -iE "toolbar\.(height|placement|visible)" /root/.fluxbox/init 2>/dev/null | sed 's/^/  /'
