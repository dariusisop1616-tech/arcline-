#!/bin/bash
# Ask Wine directly why C:\windows\Fonts is ignored: WINEDEBUG=+font traces the
# font loader - which directories it scans, which files it adds, what it rejects.
export LC_ALL=C.UTF-8 DISPLAY=:9
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
OUT=/root/winelab/out; mkdir -p "$OUT"
L="$OUT/font-trace.log"

pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
pkill -9 -x wineserver 2>/dev/null; sleep 1
timeout 30 env WINEDEBUG=-all wine reg delete 'HKCU\Software\Wine\Fonts' /f >/dev/null 2>&1
wineserver -k 2>/dev/null; sleep 1

echo "== run a GDI app with +font tracing =="
( export WINEDEBUG="+font"
  setsid nohup timeout 60 wine notepad.exe >"$L" 2>&1 & )
sleep 25
pkill -9 -f notepad.exe 2>/dev/null
echo "  log: $(stat -c%s "$L" 2>/dev/null) bytes"

echo
echo "== directories the font loader looked at =="
grep -aoE "/[A-Za-z0-9_./-]*[Ff]onts[A-Za-z0-9_./-]*" "$L" | sort -u | head -12 | sed 's/^/  /'

echo
echo "== does it mention our files at all? =="
for f in calibri segoeui consola georgia; do
  printf '  %-10s ' "$f"; grep -aic "$f" "$L" 2>/dev/null
done

echo
echo "== rejections / errors =="
grep -aiE "err:font|fixme:font|no such|failed|cannot|unable|reject|skip" "$L" \
  | sed -E 's/^[0-9a-f]+:[0-9a-f]+://' | sort | uniq -c | sort -rn | head -12 | cut -c1-170

echo
echo "== first lines of the trace (what it does at startup) =="
grep -a "font" "$L" | head -14 | sed -E 's/^[0-9a-f]+:[0-9a-f]+://' | cut -c1-170
