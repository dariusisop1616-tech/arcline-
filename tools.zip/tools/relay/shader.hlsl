// Deterministic probe shader for the D3D11 relay proof.
//
// The pixel shader deliberately leans on the parts of a GPU that differ between
// implementations - exactly the parts a canvas/WebGL fingerprint measures:
//   - attribute interpolation across the triangle (color + uv)
//   - the special-function unit: sin/cos/exp2/log2/rsqrt
//   - the float->UNORM8 output converter's rounding
// llvmpipe and an NVIDIA GPU agree on none of these to the last bit, so the
// FNV hash of the rendered pixels is a sharp yes/no on "did the real GPU draw this".

struct VSIn  { float2 pos : POSITION; float4 col : COLOR; };
struct VSOut { float4 pos : SV_POSITION; float4 col : COLOR; float2 uv : TEXCOORD0; };

VSOut VSMain(VSIn i)
{
    VSOut o;
    o.pos = float4(i.pos, 0.0f, 1.0f);
    o.col = i.col;
    o.uv  = i.pos;          // interpolated in NDC, -1..1
    return o;
}

float4 PSMain(VSOut i) : SV_TARGET
{
    float a = sin(i.uv.x * 12.9898f) * cos(i.uv.y * 78.233f);
    float b = rsqrt(abs(i.uv.x) + 0.001f) * 0.1f;
    float c = exp2(i.uv.y * 3.0f) * 0.05f;
    float d = log2(abs(i.uv.x) + 1.0f);
    return saturate(float4(i.col.r * a + b, i.col.g * c, i.col.b * d, 1.0f));
}

// ---- harder probe: texture filtering / anisotropy / blending / MSAA -------
struct QIn  { float2 pos : POSITION; float2 uv : TEXCOORD0; };
struct QOut { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; };
Texture2D    gTex : register(t0);
SamplerState gSmp : register(s0);

QOut VSQuad(QIn i)
{
    QOut o;
    o.pos = float4(i.pos, 0.0f, 1.0f);
    o.uv  = i.uv;
    return o;
}

// sampled with a strongly non-square UV gradient -> forces the anisotropic path
float4 PSTex(QOut i) : SV_TARGET
{
    float4 t = gTex.Sample(gSmp, i.uv);
    return float4(t.rgb, 0.55f);     // alpha < 1 -> exercises the blender
}
