#!/bin/bash
# Opera GX is already running in the workspace; drive it to the probe page with
# real keystrokes (ctrl+L, type, Enter) and report what it posts.
N="${1:-ws1}"; source /root/workspaces/$N/ws.conf
export DISPLAY=:$DISP
PORT=47800
rm -f /root/fp/opera.txt
W=$(wmctrl -l | grep -i opera | head -1 | awk '{print $1}')
[ -z "$W" ] && { echo "no Opera window"; exit 1; }
xdotool windowactivate --sync "$W"; sleep 1
xdotool key --clearmodifiers ctrl+l; sleep 1
xdotool type --delay 25 "http://127.0.0.1:$PORT/probe?post=/?as=opera"; sleep 1
xdotool key Return
for i in $(seq 1 30); do [ -s /root/fp/opera.txt ] && break; sleep 3; done
if [ -s /root/fp/opera.txt ]; then
  grep -E "^(userAgent|platform|webgl.UNMASKED_RENDERER|canvas2d.toDataURLHash|fonts.count|screen|deviceMemory|audio.sampleRate)" \
    /root/fp/opera.txt | sed 's/^/  /'
  echo "  --- same fields from native Windows Edge (reference) ---"
  grep -E "^(webgl.UNMASKED_RENDERER|canvas2d.toDataURLHash|fonts.count)" /root/fp/windows.txt | sed 's/^/  /'
else
  echo "  no capture; window title: $(xdotool getwindowname "$W")"
fi
