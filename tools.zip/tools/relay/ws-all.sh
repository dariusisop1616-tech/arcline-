#!/bin/bash
# Bring up all workspaces, one at a time (each Edge has a multi-GB startup spike),
# then supervise: revive a dead display piece or Edge, log memory, keep WSL alive.
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
LIST="${WSLIST:-ws1 ws2 ws3}"
echo -1000 > /proc/self/oom_score_adj 2>/dev/null

# compressed RAM: Wine's per-process page tables and idle browser memory compress
# very well, so a zram swap in front of the D: swap absorbs most of the pressure
if ! grep -q zram /proc/swaps; then
  modprobe zram num_devices=1 2>/dev/null
  if [ -e /sys/block/zram0 ]; then
    echo zstd > /sys/block/zram0/comp_algorithm 2>/dev/null || echo lz4 > /sys/block/zram0/comp_algorithm
    echo 6G > /sys/block/zram0/disksize
    mkswap /dev/zram0 >/dev/null && swapon -p 100 /dev/zram0 && echo "[zram] 6G compressed swap on ($(cat /sys/block/zram0/comp_algorithm | grep -o '\[[a-z0-9]*\]'))"
  else
    echo "[zram] not available"
  fi
fi
swapon --show | sed 's/^/  /'

win_up() { DISPLAY=:$1 wmctrl -l 2>/dev/null | grep -qi "edge"; }
for ws in $LIST; do
  source /root/workspaces/$ws/ws.conf
  bash "$REPO/tools/relay/ws-start.sh" "$ws"
  for i in $(seq 1 30); do win_up $DISP && break; sleep 3; done
  win_up $DISP && echo "  [$ws] Edge window up" || echo "  [$ws] no window yet"
  sleep 20      # let the startup spike settle before the next one
  free -m | awk 'NR==2{printf "  mem used %s/%s MB", $3, $2} NR==3{printf ", swap %s MB\n", $3}'
done

echo "=== all started ==="
for i in $(seq 1 480); do
  sleep 30
  line="[sup $i $(date +%H:%M:%S)] $(free -m | awk 'NR==2{printf "mem %s/%sMB", $3, $2} NR==3{printf " swap %sMB", $3}')"
  for ws in $LIST; do
    source /root/workspaces/$ws/ws.conf
    if ! DISPLAY=:$DISP xdpyinfo >/dev/null 2>&1 || \
       ! timeout 2 bash -c "exec 3<>/dev/tcp/127.0.0.1/$VNC; head -c 7 <&3" >/dev/null 2>&1; then
      line="$line $ws:display-restart"; bash "$REPO/tools/relay/ws-start.sh" "$ws" >/dev/null 2>&1
    elif ! win_up $DISP; then
      line="$line $ws:edge-restart"; bash "$REPO/tools/relay/ws-start.sh" "$ws" >/dev/null 2>&1
    else
      line="$line $ws:ok"
    fi
  done
  echo "$line"
done
