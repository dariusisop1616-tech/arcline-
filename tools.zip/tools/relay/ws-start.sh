#!/bin/bash
# Start ONE workspace: its display (Xvfb + fluxbox + x11vnc + noVNC), its audio
# server, and its Edge. Every setting comes from /root/workspaces/<ws>/ws.conf.
#   usage: ws-start.sh ws1
set -u
N="$1"; R=/root/workspaces/$N
source "$R/ws.conf"
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
LOG="$R/logs"; mkdir -p "$LOG"
export DISPLAY=:$DISP
AVAIL_H=$((SCREEN_H - BAR))

# ---- display ------------------------------------------------------------------
cur=$(xdpyinfo 2>/dev/null | awk '/dimensions:/{print $2}')
if [ "$cur" != "${SCREEN_W}x${SCREEN_H}" ]; then
  pkill -9 -f "Xvfb :$DISP " 2>/dev/null; sleep 1
  rm -f /tmp/.X11-unix/X$DISP /tmp/.X$DISP-lock
  setsid nohup Xvfb :$DISP -screen 0 ${SCREEN_W}x${SCREEN_H}x24 -ac >"$LOG/xvfb.log" 2>&1 &
  for i in 1 2 3 4 5; do xdpyinfo >/dev/null 2>&1 && break; sleep 1; done
fi
pgrep -f "fluxbox -display :$DISP" >/dev/null || \
  ( setsid nohup fluxbox -display :$DISP -rc "$R/fluxbox/init" >"$LOG/fluxbox.log" 2>&1 & )
if ! timeout 2 bash -c "exec 3<>/dev/tcp/127.0.0.1/$VNC; head -c 7 <&3" >/dev/null 2>&1; then
  pkill -9 -f "x11vnc.*rfbport $VNC" 2>/dev/null; sleep 1
  ( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR
    setsid nohup x11vnc -display :$DISP -forever -shared -nopw -quiet -rfbport $VNC \
      -noxdamage -xkb -o "$LOG/x11vnc.log" >/dev/null 2>&1 & )
fi
pgrep -f "websockify.* $WEB " >/dev/null || \
  ( setsid nohup websockify --web=/usr/share/novnc $WEB localhost:$VNC >"$LOG/websockify.log" 2>&1 & )

# ---- audio: own 48 kHz server --------------------------------------------------
export PULSE_SERVER=unix:$R/pulse/native
pactl info >/dev/null 2>&1 || bash "$REPO/tools/relay/setup-audio.sh" "$N" >"$LOG/audio.log" 2>&1
# Edge reads the device's rate once at startup; if the 48 kHz sink is not loaded
# yet it falls back to 44.1 kHz (seen once in 3 probes). Wait for the sink.
for i in $(seq 1 20); do
  pactl list sinks short 2>/dev/null | grep -q "speakers.*48000Hz" && break
  sleep 0.5
done

# ---- memory: KSM merges the per-process msedge.dll copies Wine makes and
# collapses zero pages (measured: one workspace 2814 MB -> 837 MB, ~0.3% CPU at
# this gentle scan rate). The shim opts every Wine process in (KSM_MERGE=1).
K=/sys/kernel/mm/ksm
if [ "$(cat $K/run 2>/dev/null)" != 1 ]; then
  echo 1 > $K/use_zero_pages; echo 1000 > $K/pages_to_scan; echo 200 > $K/sleep_millisecs
  echo 1 > $K/run
fi
export KSM_MERGE=${KSM_MERGE:-1}
# NOT WINE_STABLE_IMAGE_BASE: that experiment (patch 0002) crashed Edge with a
# page fault, because an image whose preferred address is taken then gets mapped
# elsewhere without relocation. Patch 0004 shares the cache without it.

# ---- Edge ---------------------------------------------------------------------
export WINEPREFIX=$R/prefix
# WINE_TREE picks the Wine build (default: the workspace's clone of stock Wine;
# $R/wine-ours = our own build). URL_OVERRIDE replaces the start page (probes).
WINE_TREE=${WINE_TREE:-$R/wine}
URL=${URL_OVERRIDE:-$URL}
export PATH="$WINE_TREE/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDEBUG=-all WINEDLLOVERRIDES="mscoree,mshtml=;dwrite=n"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES LC_ALL
export GALLIUM_DRIVER=d3d12
export LANG=$LANG_WS
export FONTCONFIG_FILE=$R/fontconfig/fonts.conf
export FAKE_MEM_KB=$MEM_KB
EDGE="$R/prefix/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
( export LD_PRELOAD=/root/winelab/mem/memshim_env.so
  setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --window-position=0,0 --window-size=$SCREEN_W,$AVAIL_H \
    --user-data-dir='C:\ws' "$URL" >"$LOG/edge.log" 2>&1 & )
echo "[$N] started: display :$DISP ${SCREEN_W}x${SCREEN_H}, noVNC http://localhost:$WEB/vnc.html"
