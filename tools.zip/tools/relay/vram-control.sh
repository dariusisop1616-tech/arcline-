#!/bin/bash
# Control experiment: allocate a KNOWN amount of GPU memory from inside a
# workspace, so we can tell whether Windows' nvidia-smi can see WSL allocations
# at all. Without this, "the workspace used 0 MiB VRAM" is not trustworthy.
N="${1:-ws1}"; COUNT="${2:-40}"; SECS="${3:-70}"
R=/root/workspaces/$N; source $R/ws.conf
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
export DISPLAY=:$DISP WINEPREFIX=$R/prefix WINEDEBUG=-all GALLIUM_DRIVER=d3d12
export PATH="$R/wine-ours/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml="
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
mkdir -p /root/relay
cp -f "$REPO/tools/relay/vram_alloc.exe" /root/relay/ 2>/dev/null
cd /root/relay
echo "allocating $((COUNT * 16)) MB of GPU memory inside $N for ${SECS}s..."
setsid nohup wine vram_alloc.exe "$COUNT" "$SECS" > /root/relay/vram.log 2>&1 &
sleep 12
cat /root/relay/vram.log | grep -a allocated | sed 's/^/  /'
