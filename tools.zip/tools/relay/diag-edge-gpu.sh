#!/bin/bash
# WHY does Edge's GPU process die on the real-GPU path when a plain D3D11 app
# (d3d11_hard.exe) runs fine on it? Capture both sides of the story:
#   - Wine's own fixme/err lines (what wined3d/dxgi cannot do)
#   - Chromium's verbose GPU/ANGLE logging (what ANGLE asked for)
# Crash signature so far: exit_code=0x80000003 (STATUS_BREAKPOINT = a CHECK/
# __debugbreak inside the GPU process) + "Failed to create shared context".
export LC_ALL=C.UTF-8 DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml="
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
export GALLIUM_DRIVER=d3d12
OUT=/root/winelab/out; mkdir -p "$OUT"
LOG="$OUT/edge-gpu-diag.log"
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
ANGLE="${1:-d3d11}"
HEADROOM=1200

echo "== clean slate (Edge only - NEVER the display: the user watches on :6080) =="
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 1
pkill -9 -x wineserver 2>/dev/null; sleep 1
rm -rf /root/.wine/drive_c/t16 2>/dev/null; : > "$LOG"

# The display stack must be up for Edge to map at all, and it must stay up so the
# noVNC view keeps working. Revive whatever is missing before launching.
if ! xdpyinfo >/dev/null 2>&1; then
  rm -f /tmp/.X11-unix/X9 /tmp/.X9-lock 2>/dev/null
  setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 &
  sleep 3
fi
pgrep -x fluxbox >/dev/null || { setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & sleep 2; }
if ! timeout 2 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 7 <&3' >/dev/null 2>&1; then
  pkill -9 -x x11vnc 2>/dev/null; sleep 1
  ( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR
    setsid nohup x11vnc -display :9 -forever -shared -nopw -quiet -rfbport 5901 \
      -noxdamage -xkb -o "$OUT/x11vnc.log" >/dev/null 2>&1 & ); sleep 2
fi
pgrep -f websockify >/dev/null || { setsid nohup websockify --web=/usr/share/novnc 6080 \
  localhost:5901 >"$OUT/websockify.log" 2>&1 & sleep 2; }
echo "  display=$(xdpyinfo >/dev/null 2>&1 && echo up || echo DOWN) rfb=$(timeout 2 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 7 <&3' 2>/dev/null)"

echo "== wined3d -> gl (the path proven byte-identical by d3d11_hard.exe) =="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d gl /f >/dev/null 2>&1

echo "== launch Edge --use-angle=$ANGLE with Wine fixmes + chromium gpu verbosity =="
# WINEDEBUG left at default: err+fixme only (a +trace on d3d11 would be GBs)
( export WINEDEBUG="+loaddll"
  setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --use-angle="$ANGLE" --enable-logging=stderr --v=1 \
    --vmodule="*angle*=3,*gpu*=2,*gl*=2" \
    --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t16' --new-window \
    "file:///Z:/root/linuxlab/rx580-check.html#rx580" >"$LOG" 2>&1 & )

for i in $(seq 1 40); do
  left=$(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}')
  t=$(wmctrl -l 2>/dev/null | grep -iE "microsoft|identity|rx580" | tail -1 | cut -c1-140)
  printf '  t=%-4ss left=%-5s procs=%-2s %s\n' "$((i*3))" "$left" "$(pgrep -fc msedge)" "${t:-no-window}"
  if [ "$left" -lt "$HEADROOM" ]; then echo "  !!! watchdog"; pkill -9 -f msedge; break; fi
  case "$t" in *RX580CHECK*) break ;; esac
  sleep 3
done

echo
echo "=== what Wine could not do (fixme/err from the GPU side) ==="
grep -aE "fixme:|err:" "$LOG" | grep -aiE "d3d11|dxgi|d3d|wgl|opengl|vulkan|shared|texture|swapchain" \
  | sed 's/^[0-9a-f]*:[0-9a-f]*:*//' | sort | uniq -c | sort -rn | head -25 | cut -c1-200

echo
echo "=== ANGLE / GPU init trail (chromium verbose) ==="
grep -aiE "angle|egl|d3d11|display init|gpu_init|InitializeGLOneOff|fallback|swiftshader|CHECK|FATAL" "$LOG" \
  | grep -avE "CompositorAnimation|task_manager|network_change|persistent_cache|geolocation" \
  | tail -30 | cut -c1-230

echo
echo "=== crash lines ==="
grep -aE "GPU process exited|FatalFailure|STATUS_|0x80000003|exit_code" "$LOG" | tail -6 | cut -c1-200
echo "log: $LOG ($(stat -c%s "$LOG" 2>/dev/null) bytes)"
