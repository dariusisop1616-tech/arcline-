#!/bin/bash
# Where does the GL path's adapter description "NVIDIA GeForce RTX 3060 Ti (GA104
# Low Hash Rate)" come from? It can only be served from a binary that contains it.
# Chromium strips commas from the description; the source string has one.
S='RTX 3060 Ti (GA104, Low Hash Rate)'
for f in /opt/wine-staging/lib/wine/x86_64-windows/*.dll \
         /opt/wine-staging/lib/wine/x86_64-unix/*.so \
         /root/.wine/drive_c/windows/system32/wined3d.dll; do
  [ -f "$f" ] || continue
  c=$(grep -c -a -F "$S" "$f" 2>/dev/null)
  [ "${c:-0}" -gt 0 ] && echo "  FOUND x$c in $f"
done
echo "wined3d unix side exists? $(ls /opt/wine-staging/lib/wine/x86_64-unix/ | grep -i wined3d || echo no)"
echo "prefix system32 wined3d: $(stat -c%s /root/.wine/drive_c/windows/system32/wined3d.dll 2>/dev/null) bytes (a placeholder if tiny)"
echo "real wined3d.dll       : $(stat -c%s /opt/wine-staging/lib/wine/x86_64-windows/wined3d.dll) bytes"
