#!/bin/bash
# wineboot hangs regardless of fonts, and the HKLM\...\Fonts key is NOT what the
# browser reads (the probe measured 12 families while that key held 78 entries).
# Wine builds its font list per process from C:\windows\Fonts + fontconfig. So:
# put the Windows fonts back and ask the browser directly.
export LC_ALL=C.UTF-8 DISPLAY=:9
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
export GALLIUM_DRIVER=d3d12
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT=/root/winelab/out; FP=/root/fp; PORT=47800
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
D=/root/.wine/drive_c/windows/Fonts
STAGE=/root/fonts-staging

echo "[1] restore the Windows fonts into the prefix"
mkdir -p "$D"
[ -d "$STAGE" ] && cp -f "$STAGE"/* "$D"/ 2>/dev/null
echo "    prefix fonts: $(ls "$D" 2>/dev/null | wc -l)"

echo "[2] stop wine, keep the display (viewer on :6080)"
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
pkill -9 -x wineserver 2>/dev/null; sleep 1
xdpyinfo >/dev/null 2>&1 || { rm -f /tmp/.X11-unix/X9 /tmp/.X9-lock
  setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 & sleep 3; }
pgrep -x fluxbox >/dev/null || { setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & sleep 2; }
timeout 2 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 7 <&3' >/dev/null 2>&1 || {
  pkill -9 -x x11vnc; sleep 1
  ( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR
    setsid nohup x11vnc -display :9 -forever -shared -nopw -quiet -rfbport 5901 \
      -noxdamage -xkb -o "$OUT/x11vnc.log" >/dev/null 2>&1 & ); sleep 2; }
pgrep -f websockify >/dev/null || { setsid nohup websockify --web=/usr/share/novnc 6080 \
  localhost:5901 >"$OUT/websockify.log" 2>&1 & sleep 2; }
pgrep -f collect.py >/dev/null || ( setsid nohup python3 "$REPO/tools/relay/collect.py" \
  "$FP" "$PORT" /root/linuxlab/fp.html >"$OUT/collect.log" 2>&1 & )
sleep 2

echo "[3] real-GPU config"
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d gl /f >/dev/null 2>&1
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v VideoPciVendorID /t REG_DWORD /d 4318 /f >/dev/null 2>&1
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v VideoPciDeviceID /t REG_DWORD /d 9353 /f >/dev/null 2>&1

echo "[4] Edge -> probe (first start pays the font scan)"
rm -f "$FP/wine3.txt"; rm -rf /root/.wine/drive_c/t22
( setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t22' --new-window \
    "http://127.0.0.1:$PORT/probe?post=/?as=wine3" >"$OUT/edge-fonts.log" 2>&1 & )
for i in $(seq 1 60); do
  [ -s "$FP/wine3.txt" ] && { echo "    captured at t=$((i*4))s"; break; }
  left=$(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}')
  [ "$left" -lt 700 ] && { echo "    watchdog at t=$((i*4))s"; pkill -9 -f msedge; break; }
  sleep 4
done

echo
echo "[5] what the browser now sees"
if [ -s "$FP/wine3.txt" ]; then
  grep -E "^(fonts\.count|fonts\.hash|canvas2d\.|webgl\.UNMASKED_RENDERER)" "$FP/wine3.txt" | sed 's/^/    /'
  echo "    --- windows reference ---"
  grep -E "^(fonts\.count|fonts\.hash|canvas2d\.)" "$FP/windows.txt" | sed 's/^/    /'
else
  echo "    NO CAPTURE; log tail:"; tail -5 "$OUT/edge-fonts.log" | cut -c1-160 | sed 's/^/    /'
fi
