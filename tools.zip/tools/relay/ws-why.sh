#!/bin/bash
# Why is a workspace's page not loading? Processes per workspace, CPU, log tail.
for ws in ws2 ws3; do
  R=/root/workspaces/$ws
  n=0; cpu=0
  for p in $(pgrep -f msedge); do
    grep -qz "WINEPREFIX=$R/prefix" /proc/$p/environ 2>/dev/null || continue
    n=$((n+1)); c=$(ps -o %cpu= -p $p | tr -d ' '); cpu=$(echo "$cpu + ${c:-0}" | bc)
  done
  echo "[$ws] edge procs=$n  cpu=${cpu}%"
  grep -avE "CompositorAnimation|task_manager|WSALookup|DRI3|Ensure your X" $R/logs/edge.log 2>/dev/null | tail -4 | cut -c1-170 | sed 's/^/   /'
done
echo "zram:"; awk '{printf "  %d MB stored in %d MB RAM (%.1fx)\n", $1/1048576, $3/1048576, ($3>0?$1/$3:0)}' /sys/block/zram0/mm_stat
echo "vmstat (si/so = swap in/out per s):"; vmstat 1 3 | tail -2 | sed 's/^/  /'
