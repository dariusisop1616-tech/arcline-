#!/bin/bash
# Remove browser-side tells and background services with Edge's OWN policies
# (registry under HKLM\SOFTWARE\Policies\Microsoft\Edge) - supported settings,
# not flags, so no "unsupported command-line flag" banner and no patching.
#
#   CommandLineFlagSecurityWarningsEnabled=0  hides the yellow --no-sandbox bar
#                                             that real Edge never shows
#   the rest disable background features that cost processes and RAM
N="${1:-ws1}"; R=/root/workspaces/$N
export WINEPREFIX=$R/prefix WINEDEBUG=-all
export PATH="${WINE_TREE:-$R/wine-ours}/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
K='HKLM\SOFTWARE\Policies\Microsoft\Edge'
set_d() { timeout 30 wine reg add "$K" /v "$1" /t REG_DWORD /d "$2" /f >/dev/null 2>&1; }
set_d CommandLineFlagSecurityWarningsEnabled 0
set_d HubsSidebarEnabled 0            # Copilot/"Conversation" sidebar
set_d EdgeCollectionsEnabled 0
set_d ShowMicrosoftRewards 0
set_d EdgeShoppingAssistantEnabled 0
set_d WalletDonationEnabled 0
set_d BackgroundModeEnabled 0         # no service after the window closes
set_d StartupBoostEnabled 0
set_d SleepingTabsEnabled 1           # let idle tabs release memory
set_d BrowserSignin 0
set_d SyncDisabled 1
set_d AutofillCreditCardEnabled 0
set_d PersonalizationReportingEnabled 0
set_d UserFeedbackAllowed 0
set_d DiagnosticData 0
echo "[$N] policies written:"
timeout 30 wine reg query "$K" 2>/dev/null | grep REG_DWORD | wc -l | sed 's/^/  values: /'
