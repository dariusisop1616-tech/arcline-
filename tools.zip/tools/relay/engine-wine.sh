#!/bin/bash
# Launch the workspace's Edge under our PATCHED Wine with a CDP debug port, then
# run the engine test against it. Proves the CDP injection method works on our
# stack (real GPU + patched Wine + our build).
N="${1:-ws1}"; R=/root/workspaces/$N; source $R/ws.conf
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
export DISPLAY=:$DISP WINEPREFIX=$R/prefix WINEDEBUG=-all GALLIUM_DRIVER=d3d12
export PATH="$R/wine-ours/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml=;dwrite=n" LANG=$LANG_WS FAKE_MEM_KB=$MEM_KB
export FONTCONFIG_FILE=$R/fontconfig/fonts.conf PULSE_SERVER=unix:$R/pulse/native KSM_MERGE=1
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES LC_ALL
EDGE="$R/prefix/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
DBG=9333

pkill -9 -f 'msedge\.exe' 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
rm -rf $R/prefix/drive_c/engine
# --remote-debugging-port on Windows binds to the loopback of the WSL side too,
# but Wine maps it to the Linux 127.0.0.1, so node in WSL can reach it.
( export LD_PRELOAD=/root/winelab/mem/memshim_env.so
  setsid nohup wine "$EDGE" --no-sandbox --no-first-run --no-default-browser-check \
    --disable-extensions --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --remote-debugging-port=$DBG --remote-allow-origins=* \
    --user-data-dir='C:\engine' "https://browserleaks.com/canvas" \
    > $R/logs/engine.log 2>&1 & )

echo "  waiting for CDP on $DBG ..."
for i in $(seq 1 40); do
  curl -s "http://127.0.0.1:$DBG/json/version" >/dev/null 2>&1 && { echo "  CDP up at t=$((i*2))s"; break; }
  sleep 2
done
curl -s "http://127.0.0.1:$DBG/json/version" >/dev/null 2>&1 || {
  echo "  CDP NOT reachable"; grep -aiE "DevTools|debugg|error" $R/logs/engine.log | tail -5 | sed 's/^/    /'; exit 1; }
sleep 5
DBG_PORT=$DBG node "$REPO/tools/relay/engine-test.mjs"
