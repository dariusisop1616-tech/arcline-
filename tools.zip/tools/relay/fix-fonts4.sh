#!/bin/bash
# Rebuild the prefix font registry properly.
#   - deleting HKLM\...\Fonts left it empty: only `wineboot -u` re-registers the
#     fonts found in C:\windows\Fonts, so run that.
#   - first PROVE whether FONTCONFIG_FILE is honoured, instead of assuming: if it
#     is ignored, the distro families cannot be hidden this way and the fix has
#     to move to Wine's own font loader.
set -u
export WINEPREFIX=/root/.wine PATH="/opt/wine-staging/bin:$PATH" WINEDEBUG=-all
PREFIX=/root/.wine/drive_c/windows/Fonts
FCDIR=/root/winelab/fontconfig
FC="$FCDIR/fonts.conf"

echo "== [0] is FONTCONFIG_FILE actually honoured? =="
a=$(fc-list : family 2>/dev/null | tr ',' '\n' | sort -u | wc -l)
b=$(FONTCONFIG_FILE="$FC" XDG_CACHE_HOME="$FCDIR/xdg" fc-list : family 2>/dev/null | tr ',' '\n' | sort -u | wc -l)
echo "  system config: $a families / restricted config: $b families"
[ "$a" = "$b" ] && echo "  -> IGNORED (identical counts)" || echo "  -> honoured"
echo -n "  restricted view, is DejaVu there: "
FONTCONFIG_FILE="$FC" XDG_CACHE_HOME="$FCDIR/xdg" fc-match "DejaVu Sans" 2>/dev/null | head -1

echo
echo "== [1] wineboot -u to re-register the prefix fonts =="
export FONTCONFIG_FILE="$FC" XDG_CACHE_HOME="$FCDIR/xdg"
timeout 180 wineboot -u >/dev/null 2>&1
wineserver -w 2>/dev/null
sleep 2
echo -n "  registered now: "
wine reg query "HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts" 2>/dev/null | grep -c REG_SZ

echo
echo "== [2] which families did Wine register =="
wine reg query "HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts" 2>/dev/null \
  | grep REG_SZ | sed -E 's/^[[:space:]]*//; s/[[:space:]]+REG_SZ.*//' | sort -u > /tmp/reg-fonts.txt
wc -l < /tmp/reg-fonts.txt | sed 's/^/  total: /'
echo "  windows-only check:"
for f in "Segoe UI" Calibri Cambria Consolas Candara Corbel Impact Georgia Verdana; do
  grep -qi "^$f" /tmp/reg-fonts.txt && echo "    OK   $f" || echo "    MISS $f"
done
echo "  linux leaks:"
grep -iE "dejavu|liberation|c059|d050000l|nimbus|ubuntu|roboto|noto" /tmp/reg-fonts.txt \
  | head -6 | sed 's/^/    LEAK: /' || echo "    none"
