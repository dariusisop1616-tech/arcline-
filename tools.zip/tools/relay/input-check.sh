#!/bin/bash
# Is input real and trusted in a workspace? Reports, for the Edge window on a
# display: focus/active state, pointer, and (with a probe page) whether a
# synthesized-vs-real click is seen as isTrusted with correct coordinates.
N="${1:-ws1}"; source /root/workspaces/$N/ws.conf
export DISPLAY=:$DISP
echo "[$N display :$DISP]"
echo "  active window : $(xdotool getactivewindow getwindowname 2>/dev/null)"
echo "  focus window  : $(xdotool getwindowfocus getwindowname 2>/dev/null)"
echo "  pointer       : $(xdotool getmouselocation 2>/dev/null)"
echo "  edge windows  :"; wmctrl -l 2>/dev/null | grep -i edge | sed 's/^/    /'
