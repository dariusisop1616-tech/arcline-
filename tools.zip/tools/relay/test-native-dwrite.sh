#!/bin/bash
# The deep reason canvas text cannot match by copying fonts alone:
#
# Chromium does not draw glyphs itself - on Windows it asks **DirectWrite**
# (dwrite.dll) to rasterise them, and Skia composites the result. Under Wine,
# dwrite.dll is Wine's reimplementation backed by FreeType. FreeType and
# Microsoft's rasteriser make different decisions about hinting, stem darkening
# and anti-aliasing, so the same font file at the same size yields different
# pixels - which is exactly the canvas2d.textBandHash / toDataURLHash gap, while
# the GPU-only canvas2d.gradientHash already matches.
#
# So: run the browser against the REAL Microsoft DirectWrite. The browser stays
# untouched; we only swap a DLL underneath it, which is what Wine is for.
# Windows' dwrite.dll may or may not load under Wine - this measures it.
set -u
export WINEPREFIX=/root/.wine PATH="/opt/wine-staging/bin:$PATH" WINEDEBUG=-all
SYS32=/root/.wine/drive_c/windows/system32
WINSYS=/mnt/c/Windows/System32
OUT=/root/winelab/out; mkdir -p "$OUT"

echo "== copy Microsoft's DirectWrite (and its usual companions) into the prefix =="
for d in dwrite.dll d2d1.dll; do
  if [ -f "$WINSYS/$d" ]; then
    cp -f "$WINSYS/$d" "$SYS32/$d.native" 2>/dev/null \
      && echo "  staged $d ($(stat -c%s "$SYS32/$d.native") bytes)" \
      || echo "  FAILED to copy $d"
  else
    echo "  $d not found on host"
  fi
done

echo
echo "== version check (what we are asking Wine to load) =="
for d in dwrite d2d1; do
  [ -f "$SYS32/$d.dll.native" ] && printf '  %s: ' "$d" && \
    strings -e l "$SYS32/$d.dll.native" 2>/dev/null | grep -oE "10\.0\.[0-9]{5}\.[0-9]+" | head -1
done

echo
echo "== try loading native dwrite in a throwaway GDI app =="
# Install as the real name, keep Wine's copy so we can revert instantly.
[ -f "$SYS32/dwrite.dll" ] && [ ! -f "$SYS32/dwrite.dll.wine-backup" ] && \
  cp -f "$SYS32/dwrite.dll" "$SYS32/dwrite.dll.wine-backup" 2>/dev/null
cp -f "$SYS32/dwrite.dll.native" "$SYS32/dwrite.dll" 2>/dev/null

( export WINEDLLOVERRIDES="dwrite=n"
  timeout 40 wine notepad.exe >"$OUT/dwrite-test.log" 2>&1 & )
sleep 12
if pgrep -f notepad.exe >/dev/null; then
  echo "  notepad RUNS with native dwrite (no immediate loader failure)"
else
  echo "  notepad did NOT stay up - native dwrite likely failed to load:"
  grep -aiE "err:|dwrite|not found|Unhandled" "$OUT/dwrite-test.log" | tail -6 | sed 's/^/    /'
fi
pkill -9 -f notepad.exe 2>/dev/null

echo
echo "== revert to Wine's dwrite (the Edge test enables it explicitly) =="
[ -f "$SYS32/dwrite.dll.wine-backup" ] && cp -f "$SYS32/dwrite.dll.wine-backup" "$SYS32/dwrite.dll" \
  && echo "  reverted; native copy kept at dwrite.dll.native"
