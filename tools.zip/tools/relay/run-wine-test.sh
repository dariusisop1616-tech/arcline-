#!/bin/bash
# Run the SAME d3d11_test.exe under Wine, two ways, and compare against the
# native Windows baseline. Native RTX 3060 Ti = PIXEL_FNV 9d262fa2.
#   A) wined3d on Vulkan -> our ICD -> llvmpipe   (the lab's current config)
#   B) wined3d on GL     -> Mesa d3d12 -> real RTX (real GPU, but translated)
# If B matched the baseline the relay would be unnecessary; it is expected not to.
export LC_ALL=C.UTF-8 DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all"
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
mkdir -p /root/relay && cp -f "$REPO/tools/relay/d3d11_test.exe" /root/relay/ 2>/dev/null
cd /root/relay || exit 1
ITERS="${1:-20}"

echo "=== A) wined3d renderer=vulkan (our ICD, llvmpipe underneath) ==="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d vulkan /f >/dev/null 2>&1
( export VK_DRIVER_FILES=/root/vkicd/rx580_icd.json VK_ICD_FILENAMES=/root/vkicd/rx580_icd.json
  export LIBGL_ALWAYS_SOFTWARE=1 GALLIUM_DRIVER=llvmpipe
  timeout 180 wine d3d11_test.exe --iters "$ITERS" 2>&1 | grep -vE "^[0-9a-f]{4}:|fixme|err:|warn:" )

echo
echo "=== B) wined3d renderer=gl, Mesa d3d12 -> real RTX 3060 Ti ==="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d gl /f >/dev/null 2>&1
( unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
  export GALLIUM_DRIVER=d3d12
  timeout 180 wine d3d11_test.exe --iters "$ITERS" 2>&1 | grep -vE "^[0-9a-f]{4}:|fixme|err:|warn:" )

echo
echo "=== restore lab config (renderer=vulkan for the Edge identity) ==="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d vulkan /f >/dev/null 2>&1
echo "  baseline to beat: native RTX 3060 Ti PIXEL_FNV = 9d262fa2"
