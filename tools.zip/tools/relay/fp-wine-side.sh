#!/bin/bash
# Wine half of the fingerprint comparison. Serves the probe over http from the
# collector (a file:// page cannot POST to http://localhost) and loads it in the
# lab's Edge, keeping the display alive for the noVNC viewer.
export LC_ALL=C.UTF-8 DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all"
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT=/root/winelab/out; FP=/root/fp; PORT=47800
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
mkdir -p "$FP" /root/linuxlab "$OUT"
cp -f "$REPO/tools/fingerprint-probe.html" /root/linuxlab/fp.html

echo "== collector (also serves /probe) =="
pkill -f collect.py 2>/dev/null; sleep 1
( setsid nohup python3 "$REPO/tools/relay/collect.py" "$FP" "$PORT" /root/linuxlab/fp.html \
    >"$OUT/collect.log" 2>&1 & )
sleep 2
ss -ltn 2>/dev/null | grep -q ":$PORT" && echo "  listening on $PORT" || echo "  FAILED"
curl -s -o /dev/null -w "  /probe serves: %{http_code}\n" "http://127.0.0.1:$PORT/probe"

echo "== ensure display (the user is watching :6080) =="
xdpyinfo >/dev/null 2>&1 || { rm -f /tmp/.X11-unix/X9 /tmp/.X9-lock
  setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 & sleep 3; }
pgrep -x fluxbox >/dev/null || { setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & sleep 2; }
timeout 2 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 7 <&3' >/dev/null 2>&1 || {
  pkill -9 -x x11vnc; sleep 1
  ( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR
    setsid nohup x11vnc -display :9 -forever -shared -nopw -quiet -rfbport 5901 \
      -noxdamage -xkb -o "$OUT/x11vnc.log" >/dev/null 2>&1 & ); sleep 2; }
pgrep -f websockify >/dev/null || { setsid nohup websockify --web=/usr/share/novnc 6080 \
  localhost:5901 >"$OUT/websockify.log" 2>&1 & sleep 2; }

echo "== Wine Edge -> http://127.0.0.1:$PORT/probe =="
rm -f "$FP/wine.txt"
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
rm -rf /root/.wine/drive_c/t17 2>/dev/null
( export VK_DRIVER_FILES=/root/vkicd/rx580_icd.json VK_ICD_FILENAMES=/root/vkicd/rx580_icd.json
  export LIBGL_ALWAYS_SOFTWARE=1 GALLIUM_DRIVER=llvmpipe
  setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --use-angle=vulkan --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t17' --new-window \
    "http://127.0.0.1:$PORT/probe?post=/?as=wine" >"$OUT/edge-fp.log" 2>&1 & )

for i in $(seq 1 40); do
  [ -s "$FP/wine.txt" ] && { echo "  wine.txt captured at t=$((i*3))s"; break; }
  sleep 3
done
[ -s "$FP/wine.txt" ] || echo "  NO CAPTURE (see $OUT/edge-fp.log)"
ls -l "$FP"/*.txt 2>/dev/null | sed 's/^/  /'
