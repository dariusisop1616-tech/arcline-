#!/bin/bash
# The 281 font files landed in C:\windows\Fonts but the browser still measured
# only 12 families, so Wine never rescanned: it keeps a font cache in the
# registry (HKCU\Software\Wine\Fonts\Cache) and trusts it across restarts.
# Drop the cache, kill wineserver so win32u rebuilds the list, then show what
# Wine actually registered - that list is what DirectWrite (and therefore
# Chromium) can enumerate.
set -u
export WINEPREFIX=/root/.wine PATH="/opt/wine-staging/bin:$PATH" WINEDEBUG=-all
PREFIX=/root/.wine/drive_c/windows/Fonts
FC=/root/winelab/fontconfig/fonts.conf

echo "== before: font files vs registered families =="
echo "  files in prefix Fonts dir : $(ls "$PREFIX" 2>/dev/null | wc -l)"
echo -n "  registered in registry    : "
wine reg query "HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts" 2>/dev/null | grep -c REG_SZ

echo
echo "== drop Wine's font cache and let win32u rebuild =="
wine reg delete "HKCU\\Software\\Wine\\Fonts\\Cache" /f >/dev/null 2>&1 && echo "  cache deleted" || echo "  (no cache key)"
wine reg delete "HKCU\\Software\\Wine\\Fonts" /v "Cache" /f >/dev/null 2>&1
wineserver -k 2>/dev/null; sleep 2
pkill -9 -x wineserver 2>/dev/null; sleep 1

echo "== rebuild (a trivial wine command re-inits win32u and rescans fonts) =="
wine reg query "HKCU\\Software\\Wine" >/dev/null 2>&1
sleep 3

echo
echo "== after =="
echo -n "  registered in registry    : "
wine reg query "HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts" 2>/dev/null | grep -c REG_SZ
echo "  sample of registered names:"
wine reg query "HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts" 2>/dev/null \
  | grep REG_SZ | awk '{print "    " $1, $2, $3}' | head -12

echo
echo "== does fontconfig-restricted view still show linux families? =="
FONTCONFIG_FILE="$FC" XDG_CACHE_HOME=/root/winelab/fontconfig/xdg \
  fc-list : family 2>/dev/null | tr ',' '\n' | sort -u \
  | grep -iE "ubuntu|dejavu|liberation|roboto|noto|cantarell" | head -8 | sed 's/^/    LEAK: /'
echo -n "  total families in that view: "
FONTCONFIG_FILE="$FC" XDG_CACHE_HOME=/root/winelab/fontconfig/xdg \
  fc-list : family 2>/dev/null | tr ',' '\n' | sort -u | wc -l
