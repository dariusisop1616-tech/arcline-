#!/bin/bash
# Mouse experiment in a workspace: open the probe, move the pointer along a fixed
# path with real X11 motion (exactly what a VNC/RDP client delivers), click, then
# press F8 so the page reports. Same path and timing as the native run.
N="${1:-ws1}"; LABEL="${2:-mouse_wine}"
R=/root/workspaces/$N; source $R/ws.conf
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
export DISPLAY=:$DISP
PORT=47800
pgrep -f collect.py >/dev/null || ( setsid nohup python3 "$REPO/tools/relay/collect.py" /root/fp $PORT \
  /root/linuxlab/fp.html >/root/winelab/out/collect.log 2>&1 & )
sleep 1
rm -f /root/fp/$LABEL.txt
bash "$REPO/tools/relay/ws-stop.sh" $N >/dev/null 2>&1
WINE_TREE=$R/wine-ours URL_OVERRIDE="http://127.0.0.1:$PORT/page/mouse.html?post=/?as=$LABEL" \
  bash "$REPO/tools/relay/ws-start.sh" $N >/dev/null 2>&1
for i in $(seq 1 40); do wmctrl -l 2>/dev/null | grep -qi edge && break; sleep 3; done
sleep 10
W=$(wmctrl -l | grep -i edge | head -1 | awk '{print $1}')
[ -z "$W" ] && { echo "no window"; exit 1; }
xdotool windowactivate --sync "$W"; sleep 1
eval $(xdotool getwindowgeometry --shell "$W")

# 200 steps around a circle, ~5 ms apart - the same path the native run uses
python3 - "$X" "$Y" "$WIDTH" "$HEIGHT" <<'EOF' > /tmp/path.txt
import sys, math
x, y, w, h = map(int, sys.argv[1:5])
cx, cy, r = x + w // 2, y + h // 2, min(w, h) // 3
for i in range(200):
    a = 2 * math.pi * i / 200
    print(int(cx + r * math.cos(a)), int(cy + r * math.sin(a)))
EOF
while read px py; do xdotool mousemove $px $py; sleep 0.005; done < /tmp/path.txt
sleep 1
xdotool click 1; sleep 0.3; xdotool click 1; sleep 1
xdotool key F8; sleep 3
for i in $(seq 1 10); do [ -s /root/fp/$LABEL.txt ] && break; sleep 2; done
echo "=== $LABEL (Wine, $N) ==="
cat /root/fp/$LABEL.txt 2>/dev/null | sed 's/^/  /' || echo "  no report (title: $(xdotool getwindowname "$W"))"
