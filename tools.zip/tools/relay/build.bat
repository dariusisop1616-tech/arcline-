@echo off
REM Build the D3D11 relay pieces with MSVC. One toolchain for both sides:
REM the Windows server AND the Wine-side DLL are PE binaries from the same
REM compiler, so gen_stubs.h (Windows SDK headers) compiles for both.
REM /MT = static CRT, so nothing needs the VC redist inside the Wine prefix.
setlocal
set VCVARS=C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat
set FXC=C:\Program Files (x86)\Windows Kits\10\bin\10.0.26100.0\x64\fxc.exe
cd /d "%~dp0"
call "%VCVARS%" >nul 2>&1
if errorlevel 1 (echo VCVARS FAILED & exit /b 1)

echo == shaders (fxc -^> embedded bytecode, identical bytes everywhere) ==
"%FXC%" /nologo /T vs_5_0 /E VSMain /Fh vs_bytecode.h /Vn g_VSMain shader.hlsl || exit /b 1
"%FXC%" /nologo /T ps_5_0 /E PSMain /Fh ps_bytecode.h /Vn g_PSMain shader.hlsl || exit /b 1
"%FXC%" /nologo /T vs_5_0 /E VSQuad /Fh vsq_bytecode.h /Vn g_VSQuad shader.hlsl || exit /b 1
"%FXC%" /nologo /T ps_5_0 /E PSTex  /Fh pst_bytecode.h /Vn g_PSTex  shader.hlsl || exit /b 1

echo == test apps ==
cl /nologo /EHsc /O2 /MT /W3 d3d11_test.cpp /Fe:d3d11_test.exe ^
   /link d3d11.lib dxgi.lib || exit /b 1
cl /nologo /EHsc /O2 /MT /W3 d3d11_hard.cpp /Fe:d3d11_hard.exe ^
   /link d3d11.lib dxgi.lib || exit /b 1

if exist relay_server.cpp (
  echo == windows-side relay server ==
  cl /nologo /EHsc /O2 /MT /W3 relay_server.cpp /Fe:relay_server.exe ^
     /link d3d11.lib dxgi.lib ws2_32.lib || exit /b 1
)

if exist relay_client.cpp (
  echo == wine-side d3d11.dll + dxgi.dll ==
  cl /nologo /EHsc /O2 /MT /W3 /LD relay_client.cpp /Fe:d3d11.dll ^
     /link /DEF:d3d11.def ws2_32.lib || exit /b 1
  cl /nologo /EHsc /O2 /MT /W3 /LD /DRELAY_DXGI relay_client.cpp /Fe:dxgi.dll ^
     /link /DEF:dxgi.def ws2_32.lib || exit /b 1
)

echo == built ==
dir /b *.exe *.dll 2>nul
endlocal
