#!/bin/bash
# Show (and with "set", apply) the text-smoothing settings DirectWrite and
# Chromium read. Target values = the host Windows (read 2026-09-28):
#   FontSmoothing=2 (on)  FontSmoothingType=2 (ClearType)
#   FontSmoothingGamma=0 (default)  FontSmoothingOrientation=1 (RGB)
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDEBUG=-all
K='HKCU\Control Panel\Desktop'
show() {
  for v in FontSmoothing FontSmoothingType FontSmoothingGamma FontSmoothingOrientation; do
    printf '  %-26s %s\n' "$v" "$(timeout 20 wine reg query "$K" /v $v 2>/dev/null | awk '/REG_/{print $2, $3}')"
  done
}
echo "== wine prefix now =="; show
if [ "$1" = set ]; then
  timeout 20 wine reg add "$K" /v FontSmoothing            /t REG_SZ    /d 2 /f >/dev/null
  timeout 20 wine reg add "$K" /v FontSmoothingType        /t REG_DWORD /d 2 /f >/dev/null
  timeout 20 wine reg add "$K" /v FontSmoothingGamma       /t REG_DWORD /d 0 /f >/dev/null
  timeout 20 wine reg add "$K" /v FontSmoothingOrientation /t REG_DWORD /d 1 /f >/dev/null
  wineserver -k 2>/dev/null
  echo "== after set =="; show
fi
