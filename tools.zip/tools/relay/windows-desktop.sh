#!/bin/bash
# Windows-like desktop for one workspace, plus a viewer that fits any monitor.
#
#  - noVNC: scale the remote screen to the browser window (no scrolling on a
#    big or small monitor), auto-connect, auto-reconnect. The workspace keeps its
#    fixed resolution - that is part of the fingerprint - only the VIEW scales.
#  - taskbar: a Start button on the left (opens a small menu), window buttons,
#    clock on the right; flat dark style from windows-taskbar.sh.
#  - Start menu: Microsoft Edge (new window) and File Explorer, launched with the
#    workspace's full environment through a helper script.
N="${1:-ws1}"; R=/root/workspaces/$N; source $R/ws.conf
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"

# --- viewer: fit to window by default (applies to every workspace's noVNC) ---
cat > /usr/share/novnc/defaults.json <<'EOF'
{
  "autoconnect": true,
  "resize": "scale",
  "reconnect": true,
  "reconnect_delay": 2000,
  "show_dot": false
}
EOF

# --- helper that opens programs with this workspace's environment ---
cat > $R/open.sh <<EOF
#!/bin/bash
# launched from the Start menu: \$1 = edge | explorer
source $R/ws.conf
export DISPLAY=:$DISP WINEPREFIX=$R/prefix WINEDEBUG=-all GALLIUM_DRIVER=d3d12
export PATH="$R/wine-ours/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml=;dwrite=n" LANG=\$LANG_WS FAKE_MEM_KB=\$MEM_KB
export FONTCONFIG_FILE=$R/fontconfig/fonts.conf PULSE_SERVER=unix:$R/pulse/native KSM_MERGE=1
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES LC_ALL
export LD_PRELOAD=/root/winelab/mem/memshim_env.so
case "\$1" in
  edge) exec wine "$R/prefix/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe" \\
          --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \\
          --disable-sync --disable-component-update --renderer-process-limit=1 \\
          --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \\
          --user-data-dir='C:\ws' --new-window ;;
  explorer) exec wine explorer.exe 'C:\' ;;
esac
EOF
chmod +x $R/open.sh

# --- Start menu ---
cat > $R/fluxbox/menu <<EOF
[begin] (Démarrer)
  [exec] (Microsoft Edge) {$R/open.sh edge}
  [exec] (Explorateur de fichiers) {$R/open.sh explorer}
[end]
EOF

# --- taskbar: Start button + window buttons + clock ---
sed -i '/^session.screen0.toolbar.tools:/d;/^session.screen0.toolbar.button/d;/^session.menuFile:/d' $R/fluxbox/init
cat >> $R/fluxbox/init <<EOF
session.menuFile:	$R/fluxbox/menu
session.screen0.toolbar.tools:	button.start, iconbar, clock
session.screen0.toolbar.button.start.label:	  ⊞
session.screen0.toolbar.button.start.commands:	RootMenu
EOF
# style for the Start button, appended once
S=$R/fluxbox/styles/win
grep -q 'toolbar.button:' $S 2>/dev/null || cat >> $S <<'EOF'
toolbar.button:                         flat solid
toolbar.button.color:                   #1f1f1f
toolbar.button.picColor:                #ffffff
toolbar.button.textColor:               #ffffff
toolbar.button.font:                    sans-14
toolbar.button.pressed:                 flat solid
toolbar.button.pressed.color:           #0078d4
EOF

export DISPLAY=:$DISP
pkill -9 -f "fluxbox -display :$DISP" 2>/dev/null; sleep 1
( setsid nohup fluxbox -display :$DISP -rc "$R/fluxbox/init" >"$R/logs/fluxbox.log" 2>&1 & )
sleep 3
echo "[$N] desktop ready: http://localhost:$WEB/vnc.html (scales to fit)"
