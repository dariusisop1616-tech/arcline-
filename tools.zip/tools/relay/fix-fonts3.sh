#!/bin/bash
# Three bugs found in the first font attempt, fixed here:
#  1. fonts.conf had a <!DOCTYPE ... SYSTEM "fonts.dtd"> line; when fontconfig
#     cannot resolve the DTD it silently falls back to the SYSTEM config, so the
#     distro fonts stayed visible. No DOCTYPE now.
#  2. Deleting the registry font cache is not enough: only a GDI process makes
#     win32u rescan. Run a real GDI app (notepad) to force the rebuild.
#  3. Wine registers fontconfig's fonts too, which is how DejaVu/C059/Liberation
#     got in. With a restricted fontconfig they disappear from that source.
set -u
export WINEPREFIX=/root/.wine PATH="/opt/wine-staging/bin:$PATH" WINEDEBUG=-all
PREFIX=/root/.wine/drive_c/windows/Fonts
FCDIR=/root/winelab/fontconfig
FC="$FCDIR/fonts.conf"
mkdir -p "$FCDIR/cache" "$FCDIR/xdg"

echo "== [1] fontconfig without a DOCTYPE (so it really parses) =="
cat > "$FC" <<EOF
<?xml version="1.0"?>
<fontconfig>
  <dir>$PREFIX</dir>
  <cachedir>$FCDIR/cache</cachedir>
  <alias><family>serif</family><prefer><family>Times New Roman</family></prefer></alias>
  <alias><family>sans-serif</family><prefer><family>Arial</family></prefer></alias>
  <alias><family>monospace</family><prefer><family>Consolas</family></prefer></alias>
  <alias><family>system-ui</family><prefer><family>Segoe UI</family></prefer></alias>
  <alias><family>cursive</family><prefer><family>Comic Sans MS</family></prefer></alias>
  <alias><family>fantasy</family><prefer><family>Impact</family></prefer></alias>
</fontconfig>
EOF
export FONTCONFIG_FILE="$FC" XDG_CACHE_HOME="$FCDIR/xdg"
fc-cache -f "$PREFIX" >/dev/null 2>&1
echo -n "  families now visible: "
fc-list : family 2>/dev/null | tr ',' '\n' | sort -u | wc -l
echo -n "  linux families leaking: "
fc-list : family 2>/dev/null | tr ',' '\n' | sort -u \
  | grep -icE "ubuntu|dejavu|liberation|roboto|noto|cantarell|c059|d050000l|nimbus|urw" || true

echo
echo "== [2] wipe the font cache AND the stale registered list =="
wine reg delete "HKCU\\Software\\Wine\\Fonts" /f >/dev/null 2>&1
wine reg delete "HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts" /f >/dev/null 2>&1
rm -rf "$FCDIR/xdg/fontconfig" 2>/dev/null
wineserver -k 2>/dev/null; sleep 2; pkill -9 -x wineserver 2>/dev/null; sleep 1

echo "== [3] force a rescan with a real GDI app =="
( setsid nohup timeout 20 wine notepad.exe >/dev/null 2>&1 & )
sleep 12
pkill -9 -f notepad.exe 2>/dev/null

echo
echo "== result =="
echo -n "  registered families: "
wine reg query "HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts" 2>/dev/null | grep -c REG_SZ
echo "  windows-only names present?"
for f in "Segoe UI" "Calibri" "Cambria" "Consolas" "Candara" "Corbel" "Ebrima" "Gadugi" "Impact"; do
  if wine reg query "HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts" 2>/dev/null | grep -qi "$f"; then
    echo "    OK   $f"
  else
    echo "    MISS $f"
  fi
done
echo "  linux names still registered?"
wine reg query "HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts" 2>/dev/null \
  | grep -iE "dejavu|liberation|c059|d050000l|nimbus|ubuntu|roboto" | head -5 | sed 's/^/    LEAK:/'
