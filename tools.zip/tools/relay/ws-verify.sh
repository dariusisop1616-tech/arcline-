#!/bin/bash
# Per workspace: what does DXGI report (the adapter ANGLE builds the WebGL
# renderer string from)? Runs the tiny d3d11_test.exe inside each workspace's
# own Wine tree + prefix, on its own display.
for ws in ws1 ws2 ws3; do
  R=/root/workspaces/$ws; source $R/ws.conf
  a=$( export DISPLAY=:$DISP WINEPREFIX=$R/prefix WINEDEBUG=-all GALLIUM_DRIVER=d3d12
       export PATH="$R/wine/bin:/usr/bin:/bin" WINEDLLOVERRIDES="mscoree,mshtml="
       unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
       cd /root/relay && timeout 120 wine d3d11_test.exe 2>/dev/null | grep -a -E "^(adapter|PIXEL)" | tr -d '\r' | tr '\n' ' ')
  printf '  %s  %s\n' "$ws" "${a:-<no answer>}"
done
