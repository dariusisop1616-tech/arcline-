#!/bin/bash
# Make the workspace look like Windows, not like a Linux window manager.
#
# What the user sees today: fluxbox puts its OWN title bar (black strip with the
# page title) above Edge, so Edge's real title/tab bar is pushed down and looks
# doubled. Real Windows has no such strip - the browser draws its own frame.
# Fix: an apps rule telling fluxbox to draw NO decorations for Edge, and to
# maximize it over the work area (the taskbar space stays reserved, so
# screen.availHeight is unchanged and the fingerprint does not move).
N="${1:-ws1}"; R=/root/workspaces/$N; source $R/ws.conf
mkdir -p $R/fluxbox
cat > "$R/fluxbox/apps" <<'EOF'
# no title bar / border for the browser: Windows browsers draw their own frame
[app] (class=msedge.exe)
  [Deco]    {NONE}
  [Maximized]   {yes}
  [Layer]   {2}
[end]
[app] (class=chrome.exe)
  [Deco]    {NONE}
  [Maximized]   {yes}
  [Layer]   {2}
[end]
[app] (class=opera.exe)
  [Deco]    {NONE}
  [Maximized]   {yes}
  [Layer]   {2}
[end]
EOF
# point fluxbox at it and keep the taskbar reserving exactly BAR pixels
grep -q '^session.appsFile:' "$R/fluxbox/init" 2>/dev/null || \
  echo "session.appsFile:	$R/fluxbox/apps" >> "$R/fluxbox/init"
sed -i "s#^session.appsFile:.*#session.appsFile:	$R/fluxbox/apps#" "$R/fluxbox/init"
echo "[$N] fluxbox apps rule written ($R/fluxbox/apps)"
grep -E 'appsFile|toolbar.height' "$R/fluxbox/init" | sed 's/^/  /'
