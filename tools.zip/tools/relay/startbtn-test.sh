#!/bin/bash
# Try Start-button labels until one renders; screenshot the taskbar each time.
N="${1:-ws1}"; R=/root/workspaces/$N; source $R/ws.conf
OUTD="/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/vm-display"
export DISPLAY=:$DISP
try() {
  sed -i '/^session.screen0.toolbar.button.start.label:/d' $R/fluxbox/init
  printf 'session.screen0.toolbar.button.start.label:\t%s\n' "$1" >> $R/fluxbox/init
  pkill -9 -f "fluxbox -display :$DISP" 2>/dev/null; sleep 1
  ( setsid nohup fluxbox -display :$DISP -rc "$R/fluxbox/init" >"$R/logs/fluxbox.log" 2>&1 & )
  sleep 3
  import -window root -crop 400x40+0+$((SCREEN_H - 40)) /root/winelab/out/bar.png 2>/dev/null
  cp -f /root/winelab/out/bar.png "$OUTD/bar-$2.png"
  echo "label '$1' -> results/vm-display/bar-$2.png"
}
try "Start" plain
wmctrl -a "Edge" 2>/dev/null
