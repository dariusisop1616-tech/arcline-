#!/bin/bash
# Which workspace owns the running Wine processes, and how much each holds
# (RSS + swapped). Anything not ws3 should be gone after ws-stop ws1 ws2.
declare -A n rss sw
for p in $(pgrep -f "wine|msedge|\.exe"); do
  e=$(tr '\0' '\n' < /proc/$p/environ 2>/dev/null | grep -oE "^WINEPREFIX=.*" | sed 's#.*/workspaces/##; s#/prefix##')
  [ -z "$e" ] && e="(other)"
  n[$e]=$(( ${n[$e]:-0} + 1 ))
  rss[$e]=$(( ${rss[$e]:-0} + $(awk '/^VmRSS/{print $2}' /proc/$p/status 2>/dev/null || echo 0) ))
  sw[$e]=$(( ${sw[$e]:-0} + $(awk '/^VmSwap/{print $2}' /proc/$p/status 2>/dev/null || echo 0) ))
done
for k in "${!n[@]}"; do printf '  %-10s procs=%-3s rss=%5d MB  swapped=%5d MB\n' "$k" "${n[$k]}" $((rss[$k]/1024)) $((sw[$k]/1024)); done
free -m | awk 'NR==2{printf "  mem %s/%s MB", $3, $2} NR==3{printf ", swap %s MB\n", $3}'
