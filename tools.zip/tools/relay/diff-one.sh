#!/bin/bash
# Diff one capture against native windows.txt (no browser launch, seconds).
F="/root/fp/${1:-wine8}.txt"
python3 - /root/fp/windows.txt "$F" <<'EOF'
import sys
def load(p):
    d = {}
    for line in open(p, encoding='utf-8', errors='replace'):
        if line.startswith('---') or ':' not in line: continue
        k, v = line.split(':', 1); d[k.strip()] = v.strip()
    return d
w, l = load(sys.argv[1]), load(sys.argv[2])
keys = list(dict.fromkeys(list(w) + list(l)))
diff = [k for k in keys if w.get(k, '<absent>') != l.get(k, '<absent>')]
print(f"identical: {len(keys) - len(diff)}   different: {len(diff)}")
for k in diff:
    print(f"  {k}\n     windows: {w.get(k,'<absent>')[:130]}\n     wine   : {l.get(k,'<absent>')[:130]}")
EOF
