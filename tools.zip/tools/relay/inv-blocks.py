#!/usr/bin/env python3
"""Investigation step 1: what IS inside a Wine renderer's memory?

For the biggest renderer of a workspace, list its largest anonymous mappings and
sample their actual bytes from /proc/<pid>/mem (read-only; the process keeps
running). A page-tracking table is a few repeated byte values; real heap data
(V8, Blink, PartitionAlloc) is varied. Also reports how much of each block is
still all-zero pages (committed-and-touched-but-empty would point at zeroing).

usage: inv-blocks.py [workspace]
"""
import os, sys, collections, subprocess

ws = sys.argv[1] if len(sys.argv) > 1 else "ws3"
prefix = f"/root/workspaces/{ws}/prefix"

def env_prefix(pid):
    try:
        return b"WINEPREFIX=" + prefix.encode() in open(f"/proc/{pid}/environ", "rb").read()
    except OSError:
        return False

def cmd(pid):
    try:
        return open(f"/proc/{pid}/cmdline", "rb").read().replace(b"\0", b" ").decode(errors="replace")
    except OSError:
        return ""

def rss_anon(pid):
    for l in open(f"/proc/{pid}/status"):
        if l.startswith("RssAnon"):
            return int(l.split()[1])
    return 0

pids = [int(p) for p in os.listdir("/proc") if p.isdigit()]
rend = [p for p in pids if "--type=renderer" in cmd(p) and env_prefix(p)]
if not rend:
    sys.exit(f"no renderer found in {ws}")
pid = max(rend, key=rss_anon)
print(f"renderer pid {pid}  RssAnon {rss_anon(pid)//1024} MB  ({len(rend)} renderers in {ws})")

# largest anonymous mappings by Anonymous kB
maps, cur = [], None
for l in open(f"/proc/{pid}/smaps"):
    f = l.split()
    if "-" in f[0] and len(f) >= 5 and ":" in f[3]:
        a, b = (int(x, 16) for x in f[0].split("-"))
        cur = {"start": a, "end": b, "name": f[5] if len(f) > 5 else "[anon]", "anon": 0}
        maps.append(cur)
    elif f[0] == "Anonymous:" and cur is not None:
        cur["anon"] = int(f[1])
big = sorted((m for m in maps if m["name"] == "[anon]"), key=lambda m: -m["anon"])[:4]

mem = open(f"/proc/{pid}/mem", "rb", buffering=0)
CH = 1 << 20
for m in big:
    size = m["end"] - m["start"]
    counts = collections.Counter(); zero_pages = pages = 0; unread = 0
    # sample up to 24 x 1 MB spread across the block
    n = min(24, max(1, size // CH))
    for i in range(n):
        off = m["start"] + (size - CH) * i // max(1, n - 1) if n > 1 else m["start"]
        try:
            mem.seek(off); d = mem.read(min(CH, m["end"] - off))
        except OSError:
            unread += 1; continue
        counts.update(d[::64])                   # byte histogram on a stride
        for p in range(0, len(d), 4096):
            pages += 1
            if not any(d[p:p + 4096]): zero_pages += 1
    tot = sum(counts.values()) or 1
    top = ", ".join(f"0x{b:02x}:{c*100//tot}%" for b, c in counts.most_common(4))
    print(f"\nblock @{m['start']:#x}  {size/2**20:.0f} MB virtual, {m['anon']/1024:.0f} MB resident")
    print(f"   distinct byte values: {len(counts)}   top: {top}")
    print(f"   all-zero pages: {zero_pages}/{pages}" + (f"   (unreadable samples: {unread})" if unread else ""))

print("\n--- renderer launch arguments (what distinguishes them) ---")
for p in sorted(rend):
    c = cmd(p)
    keep = [a for a in c.split() if a.startswith("--") and not a.startswith(("--no-sandbox", "--lang", "--user-data-dir",
            "--field-trial", "--variations", "--mojo", "--metrics", "--enable-features", "--disable-features",
            "--launch-time", "--time-ticks", "--shared-files", "--renderer-client-id", "--change-stack",
            "--seatbelt", "--pseudonymization", "--device-scale", "--num-raster", "--enable-main-frame",
            "--video-capture", "--web-bluetooth", "--first-renderer", "--disable-gpu-compositing"))]
    extra = [a for a in keep if a not in ("--type=renderer",)]
    print(f"  pid {p:<7} {rss_anon(p)//1024:>5} MB  {' '.join(extra)[:150]}")
