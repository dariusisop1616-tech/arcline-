#!/bin/bash
# Give the workspace a Windows-looking desktop: a dark taskbar with the window
# buttons on the left and a clock on the right, and a plain dark wallpaper.
# Cost is a few MB - fluxbox is already running; this only restyles it.
# The taskbar keeps reserving exactly BAR pixels, so screen.availHeight (and the
# fingerprint) does not change.
N="${1:-ws1}"; R=/root/workspaces/$N; source $R/ws.conf
mkdir -p $R/fluxbox/styles
S=$R/fluxbox/styles/win

cat > "$S" <<'EOF'
! Windows-like: flat dark taskbar, light text, subtle active button
*.font:                                 sans-8
toolbar:                                flat solid
toolbar.height:                         40
toolbar.color:                          #1f1f1f
toolbar.borderWidth:                    0
toolbar.clock:                          flat solid
toolbar.clock.color:                    #1f1f1f
toolbar.clock.textColor:                #ffffff
toolbar.clock.font:                     sans-9
toolbar.clock.justify:                  center
toolbar.workspace:                      flat solid
toolbar.workspace.color:                #1f1f1f
toolbar.workspace.textColor:            #ffffff
toolbar.iconbar.empty:                  flat solid
toolbar.iconbar.empty.color:            #1f1f1f
toolbar.iconbar.focused:                flat solid
toolbar.iconbar.focused.color:          #2d2d2d
toolbar.iconbar.focused.textColor:      #ffffff
toolbar.iconbar.focused.borderWidth:    0
toolbar.iconbar.unfocused:              flat solid
toolbar.iconbar.unfocused.color:        #1f1f1f
toolbar.iconbar.unfocused.textColor:    #d0d0d0
toolbar.iconbar.unfocused.borderWidth:  0
toolbar.iconbar.focused.justify:        left
toolbar.iconbar.unfocused.justify:      left
menu.title:                             flat solid
menu.title.color:                       #1f1f1f
menu.title.textColor:                   #ffffff
menu.frame:                             flat solid
menu.frame.color:                       #2b2b2b
menu.frame.textColor:                   #ffffff
menu.hilite:                            flat solid
menu.hilite.color:                      #0078d4
menu.hilite.textColor:                  #ffffff
window.title.focus:                     flat solid
window.title.focus.color:               #1f1f1f
window.label.focus.textColor:           #ffffff
background:                             solid
background.color:                       #0b2545
EOF

# toolbar: window buttons left, clock right, no workspace switcher (Windows has none)
sed -i '/^session.screen0.toolbar.tools:/d;/^session.styleFile:/d;/^session.screen0.strftimeFormat:/d' "$R/fluxbox/init"
cat >> "$R/fluxbox/init" <<EOF
session.screen0.toolbar.tools:	iconbar, clock
session.screen0.strftimeFormat:	%H:%M  %d/%m/%Y
session.styleFile:	$S
EOF

export DISPLAY=:$DISP
command -v xsetroot >/dev/null && xsetroot -solid "#0b2545" 2>/dev/null
pkill -9 -f "fluxbox -display :$DISP" 2>/dev/null; sleep 1
( setsid nohup fluxbox -display :$DISP -rc "$R/fluxbox/init" >"$R/logs/fluxbox.log" 2>&1 & )
sleep 3
echo "[$N] taskbar restyled; availHeight still $((SCREEN_H - BAR))"
xdpyinfo 2>/dev/null | awk '/dimensions:/{print "  screen: " $2}'
