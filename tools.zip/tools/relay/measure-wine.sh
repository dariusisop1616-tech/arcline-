#!/bin/bash
# Wine memory of ONE browser instance in a workspace (default ws2 = GTX 1080 Ti),
# same page and flags as measure-native.ps1. Memory = resident + swapped, summed
# over every process of that workspace's Wine prefix.
#   measure-wine.sh edge|chrome [url] [ws]
B="${1:-edge}"; URL="${2:-https://browserleaks.com/webgl}"; N="${3:-ws2}"; SETTLE=45
R=/root/workspaces/$N; source $R/ws.conf
export DISPLAY=:$DISP WINEPREFIX=$R/prefix WINEDEBUG=-all GALLIUM_DRIVER=d3d12
export PATH="$R/wine/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml=;dwrite=n" LANG=$LANG_WS FAKE_MEM_KB=$MEM_KB
export FONTCONFIG_FILE=$R/fontconfig/fonts.conf PULSE_SERVER=unix:$R/pulse/native
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES LC_ALL

# display + audio only (no browser)
if ! xdpyinfo >/dev/null 2>&1; then
  rm -f /tmp/.X11-unix/X$DISP /tmp/.X$DISP-lock
  setsid nohup Xvfb :$DISP -screen 0 ${SCREEN_W}x${SCREEN_H}x24 -ac >/dev/null 2>&1 &
  sleep 3
fi
pgrep -f "fluxbox -display :$DISP" >/dev/null || ( setsid nohup fluxbox -display :$DISP -rc $R/fluxbox/init >/dev/null 2>&1 & )
pactl info >/dev/null 2>&1 || bash "/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/relay/setup-audio.sh" $N >/dev/null 2>&1

wineserver -k 2>/dev/null; sleep 2
if [ "$B" = chrome ]; then
  EXE="/mnt/c/Program Files/Google/Chrome/Application/chrome.exe"; PROF='C:\memtest_chrome'
  rm -rf $R/prefix/drive_c/memtest_chrome
else
  EXE="$R/prefix/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"; PROF='C:\memtest_edge'
  rm -rf $R/prefix/drive_c/memtest_edge
fi
( export LD_PRELOAD=/root/winelab/mem/memshim_env.so
  setsid nohup wine "$EXE" --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --window-position=0,0 --window-size=1920,1040 --user-data-dir="$PROF" "$URL" \
    >$R/logs/memtest-$B.log 2>&1 & )
sleep $SETTLE

tot=0; cnt=0; rows=""
for p in $(pgrep -f "msedge|chrome"); do
  grep -qz "WINEPREFIX=$R/prefix" /proc/$p/environ 2>/dev/null || continue
  r=$(awk '/^VmRSS/{print $2}' /proc/$p/status); s=$(awk '/^VmSwap/{print $2}' /proc/$p/status)
  m=$(( (${r:-0} + ${s:-0}) / 1024 )); tot=$((tot + m)); cnt=$((cnt + 1))
  t=$(tr '\0' ' ' < /proc/$p/cmdline | grep -oE -- '--type=[a-z-]+' | head -1 | cut -d= -f2)
  rows="$rows$(printf '          %-14s %6d MB' "${t:-browser}" $m)\n"
done
printf '%-7s wine   : %2d processes  resident+swap %6d MB\n' $B $cnt $tot
printf "$rows" | sort -k2 -nr | head -6
t=$(wmctrl -l 2>/dev/null | grep -iE "edge|chrome" | head -1 | cut -c32-110)
echo "          window: ${t:-none}"
wineserver -k 2>/dev/null
