#!/bin/bash
# Per-workspace GPU name via WINEDLLPATH: Wine searches these directories for its
# builtin DLLs before its own lib dir. A workspace dir holds a renamed
# wined3d.dll (PE half) plus a link to the unchanged wined3d.so (unix half, which
# Wine locates next to the dll: <dir>/x86_64-windows <-> <dir>/x86_64-unix).
export DISPLAY=:9 WINEPREFIX=/root/.wine WINEDEBUG=-all GALLIUM_DRIVER=d3d12
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml="
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
W=/opt/wine-staging/lib/wine
SYS=/root/.wine/drive_c/windows/system32/wined3d.dll
WS=/root/workspaces/ws1/dlls
cd /root/relay

# put the prefix copy back to stock; the renamed copy lives in the workspace dir
[ -f "$SYS.orig" ] && mv -f "$SYS.orig" "$SYS"

mkdir -p "$WS/x86_64-windows" "$WS/x86_64-unix"
cp -f "$W/x86_64-windows/wined3d.dll" "$WS/x86_64-windows/wined3d.dll"
ln -sf "$W/x86_64-unix/wined3d.so" "$WS/x86_64-unix/wined3d.so"
rm -f "$WS/x86_64-windows/wined3d.dll.orig"
python3 "$REPO/tools/relay/set_gpu_name.py" "$WS/x86_64-windows/wined3d.dll" \
  "NVIDIA GeForce RTX 3060 Ti (GA104, Low Hash Rate)" "NVIDIA GeForce RTX 3060 Ti"
rm -f "$WS/x86_64-windows/wined3d.dll.orig"

adapter() { timeout 90 wine d3d11_test.exe 2>/dev/null | grep -a -E "^(adapter|PIXEL)" | tr -d '\r' | tr '\n' ' '; }
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 1
echo "[no WINEDLLPATH]  $(adapter)"
wineserver -k 2>/dev/null; sleep 1
echo "[WINEDLLPATH=ws1] $(WINEDLLPATH=$WS adapter)"
