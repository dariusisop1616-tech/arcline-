#!/bin/bash
# Seconds-fast: what is Edge doing right now?
export DISPLAY=:9
echo "edge procs : $(pgrep -fc msedge)"
echo "screen     : $(xdpyinfo 2>/dev/null | awk '/dimensions:/{print $2}')"
echo "windows    :"; wmctrl -l 2>/dev/null | cut -c1-160 | sed 's/^/  /'
echo "mem left   : $(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}') MB"
echo "log tail   :"; grep -avE "CompositorAnimation|task_manager|WSALookup" /root/winelab/out/edge-rtx.log 2>/dev/null | tail -8 | cut -c1-170 | sed 's/^/  /'
echo "collector  : $(tail -2 /root/winelab/out/collect.log 2>/dev/null | tr '\n' ' ')"
