#!/bin/bash
# Why so many renderers under Wine? Look for crashes/restarts in the memtest logs.
for b in edge chrome; do
  f=/root/workspaces/ws2/logs/memtest-$b.log
  echo "== $b ($(stat -c%s $f 2>/dev/null) bytes)"
  grep -aE "crash|terminated|exited|Renderer|network|Failed" "$f" 2>/dev/null \
    | grep -avE "CompositorAnimation|task_manager|DRI3|Ensure your X" \
    | sed -E 's/^\[[0-9:\/.]+//' | cut -c1-150 | sort | uniq -c | sort -rn | head -8
done
