#!/bin/bash
# Side-by-side fingerprint diff: the SAME probe page in
#   (a) the lab's Wine Edge   -> posts as "wine"
#   (b) native Windows Edge   -> posts as "windows" (launched separately)
# Both POST to one collector inside WSL, so the two captures are directly
# diffable and every difference is a leak that says "this is not Windows".
export LC_ALL=C.UTF-8 DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all"
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT=/root/winelab/out
FP=/root/fp
PORT=47800
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

mkdir -p "$FP" /root/linuxlab
cp -f "$REPO/tools/fingerprint-probe.html" /root/linuxlab/fp.html

echo "== collector =="
pkill -f "collect.py" 2>/dev/null; sleep 1
( setsid nohup python3 "$REPO/tools/relay/collect.py" "$FP" "$PORT" \
    >"$OUT/collect.log" 2>&1 & )
sleep 2
ss -ltn 2>/dev/null | grep -q ":$PORT" && echo "  up on $PORT" || echo "  FAILED to listen"

echo "== Wine Edge -> probe (reuses the lab's running Edge config) =="
rm -f "$FP/wine.txt"
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
rm -rf /root/.wine/drive_c/t17 2>/dev/null
( export VK_DRIVER_FILES=/root/vkicd/rx580_icd.json VK_ICD_FILENAMES=/root/vkicd/rx580_icd.json
  export LIBGL_ALWAYS_SOFTWARE=1 GALLIUM_DRIVER=llvmpipe
  setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --use-angle=vulkan --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t17' --new-window \
    "file:///Z:/root/linuxlab/fp.html?post=http://127.0.0.1:$PORT/&as=wine" \
    >"$OUT/edge-fp.log" 2>&1 & )

for i in $(seq 1 40); do
  [ -s "$FP/wine.txt" ] && { echo "  captured at t=$((i*3))s"; break; }
  sleep 3
done
[ -s "$FP/wine.txt" ] || echo "  NO CAPTURE from Wine Edge"

echo
echo "== waiting for the Windows-side capture (launch it from the host) =="
for i in $(seq 1 40); do
  [ -s "$FP/windows.txt" ] && { echo "  windows.txt arrived"; break; }
  sleep 3
done

if [ -s "$FP/wine.txt" ] && [ -s "$FP/windows.txt" ]; then
  echo
  echo "=========== LEAKS: windows (left) vs wine (right) ==========="
  diff --side-by-side --width=200 "$FP/windows.txt" "$FP/wine.txt" | grep -E "[|<>]" | cut -c1-200
else
  echo "  (missing one side; wine=$(stat -c%s "$FP/wine.txt" 2>/dev/null || echo 0)B windows=$(stat -c%s "$FP/windows.txt" 2>/dev/null || echo 0)B)"
fi
