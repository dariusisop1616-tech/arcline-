#!/bin/bash
# Rename the 0x2489 entry in the PREFIX copy of wined3d.dll and check, with the
# fast DXGI test app (same GetDesc that ANGLE reads), whether Wine uses that copy.
export DISPLAY=:9 WINEPREFIX=/root/.wine WINEDEBUG=-all GALLIUM_DRIVER=d3d12
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
P=/root/.wine/drive_c/windows/system32/wined3d.dll
cp -f "$REPO/tools/relay/d3d11_test.exe" /root/relay/ 2>/dev/null
cd /root/relay
adapter() { timeout 90 wine d3d11_test.exe 2>/dev/null | grep -a "^adapter" | tr -d '\r'; }

pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 1
echo "[before]              $(WINEDLLOVERRIDES='mscoree,mshtml=' adapter)"
python3 "$REPO/tools/relay/set_gpu_name.py" "$P" \
  "NVIDIA GeForce RTX 3060 Ti (GA104, Low Hash Rate)" "NVIDIA GeForce RTX 3060 Ti"
wineserver -k 2>/dev/null; sleep 1
echo "[patched, default]    $(WINEDLLOVERRIDES='mscoree,mshtml=' adapter)"
wineserver -k 2>/dev/null; sleep 1
echo "[patched, wined3d=n]  $(WINEDLLOVERRIDES='mscoree,mshtml=;wined3d=n' adapter)"
