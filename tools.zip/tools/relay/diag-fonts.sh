#!/bin/bash
# Why does wineboot hang now? Prime suspect: one of the 281 font files I copied
# into the prefix (a 0-byte copy, or a .ttc collection Wine's parser dislikes)
# stalls the font scan. Report the evidence, do not change anything yet.
OUT=/root/winelab/out
D=/root/.wine/drive_c/windows/Fonts
echo "=== wineboot log ==="
cat "$OUT/wineboot.log" 2>/dev/null | tail -15 | sed 's/^/  /'
echo
echo "=== suspicious font files ==="
echo -n "  zero-byte: "; find "$D" -maxdepth 1 -type f -size 0 2>/dev/null | wc -l
find "$D" -maxdepth 1 -type f -size 0 2>/dev/null | head -5 | sed 's/^/    /'
echo -n "  .ttc collections: "; ls "$D"/*.ttc 2>/dev/null | wc -l
ls -S "$D" 2>/dev/null | head -5 | sed 's/^/    biggest: /'
echo -n "  total bytes: "; du -sh "$D" 2>/dev/null | cut -f1
echo
echo "=== what processes are stuck ==="
pgrep -a wine 2>/dev/null | head -5 | sed 's/^/  /'
pgrep -ac wineserver 2>/dev/null | sed 's/^/  wineservers: /'
echo
echo "=== is the display/lab still alive for the viewer? ==="
DISPLAY=:9 xdpyinfo >/dev/null 2>&1 && echo "  X: up" || echo "  X: DOWN"
timeout 2 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 7 <&3' 2>/dev/null | sed 's/^/  rfb: /'
