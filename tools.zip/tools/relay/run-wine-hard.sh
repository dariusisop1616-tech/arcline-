#!/bin/bash
# The demanding probe under Wine on the REAL GPU (wined3d renderer=gl -> Mesa
# d3d12 -> whatever card Windows has). Compare against the native run on the
# same machine - that is the vendor-neutral invariant: identical bytes from the
# same hardware, whoever made it.
export LC_ALL=C.UTF-8 DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all"
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
mkdir -p /root/relay && cp -f "$REPO/tools/relay/d3d11_hard.exe" /root/relay/
cd /root/relay || exit 1

echo "=== Wine, wined3d renderer=gl, Mesa d3d12 -> real GPU ==="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d gl /f >/dev/null 2>&1
( unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
  export GALLIUM_DRIVER=d3d12
  timeout 300 wine d3d11_hard.exe 2>&1 | grep -vE "^[0-9a-f]{4}:|fixme|err:|warn:|libEGL" )

echo
echo "=== Wine, software (llvmpipe) for contrast ==="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d vulkan /f >/dev/null 2>&1
( export VK_DRIVER_FILES=/root/vkicd/rx580_icd.json VK_ICD_FILENAMES=/root/vkicd/rx580_icd.json
  export LIBGL_ALWAYS_SOFTWARE=1 GALLIUM_DRIVER=llvmpipe
  timeout 300 wine d3d11_hard.exe 2>&1 | grep -vE "^[0-9a-f]{4}:|fixme|err:|warn:|libEGL" )

echo
echo "native baseline: aniso_blend 5f4c9dc5 | msaa 5f4c9dc5 | math_tri 9d262fa2"
