#!/bin/bash
# Isolate the hang: is it the 383MB of copied fonts, or something else in
# wineboot? Move the fonts aside (instant), run wineboot, measure. If it now
# completes, the font scan was the cause and the set needs trimming; if it still
# hangs, the fonts were innocent and the problem is elsewhere.
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDEBUG=-all
export DISPLAY=:9
OUT=/root/winelab/out; mkdir -p "$OUT"
D=/root/.wine/drive_c/windows/Fonts
STAGE=/root/fonts-staging
mkdir -p "$STAGE"

echo "[1] move copied fonts aside"
mv "$D"/* "$STAGE"/ 2>/dev/null
echo "    prefix fonts now: $(ls "$D" 2>/dev/null | wc -l)  staged: $(ls "$STAGE" | wc -l)"

echo "[2] stop wine cleanly"
wineserver -k 2>/dev/null; sleep 2; pkill -9 -x wineserver 2>/dev/null; sleep 1

echo "[3] wineboot -u with an EMPTY font dir (max 90s)"
s=$(date +%s)
timeout 90 wineboot -u >"$OUT/wineboot2.log" 2>&1
rc=$?
echo "    exit=$rc after $(( $(date +%s) - s ))s"

echo "[4] registered families now:"
timeout 25 wine reg query 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Fonts' 2>/dev/null \
  | grep -c REG_SZ | sed 's/^/    /'
echo "[5] wineboot log:"
tail -4 "$OUT/wineboot2.log" 2>/dev/null | sed 's/^/    /'
