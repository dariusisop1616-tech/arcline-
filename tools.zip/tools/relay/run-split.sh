#!/bin/bash
# Run split.html in Wine Edge on the real GPU.
#   $1 = builtin : Wine's own DirectWrite (FreeType-backed)
#   $1 = native  : Microsoft's dwrite.dll copied from the host, loaded via override
# The browser is untouched either way; only the DLL underneath it changes.
MODE="${1:-builtin}"
export LC_ALL=C.UTF-8 DISPLAY=:9
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDEBUG="-all"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
export GALLIUM_DRIVER=d3d12
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT=/root/winelab/out; FP=/root/fp; PORT=47800
SYS32=/root/.wine/drive_c/windows/system32
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
LABEL="split_wine_$MODE"

pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
pkill -9 -x wineserver 2>/dev/null; sleep 1

# restart the collector so it serves /page/split.html
pkill -f collect.py 2>/dev/null; sleep 1
( setsid nohup python3 "$REPO/tools/relay/collect.py" "$FP" "$PORT" /root/linuxlab/fp.html \
    >"$OUT/collect.log" 2>&1 & )
sleep 2
curl -s -o /dev/null -w "  split page: %{http_code}\n" "http://127.0.0.1:$PORT/page/split.html"

# DLL swap
[ -f "$SYS32/dwrite.dll.wine" ] || cp -f "$SYS32/dwrite.dll" "$SYS32/dwrite.dll.wine"
if [ "$MODE" = native ]; then
  cp -f /mnt/c/Windows/System32/dwrite.dll "$SYS32/dwrite.dll"
  export WINEDLLOVERRIDES="mscoree,mshtml=;dwrite=n"
  echo "  dwrite: NATIVE Microsoft ($(stat -c%s "$SYS32/dwrite.dll") bytes)"
else
  cp -f "$SYS32/dwrite.dll.wine" "$SYS32/dwrite.dll"
  export WINEDLLOVERRIDES="mscoree,mshtml="
  echo "  dwrite: Wine builtin"
fi

xdpyinfo >/dev/null 2>&1 || { setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 & sleep 3; }
pgrep -x fluxbox >/dev/null || { setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & sleep 2; }
rm -f "$FP/$LABEL.txt"; rm -rf /root/.wine/drive_c/t25
( setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t25' --new-window \
    "http://127.0.0.1:$PORT/page/split.html?post=/?as=$LABEL" >"$OUT/edge-split.log" 2>&1 & )
for i in $(seq 1 45); do
  [ -s "$FP/$LABEL.txt" ] && { echo "  captured at t=$((i*4))s"; break; }
  left=$(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}')
  [ "$left" -lt 700 ] && { echo "  watchdog"; pkill -9 -f msedge; break; }
  if [ $i -gt 8 ] && ! pgrep -f msedge >/dev/null; then echo "  Edge DIED (t=$((i*4))s)"; break; fi
  sleep 4
done
[ -s "$FP/$LABEL.txt" ] || { echo "  NO CAPTURE"; grep -aiE "err:|dwrite|Unhandled" "$OUT/edge-split.log" | head -8 | cut -c1-160 | sed 's/^/    /'; }

# always put Wine's dwrite back so other tests are unaffected
cp -f "$SYS32/dwrite.dll.wine" "$SYS32/dwrite.dll"
cat "$FP/$LABEL.txt" 2>/dev/null | sed 's/^/  /'
