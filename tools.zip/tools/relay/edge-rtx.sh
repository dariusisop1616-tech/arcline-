#!/bin/bash
# THE launcher: stock Windows Edge under Wine, environment made to match the host
# Windows machine. The browser binary is never modified - everything below is
# Wine configuration, DLLs underneath the browser, or the process environment.
#
#   usage: edge-rtx.sh [probe LABEL | open URL]
#
# What each layer fixes (all measured 2026-09-28 against native Edge 154.0.4258.37):
#   GPU     wined3d renderer=gl + Mesa GALLIUM_DRIVER=d3d12 -> the real card;
#           --in-process-gpu (no cross-process shared handles, which Wine lacks)
#           --use-angle=d3d11 -> native "Direct3D11 vs_5_0 ps_5_0, D3D11" string
#   text    Microsoft's dwrite.dll (native override) + ClearType (FontSmoothingType=2)
#   fonts   host font files + host HKLM Fonts key; fontconfig limited to the
#           prefix so distro-only families (Ubuntu) are invisible
#   memory  sysinfo() shim -> Windows sees 12 GB -> navigator.deviceMemory 8
#   locale  fr_FR + profile accept_languages = the host's list
#   screen  1920x1080 with a 40px bottom bar -> avail 1920x1040
MODE="${1:-open}"; ARG="${2:-about:blank}"
export DISPLAY=:9
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDEBUG="-all"
export WINEDLLOVERRIDES="mscoree,mshtml=;dwrite=n"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES LC_ALL
export GALLIUM_DRIVER=d3d12
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
LAB=/root/winelab; OUT=$LAB/out; FP=/root/fp; PORT=47800
SYS32=/root/.wine/drive_c/windows/system32
FONTS=/root/.wine/drive_c/windows/Fonts
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
PROFILE_UNIX=/root/.wine/drive_c/rtx; PROFILE_WIN='C:\rtx'
ACCEPT_LANG="fr,fr-FR,en,en-GB,en-US"
SCREEN_W=1920; SCREEN_H=1080; BAR=40
MEM_KB=12511980
mkdir -p "$OUT" "$FP" "$LAB/mem" "$LAB/fontconfig/cache"

step() { echo "[$(date +%H:%M:%S)] $*"; }

# ---- one-time prerequisites (idempotent) -----------------------------------
if ! locale -a 2>/dev/null | grep -qi '^fr_FR.utf8$'; then
  step "generating fr_FR.UTF-8 locale"
  sed -i 's/^# *fr_FR.UTF-8 UTF-8/fr_FR.UTF-8 UTF-8/' /etc/locale.gen 2>/dev/null
  grep -q '^fr_FR.UTF-8 UTF-8' /etc/locale.gen 2>/dev/null || echo 'fr_FR.UTF-8 UTF-8' >> /etc/locale.gen
  locale-gen >/dev/null 2>&1
fi
export LANG=fr_FR.UTF-8

if [ ! -f "$LAB/mem/memshim.so" ]; then
  step "building sysinfo shim"
  cat > "$LAB/mem/memshim.c" <<EOF
#define _GNU_SOURCE
#include <sys/sysinfo.h>
#include <dlfcn.h>
/* Report the profile's RAM to Wine (Windows' GlobalMemoryStatusEx reads it),
 * so navigator.deviceMemory matches the target machine. */
int sysinfo(struct sysinfo *i) {
    static int (*real)(struct sysinfo *);
    if (!real) real = dlsym(RTLD_NEXT, "sysinfo");
    int r = real(i);
    if (r == 0 && i->mem_unit) i->totalram = (unsigned long)${MEM_KB}ULL * 1024ULL / i->mem_unit;
    return r;
}
EOF
  gcc -shared -fPIC -O2 -o "$LAB/mem/memshim.so" "$LAB/mem/memshim.c" -ldl
fi

cat > "$LAB/fontconfig/fonts.conf" <<EOF
<?xml version="1.0"?>
<fontconfig>
  <dir>$FONTS</dir>
  <cachedir>$LAB/fontconfig/cache</cachedir>
</fontconfig>
EOF
export FONTCONFIG_FILE="$LAB/fontconfig/fonts.conf"

# ---- stop Wine ---------------------------------------------------------------
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
pkill -9 -x wineserver 2>/dev/null; sleep 1

# ---- Wine-side configuration ---------------------------------------------------
[ -f "$SYS32/dwrite.dll.wine" ] || cp -f "$SYS32/dwrite.dll" "$SYS32/dwrite.dll.wine"
cmp -s /mnt/c/Windows/System32/dwrite.dll "$SYS32/dwrite.dll" || cp -f /mnt/c/Windows/System32/dwrite.dll "$SYS32/dwrite.dll"
R() { timeout 30 wine reg add "$@" /f >/dev/null 2>&1; }
R 'HKCU\Software\Wine\Direct3D' /v renderer /t REG_SZ /d gl
R 'HKCU\Software\Wine\Direct3D' /v VideoPciVendorID /t REG_DWORD /d 4318
R 'HKCU\Software\Wine\Direct3D' /v VideoPciDeviceID /t REG_DWORD /d 9353
R 'HKCU\Control Panel\Desktop' /v FontSmoothing /t REG_SZ /d 2
R 'HKCU\Control Panel\Desktop' /v FontSmoothingType /t REG_DWORD /d 2
R 'HKCU\Control Panel\Desktop' /v FontSmoothingGamma /t REG_DWORD /d 0
R 'HKCU\Control Panel\Desktop' /v FontSmoothingOrientation /t REG_DWORD /d 1
# fontconfig-sourced fonts are cached as "External Fonts"; drop them so the
# restricted fontconfig decides what exists (removes Ubuntu, keeps the rest)
if [ ! -f "$LAB/fontconfig/.recached" ]; then
  step "dropping Wine's external-font cache once"
  timeout 30 wine reg delete 'HKCU\Software\Wine\Fonts' /f >/dev/null 2>&1
  touch "$LAB/fontconfig/.recached"
fi
wineserver -k 2>/dev/null; sleep 1

# ---- display: 1920x1080 with a 40px bottom bar ------------------------------
cur=$(xdpyinfo 2>/dev/null | awk '/dimensions:/{print $2}')
if [ "$cur" != "${SCREEN_W}x${SCREEN_H}" ]; then
  step "display ${cur:-down} -> ${SCREEN_W}x${SCREEN_H} (viewer reconnects)"
  pkill -9 -x x11vnc 2>/dev/null; pkill -9 -x fluxbox 2>/dev/null; pkill -9 -f 'Xvfb :9' 2>/dev/null
  sleep 1; rm -f /tmp/.X11-unix/X9 /tmp/.X9-lock
  setsid nohup Xvfb :9 -screen 0 ${SCREEN_W}x${SCREEN_H}x24 -ac >"$OUT/xvfb.log" 2>&1 &
  sleep 3
fi
# fluxbox reserves toolbar height + a 1px border on each side, so ask for BAR-2
# to reserve exactly BAR (measured: height 40 gave avail 1038, not 1040)
mkdir -p /root/.fluxbox; touch /root/.fluxbox/init
sed -i '/toolbar\.height/d;/toolbar\.placement/d;/toolbar\.widthPercent/d;/toolbar\.visible/d;/toolbar\.maxOver/d' /root/.fluxbox/init
cat >> /root/.fluxbox/init <<EOF
session.screen0.toolbar.visible:	true
session.screen0.toolbar.placement:	BottomCenter
session.screen0.toolbar.height:	$((BAR - 2))
session.screen0.toolbar.widthPercent:	100
session.screen0.toolbar.maxOver:	false
EOF
pkill -9 -x fluxbox 2>/dev/null; sleep 1
( setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & ); sleep 2
timeout 2 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 7 <&3' >/dev/null 2>&1 || {
  pkill -9 -x x11vnc 2>/dev/null; sleep 1
  ( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR
    setsid nohup x11vnc -display :9 -forever -shared -nopw -quiet -rfbport 5901 \
      -noxdamage -xkb -o "$OUT/x11vnc.log" >/dev/null 2>&1 & ); sleep 2; }
pgrep -f websockify >/dev/null || ( setsid nohup websockify --web=/usr/share/novnc 6080 \
  localhost:5901 >"$OUT/websockify.log" 2>&1 & )
pgrep -f collect.py >/dev/null || ( setsid nohup python3 "$REPO/tools/relay/collect.py" \
  "$FP" "$PORT" /root/linuxlab/fp.html >"$OUT/collect.log" 2>&1 & )

# ---- profile: languages preset (a fresh profile for probe runs) -------------
[ "$MODE" = probe ] && rm -rf "$PROFILE_UNIX"
mkdir -p "$PROFILE_UNIX/Default"
if [ ! -f "$PROFILE_UNIX/Default/Preferences" ]; then
  cat > "$PROFILE_UNIX/Default/Preferences" <<EOF
{"intl":{"accept_languages":"$ACCEPT_LANG","selected_languages":"$ACCEPT_LANG"}}
EOF
fi

# ---- audio: the workspace's own 48 kHz server (WSLg's runs at 44.1 kHz) -------
export PULSE_SERVER=unix:/root/workspaces/ws1/pulse/native
PULSE_SERVER=$PULSE_SERVER pactl info >/dev/null 2>&1 || \
  bash "$REPO/tools/relay/setup-audio.sh" ws1 >/dev/null 2>&1
step "audio: $(PULSE_SERVER=$PULSE_SERVER pactl list sinks short 2>/dev/null | awk '{print $2, $4, $5, $6}' | head -1)"

# ---- launch -------------------------------------------------------------------
if [ "$MODE" = probe ]; then URL="http://127.0.0.1:$PORT/probe?post=/?as=$ARG"; rm -f "$FP/$ARG.txt"
else URL="$ARG"; fi
step "launching Edge -> $URL"
( export LD_PRELOAD="$LAB/mem/memshim.so"
  # NOT --lang / --start-maximized: bisected 2026-09-28, that pair makes Edge
  # exit silently under Wine. LANG=fr_FR already gives the French UI.
  setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --window-position=0,0 --window-size=${SCREEN_W},$((SCREEN_H - BAR)) \
    --user-data-dir="$PROFILE_WIN" \
    "$URL" >"$OUT/edge-rtx.log" 2>&1 & )

if [ "$MODE" = probe ]; then
  for i in $(seq 1 45); do
    [ -s "$FP/$ARG.txt" ] && { step "captured"; break; }
    sleep 4
  done
  [ -s "$FP/$ARG.txt" ] || { step "NO CAPTURE"; exit 1; }
  python3 - "$FP/windows.txt" "$FP/$ARG.txt" <<'EOF'
import sys
def load(p):
    d = {}
    for line in open(p, encoding='utf-8', errors='replace'):
        if line.startswith('---') or ':' not in line: continue
        k, v = line.split(':', 1); d[k.strip()] = v.strip()
    return d
w, l = load(sys.argv[1]), load(sys.argv[2])
keys = list(dict.fromkeys(list(w) + list(l)))
diff = [k for k in keys if w.get(k, '<absent>') != l.get(k, '<absent>')]
print(f"identical: {len(keys) - len(diff)}   different: {len(diff)}")
for k in diff:
    print(f"  {k}\n     windows: {w.get(k,'<absent>')[:130]}\n     wine   : {l.get(k,'<absent>')[:130]}")
EOF
else
  for i in $(seq 1 30); do
    wmctrl -l 2>/dev/null | grep -qi "edge" && { step "Edge window is up"; break; }
    sleep 3
  done
fi
