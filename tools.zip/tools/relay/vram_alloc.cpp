// Allocate a known amount of GPU memory and hold it, so we can tell whether
// nvidia-smi on Windows can see allocations made from inside WSL at all.
// Without this control, "the workspace used 0 MiB VRAM" could just mean
// "Windows cannot see WSL's VRAM".
//   vram_alloc.exe <count> <seconds>     (each texture is 2048x2048 RGBA = 16 MB)
#include <windows.h>
#include <d3d11.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    int count = argc > 1 ? atoi(argv[1]) : 40;
    int secs  = argc > 2 ? atoi(argv[2]) : 60;
    ID3D11Device *dev = nullptr; ID3D11DeviceContext *ctx = nullptr;
    D3D_FEATURE_LEVEL want[] = { D3D_FEATURE_LEVEL_11_0 }, got{};
    if (FAILED(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
                                 want, 1, D3D11_SDK_VERSION, &dev, &got, &ctx)))
    { printf("device failed\n"); return 2; }

    D3D11_TEXTURE2D_DESC td{};
    td.Width = td.Height = 2048; td.MipLevels = 1; td.ArraySize = 1;
    td.Format = DXGI_FORMAT_R8G8B8A8_UNORM; td.SampleDesc.Count = 1;
    // RENDER_TARGET + an actual clear per texture: a driver does not commit
    // physical memory for a texture that is only created and never touched, so
    // creating alone measures nothing.
    td.Usage = D3D11_USAGE_DEFAULT;
    td.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;

    int ok = 0;
    for (int i = 0; i < count; i++) {
        ID3D11Texture2D *t = nullptr;
        if (FAILED(dev->CreateTexture2D(&td, nullptr, &t))) break;
        ID3D11RenderTargetView *rtv = nullptr;
        if (SUCCEEDED(dev->CreateRenderTargetView(t, nullptr, &rtv))) {
            float c[4] = { (float)(i % 10) / 10.0f, 0.25f, 0.5f, 1.0f };
            ctx->ClearRenderTargetView(rtv, c);   // touches every pixel
        }
        ok++;
    }
    ctx->Flush();
    printf("allocated %d textures = %d MB of GPU memory; holding %d s\n",
           ok, ok * 16, secs);
    fflush(stdout);
    Sleep(secs * 1000);
    return 0;
}
