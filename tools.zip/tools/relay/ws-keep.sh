#!/bin/bash
# Supervise already-running workspaces WITHOUT starting new Edges: revive a dead
# display/noVNC or a vanished Edge window, log memory, keep WSL alive.
#   WSLIST="ws3" ws-keep.sh
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
LIST="${WSLIST:-ws3}"
echo -1000 > /proc/self/oom_score_adj 2>/dev/null
win_up() { DISPLAY=:$1 wmctrl -l 2>/dev/null | grep -qi "edge"; }
for i in $(seq 1 960); do
  sleep 30
  line="[keep $i $(date +%H:%M:%S)] $(free -m | awk 'NR==2{printf "mem %s/%sMB", $3, $2} NR==3{printf " swap %sMB", $3}')"
  for ws in $LIST; do
    source /root/workspaces/$ws/ws.conf
    if ! DISPLAY=:$DISP xdpyinfo >/dev/null 2>&1 || \
       ! timeout 2 bash -c "exec 3<>/dev/tcp/127.0.0.1/$VNC; head -c 7 <&3" >/dev/null 2>&1 || \
       ! win_up $DISP; then
      line="$line $ws:restart"; bash "$REPO/tools/relay/ws-start.sh" "$ws" >/dev/null 2>&1
    else
      line="$line $ws:ok"
    fi
  done
  echo "$line"
done
