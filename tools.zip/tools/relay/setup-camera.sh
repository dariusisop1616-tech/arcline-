#!/bin/bash
# The host's only videoinput is "OBS Virtual Camera" - a DirectShow source filter
# (obs-virtualcam-module64.dll) registered in the VideoInputDevice category.
# Install the same filter, at the same path, into the prefix and register it the
# way OBS's own virtualcam-install.bat does (regsvr32). Chromium lists DirectShow
# video sources, so the browser sees the same device kind, from the same filter.
export WINEPREFIX=/root/.wine WINEDEBUG=-all DISPLAY=:9
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml="
SRC="/mnt/c/Program Files/obs-studio/data/obs-plugins/win-dshow/obs-virtualcam-module64.dll"
DST_DIR="/root/.wine/drive_c/Program Files/obs-studio/data/obs-plugins/win-dshow"
mkdir -p "$DST_DIR"
cp -f "$SRC" "$DST_DIR/"
echo "[1] copied $(stat -c%s "$DST_DIR/obs-virtualcam-module64.dll") bytes"

pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 1
echo "[2] regsvr32"
timeout 60 wine regsvr32 /s 'C:\Program Files\obs-studio\data\obs-plugins\win-dshow\obs-virtualcam-module64.dll'
echo "    exit=$?"

echo "[3] is it in the video input category now?"
timeout 30 wine reg query 'HKCR\CLSID\{860BB310-5D01-11d0-BD3B-00A0C911CE86}\Instance' /s 2>/dev/null \
  | grep -iE "FriendlyName|CLSID" | sed 's/^/    /'
timeout 30 wine reg query 'HKCR\CLSID\{A3FCE0F5-3493-419F-958A-ABA1250EC20B}\InprocServer32' 2>/dev/null \
  | grep -i REG_SZ | sed 's/^/    /'
