#!/bin/bash
# Wait for both captures, then print every field that differs between native
# Windows Edge and Wine Edge (same browser build 154.0.4258.37 on both sides).
# Every difference here is a signal that says "this is not a Windows machine".
FP=/root/fp
for i in $(seq 1 30); do
  [ -s "$FP/windows.txt" ] && break
  sleep 3
done
if [ ! -s "$FP/windows.txt" ]; then echo "windows.txt MISSING"; exit 1; fi
if [ ! -s "$FP/wine.txt" ];    then echo "wine.txt MISSING";    exit 1; fi

echo "=============== IDENTICAL FIELDS (count) ==============="
join -t: -j1 <(sed 's/ *:/:/' "$FP/windows.txt" | sort -t: -k1,1) \
             <(sed 's/ *:/:/' "$FP/wine.txt"    | sort -t: -k1,1) 2>/dev/null \
  | awk -F: '{k=$1; w=$2; l=$3; if (w==l) n++} END {print "  matching: " n+0}'

echo
echo "=============== LEAKS: field | windows | wine ==============="
python3 - "$FP/windows.txt" "$FP/wine.txt" <<'EOF'
import sys, re
def load(p):
    d, section = {}, ''
    for line in open(p, encoding='utf-8', errors='replace'):
        line = line.rstrip('\n')
        if line.startswith('---'):
            section = line.strip('- '); continue
        if ':' not in line: continue
        k, v = line.split(':', 1)
        d[k.strip()] = v.strip()
    return d
w, l = load(sys.argv[1]), load(sys.argv[2])
keys = list(dict.fromkeys(list(w) + list(l)))
same = diff = 0
rows = []
for k in keys:
    a, b = w.get(k, '<absent>'), l.get(k, '<absent>')
    if a == b:
        same += 1
    else:
        diff += 1
        rows.append((k, a, b))
for k, a, b in rows:
    print(f"  {k}")
    print(f"      windows: {a[:150]}")
    print(f"      wine   : {b[:150]}")
print(f"\n  identical: {same}   different: {diff}")
EOF
