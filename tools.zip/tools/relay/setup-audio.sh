#!/bin/bash
# Per-workspace audio server at the host's 48 kHz.
# AudioContext.sampleRate follows the PulseAudio sink winepulse connects to.
# WSLg's shared server runs at 44.1 kHz, so the workspace gets its own server:
# a 48 kHz "Speakers" sink and a "Microphone" source (Windows exposes one of each).
# Also the right shape for RDP later: every workspace owns its audio.
WS="${1:-ws1}"
D=/root/workspaces/$WS/pulse
mkdir -p "$D"

if ! command -v pulseaudio >/dev/null; then
  echo "[1] installing pulseaudio"
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq pulseaudio pulseaudio-utils >/dev/null 2>&1
  command -v pulseaudio >/dev/null && echo "    ok" || { echo "    INSTALL FAILED"; exit 1; }
fi

# pulseaudio has no --daemon-conf flag; it reads $XDG_CONFIG_HOME/pulse/daemon.conf
mkdir -p "$D/pulse"
cat > "$D/pulse/daemon.conf" <<EOF
default-sample-rate = 48000
alternate-sample-rate = 48000
default-sample-format = float32le
exit-idle-time = -1
flat-volumes = no
EOF
cat > "$D/default.pa" <<EOF
load-module module-native-protocol-unix socket=$D/native auth-anonymous=1
load-module module-null-sink sink_name=speakers rate=48000 sink_properties=device.description=Speakers
load-module module-null-source source_name=mic rate=48000 description=Microphone
set-default-sink speakers
set-default-source mic
EOF

pkill -f "pulseaudio.*$WS" 2>/dev/null; sleep 1
echo "[2] starting the $WS audio server"
( export HOME=$D XDG_RUNTIME_DIR=$D PULSE_RUNTIME_PATH=$D XDG_CONFIG_HOME=$D
  unset PULSE_SERVER
  setsid nohup pulseaudio -n --daemonize=no --system=false --disallow-exit \
    --exit-idle-time=-1 --use-pid-file=no --log-target=stderr \
    -F "$D/default.pa" >"$D/pulse.log" 2>&1 & )
sleep 3
export PULSE_SERVER=unix:$D/native
if pactl info >/dev/null 2>&1; then
  pactl info | grep -E "Default Sample|Default Sink|Default Source" | sed 's/^/    /'
  echo "    PULSE_SERVER=unix:$D/native"
else
  echo "    server NOT answering:"; tail -5 "$D/pulse.log" | sed 's/^/    /'
fi
