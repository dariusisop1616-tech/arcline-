#!/bin/bash
# Make the prefix's font world look like Windows.
#
# Two separate leaks to close:
#   1. MISSING fonts - the prefix has 0 files in C:\windows\Fonts, so the probe
#      finds 12 families where Windows has 45. Fix: install the host's own
#      Windows font files into the prefix (the user's own machine, own fonts).
#   2. EXTRA fonts - "Ubuntu, DejaVu Sans, Liberation Serif, Roboto" show up
#      through fontconfig and say "Linux" out loud. Fix: run Edge with a
#      FONTCONFIG_FILE that serves ONLY the prefix font directory, so the
#      distro fonts are not visible to the process at all.
# Canvas 2D text hashes are downstream of this (gradientHash already matches;
# only the text-bearing canvas hashes still differ).
set -u
WINFONTS=/mnt/c/Windows/Fonts
PREFIX=/root/.wine/drive_c/windows/Fonts
FCDIR=/root/winelab/fontconfig
mkdir -p "$PREFIX" "$FCDIR"

echo "== host font files =="
ls "$WINFONTS" 2>/dev/null | wc -l | sed 's/^/  files visible: /'

echo "== copy the Windows font set into the prefix =="
n=0
for f in "$WINFONTS"/*.ttf "$WINFONTS"/*.ttc "$WINFONTS"/*.otf; do
  [ -f "$f" ] || continue
  b=$(basename "$f")
  if [ ! -f "$PREFIX/$b" ]; then
    cp -f "$f" "$PREFIX/$b" 2>/dev/null && n=$((n+1))
  fi
done
echo "  copied $n files; prefix now has $(ls "$PREFIX" | wc -l)"

echo "== a fontconfig that serves ONLY the prefix fonts =="
cat > "$FCDIR/fonts.conf" <<EOF
<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "fonts.dtd">
<!-- Used via FONTCONFIG_FILE for the Wine Edge process only. It deliberately
     does NOT include /etc/fonts, so the distro families (Ubuntu, DejaVu,
     Liberation, Roboto) are invisible: on real Windows they do not exist. -->
<fontconfig>
  <dir>$PREFIX</dir>
  <cachedir>$FCDIR/cache</cachedir>
  <config><rescan><int>30</int></rescan></config>
  <!-- keep the standard Windows aliasing so fallback stays Windows-like -->
  <alias><family>serif</family><prefer><family>Times New Roman</family></prefer></alias>
  <alias><family>sans-serif</family><prefer><family>Arial</family></prefer></alias>
  <alias><family>monospace</family><prefer><family>Consolas</family></prefer></alias>
  <alias><family>system-ui</family><prefer><family>Segoe UI</family></prefer></alias>
  <alias><family>cursive</family><prefer><family>Comic Sans MS</family></prefer></alias>
  <alias><family>fantasy</family><prefer><family>Impact</family></prefer></alias>
</fontconfig>
EOF
mkdir -p "$FCDIR/cache"
FONTCONFIG_FILE="$FCDIR/fonts.conf" fc-cache -f "$PREFIX" >/dev/null 2>&1
echo -n "  families visible with that config: "
FONTCONFIG_FILE="$FCDIR/fonts.conf" fc-list : family 2>/dev/null | sort -u | wc -l
echo -n "  linux families still visible: "
FONTCONFIG_FILE="$FCDIR/fonts.conf" fc-list : family 2>/dev/null \
  | grep -icE "ubuntu|dejavu|liberation|roboto|noto|cantarell" || true

echo "== register the fonts with Wine (so win32u/dwrite enumerate them) =="
export WINEPREFIX=/root/.wine PATH="/opt/wine-staging/bin:$PATH" WINEDEBUG=-all
cnt=0
for f in "$PREFIX"/*.ttf "$PREFIX"/*.ttc "$PREFIX"/*.otf; do
  [ -f "$f" ] || continue
  cnt=$((cnt+1))
done
echo "  $cnt font files in the prefix font dir (Wine scans this dir at startup)"
echo
echo "  NOTE: launch Edge with FONTCONFIG_FILE=$FCDIR/fonts.conf"
