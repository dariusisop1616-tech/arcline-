#!/bin/bash
# Open the click probe in a workspace's Edge and send real X11 input (xdotool
# moves the actual pointer and presses the actual button, the same events a VNC
# or RDP client delivers). The page reports isTrusted and coordinates.
N="${1:-ws1}"; source /root/workspaces/$N/ws.conf
export DISPLAY=:$DISP
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
PORT=47800
cp -f "$REPO/tools/relay/click.html" /root/linuxlab/click.html 2>/dev/null
W=$(wmctrl -l | grep -i edge | head -1 | awk '{print $1}')
[ -z "$W" ] && { echo "no Edge window on :$DISP"; exit 1; }

# navigate the existing window: focus the address bar, type the URL
xdotool windowactivate --sync "$W" 2>/dev/null; sleep 1
xdotool key --window "$W" ctrl+l 2>/dev/null; sleep 1
xdotool type --window "$W" --delay 25 "http://127.0.0.1:$PORT/page/click.html"; sleep 1
xdotool key --window "$W" Return; sleep 6

eval $(xdotool getwindowgeometry --shell "$W")
cx=$((X + WIDTH / 2)); cy=$((Y + 250))
echo "  window at ${X},${Y} ${WIDTH}x${HEIGHT} -> clicking ${cx},${cy}"
xdotool mousemove $cx $cy; sleep 1
xdotool click 1; sleep 1
xdotool click 1; sleep 2
xdotool type --delay 40 "hello"; sleep 2
echo "  title now: $(xdotool getwindowname "$W")"
echo "  (the page shows isTrusted + coordinates; screenshot below)"
import -window "$W" /root/winelab/out/click-test.png 2>/dev/null && \
  cp -f /root/winelab/out/click-test.png "$REPO/results/vm-display/click-test-$N.png" && \
  echo "  saved results/vm-display/click-test-$N.png"
