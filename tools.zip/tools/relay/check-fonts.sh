#!/bin/bash
# Fast state check (seconds, not minutes): is the font registration back?
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDEBUG=-all
echo "font files in prefix : $(ls /root/.wine/drive_c/windows/Fonts 2>/dev/null | wc -l)"
echo "wineboot running     : $(pgrep -c wineboot 2>/dev/null || echo 0)"
echo "wineserver running   : $(pgrep -c wineserver 2>/dev/null || echo 0)"
echo -n "registered families  : "
timeout 25 wine reg query 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Fonts' 2>/dev/null | grep -c REG_SZ
echo "wineboot log tail:"
tail -3 /root/winelab/out/wineboot.log 2>/dev/null | sed 's/^/  /'
