#!/bin/bash
# Two workspaces, both watching the pointer. Move ONLY ws1's pointer, then only
# ws2's, and read each page's counter from its window title.
# A leak would be: ws2 seeing events while only ws1 moved, or the two reporting
# the same screen coordinates (which would tie the two profiles to one machine).
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
PORT=47800
pgrep -f collect.py >/dev/null || ( setsid nohup python3 "$REPO/tools/relay/collect.py" /root/fp $PORT \
  /root/linuxlab/fp.html >/root/winelab/out/collect.log 2>&1 & )
sleep 1
for n in ws1 ws2; do
  R=/root/workspaces/$n; source $R/ws.conf
  bash "$REPO/tools/relay/ws-stop.sh" $n >/dev/null 2>&1
  WINE_TREE=$R/wine-ours URL_OVERRIDE="http://127.0.0.1:$PORT/page/mouse.html?post=/?as=leak_$n" \
    bash "$REPO/tools/relay/ws-start.sh" $n >/dev/null 2>&1
  for i in $(seq 1 40); do DISPLAY=:$DISP wmctrl -l 2>/dev/null | grep -qi edge && break; sleep 3; done
done
sleep 8

title() { local d=$1; DISPLAY=:$d xdotool search --name "MOUSE" getwindowname %@ 2>/dev/null | head -1; }
count() { title $1 | grep -oE 'n=[0-9]+' | cut -d= -f2; }
move() { # $1 display, $2 how many steps
  local d=$1 W
  export DISPLAY=:$d
  W=$(wmctrl -l | grep -i edge | head -1 | awk '{print $1}')
  xdotool windowactivate --sync "$W" 2>/dev/null; sleep 1
  eval $(xdotool getwindowgeometry --shell "$W")
  for i in $(seq 1 $2); do
    xdotool mousemove $((X + 200 + i * 3)) $((Y + 200 + (i % 40))); sleep 0.01
  done
}
d1=$(grep -oP 'DISP=\K[0-9]+' /root/workspaces/ws1/ws.conf)
d2=$(grep -oP 'DISP=\K[0-9]+' /root/workspaces/ws2/ws.conf)
echo "  start:            ws1 n=$(count $d1)   ws2 n=$(count $d2)"
move $d1 60
echo "  after moving ws1: ws1 n=$(count $d1)   ws2 n=$(count $d2)"
move $d2 60
echo "  after moving ws2: ws1 n=$(count $d1)   ws2 n=$(count $d2)"
echo
echo "  pointer positions (each display has its own):"
echo "    ws1: $(DISPLAY=:$d1 xdotool getmouselocation 2>/dev/null)"
echo "    ws2: $(DISPLAY=:$d2 xdotool getmouselocation 2>/dev/null)"
for d in $d1 $d2; do DISPLAY=:$d xdotool key F8 2>/dev/null; done
sleep 4
for n in ws1 ws2; do
  echo "  --- leak_$n report ---"
  python3 -c "
import json,sys
try:
    d=json.load(open('/root/fp/leak_$n.txt'))
    print('   ', {k:d[k] for k in ('n','clicks','untrusted','screen_at_first','client_at_first','screen','rate_hz')})
except Exception as e: print('    no report', e)"
done
