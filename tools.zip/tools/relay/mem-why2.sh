#!/bin/bash
# Inside the biggest renderer: the largest individual anonymous mappings by RSS,
# with their virtual size. A ~390 MB block would be Wine's page table for the
# 1.5 TB reservation; many mid-size blocks would be Chromium heaps.
p=$(for q in $(pgrep -f -- '--type=renderer'); do echo "$(awk '/^RssAnon/{print $2}' /proc/$q/status) $q"; done | sort -nr | head -1 | cut -d' ' -f2)
echo "renderer pid $p  RssAnon=$(awk '/^RssAnon/{print $2/1024}' /proc/$p/status) MB"
awk '
/^[0-9a-f]+-[0-9a-f]+ / { split($1,a,"-"); start=a[1]; name=($6==""?"[anon]":$6); cur=start; nm[cur]=name;
                          vs[cur]=(strtonum("0x" a[2]) - strtonum("0x" a[1]))/1048576 }
/^Rss:/                 { rss[cur]=$2/1024 }
/^Anonymous:/           { an[cur]=$2/1024 }
END { for (k in rss) if (an[k] > 8) printf "%9.1f MB anon  %11.1f MB virtual  %s  @%s\n", an[k], vs[k], nm[k], k }
' /proc/$p/smaps | sort -nr | head -14
echo
echo "anon split: blocks >100MB vs the rest"
awk '/^Anonymous:/{a=$2/1024; if (a>100) big+=a; else small+=a} END{printf "  big blocks: %.0f MB   many small blocks: %.0f MB\n", big, small}' /proc/$p/smaps
