#!/bin/bash
# Is the workspace's own 48 kHz audio server up, and is Edge connected to it?
N="${1:-ws1}"; R=/root/workspaces/$N
echo "server socket: $(ls -l $R/pulse/native 2>&1 | cut -c1-90)"
PULSE_SERVER=unix:$R/pulse/native pactl info 2>&1 | grep -E "Server Name|Default Sink|Default Sample|Connection" | sed 's/^/  /'
PULSE_SERVER=unix:$R/pulse/native pactl list sinks short 2>&1 | sed 's/^/  sink: /'
echo "pulseaudio processes:"
for p in $(pgrep -x pulseaudio); do
  echo "  pid $p  $(tr '\0' '\n' < /proc/$p/environ | grep -E '^XDG_RUNTIME_DIR=' )"
done
echo "PULSE_SERVER seen by Edge:"
for p in $(pgrep -f msedge | head -3); do
  grep -qz "WINEPREFIX=$R/prefix" /proc/$p/environ 2>/dev/null || continue
  echo "  $(tr '\0' '\n' < /proc/$p/environ | grep -E '^PULSE_SERVER=')"
done
tail -4 $R/logs/audio.log 2>/dev/null | sed 's/^/  audio.log: /'
