#!/bin/bash
# The complete best-known config, then a full fingerprint diff vs native Edge.
#   GPU   : wined3d renderer=gl, Mesa GALLIUM_DRIVER=d3d12 -> real card,
#           --in-process-gpu --use-angle=d3d11, PCI ids = host card
#   text  : Microsoft's dwrite.dll (native override) + ClearType settings
#   fonts : host C:\Windows\Fonts files + host HKLM Fonts registry key
LABEL="${1:-wine6}"
export LC_ALL=C.UTF-8 DISPLAY=:9
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDEBUG="-all"
export WINEDLLOVERRIDES="mscoree,mshtml=;dwrite=n"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
export GALLIUM_DRIVER=d3d12
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT=/root/winelab/out; FP=/root/fp; PORT=47800
SYS32=/root/.wine/drive_c/windows/system32
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
pkill -9 -x wineserver 2>/dev/null; sleep 1

[ -f "$SYS32/dwrite.dll.wine" ] || cp -f "$SYS32/dwrite.dll" "$SYS32/dwrite.dll.wine"
cp -f /mnt/c/Windows/System32/dwrite.dll "$SYS32/dwrite.dll"
timeout 20 wine reg add 'HKCU\Software\Wine\Direct3D' /v renderer /t REG_SZ /d gl /f >/dev/null 2>&1
timeout 20 wine reg add 'HKCU\Software\Wine\Direct3D' /v VideoPciVendorID /t REG_DWORD /d 4318 /f >/dev/null 2>&1
timeout 20 wine reg add 'HKCU\Software\Wine\Direct3D' /v VideoPciDeviceID /t REG_DWORD /d 9353 /f >/dev/null 2>&1

pgrep -f collect.py >/dev/null || ( setsid nohup python3 "$REPO/tools/relay/collect.py" \
  "$FP" "$PORT" /root/linuxlab/fp.html >"$OUT/collect.log" 2>&1 & )
xdpyinfo >/dev/null 2>&1 || { setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 & sleep 3; }
pgrep -x fluxbox >/dev/null || { setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & sleep 2; }
sleep 1
rm -f "$FP/$LABEL.txt"; rm -rf /root/.wine/drive_c/t26
( setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t26' --new-window \
    "http://127.0.0.1:$PORT/probe?post=/?as=$LABEL" >"$OUT/edge-full.log" 2>&1 & )
for i in $(seq 1 45); do
  [ -s "$FP/$LABEL.txt" ] && { echo "captured at t=$((i*4))s"; break; }
  left=$(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}')
  [ "$left" -lt 700 ] && { echo "watchdog"; pkill -9 -f msedge; break; }
  sleep 4
done
[ -s "$FP/$LABEL.txt" ] || { echo "NO CAPTURE"; exit 1; }

python3 - "$FP/windows.txt" "$FP/$LABEL.txt" <<'EOF'
import sys
def load(p):
    d = {}
    for line in open(p, encoding='utf-8', errors='replace'):
        if line.startswith('---') or ':' not in line: continue
        k, v = line.split(':', 1); d[k.strip()] = v.strip()
    return d
w, l = load(sys.argv[1]), load(sys.argv[2])
keys = list(dict.fromkeys(list(w) + list(l)))
diff = [k for k in keys if w.get(k, '<absent>') != l.get(k, '<absent>')]
print(f"identical: {len(keys) - len(diff)}   different: {len(diff)}")
for k in diff:
    print(f"  {k}\n     windows: {w.get(k,'<absent>')[:130]}\n     wine   : {l.get(k,'<absent>')[:130]}")
EOF
