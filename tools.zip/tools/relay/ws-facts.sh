#!/bin/bash
# Facts for a 3-workspace build (seconds).
echo "[prefix] golden /root/.wine: $(du -sh /root/.wine 2>/dev/null | cut -f1)"
du -sh "/root/.wine/drive_c/Program Files (x86)/Microsoft" /root/.wine/drive_c/windows/Fonts 2>/dev/null | sed 's/^/   /'
echo "[wine] /opt/wine-staging: $(du -sh /opt/wine-staging 2>/dev/null | cut -f1)"
echo "[fs] same filesystem for hardlinks? $(stat -c %d /opt/wine-staging) vs $(stat -c %d /root)"
W=/opt/wine-staging/lib/wine/x86_64-windows/wined3d.dll
S=/opt/wine-staging/lib/wine/x86_64-windows/wined3d.dll.orig-rx480
echo "[stock backup] $(ls -l $S 2>/dev/null | awk '{print $5, $9}')"
echo "[db] candidate entries in stock wined3d.dll:"
strings -a "$S" | grep -E "^(NVIDIA GeForce GTX 1080 Ti|AMD Radeon RX 7[0-9]{3}.*|AMD Radeon RX 9[0-9]{3}.*|Radeon RX 7[0-9]{3}.*)$" | sort -u | sed 's/^/   /'
echo "[mem] VM:"; free -m | sed 's/^/   /'
