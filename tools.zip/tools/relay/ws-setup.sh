#!/bin/bash
# Build independent workspaces from the validated golden prefix (/root/.wine,
# 63/63 probe match). Each workspace gets:
#   prefix : hard-linked clone of the golden prefix (near-zero disk); files Wine
#            rewrites in place (registry hives, ini files, user dirs) are real copies
#   wine   : hard-linked clone of /opt/wine-staging with its OWN wined3d.dll, so
#            the GPU name table is per workspace (WINEDLLPATH is not honoured)
#   ws.conf: display, ports, screen, GPU ids/name, RAM, language
# Idempotent: existing workspaces are left alone.
set -u
export WINEDEBUG=-all
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
GOLD=/root/.wine
BASE=/root/workspaces
STOCK=/opt/wine-staging/lib/wine/x86_64-windows/wined3d.dll.orig-rx480
mkdir -p "$BASE"

# name                 disp vnc  web  W    H    vendor dev    rename_from -> rename_to              mem_kb
WS=(
 "ws1|9|5901|6080|1920|1080|4318|9353|NVIDIA GeForce RTX 3060 Ti (GA104, Low Hash Rate)|NVIDIA GeForce RTX 3060 Ti|12511980"
 "ws2|10|5902|6081|1920|1080|4318|6918|||16686772"
 "ws3|11|5903|6082|2560|1440|4098|30096|||33476040"
)

echo "[golden] removing old test profiles"
rm -rf "$GOLD"/drive_c/t[0-9]* "$GOLD"/drive_c/tb "$GOLD"/drive_c/rtx 2>/dev/null

echo "[shim] env-driven RAM shim"
mkdir -p /root/winelab/mem
cat > /root/winelab/mem/memshim_env.c <<'EOF'
#define _GNU_SOURCE
#include <sys/sysinfo.h>
#include <dlfcn.h>
#include <stdlib.h>
/* Report FAKE_MEM_KB as physical RAM to Wine (GlobalMemoryStatusEx reads
 * sysinfo), so navigator.deviceMemory follows the workspace's profile. */
int sysinfo(struct sysinfo *i) {
    static int (*real)(struct sysinfo *);
    if (!real) real = dlsym(RTLD_NEXT, "sysinfo");
    int r = real(i);
    const char *kb = getenv("FAKE_MEM_KB");
    if (r == 0 && kb && i->mem_unit)
        i->totalram = (unsigned long)(strtoull(kb, 0, 10) * 1024ULL / i->mem_unit);
    return r;
}
EOF
gcc -shared -fPIC -O2 -o /root/winelab/mem/memshim_env.so /root/winelab/mem/memshim_env.c -ldl

breaklink() { for f in "$@"; do [ -f "$f" ] && cp -p "$f" "$f.t" && mv -f "$f.t" "$f"; done; }

for row in "${WS[@]}"; do
  IFS='|' read -r N D V P W H VEN DEV RFROM RTO MEM <<<"$row"
  R="$BASE/$N"; mkdir -p "$R"
  echo "[$N] building"

  if [ ! -d "$R/prefix" ]; then
    cp -al "$GOLD" "$R/prefix"
    breaklink "$R"/prefix/*.reg "$R"/prefix/drive_c/windows/*.ini
    rm -rf "$R/prefix/drive_c/users" && cp -a "$GOLD/drive_c/users" "$R/prefix/drive_c/users"
    echo "   prefix cloned"
  fi

  if [ ! -d "$R/wine" ]; then
    cp -al /opt/wine-staging "$R/wine"
    echo "   wine tree cloned"
  fi
  F="$R/wine/lib/wine/x86_64-windows/wined3d.dll"
  rm -f "$F" && cp "$STOCK" "$F"                     # own real file, stock table
  rm -f "$R/wine/lib/wine/x86_64-windows/"wined3d.dll.orig* 2>/dev/null
  if [ -n "$RFROM" ]; then
    python3 "$REPO/tools/relay/set_gpu_name.py" "$F" "$RFROM" "$RTO" | sed 's/^/   /'
    rm -f "$F.orig"
  fi

  WX="$R/wine/bin/wine"
  export WINEPREFIX="$R/prefix"
  "$R/wine/bin/wineserver" -k 2>/dev/null
  rg() { timeout 30 "$WX" reg add "$@" /f >/dev/null 2>&1; }
  rg 'HKCU\Software\Wine\Direct3D' /v renderer /t REG_SZ /d gl
  rg 'HKCU\Software\Wine\Direct3D' /v VideoPciVendorID /t REG_DWORD /d "$VEN"
  rg 'HKCU\Software\Wine\Direct3D' /v VideoPciDeviceID /t REG_DWORD /d "$DEV"
  timeout 30 "$WX" reg delete 'HKCU\Software\Wine\Direct3D' /v VideoDescription_1002_67df /f >/dev/null 2>&1
  rg 'HKLM\SOFTWARE\Policies\Microsoft\EdgeUpdate' /v UpdateDefault /t REG_DWORD /d 0
  "$R/wine/bin/wineserver" -w 2>/dev/null

  mkdir -p "$R/prefix/drive_c/ws/Default" "$R/fontconfig/cache" "$R/fluxbox"
  [ -f "$R/prefix/drive_c/ws/Default/Preferences" ] || \
    echo '{"intl":{"accept_languages":"fr,fr-FR,en,en-GB,en-US","selected_languages":"fr,fr-FR,en,en-GB,en-US"}}' \
      > "$R/prefix/drive_c/ws/Default/Preferences"
  cat > "$R/fontconfig/fonts.conf" <<EOF
<?xml version="1.0"?>
<fontconfig>
  <dir>$R/prefix/drive_c/windows/Fonts</dir>
  <cachedir>$R/fontconfig/cache</cachedir>
</fontconfig>
EOF
  cat > "$R/fluxbox/init" <<EOF
session.screen0.toolbar.visible:	true
session.screen0.toolbar.placement:	BottomCenter
session.screen0.toolbar.height:	38
session.screen0.toolbar.widthPercent:	100
session.screen0.toolbar.maxOver:	false
session.screen0.workspaces:	1
EOF
  cat > "$R/ws.conf" <<EOF
NAME=$N
DISP=$D
VNC=$V
WEB=$P
SCREEN_W=$W
SCREEN_H=$H
BAR=40
VENDOR=$VEN
DEVICE=$DEV
MEM_KB=$MEM
LANG_WS=fr_FR.UTF-8
URL=https://browserleaks.com/webgl
EOF
  echo "   conf: :$D vnc $V web $P ${W}x${H} gpu $(printf '0x%04X:0x%04X' $VEN $DEV)"
done
echo "[disk] workspaces use: $(du -sh "$BASE" 2>/dev/null | cut -f1) apparent (hard links shared with golden)"
df -h / | tail -1 | awk '{print "[disk] WSL root free: " $4}'
