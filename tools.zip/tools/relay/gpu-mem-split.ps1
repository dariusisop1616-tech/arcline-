# Dedicated VRAM vs shared (system) GPU memory, per process.
# WSL's GPU work may land in shared memory instead of dedicated VRAM, which
# would explain why a workspace shows ~0 MiB in nvidia-smi. This reads Windows'
# own GPU counters, which report both pools.
param([string]$Phase = "now")
function Sum($path) {
  try {
    $s = (Get-Counter $path -ErrorAction Stop).CounterSamples
    [math]::Round((($s | Measure-Object CookedValue -Sum).Sum) / 1MB)
  } catch { -1 }
}
$ded = Sum '\GPU Process Memory(*)\Dedicated Usage'
$shr = Sum '\GPU Process Memory(*)\Shared Usage'
$smi = (& "C:\Windows\System32\nvidia-smi.exe" --query-gpu=memory.used --format=csv,noheader,nounits) -as [int]
"{0,-8} dedicated {1,6} MB   shared {2,6} MB   nvidia-smi {3,6} MB" -f $Phase, $ded, $shr, $smi

# which processes hold the most shared GPU memory (vmmem = the WSL VM)
$top = (Get-Counter '\GPU Process Memory(*)\Shared Usage' -ErrorAction SilentlyContinue).CounterSamples |
  Where-Object { $_.CookedValue -gt 50MB } |
  Sort-Object CookedValue -Descending | Select-Object -First 5
foreach ($t in $top) {
  "   {0,8:N0} MB  {1}" -f ($t.CookedValue/1MB), ($t.InstanceName -replace '^pid_(\d+).*','pid $1')
}
