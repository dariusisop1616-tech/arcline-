#!/bin/bash
# CPU cost of KSM's scanner. ksmd is a kernel thread, invisible inside the WSL
# distro's PID namespace, but /proc/stat is system-wide and includes it. So:
# total CPU busy over 15 s with scanning paused (run=0 keeps merged pages merged)
# vs running at a gentle and at the fast test rate, same idle workspace.
K=/sys/kernel/mm/ksm
busy() {  # % of ALL cores busy over 15 s
  read -r _ a1 a2 a3 a4 a5 a6 a7 a8 _ < /proc/stat; t1=$((a1+a2+a3+a4+a5+a6+a7+a8)); i1=$((a4+a5))
  sleep 15
  read -r _ b1 b2 b3 b4 b5 b6 b7 b8 _ < /proc/stat; t2=$((b1+b2+b3+b4+b5+b6+b7+b8)); i2=$((b4+b5))
  echo "scale=1; 100 * (($t2 - $t1) - ($i2 - $i1)) / ($t2 - $t1)" | bc
}
save() { echo "$(( $(cat $K/pages_sharing) * 4 / 1024 )) MB dedup + $(( $(cat $K/ksm_zero_pages) * 4 / 1024 )) MB zero"; }
echo 0 > $K/run
echo "paused                      : system CPU $(busy)% of 8 cores   saving kept: $(save)"
echo 1000 > $K/pages_to_scan; echo 200 > $K/sleep_millisecs; echo 1 > $K/run
echo "gentle (1000 pages / 200 ms): system CPU $(busy)% of 8 cores   saving: $(save)"
echo 20000 > $K/pages_to_scan; echo 20 > $K/sleep_millisecs
echo "fast  (20000 pages / 20 ms) : system CPU $(busy)% of 8 cores   saving: $(save)"
echo 1000 > $K/pages_to_scan; echo 200 > $K/sleep_millisecs
echo "left at gentle"
