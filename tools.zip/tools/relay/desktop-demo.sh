#!/bin/bash
# Stop ws gracefully, apply the Windows desktop, start Edge, open the Start menu,
# and screenshot the result.
N="${1:-ws1}"
REL="/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/relay"
OUTD="/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/vm-display"
source /root/workspaces/$N/ws.conf
bash "$REL/ws-stop.sh" $N >/dev/null 2>&1
bash "$REL/windows-desktop.sh" $N
WINE_TREE=/root/workspaces/$N/wine-ours URL_OVERRIDE=https://www.bing.com \
  bash "$REL/ws-start.sh" $N >/dev/null 2>&1
for i in $(seq 1 30); do DISPLAY=:$DISP wmctrl -l 2>/dev/null | grep -qi edge && break; sleep 3; done
sleep 12
export DISPLAY=:$DISP
xdotool mousemove 20 $((SCREEN_H - 20)) click 1; sleep 2
import -window root /root/winelab/out/desk2.png && cp -f /root/winelab/out/desk2.png "$OUTD/desk2-$N.png" && echo "screenshot: results/vm-display/desk2-$N.png"
xdotool key Escape
