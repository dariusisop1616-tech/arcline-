#!/bin/bash
# deviceMemory = physical RAM (as Windows reports it) bucketed to a power of two,
# capped at 8. The host has 12 GB -> 8; the WSL VM has 6 GB -> 4.
# Which source does Wine use for "physical memory": /proc/meminfo or sysinfo()?
# Test both levers with Wine's own systeminfo.exe, without touching the browser.
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDEBUG=-all
W=/root/winelab/mem; mkdir -p "$W"
TOTAL_KB=12511980   # ~11.9 GiB, what a 12 GB Windows machine reports

q() { timeout 60 wine systeminfo 2>/dev/null | grep -iE "Total Physical Memory" | tr -d '\r'; }

wineserver -k 2>/dev/null; sleep 1
echo "[A] baseline:            $(q)"

# lever 1: a bind-mounted /proc/meminfo in a private mount namespace
awk -v t=$TOTAL_KB '/^MemTotal:/{printf "MemTotal:       %d kB\n", t; next} {print}' /proc/meminfo > "$W/meminfo"
wineserver -k 2>/dev/null; sleep 1
echo "[B] /proc/meminfo bind:  $(unshare -m --propagation private bash -c "mount --bind $W/meminfo /proc/meminfo && $(declare -f q); q")"

# lever 2: an LD_PRELOAD shim for sysinfo() (Wine's unix side calls libc directly)
cat > "$W/memshim.c" <<EOF
#define _GNU_SOURCE
#include <sys/sysinfo.h>
#include <dlfcn.h>
int sysinfo(struct sysinfo *i) {
    static int (*real)(struct sysinfo *);
    if (!real) real = dlsym(RTLD_NEXT, "sysinfo");
    int r = real(i);
    if (r == 0 && i->mem_unit) i->totalram = (unsigned long)${TOTAL_KB}ULL * 1024ULL / i->mem_unit;
    return r;
}
EOF
gcc -shared -fPIC -O2 -o "$W/memshim.so" "$W/memshim.c" -ldl 2>&1 | head -3
wineserver -k 2>/dev/null; sleep 1
echo "[C] sysinfo() shim:      $(LD_PRELOAD=$W/memshim.so q)"

wineserver -k 2>/dev/null; sleep 1
echo "[D] both:                $(LD_PRELOAD=$W/memshim.so unshare -m --propagation private bash -c "mount --bind $W/meminfo /proc/meminfo && $(declare -f q); q")"
