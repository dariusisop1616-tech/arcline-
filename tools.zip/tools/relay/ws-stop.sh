#!/bin/bash
# Stop workspaces completely: Wine (all processes of that prefix), display,
# noVNC, audio. Other workspaces are untouched.
#   ws-stop.sh ws1 ws2
pkill -f "ws-all.sh" 2>/dev/null          # the old supervisor would restart them
for ws in "$@"; do
  R=/root/workspaces/$ws; source $R/ws.conf
  # close browser windows politely first, so the profile is marked as cleanly
  # shut down (a hard kill makes Edge show "Restore pages" on the next start -
  # something a real Windows user rarely sees)
  for w in $(DISPLAY=:$DISP wmctrl -l 2>/dev/null | grep -iE 'edge|opera|chrome' | awk '{print $1}'); do
    DISPLAY=:$DISP wmctrl -i -c $w 2>/dev/null
  done
  for i in $(seq 1 10); do
    DISPLAY=:$DISP wmctrl -l 2>/dev/null | grep -qiE 'edge|opera|chrome' || break
    sleep 1
  done
  for T in "$R/wine-ours" "$R/wine"; do
    [ -x "$T/bin/wineserver" ] && WINEPREFIX=$R/prefix "$T/bin/wineserver" -k 2>/dev/null
  done
  sleep 1
  for p in $(pgrep -f msedge); do          # stragglers of this prefix only
    grep -qz "WINEPREFIX=$R/prefix" /proc/$p/environ 2>/dev/null && kill -9 $p
  done
  pkill -9 -f "websockify.* $WEB " 2>/dev/null
  pkill -9 -f "x11vnc.*rfbport $VNC" 2>/dev/null
  pkill -9 -f "fluxbox -display :$DISP" 2>/dev/null
  pkill -9 -f "Xvfb :$DISP " 2>/dev/null
  rm -f /tmp/.X11-unix/X$DISP /tmp/.X$DISP-lock
  pkill -f "pulseaudio.*$R/pulse" 2>/dev/null
  for p in $(pgrep -x pulseaudio); do
    grep -qz "XDG_RUNTIME_DIR=$R/pulse" /proc/$p/environ 2>/dev/null && kill $p
  done
  echo "[$ws] stopped"
done
sleep 2
free -m | awk 'NR==2{printf "mem %s/%s MB", $3, $2} NR==3{printf ", swap %s MB\n", $3}'
