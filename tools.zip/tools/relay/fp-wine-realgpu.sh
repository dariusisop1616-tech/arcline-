#!/bin/bash
# Capture the full fingerprint from Wine Edge running on the REAL GPU:
#   --in-process-gpu  (avoids the cross-process shared-handle gap that crashed it)
#   --use-angle=d3d11 (native Windows backend -> native renderer-string format)
#   wined3d renderer=gl + GALLIUM_DRIVER=d3d12 -> /dev/dxg -> the real card
#   VideoPciVendorID/DeviceID overridden to the host card's real IDs
# Posts as "wine2" so fp-diff can compare it against the native windows.txt.
export LC_ALL=C.UTF-8 DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
export GALLIUM_DRIVER=d3d12
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT=/root/winelab/out; FP=/root/fp; PORT=47800
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
mkdir -p "$FP" /root/linuxlab "$OUT"
cp -f "$REPO/tools/fingerprint-probe.html" /root/linuxlab/fp.html

echo "== collector =="
pgrep -f collect.py >/dev/null || ( setsid nohup python3 "$REPO/tools/relay/collect.py" \
  "$FP" "$PORT" /root/linuxlab/fp.html >"$OUT/collect.log" 2>&1 & )
sleep 2
curl -s -o /dev/null -w "  /probe: %{http_code}\n" "http://127.0.0.1:$PORT/probe"

echo "== display =="
xdpyinfo >/dev/null 2>&1 || { rm -f /tmp/.X11-unix/X9 /tmp/.X9-lock
  setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 & sleep 3; }
pgrep -x fluxbox >/dev/null || { setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & sleep 2; }
timeout 2 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 7 <&3' >/dev/null 2>&1 || {
  pkill -9 -x x11vnc; sleep 1
  ( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR
    setsid nohup x11vnc -display :9 -forever -shared -nopw -quiet -rfbport 5901 \
      -noxdamage -xkb -o "$OUT/x11vnc.log" >/dev/null 2>&1 & ); sleep 2; }
pgrep -f websockify >/dev/null || { setsid nohup websockify --web=/usr/share/novnc 6080 \
  localhost:5901 >"$OUT/websockify.log" 2>&1 & sleep 2; }

echo "== config =="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d gl /f >/dev/null 2>&1
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v VideoPciVendorID /t REG_DWORD /d 4318 /f >/dev/null 2>&1
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v VideoPciDeviceID /t REG_DWORD /d 9353 /f >/dev/null 2>&1
glxinfo -B 2>&1 | grep -E "OpenGL renderer" | sed 's/^/  /'

# No fontconfig restriction here. Measured 2026-09-28: the host Windows itself
# reports DejaVu Sans, Liberation Serif and Roboto, so those are NOT Linux tells;
# only "Ubuntu" is genuinely extra. The real gap is ~33 MISSING Windows families,
# which the 281 files now in C:\windows\Fonts supply. Wine has no font cache at
# the moment, so this first Edge start pays a one-time scan of ~383MB of fonts -
# hence the long patience below.

echo "== Edge on the real GPU -> probe =="
rm -f "$FP/wine2.txt"
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
rm -rf /root/.wine/drive_c/t21 2>/dev/null
( setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t21' --new-window \
    "http://127.0.0.1:$PORT/probe?post=/?as=wine2" >"$OUT/edge-fp2.log" 2>&1 & )

for i in $(seq 1 120); do
  [ -s "$FP/wine2.txt" ] && { echo "  captured at t=$((i*3))s"; break; }
  left=$(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}')
  [ "$left" -lt 700 ] && { echo "  watchdog at t=$((i*3))s"; pkill -9 -f msedge; break; }
  sleep 3
done
[ -s "$FP/wine2.txt" ] || { echo "  NO CAPTURE"; exit 1; }

echo
echo "=============== windows vs wine-on-real-GPU ==============="
python3 - "$FP/windows.txt" "$FP/wine2.txt" <<'EOF'
import sys
def load(p):
    d = {}
    for line in open(p, encoding='utf-8', errors='replace'):
        if line.startswith('---') or ':' not in line: continue
        k, v = line.split(':', 1); d[k.strip()] = v.strip()
    return d
w, l = load(sys.argv[1]), load(sys.argv[2])
gpu = ('webgl', 'webgl2', 'canvas2d', 'webgpu')
same = [k for k in w if k in l and w[k] == l[k]]
diff = [k for k in dict.fromkeys(list(w) + list(l)) if w.get(k, '<absent>') != l.get(k, '<absent>')]
print(f"  identical: {len(same)}   different: {len(diff)}\n")
print("  --- GPU/canvas signals ---")
for k in [k for k in dict.fromkeys(list(w)+list(l)) if k.startswith(gpu)]:
    a, b = w.get(k, '<absent>'), l.get(k, '<absent>')
    mark = "OK  " if a == b else "DIFF"
    print(f"  [{mark}] {k}")
    if a != b:
        print(f"         windows: {a[:120]}")
        print(f"         wine   : {b[:120]}")
print("\n  --- other differences ---")
for k in diff:
    if not k.startswith(gpu):
        print(f"  {k}: windows={w.get(k,'<absent>')[:60]} | wine={l.get(k,'<absent>')[:60]}")
EOF
