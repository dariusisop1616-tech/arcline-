#!/bin/bash
# Wine caches its font list in HKCU\Software\Wine\Fonts\Cache and trusts it.
# During the isolation test the font directory was EMPTY, so Wine cached an empty
# font list; restoring the 281 files afterwards changed nothing because the cache
# said "already scanned". Drop the cache with the files in place, then ask the
# browser again.
export LC_ALL=C.UTF-8 DISPLAY=:9
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
export GALLIUM_DRIVER=d3d12
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT=/root/winelab/out; FP=/root/fp; PORT=47800
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

echo "[1] fonts present: $(ls /root/.wine/drive_c/windows/Fonts | wc -l) files"
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
pkill -9 -x wineserver 2>/dev/null; sleep 1

echo "[2] drop the font cache"
timeout 30 wine reg delete 'HKCU\Software\Wine\Fonts' /f >/dev/null 2>&1 && echo "    cache dropped" || echo "    (nothing to drop)"
wineserver -k 2>/dev/null; sleep 2

echo "[3] launch Edge (pays the scan once) -> probe"
pgrep -f collect.py >/dev/null || ( setsid nohup python3 "$REPO/tools/relay/collect.py" \
  "$FP" "$PORT" /root/linuxlab/fp.html >"$OUT/collect.log" 2>&1 & )
xdpyinfo >/dev/null 2>&1 || { setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 & sleep 3; }
pgrep -x fluxbox >/dev/null || { setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & sleep 2; }
rm -f "$FP/wine4.txt"; rm -rf /root/.wine/drive_c/t23
( setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t23' --new-window \
    "http://127.0.0.1:$PORT/probe?post=/?as=wine4" >"$OUT/edge-recache.log" 2>&1 & )
for i in $(seq 1 60); do
  [ -s "$FP/wine4.txt" ] && { echo "    captured at t=$((i*4))s"; break; }
  left=$(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}')
  [ "$left" -lt 700 ] && { echo "    watchdog"; pkill -9 -f msedge; break; }
  sleep 4
done

echo
echo "[4] fonts + canvas now vs windows"
if [ -s "$FP/wine4.txt" ]; then
  for k in fonts.count fonts.hash canvas2d.toDataURLHash canvas2d.imageDataHash \
           canvas2d.textBandHash canvas2d.gradientHash canvas2d.textMetrics; do
    w=$(grep -E "^$k " "$FP/windows.txt" | sed 's/.*: //')
    l=$(grep -E "^$k " "$FP/wine4.txt"   | sed 's/.*: //')
    [ "$w" = "$l" ] && m="MATCH" || m="diff "
    printf '    [%s] %-26s win=%-14s wine=%s\n' "$m" "$k" "$w" "$l"
  done
  echo "    fonts the wine side reports:"
  grep "^fonts.present" "$FP/wine4.txt" | sed 's/.*: //' | fold -w 150 | sed 's/^/      /'
else
  echo "    NO CAPTURE"; tail -4 "$OUT/edge-recache.log" | cut -c1-150 | sed 's/^/    /'
fi
