#!/bin/bash
# Restore the prefix font registration (I deleted HKLM\...\Fonts while testing,
# which left it empty). `wineboot -u` rescans C:\windows\Fonts and re-registers.
# Deliberately NOT restricting fontconfig here: prove registration works first,
# then hide the distro families as a second, separate step.
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDEBUG=-all
OUT=/root/winelab/out; mkdir -p "$OUT"
echo "files in prefix font dir: $(ls /root/.wine/drive_c/windows/Fonts 2>/dev/null | wc -l)"
echo "registered before       : $(wine reg query 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Fonts' 2>/dev/null | grep -c REG_SZ)"
echo "running wineboot -u ..."
timeout 300 wineboot -u >"$OUT/wineboot.log" 2>&1
wineserver -w 2>/dev/null
echo "registered after        : $(wine reg query 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Fonts' 2>/dev/null | grep -c REG_SZ)"
wine reg query 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Fonts' 2>/dev/null \
  | grep REG_SZ | sed -E 's/^[[:space:]]*//; s/[[:space:]]+REG_SZ.*//' | sort -u > /tmp/regf.txt
echo "windows families present:"
for f in "Segoe UI" Calibri Cambria Consolas Georgia Verdana Impact Tahoma; do
  grep -qi "^$f" /tmp/regf.txt && echo "  OK   $f" || echo "  MISS $f"
done
echo "linux families present:"
grep -icE "dejavu|liberation|c059|nimbus|ubuntu|roboto" /tmp/regf.txt | sed 's/^/  count: /'
