#!/bin/bash
# Wait (max ~3 min) for one workspace's Edge window, then print its status line.
N="${1:-ws3}"; source /root/workspaces/$N/ws.conf
for i in $(seq 1 36); do
  DISPLAY=:$DISP wmctrl -l 2>/dev/null | grep -qi edge && break
  sleep 5
done
t=$(DISPLAY=:$DISP wmctrl -l 2>/dev/null | grep -i edge | head -1 | cut -c32-110)
rfb=$(timeout 2 bash -c "exec 3<>/dev/tcp/127.0.0.1/$VNC; head -c 3 <&3" 2>/dev/null)
echo "$N  vnc=${rfb:-no}  http://localhost:$WEB/vnc.html  ${t:-NO WINDOW}"
free -m | awk 'NR==2{printf "mem %s/%s MB", $3, $2} NR==3{printf ", swap %s MB\n", $3}'
