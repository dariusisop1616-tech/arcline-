#!/bin/bash
# Side-by-side of the two mouse runs (same path, same spacing, same page).
python3 - <<'EOF'
import json, os
def load(n):
    p = f"/root/fp/{n}.txt"
    return json.load(open(p)) if os.path.exists(p) and os.path.getsize(p) else None
a, b = load("mouse_native"), load("mouse_wine")
if not a: print("  native capture missing"); raise SystemExit
if not b: print("  wine capture missing"); raise SystemExit
keys = [k for k in a if k in b]
w = max(len(k) for k in keys)
print(f"  {'signal'.ljust(w)}  {'NATIVE WINDOWS':<22} {'WINE WORKSPACE':<22} same?")
for k in keys:
    same = "yes" if a[k] == b[k] else ""
    print(f"  {k.ljust(w)}  {str(a[k]):<22} {str(b[k]):<22} {same}")
EOF
