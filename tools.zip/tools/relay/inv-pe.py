#!/usr/bin/env python3
"""Investigation step 2: is msedge.dll the 270 MB private block?

Windows shares a DLL's code between all processes (one copy in RAM). Wine can only
share (mmap) a PE image when its sections are page-aligned in the file
(FileAlignment == SectionAlignment == 0x1000). With the usual FileAlignment 0x200
it reads the sections into private anonymous memory - a full copy per process.
This prints the alignment and image size of the big DLLs Edge loads.
"""
import struct, sys, os
D = "/root/workspaces/ws3/prefix/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37"
for name in ["msedge.dll", "msedge_elf.dll", "d3dcompiler_47.dll", "libGLESv2.dll"]:
    p = os.path.join(D, name)
    if not os.path.exists(p):
        continue
    b = open(p, "rb").read(4096)
    pe = struct.unpack_from("<I", b, 0x3C)[0]
    opt = pe + 24
    sect_align, file_align = struct.unpack_from("<II", b, opt + 32)
    size_image = struct.unpack_from("<I", b, opt + 56)[0]
    shareable = "mmap-able (shared)" if file_align >= 0x1000 and sect_align >= 0x1000 else "READ INTO PRIVATE MEMORY per process"
    print(f"{name:<20} file {os.path.getsize(p)/2**20:6.1f} MB  image {size_image/2**20:6.1f} MB  "
          f"SectionAlign {sect_align:#x}  FileAlign {file_align:#x}  -> {shareable}")
