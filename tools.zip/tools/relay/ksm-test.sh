#!/bin/bash
# RAM trim experiment #1, no Wine patch: Kernel Samepage Merging.
# The two measured wastes are (a) a private copy of msedge.dll in every process
# (Wine cannot share a DLL whose FileAlignment is 0x200) and (b) resident all-zero
# pages. KSM merges identical anonymous pages across processes and, with
# use_zero_pages, collapses zero pages onto the kernel's shared zero page.
# Linux 6.4+ lets a process opt ALL its memory in (PR_SET_MEMORY_MERGE); our
# LD_PRELOAD shim is already in every Wine process, so it does that at start.
set -u
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
WS=ws3; SETTLE=90
KSM=/sys/kernel/mm/ksm

echo "[shim] rebuilding with an opt-in KSM constructor"
cat > /root/winelab/mem/memshim_env.c <<'EOF'
#define _GNU_SOURCE
#include <sys/sysinfo.h>
#include <sys/prctl.h>
#include <dlfcn.h>
#include <stdlib.h>
#ifndef PR_SET_MEMORY_MERGE
#define PR_SET_MEMORY_MERGE 67
#endif
/* KSM_MERGE=1: let the kernel merge this process's identical pages (Linux 6.4+). */
__attribute__((constructor)) static void ksm_optin(void) {
    const char *k = getenv("KSM_MERGE");
    if (k && *k == '1') prctl(PR_SET_MEMORY_MERGE, 1, 0, 0, 0);
}
/* FAKE_MEM_KB: physical RAM reported to Wine -> navigator.deviceMemory. */
int sysinfo(struct sysinfo *i) {
    static int (*real)(struct sysinfo *);
    if (!real) real = dlsym(RTLD_NEXT, "sysinfo");
    int r = real(i);
    const char *kb = getenv("FAKE_MEM_KB");
    if (r == 0 && kb && i->mem_unit)
        i->totalram = (unsigned long)(strtoull(kb, 0, 10) * 1024ULL / i->mem_unit);
    return r;
}
EOF
gcc -shared -fPIC -O2 -o /root/winelab/mem/memshim_env.so /root/winelab/mem/memshim_env.c -ldl || exit 1

used() { free -m | awk 'NR==2{print $3}'; }
swp()  { free -m | awk 'NR==3{print $3}'; }
footprint() {  # resident + swapped of every process in the workspace prefix
  local t=0
  for p in $(pgrep -f "msedge|wine|\.exe"); do
    grep -qz "WINEPREFIX=/root/workspaces/$WS/prefix" /proc/$p/environ 2>/dev/null || continue
    r=$(awk '/^VmRSS/{print $2}' /proc/$p/status 2>/dev/null); s=$(awk '/^VmSwap/{print $2}' /proc/$p/status 2>/dev/null)
    t=$((t + ${r:-0} + ${s:-0}))
  done
  echo $((t / 1024))
}
run() {  # $1 = label, $2 = KSM_MERGE value
  bash "$REPO/tools/relay/ws-stop.sh" $WS >/dev/null 2>&1; sleep 3
  sync; echo 1 > /proc/sys/vm/drop_caches
  local base=$(used)
  KSM_MERGE=$2 bash "$REPO/tools/relay/ws-start.sh" $WS >/dev/null 2>&1
  sleep $SETTLE
  if [ "$2" = 1 ]; then  # give KSM time to finish at least two full scans
    local f0=$(cat $KSM/full_scans)
    for i in $(seq 1 40); do [ $(( $(cat $KSM/full_scans) - f0 )) -ge 2 ] && break; sleep 5; done
  fi
  local u=$(used) s=$(swp)
  printf '  %-16s system RAM +%5d MB   (swap %5d MB)   per-process sum %5d MB\n' "$1" $((u - base)) $s $(footprint)
  if [ "$2" = 1 ]; then
    printf '  %-16s KSM: %d MB deduplicated, %d MB zero pages collapsed\n' "" \
      $(( $(cat $KSM/pages_sharing) * 4 / 1024 )) $(( $(cat $KSM/ksm_zero_pages) * 4 / 1024 ))
  fi
}

echo "[ksm] off for the baseline"
echo 0 > $KSM/run
run "baseline" 0

echo "[ksm] on: use_zero_pages, fast scan for the test"
echo 1 > $KSM/use_zero_pages
echo 20000 > $KSM/pages_to_scan
echo 20 > $KSM/sleep_millisecs
echo 1 > $KSM/run
run "with KSM" 1
echo "  ksmd CPU now: $(ps -o %cpu= -C ksmd | tr -d ' ')%"
