# How much GPU memory does a workspace actually cost?
# Windows does not attribute VRAM per process under WDDM, so measure by
# difference: no workspace -> one -> two. Each step stops/starts through WSL.
# (Comparison point: a Windows RDP session reportedly costs ~1 GB VRAM each.)
$ErrorActionPreference = "Continue"
$smi = "C:\Windows\System32\nvidia-smi.exe"
function VRAM { (& $smi --query-gpu=memory.used --format=csv,noheader,nounits) -as [int] }
function WSLRun($cmd) { & wsl.exe -d Ubuntu -- bash -c $cmd 2>&1 | Out-Null }
$rel = "/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/relay"

Write-Output "stopping all workspaces..."
WSLRun "for n in ws1 ws2 ws3; do bash '$rel/ws-stop.sh' `$n; done"
Start-Sleep -Seconds 12
$base = VRAM; Write-Output ("baseline (no workspace) : {0} MiB" -f $base)

foreach ($ws in @("ws1","ws2")) {
  WSLRun "WINE_TREE=/root/workspaces/$ws/wine-ours bash '$rel/ws-start.sh' $ws"
  Start-Sleep -Seconds 75
  $v = VRAM
  Write-Output ("after {0}              : {1} MiB   (+{2} MiB for this workspace, {3} total)" -f $ws, $v, ($v - $script:last), ($v - $base))
  $script:last = $v
}
Write-Output ""
Write-Output "note: your own apps (Chrome, Opera, Discord, League) also move this number."
