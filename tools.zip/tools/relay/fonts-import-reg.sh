#!/bin/bash
# Wine's DirectWrite (what Chromium enumerates fonts through) builds its system
# collection from HKLM\...\Windows NT\CurrentVersion\Fonts, not from the files in
# C:\windows\Fonts. GDI saw our 281 files (+font trace: calibri x294), dwrite did
# not. Import the host's REAL key so the name->file mapping is identical to the
# user's Windows, then ask the browser.
export LC_ALL=C.UTF-8 DISPLAY=:9
export WINEPREFIX=/root/.wine
export PATH="/opt/wine-staging/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
export GALLIUM_DRIVER=d3d12
REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
REG="$REPO/tools/relay/win-fonts.reg"
OUT=/root/winelab/out; FP=/root/fp; PORT=47800
D=/root/.wine/drive_c/windows/Fonts
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
pkill -9 -x wineserver 2>/dev/null; sleep 1

echo "[1] files the key references that are missing from the prefix"
iconv -f UTF-16LE -t UTF-8 "$REG" 2>/dev/null | tr -d '\r' \
  | sed -nE 's/^"[^"]*"="([^"]+)"$/\1/p' > /tmp/regfiles.txt
miss=0
while read -r f; do
  case "$f" in *\\*) continue ;; esac          # full paths = not in Fonts dir
  [ -f "$D/$f" ] || [ -f "$D/$(echo "$f" | tr 'A-Z' 'a-z')" ] || miss=$((miss+1))
done < /tmp/regfiles.txt
echo "    referenced: $(wc -l < /tmp/regfiles.txt)  missing: $miss"

echo "[2] import the key"
cp -f "$REG" /tmp/win-fonts.reg
timeout 60 wine regedit /S 'Z:\tmp\win-fonts.reg' >/dev/null 2>&1
echo "    registered now: $(timeout 30 wine reg query 'HKLM\Software\Microsoft\Windows NT\CurrentVersion\Fonts' 2>/dev/null | grep -c REG_SZ)"

echo "[3] drop font cache, relaunch Edge -> probe"
timeout 30 wine reg delete 'HKCU\Software\Wine\Fonts' /f >/dev/null 2>&1
wineserver -k 2>/dev/null; sleep 2
pgrep -f collect.py >/dev/null || ( setsid nohup python3 "$REPO/tools/relay/collect.py" \
  "$FP" "$PORT" /root/linuxlab/fp.html >"$OUT/collect.log" 2>&1 & )
xdpyinfo >/dev/null 2>&1 || { setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 & sleep 3; }
pgrep -x fluxbox >/dev/null || { setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & sleep 2; }
rm -f "$FP/wine5.txt"; rm -rf /root/.wine/drive_c/t24
( setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --in-process-gpu --use-angle=d3d11 --disable-gpu-watchdog \
    --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t24' --new-window \
    "http://127.0.0.1:$PORT/probe?post=/?as=wine5" >"$OUT/edge-fontreg.log" 2>&1 & )
for i in $(seq 1 60); do
  [ -s "$FP/wine5.txt" ] && { echo "    captured at t=$((i*4))s"; break; }
  left=$(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}')
  [ "$left" -lt 700 ] && { echo "    watchdog"; pkill -9 -f msedge; break; }
  sleep 4
done

echo
echo "[4] vs windows"
if [ -s "$FP/wine5.txt" ]; then
  for k in fonts.count fonts.hash canvas2d.toDataURLHash canvas2d.imageDataHash \
           canvas2d.textBandHash canvas2d.gradientHash canvas2d.textMetrics; do
    w=$(grep -E "^$k " "$FP/windows.txt" | sed 's/.*: //')
    l=$(grep -E "^$k " "$FP/wine5.txt"   | sed 's/.*: //')
    [ "$w" = "$l" ] && m="MATCH" || m="diff "
    printf '    [%s] %-26s win=%-24s wine=%s\n' "$m" "$k" "$w" "$l"
  done
  echo "    wine fonts:"
  grep "^fonts.present" "$FP/wine5.txt" | sed 's/.*: //' | fold -w 150 | sed 's/^/      /'
else
  echo "    NO CAPTURE"; tail -4 "$OUT/edge-fontreg.log" | cut -c1-150 | sed 's/^/    /'
fi
