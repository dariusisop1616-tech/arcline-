#!/bin/bash
# The window DOES appear and then Chrome exits - so this is a crash-after-show, not a
# mapping failure. Poll tightly to catch the moment it dies, record the exit code, and
# keep it on :9 because that is the display the user is actually looking at.
export DISPLAY=:9
W=/root/winelab
OUT="$W/out"
mkdir -p "$OUT"

EXE=$(find "$W/old/c110" -maxdepth 3 -name chrome.exe | head -1)
echo "### exe: ${EXE:-MISSING}"
[ -z "$EXE" ] && exit 1
echo

echo "=== [1] what is on :9 right now (before we touch anything) ==="
for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -30); do
  info=$(xwininfo -id "$w" 2>/dev/null) || continue
  geo=$(echo "$info" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
  nm=$(echo "$info" | grep -oE '"[^"]*"' | head -1)
  st=unmapped; echo "$info" | grep -q IsViewable && st=MAP
  [ "$st" = MAP ] && printf '  MAP %-10s %-22s %s\n' "$w" "$geo" "$nm"
done
echo "  wine procs: $(pgrep -fc wine 2>/dev/null || echo 0)"
echo

echo "=== [2] launch on :9 and poll for 40s ==="
pkill -9 -f chrome.exe 2>/dev/null
pkill -9 -f wineserver 2>/dev/null
sleep 3
rm -rf "$W/cd_seen" 2>/dev/null
setsid nohup wine "$EXE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-gpu \
  --window-size=1200,700 --window-position=80,80 \
  --user-data-dir='C:\cd_seen' --new-window "about:blank" \
  >"$OUT/seen.log" 2>&1 &
PIDS=$(pgrep -f chrome.exe 2>/dev/null | tr '\n' ' ')
echo "  launched, chrome pids: $PIDS"
echo

prev=""
died_at=""
for i in $(seq 1 20); do
  n=$(pgrep -fc chrome.exe 2>/dev/null || echo 0)
  # any mapped window wider than 400px that we did not see before
  win=""
  for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -40); do
    info=$(xwininfo -id "$w" 2>/dev/null) || continue
    echo "$info" | grep -q IsViewable || continue
    geo=$(echo "$info" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
    wdt=${geo%%x*}
    if [ "${wdt:-0}" -gt 400 ] 2>/dev/null; then
      nm=$(echo "$info" | grep -oE '"[^"]*"' | head -1)
      case "$nm" in
        *"Chrome for Testing"*|*"New Tab"*|*Mouse*) continue ;;
      esac
      win="$w $geo $nm"
    fi
  done
  line="t=$((i*2))s procs=$n win=${win:-none}"
  [ "$line" != "$prev" ] && echo "  $line"
  prev="$line"
  if [ "$n" = 0 ] && [ -z "$died_at" ]; then died_at=$((i*2)); fi
  sleep 2
done
echo
echo "  procs died at approximately: ${died_at:-did-not-die}s"
echo

echo "=== [3] why did it die? ==="
echo "  --- log size: $(stat -c%s "$OUT/seen.log" 2>/dev/null) bytes ---"
echo "  --- crash / fatal / error lines ---"
grep -inE 'crash|fatal|Check failed|assert|exception|unhandled|SIGSEGV|SIGABRT|abort' "$OUT/seen.log" 2>/dev/null | head -20 | sed 's/^/    /'
echo "  --- last 30 lines ---"
tail -30 "$OUT/seen.log" 2>/dev/null | sed 's/^/    /'
echo
echo "=== [4] screenshot :9 ==="
command -v import >/dev/null && import -window root "$OUT/seen.png" 2>/dev/null \
  && cp "$OUT/seen.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-seen.png" \
  && echo "  saved results/wine-seen.png"
