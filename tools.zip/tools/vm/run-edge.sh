#!/bin/bash
# Edge is installed by Wine's msiexec at C:\Program Files (x86)\Microsoft\Edge\Application\
# <ver>\msedge.exe. Launch THAT, on :9 so it is visible on the display being watched.
# Window detection uses wmctrl -lp (a managed-client list with pids); the xwininfo tree
# parsing used earlier was unreliable and produced false "nothing mapped" readings.
export DISPLAY=:9
W=/root/winelab
OUT="$W/out"
mkdir -p "$OUT"

EXE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
if [ ! -f "$EXE" ]; then
  EXE=$(find /root/.wine/drive_c -iname msedge.exe 2>/dev/null | head -1)
fi
echo "### edge exe: ${EXE:-MISSING}"
[ -z "$EXE" ] && exit 1
echo "### size: $(stat -c%s "$EXE" 2>/dev/null) bytes"
echo "### install dir:"
ls "$(dirname "$EXE")" 2>/dev/null | head -12 | sed 's/^/    /'
echo

echo "=== [1] let the installer settle, then clear leftovers ==="
pkill -9 -f msiexec 2>/dev/null
pkill -9 -f EdgeUpdate 2>/dev/null
pkill -9 -f chrome.exe 2>/dev/null
pkill -9 -f msedge 2>/dev/null
sleep 4
echo "  cleared"
echo

echo "=== [2] baseline mapped windows on :9 ==="
wmctrl -lp 2>/dev/null | sed 's/^/  /'
echo

echo "=== [3] launch Edge on :9 ==="
rm -rf "$W/edge/profile" 2>/dev/null
setsid nohup wine "$EXE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-sync --disable-features=msEdgeFirstRunExperience \
  --window-size=1200,700 --window-position=70,70 \
  --user-data-dir='C:\edge_profile' --new-window "about:blank" \
  >"$OUT/edge.log" 2>&1 &
echo "  launched, pid $!"
echo

echo "=== [4] poll 45s for an Edge window ==="
prev=""
for i in $(seq 1 15); do
  n=$(pgrep -fc msedge 2>/dev/null || echo 0)
  wins=$(wmctrl -lp 2>/dev/null | grep -viE 'Chrome for Testing|RX580' | tr '\n' ';')
  line="t=$((i*3))s msedge_procs=$n | managed: ${wins:-none}"
  [ "$line" != "$prev" ] && echo "  $line"
  prev="$line"
  sleep 3
done
echo

echo "=== [5] all windows on :9 now (incl unmapped, by class) ==="
wmctrl -lp 2>/dev/null | sed 's/^/  MAPPED /'
for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]{4,}' | head -30); do
  info=$(xwininfo -id "$w" 2>/dev/null) || continue
  nm=$(echo "$info" | grep -oE '"[^"]*"' | head -1)
  case "$nm" in *msedge*|*Edge*|*"about:blank"*) echo "  TREE $w $nm";; esac
done
echo

echo "=== [6] edge log: errors and tail ==="
echo "  size: $(stat -c%s "$OUT/edge.log" 2>/dev/null) bytes"
grep -inE 'ERROR|FATAL|Check failed|unimplemented|abort|crash' "$OUT/edge.log" 2>/dev/null | head -15 | sed 's/^/    /'
echo "  --- tail 25 ---"
tail -25 "$OUT/edge.log" 2>/dev/null | sed 's/^/    /'
echo

echo "=== [7] screenshot ==="
command -v import >/dev/null && import -window root "$OUT/edge.png" 2>/dev/null \
  && cp "$OUT/edge.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-edge.png" \
  && echo "  saved results/wine-edge.png"
