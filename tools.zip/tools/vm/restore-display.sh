#!/bin/bash
# The noVNC display died because its launcher was tied to a shell that exited, taking
# websockify (port 6080) with it. Bring the stack back, and start each piece with
# setsid+nohup so it survives the shell that launched it.
LAB=/root/linuxlab
DISP=:9
PORT_RFB=5901
PORT_WEB=6080
mkdir -p "$LAB/out"

echo "=== what survived? ==="
for p in Xvfb x11vnc websockify fluxbox; do
  n=$(pgrep -fc "$p" 2>/dev/null || echo 0)
  echo "  $p: $n"
done
echo

# Xvfb
if ! pgrep -f "Xvfb $DISP" >/dev/null 2>&1; then
  echo "starting Xvfb $DISP"
  setsid nohup Xvfb "$DISP" 1440x900x24 -ac +extension GLX +render -noreset \
    >"$LAB/out/xvfb.log" 2>&1 < /dev/null &
  sleep 3
else
  echo "Xvfb already up"
fi

# fluxbox
if ! pgrep -f fluxbox >/dev/null 2>&1; then
  echo "starting fluxbox"
  DISPLAY=$DISP setsid nohup fluxbox >"$LAB/out/fluxbox.log" 2>&1 < /dev/null &
  sleep 2
else
  echo "fluxbox already up"
fi

# x11vnc - must not see Wayland vars or it refuses to start
if ! pgrep -f "x11vnc.*$DISP" >/dev/null 2>&1; then
  echo "starting x11vnc"
  unset WAYLAND_DISPLAY
  unset XDG_RUNTIME_DIR
  unset PULSE_SERVER
  setsid nohup x11vnc -display "$DISP" -forever -shared -nopw -quiet \
    -rfbport "$PORT_RFB" -noxdamage -xkb -o "$LAB/out/x11vnc.log" \
    >"$LAB/out/x11vnc-stdout.log" 2>&1 < /dev/null &
  sleep 3
else
  echo "x11vnc already up"
fi

# websockify + noVNC - this is the part that serves localhost:6080
if ! pgrep -f "websockify.*$PORT_WEB" >/dev/null 2>&1; then
  echo "starting websockify on $PORT_WEB"
  setsid nohup websockify --web=/usr/share/novnc "$PORT_WEB" "localhost:$PORT_RFB" \
    >"$LAB/out/websockify.log" 2>&1 < /dev/null &
  sleep 3
else
  echo "websockify already up"
fi

echo
echo "=== verify ==="
echo "  processes: Xvfb=$(pgrep -fc Xvfb) x11vnc=$(pgrep -fc x11vnc) websockify=$(pgrep -fc websockify) fluxbox=$(pgrep -fc fluxbox)"
echo -n "  port 6080: "
if curl -s -o /dev/null -w '%{http_code}' --max-time 5 "http://localhost:$PORT_WEB/vnc.html" 2>/dev/null; then
  echo " (HTTP ok)"
else
  echo "NOT responding"
fi
echo -n "  port 5901: "
(echo > /dev/tcp/127.0.0.1/$PORT_RFB) >/dev/null 2>&1 && echo "open" || echo "closed"
echo
echo "=== windows on the display ==="
DISPLAY=$DISP wmctrl -l 2>/dev/null | sed 's/^/  /' || echo "  (none)"
