#!/bin/bash
# Which graphics DLLs does Edge ship itself, and which does it import from the
# system (= the ones Wine provides, i.e. the ones a relay would replace)?
D="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37"
echo "== graphics DLLs shipped inside Edge =="
ls "$D" | grep -iE "d3d|dxgi|dxcompiler|dxil|libGLES|libEGL|vk_|vulkan|swiftshader|dcomp"
echo
echo "== system graphics DLLs referenced by Edge's GPU-side binaries =="
for f in msedge.dll libGLESv2.dll; do
  [ -f "$D/$f" ] || continue
  echo "-- $f"
  strings -e l "$D/$f" | grep -ioE "^(d3d11|d3d12|dxgi|dcomp|d3dcompiler_47|dwrite)\.dll$" | sort -u | sed 's/^/   /'
  strings "$D/$f" | grep -ioE "^(d3d11|d3d12|dxgi|dcomp|d3dcompiler_47|dwrite)\.dll$" | sort -u | sed 's/^/   /'
done
