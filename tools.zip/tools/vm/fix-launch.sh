#!/bin/bash
# Goal: get a browser window actually MAPPED (visible) under Wine. Detection matches the WM
# class string ("msedge.exe"/"chrome.exe") because the window NAME lives only in
# `xwininfo -root -tree` and Edge's title contains a zero-width space.
export DISPLAY=:9
W=/root/winelab
OUT="$W/out"
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
C110=$(find "$W/old/c110" -maxdepth 3 -name chrome.exe | head -1)

probe() {  # probe <tag> <class-regex> <procname>
  local tag="$1" pat="$2" pname="$3" line wid info map geo procs
  line=$(xwininfo -root -tree 2>/dev/null | grep -iE "$pat" | head -1)
  wid=$(echo "$line" | grep -oE '0x[0-9a-f]{4,}' | head -1)
  procs=$(pgrep -fc "$pname" 2>/dev/null || echo 0)
  if [ -n "$wid" ]; then
    info=$(xwininfo -id "$wid" 2>/dev/null)
    map=$(echo "$info" | grep -oE 'Map State: [A-Za-z]+' | head -1)
    geo=$(echo "$line" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
    printf '    %-12s procs=%-3s %s %s win=%s\n' "$tag" "$procs" "$map" "$geo" "$wid"
  else
    printf '    %-12s procs=%-3s NO WINDOW in tree (pattern %s)\n' "$tag" "$procs" "$pat"
  fi
}

reset() {
  pkill -9 -f msedge 2>/dev/null
  pkill -9 -f 'chrome\.exe' 2>/dev/null
  pkill -9 -f wineserver 2>/dev/null
  sleep 4
}

echo "########## T1: Chromium 110, plain ##########"
reset
rm -rf "$W/t1" 2>/dev/null
setsid nohup wine "$C110" --no-sandbox --no-first-run --no-default-browser-check \
  --disable-extensions --window-size=1200,700 --window-position=60,60 \
  --user-data-dir='C:\t1' --new-window "about:blank" >"$OUT/t1.log" 2>&1 &
sleep 20; probe c110 'chrome\.exe|Chromium' chrome.exe
echo "    DComp=$(grep -c DCompositionCreateDevice "$OUT/t1.log" 2>/dev/null) deadlock=$(grep -c loader_section "$OUT/t1.log" 2>/dev/null)"
echo

echo "########## T2: Chromium 110, --disable-gpu ##########"
reset
rm -rf "$W/t2" 2>/dev/null
setsid nohup wine "$C110" --no-sandbox --no-first-run --no-default-browser-check \
  --disable-extensions --disable-gpu --window-size=1200,700 --window-position=60,60 \
  --user-data-dir='C:\t2' --new-window "about:blank" >"$OUT/t2.log" 2>&1 &
sleep 20; probe c110gpu 'chrome\.exe|Chromium' chrome.exe
echo "    DComp=$(grep -c DCompositionCreateDevice "$OUT/t2.log" 2>/dev/null)"
echo

echo "########## T3: Edge 154 with Microsoft's REAL dcomp.dll ##########"
reset
NATIVE=/mnt/g/Windows/System32/dcomp.dll
[ -f "$NATIVE" ] || NATIVE=$(find /mnt/c/Windows/System32 -maxdepth 1 -iname dcomp.dll 2>/dev/null | head -1)
echo "    native source: ${NATIVE:-NOT FOUND}"
if [ -n "$NATIVE" ] && [ -f "$NATIVE" ]; then
  cp -n /root/.wine/drive_c/windows/system32/dcomp.dll /root/.wine/drive_c/windows/system32/dcomp.dll.winebak 2>/dev/null
  cp -f "$NATIVE" /root/.wine/drive_c/windows/system32/dcomp.dll 2>/dev/null
  echo "    installed: $(stat -c%s /root/.wine/drive_c/windows/system32/dcomp.dll) bytes"
  echo "    imports resolve? (dwmapi/dxgi expected)"
  rm -rf "$W/t3" 2>/dev/null
  WINEDLLOVERRIDES="dcomp=n" setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t3' --new-window "about:blank" >"$OUT/t3.log" 2>&1 &
  sleep 22; probe edge 'msedge\.exe' msedge
  echo "    DComp=$(grep -c DCompositionCreateDevice "$OUT/t3.log" 2>/dev/null)"
  echo "    --- dcomp-related log lines ---"
  grep -iE 'dcomp|dwmapi|dxgi' "$OUT/t3.log" 2>/dev/null | head -5 | sed 's/^/      /'
  # restore the wine stub
  [ -f /root/.wine/drive_c/windows/system32/dcomp.dll.winebak ] && \
    mv -f /root/.wine/drive_c/windows/system32/dcomp.dll.winebak \
          /root/.wine/drive_c/windows/system32/dcomp.dll
fi
echo

echo "########## T4: Edge, --disable-direct-composition + desktop GL ##########"
reset
rm -rf "$W/t4" 2>/dev/null
setsid nohup wine "$EDGE" --no-sandbox --no-first-run --no-default-browser-check \
  --disable-extensions --disable-sync --disable-component-update \
  --disable-direct-composition --use-angle=gl --disable-gpu-sandbox \
  --window-size=1200,700 --window-position=60,60 \
  --user-data-dir='C:\t4' --new-window "about:blank" >"$OUT/t4.log" 2>&1 &
sleep 20; probe edge-gl 'msedge\.exe' msedge
echo

echo "########## T5: Edge inside a Wine virtual desktop ##########"
reset
pkill -9 -f explorer.exe 2>/dev/null; sleep 2
wine reg add "HKCU\\Software\\Wine\\Explorer" /v Desktop /d edge /f >/dev/null 2>&1
wine reg add "HKCU\\Software\\Wine\\Explorer\\Desktops" /v edge /d 1280x800 /f >/dev/null 2>&1
rm -rf "$W/t5" 2>/dev/null
setsid nohup wine "$EDGE" --no-sandbox --no-first-run --no-default-browser-check \
  --disable-extensions --disable-sync --disable-component-update \
  --window-size=1200,700 --user-data-dir='C:\t5' --new-window "about:blank" \
  >"$OUT/t5.log" 2>&1 &
sleep 22; probe edge-vdesk 'msedge\.exe|Wine desktop' msedge
echo "    --- Wine desktop windows ---"
for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]{4,}' | head -40); do
  i=$(xwininfo -id "$w" 2>/dev/null) || continue
  case "$i" in *"Wine desktop"*) echo "      $w $(echo "$i" | grep -oE 'Map State: [A-Za-z]+' | head -1)";; esac
done
# turn the virtual desktop back off so it does not wrap future launches
wine reg delete "HKCU\\Software\\Wine\\Explorer" /v Desktop /f >/dev/null 2>&1
echo

echo "########## summary: managed windows + screenshot ##########"
wmctrl -lp 2>/dev/null | grep -viE 'Chrome for Testing|RX580' | sed 's/^/  /'
command -v import >/dev/null && import -window root "$OUT/fix-launch.png" 2>/dev/null \
  && cp "$OUT/fix-launch.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-fix-launch.png" \
  && echo "  saved results/wine-fix-launch.png"
