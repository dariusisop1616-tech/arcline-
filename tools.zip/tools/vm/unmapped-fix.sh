#!/bin/bash
# The window is created but NEVER MAPPED (IsUnMapped, WM _NET_CLIENT_LIST empty).
# Notepad maps fine, so Wine's X11 driver is healthy - it is Chrome's window style.
# Three known fixes for exactly this symptom:
#   [A] Wine virtual desktop, invoked with a proper WINDOWS path
#   [B] --disable-features=CalculateNativeWinOcclusion  (Chrome decides its window is
#       occluded and never paints/maps it - classic in VMs, Wine, remote sessions)
#   [C] Edge under Wine instead of Chrome

export LC_ALL=C.UTF-8
LAB="$HOME/winelab"
export WINEPREFIX="$LAB/prefix"
export WINEDEBUG="-all"
export PATH="$PATH:/usr/lib/x86_64-linux-gnu/wine"
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe
export DISPLAY=:9

REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT="$REPO/results/vm-display"
mkdir -p "$OUT" "$LAB/out"
pkill -x xmessage 2>/dev/null

BASE=(--no-sandbox --disable-dev-shm-usage
      --use-angle=swiftshader --ignore-gpu-blocklist
      --no-first-run --no-default-browser-check --disable-extensions
      --window-size=1280,800)

report() {
  local tag="$1"
  echo "  chrome procs : $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
  echo "  msedge procs : $(pgrep -fc msedge.exe 2>/dev/null || echo 0)"
  local mapped=0
  for id in $(xwininfo -root -tree 2>/dev/null | grep -iE 'chrome|msedge|wine' | grep -oE '0x[0-9a-f]+' | sort -u); do
    ms=$(xwininfo -id "$id" 2>/dev/null | grep -i 'Map State' | head -1 | awk '{print $NF}')
    wh=$(xwininfo -id "$id" 2>/dev/null | grep -E '^  Width|^  Height' | awk '{print $2}' | tr '\n' 'x')
    echo "    $id  map=$ms  size=$wh"
    [ "$ms" = "IsViewable" ] && mapped=$((mapped+1))
  done
  echo "  >>> VIEWABLE windows: $mapped"
  import -window root -display :9 "$OUT/fix_$tag.png" 2>/dev/null \
    && echo "  shot: results/vm-display/fix_$tag.png"
}

echo "################ [A] wine virtual desktop, windows path ################"
pkill -f chrome.exe 2>/dev/null; pkill -f msedge.exe 2>/dev/null; sleep 3
wine explorer /desktop=lab,1440x900 'Z:\root\winelab\chrome\chrome.exe' "${BASE[@]}" \
  --user-data-dir="$LAB/cd_vd2" 'file:///Z:/root/winelab/show.html' \
  >"$LAB/out/fixA.log" 2>&1 &
sleep 35
report A
echo "  log:"; grep -viE 'alsa|pcm|conf' "$LAB/out/fixA.log" 2>/dev/null | tail -4 | sed 's/^/    /'

echo
echo "################ [B] CalculateNativeWinOcclusion disabled ################"
pkill -f chrome.exe 2>/dev/null; sleep 3
wine "$LAB/chrome/chrome.exe" "${BASE[@]}" \
  --disable-features=CalculateNativeWinOcclusion \
  --user-data-dir="$LAB/cd_occ" 'file:///Z:/root/winelab/show.html' \
  >"$LAB/out/fixB.log" 2>&1 &
sleep 30
report B

echo
echo "################ [C] Edge under Wine ################"
pkill -f chrome.exe 2>/dev/null; sleep 3
EDGE=$(ls "$LAB"/edge/*/msedge.exe "$LAB"/edge/*/*/msedge.exe 2>/dev/null | head -1)
if [ -z "$EDGE" ]; then EDGE=$(find "$LAB/edge" -name msedge.exe 2>/dev/null | head -1); fi
echo "  edge binary: ${EDGE:-NOT FOUND}"
if [ -n "$EDGE" ]; then
  WINEDGE="Z:$(echo "$EDGE" | sed 's|^/|/|')"
  echo "  as windows path: $WINEDGE"
  wine "$EDGE" "${BASE[@]}" --disable-features=CalculateNativeWinOcclusion \
    --user-data-dir="$LAB/cd_edge2" 'file:///Z:/root/winelab/show.html' \
    >"$LAB/out/fixC.log" 2>&1 &
  sleep 35
  report C
  echo "  log:"; grep -viE 'alsa|pcm|conf' "$LAB/out/fixC.log" 2>/dev/null | tail -4 | sed 's/^/    /'
fi
echo "=== DONE ==="
