#!/bin/bash
# Round 2: the first patch hit wined3d.dll (x86_64-windows PE copy) but the
# name still came through as 480. The scan shows the string ALSO lives in the
# unix-side win32u.so - in modern Wine the adapter/GPU-description code runs
# there - and in the i386 PE copy. Patch every /opt copy (the distro Wine in
# /usr/lib is not the one the lab runs, leave it as a control).
set -e
OLD="Radeon (TM) RX 480 Graphics"
NEW="Radeon (TM) RX 580 Series"    # 25 chars vs 27 -> 2 NUL padding

patch_one() {
  F="$1"
  if [ ! -f "$F" ]; then echo "missing: $F"; return; fi
  BAK="$F.orig-rx480"
  [ -f "$BAK" ] || cp -a "$F" "$BAK"
  python3 - "$F" <<'EOF'
import sys
f = sys.argv[1]
data = bytearray(open(f, 'rb').read())
old = b"Radeon (TM) RX 480 Graphics"
new = b"Radeon (TM) RX 580 Series\x00\x00"
n = data.count(old)
if n:
    open(f, 'wb').write(data.replace(old, new))
    print(f"  patched {n} occurrence(s) in {f}")
else:
    print(f"  no 480 entry in {f} ({'580 already there' if data.count(b'RX 580 Series') else 'nothing to do'})")
EOF
  echo -n "  verify: "; strings "$F" | grep -oE "Radeon .TM. RX 5[58]0 [A-Za-z]+" | head -2 | tr '\n' ' '; echo
}

echo "== patching =="
patch_one /opt/wine-staging/lib/wine/x86_64-unix/win32u.so
patch_one /opt/wine-staging/lib/wine/i386-windows/wined3d.dll

echo "== restart Edge (supervisor revives it with a fresh profile) =="
pkill -9 -f msedge 2>/dev/null || true
sleep 2

echo "== poll the title; success = renderer says 'RX 580 Series' =="
for i in $(seq 1 45); do
  line=$(DISPLAY=:9 wmctrl -l 2>/dev/null | grep -iE "rx580check" | tail -1 | cut -c1-260)
  if [ -n "$line" ]; then
    printf '    t=%-3ss %s\n' "$((i*2))" "$line"
    case "$line" in
      *RX580CHECK*"RX 580 Series"*) echo "    >>> RX 580 NAME IS THROUGH"; break ;;
      *RX580CHECK*"RX 480"*) : ;;
    esac
  fi
  sleep 2
done