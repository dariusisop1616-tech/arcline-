#!/bin/bash
# Fixed detection: the window NAME only appears in `xwininfo -root -tree`, and the title
# contains a zero-width space ("Microsoft<U+200B> Edge"), so match the ASCII class
# ("msedge.exe") instead. Previous run's "no-window" lines were false negatives.
export DISPLAY=:9
W=/root/winelab
OUT="$W/out"
EXE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

probe() {  # probe <tag>
  local tag="$1"
  local line wid info map geo procs dead
  line=$(xwininfo -root -tree 2>/dev/null | grep -i 'msedge\.exe' | head -1)
  wid=$(echo "$line" | grep -oE '0x[0-9a-f]{4,}' | head -1)
  procs=$(pgrep -fc msedge 2>/dev/null || echo 0)
  dead=no; grep -q 'loader_section' "$OUT/m_$tag.log" 2>/dev/null && dead=YES
  if [ -n "$wid" ]; then
    info=$(xwininfo -id "$wid" 2>/dev/null)
    map=$(echo "$info" | grep -oE 'Map State: [A-Za-z]+' | head -1)
    geo=$(echo "$line" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
    printf '  %-13s procs=%-3s deadlock=%-4s win=%s %s %s\n' "$tag" "$procs" "$dead" "$wid" "$map" "$geo"
  else
    printf '  %-13s procs=%-3s deadlock=%-4s NO WINDOW IN TREE\n' "$tag" "$procs" "$dead"
  fi
}

run() {
  local tag="$1"; shift
  pkill -9 -f msedge 2>/dev/null; pkill -9 -f wineserver 2>/dev/null
  sleep 4
  rm -rf "$W/m_$tag" 2>/dev/null
  setsid nohup wine "$EXE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update \
    --window-size=1200,700 --window-position=70,70 \
    --user-data-dir="C:\\m_$tag" --new-window "about:blank" \
    "$@" >"$OUT/m_$tag.log" 2>&1 &
  sleep 18
  probe "$tag"
  sleep 6
  probe "$tag"
}

echo "=== Edge variants (2 probes each: ~18s and ~24s after launch) ==="
run baseline
run single   --single-process
run nodcomp  --disable-direct-composition
echo

echo "=== which logs actually contain the loader deadlock? ==="
for f in "$OUT"/m_*.log "$OUT"/edge2.log; do
  [ -f "$f" ] || continue
  printf '  %-28s loader_section=%s  DComp=%s  bytes=%s\n' "$(basename "$f")" \
    "$(grep -c loader_section "$f" 2>/dev/null)" \
    "$(grep -c DCompositionCreateDevice "$f" 2>/dev/null)" \
    "$(stat -c%s "$f" 2>/dev/null)"
done
echo

echo "=== keep one alive and watch every 5s ==="
pkill -9 -f msedge 2>/dev/null; pkill -9 -f wineserver 2>/dev/null; sleep 4
rm -rf "$W/m_live" 2>/dev/null
setsid nohup wine "$EXE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-sync --disable-component-update \
  --window-size=1200,700 --window-position=70,70 \
  --user-data-dir='C:\m_live' --new-window "about:blank" \
  >"$OUT/m_live.log" 2>&1 &
for i in 1 2 3 4; do probe live; sleep 5; done
echo
echo "  managed windows on :9:"
wmctrl -lp 2>/dev/null | grep -c . | sed 's/^/    count: /'
wmctrl -lp 2>/dev/null | grep -viE 'Chrome for Testing|RX580' | sed 's/^/    /'
command -v import >/dev/null && import -window root "$OUT/edge-m2.png" 2>/dev/null \
  && cp "$OUT/edge-m2.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-edge-m2.png" \
  && echo "  saved results/wine-edge-m2.png"
