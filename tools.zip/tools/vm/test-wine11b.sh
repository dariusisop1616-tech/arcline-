#!/bin/bash
# wineboot -u stalled because Wine 11 popped a "Wine Mono Installer" dialog (which was itself
# mapped - so Wine 11 maps its own windows fine). Disable the mscoree/mshtml prompts so the
# prefix migrates unattended, then retest Edge under Wine 11.
export DISPLAY=:9
export PATH="/opt/wine-staging/bin:$PATH"
# mscoree = Wine Mono prompt, mshtml = Gecko prompt. Edge needs neither.
export WINEDLLOVERRIDES="mscoree,mshtml="
W=/root/winelab
OUT="$W/out"
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

echo "=== [1] clear the installer dialog and finish the prefix update ==="
pkill -9 -f msedge 2>/dev/null
pkill -9 -f 'chrome\.exe' 2>/dev/null
pkill -9 -f wineboot 2>/dev/null
pkill -9 -f 'Mono' 2>/dev/null
wineserver -k 2>/dev/null
sleep 4
echo "  wineboot -u with prompts disabled..."
timeout 180 wineboot -u >"$OUT/wineboot2.log" 2>&1
echo "  exit=$?"
echo "  tail:"
tail -6 "$OUT/wineboot2.log" 2>/dev/null | sed 's/^/    /'
echo

echo "=== [2] launch Edge under Wine 11, probe every 2s for 44s ==="
rm -rf "$W/t12" 2>/dev/null
setsid nohup wine "$EDGE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-sync --disable-component-update \
  --window-size=1200,700 --window-position=60,60 \
  --user-data-dir='C:\t12' --new-window "about:blank" >"$OUT/t12.log" 2>&1 &
prev=""
for i in $(seq 1 22); do
  line=$(xwininfo -root -tree 2>/dev/null | grep -i 'msedge\.exe' | head -1)
  wid=$(echo "$line" | grep -oE '0x[0-9a-f]{4,}' | head -1)
  procs=$(pgrep -fc msedge 2>/dev/null || echo 0)
  if [ -n "$wid" ]; then
    st=$(xwininfo -id "$wid" 2>/dev/null | grep -oE 'Map State: [A-Za-z]+' | head -1)
    geo=$(echo "$line" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
  else
    st="no-window"; geo=""
  fi
  cur="procs=$procs $st $geo"
  [ "$cur" != "$prev" ] && printf '  t=%-3ss %s\n' "$((i*2))" "$cur"
  prev="$cur"
  sleep 2
done
echo

echo "=== [3] MAP CHECK: managed windows ==="
wmctrl -lp 2>/dev/null | grep -viE 'Chrome for Testing|RX580' | sed 's/^/  /'
echo "  -> Edge listed above means it IS mapped and visible"
echo

echo "=== [4] log ==="
printf '  bytes=%s DComp=%s deadlock=%s\n' \
  "$(stat -c%s "$OUT/t12.log" 2>/dev/null)" \
  "$(grep -c DCompositionCreateDevice "$OUT/t12.log" 2>/dev/null)" \
  "$(grep -c loader_section "$OUT/t12.log" 2>/dev/null)"
grep -iE 'ERROR|unimplemented|abort|wine:' "$OUT/t12.log" 2>/dev/null | head -12 | sed 's/^/    /'
echo
echo "=== [5] screenshot ==="
command -v import >/dev/null && import -window root "$OUT/t12.png" 2>/dev/null \
  && cp "$OUT/t12.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine11b-edge.png" \
  && echo "  saved results/wine11b-edge.png"
