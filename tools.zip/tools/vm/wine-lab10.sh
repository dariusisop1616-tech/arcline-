#!/bin/bash
# Wine tests get their own display (:10) so the Linux browser on :9 - the one being used
# interactively - is never disturbed. Then attack the actual finding: Chrome creates its
# window and Wine never maps it, on any Chrome version, while notepad maps fine. So the
# levers are (a) Wine itself, (b) the window manager, (c) GPU/compositor flags.
set -u
LAB=/root/linuxlab
DISP=:10
OUT=/root/winelab/out
mkdir -p "$OUT"

echo "=== [1] what Wine do we have, and what else is installable? ==="
wine --version 2>/dev/null | sed 's/^/  installed: /'
apt-cache policy wine wine-staging wine-devel winehq-staging 2>/dev/null \
  | grep -E '^[a-z-]+:|Candidate:' | head -20 | sed 's/^/  /'
echo "  winehq repo present: $(ls /etc/apt/sources.list.d/ 2>/dev/null | grep -ci winehq)"
echo "  distro: $(. /etc/os-release; echo "$PRETTY_NAME")"
echo

echo "=== [2] stand up display $DISP (isolated from the user's $DISP=:9 session) ==="
if ! pgrep -f "Xvfb $DISP" >/dev/null 2>&1; then
  setsid nohup Xvfb "$DISP" 1440x900x24 -ac +extension GLX +render -noreset \
    >"$OUT/xvfb10.log" 2>&1 < /dev/null &
  sleep 3
  echo "  Xvfb $DISP started"
else
  echo "  Xvfb $DISP already up"
fi
export DISPLAY=$DISP
echo "  test: $(xdpyinfo -display $DISP >/dev/null 2>&1 && echo 'display responds' || echo 'NO RESPONSE')"
echo

scan() {  # scan <label>
  echo "  --- windows on $DISP ($1) ---"
  local big=0
  for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -40); do
    info=$(xwininfo -id "$w" 2>/dev/null) || continue
    geo=$(echo "$info" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
    nm=$(echo "$info" | grep -oE '"[^"]*"' | head -1)
    st=unmapped; echo "$info" | grep -q IsViewable && st=MAP
    wdt=${geo%%x*}
    if [ "$st" = MAP ] || [ "${wdt:-0}" -gt 400 ] 2>/dev/null; then
      printf '    %-4s %-10s %-22s %s\n' "$st" "$w" "$geo" "$nm"
      [ "${wdt:-0}" -gt 400 ] 2>/dev/null && big=$((big+1))
    fi
  done
  echo "    large windows seen: $big"
  echo "    chrome.exe procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
}

EXE=$(find /root/winelab/old/c110 -maxdepth 3 -name chrome.exe | head -1)

echo "=== [3] NO window manager at all - does Chrome map then? ==="
pkill -9 -f chrome.exe 2>/dev/null; pkill -9 -f wineserver 2>/dev/null; sleep 3
rm -rf /root/winelab/cd_nowm 2>/dev/null
setsid nohup wine "$EXE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-gpu --window-size=1200,700 --window-position=30,30 \
  --user-data-dir='C:\cd_nowm' --new-window "about:blank" \
  >"$OUT/nowm.log" 2>&1 &
sleep 22
scan "no WM"
echo

echo "=== [4] add fluxbox on $DISP - does a WM change it? ==="
if ! pgrep -f "fluxbox" >/dev/null 2>&1 || ! DISPLAY=$DISP pgrep -f fluxbox >/dev/null 2>&1; then
  DISPLAY=$DISP setsid nohup fluxbox >"$OUT/fluxbox10.log" 2>&1 < /dev/null &
  sleep 3
  echo "  fluxbox started on $DISP"
fi
scan "after WM start"
echo

echo "=== [5] relaunch with WM present, no --disable-gpu ==="
pkill -9 -f chrome.exe 2>/dev/null; sleep 3
rm -rf /root/winelab/cd_wm 2>/dev/null
setsid nohup wine "$EXE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1200,700 --window-position=30,30 \
  --user-data-dir='C:\cd_wm' --new-window "about:blank" \
  >"$OUT/wm.log" 2>&1 &
sleep 22
scan "with WM, gpu on"
echo

echo "=== [6] screenshot $DISP ==="
command -v import >/dev/null && import -display $DISP -window root "$OUT/lab10.png" 2>/dev/null \
  && cp "$OUT/lab10.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-lab10.png" \
  && echo "  saved results/wine-lab10.png"
