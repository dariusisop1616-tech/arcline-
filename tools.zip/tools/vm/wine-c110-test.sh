#!/bin/bash
# Does milestone 110 (pre-DirectComposition-default) map its window under Wine?
# The control run is Wine's own notepad: it maps fine, which is what told us the failure
# is Chrome-specific and not Wine's X11 driver in general. Keep that control here.
export DISPLAY=:9
W=/root/winelab
OLD="$W/old"
EXE=$(find "$OLD/c110" -maxdepth 3 -name chrome.exe | head -1)
OUT="$W/out"
mkdir -p "$OUT"

echo "### exe: ${EXE:-MISSING}"
[ -z "$EXE" ] && { echo "NO EXE - run fetch-chromium-110.sh first"; exit 1; }
echo "### wine: $(wine --version 2>/dev/null)"
echo

scan() {  # scan <label>
  echo "--- windows on :9 ($1) ---"
  local any=0
  for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -40); do
    info=$(xwininfo -id "$w" 2>/dev/null)
    geo=$(echo "$info" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
    nm=$(echo "$info" | grep -oE '"[^"]*"' | head -1)
    st=unmapped
    echo "$info" | grep -q 'IsViewable' && st=MAP
    # report every non-trivial window, plus anything wine-ish
    if [ "$st" = MAP ] || echo "$nm" | grep -qiE 'chrome|chromium|notepad|wine'; then
      printf '  %-4s %-12s %-34s %s\n' "$st" "$w" "$geo" "$nm"
      any=1
    fi
  done
  [ "$any" = 0 ] && echo "  (nothing)"
  echo "  chrome.exe procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)   wine procs: $(pgrep -fc 'wine' 2>/dev/null || echo 0)"
  echo
}

echo "=== [0] control: wine notepad - does Wine map its own window at all? ==="
pkill -9 -f notepad.exe 2>/dev/null
setsid nohup wine notepad >"$OUT/c110-notepad.log" 2>&1 &
sleep 8
scan "control"
pkill -9 -f notepad.exe 2>/dev/null
sleep 2
echo

echo "=== [1] purge stale wine state, then launch milestone 110 ==="
pkill -9 -f chrome.exe 2>/dev/null
pkill -9 -f wineserver 2>/dev/null
sleep 3
rm -rf "$W/cd_c110" 2>/dev/null
setsid nohup wine "$EXE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-features=CalculateNativeWinOcclusion \
  --window-size=1200,700 --window-position=40,60 \
  --user-data-dir='C:\cd_c110' --new-window "about:blank" \
  >"$OUT/c110.log" 2>&1 &
echo "  launched, pid $!"
sleep 25
scan "c110"
echo "  --- log tail ---"
tail -20 "$OUT/c110.log" 2>/dev/null | sed 's/^/  /'
echo

echo "=== [2] screenshot whatever is there ==="
if command -v import >/dev/null 2>&1; then
  import -window root "$OUT/c110.png" 2>/dev/null \
    && cp "$OUT/c110.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-c110.png" \
    && echo "  saved: results/wine-c110.png"
fi
