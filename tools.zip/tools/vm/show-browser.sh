#!/bin/bash
# Give the user a VISIBLE, NAVIGABLE browser on the display, right now.
#
# This is native Linux Chrome for Testing - the same binary the driver socket was
# proven on. It is launched with --use-angle=vulkan so it renders through the EXTERNAL
# Mesa lavapipe driver (lvp_icd.json) instead of Chrome's own bundled SwiftShader.
# That is the whole architecture: browser untouched, driver underneath is ours to replace.

export LC_ALL=C.UTF-8
LAB="$HOME/linuxlab"
[ -x "$LAB/chrome/chrome" ] || LAB="$HOME/winelab/linuxchrome"
CHROME="$LAB/chrome/chrome"
export DISPLAY=:9
export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe

REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT="$REPO/results/vm-display"
mkdir -p "$OUT" "$LAB/out" "$LAB/cd_show"
cp "$REPO/tools/show-gpu.html" "$LAB/show.html" 2>/dev/null

echo "chrome binary : $CHROME"
[ -x "$CHROME" ] || { echo "MISSING"; exit 1; }
echo "vk driver     : $VK_ICD_FILENAMES"

pkill -f "$LAB/chrome/chrome" 2>/dev/null
pkill -f chrome.exe 2>/dev/null
sleep 2

"$CHROME" \
  --no-sandbox --disable-dev-shm-usage \
  --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1360,820 --window-position=20,20 \
  --user-data-dir="$LAB/cd_show" \
  "file://$LAB/show.html" >"$LAB/out/show.log" 2>&1 &

echo "waiting for the window..."
for i in $(seq 1 30); do
  sleep 2
  w=$(xwininfo -root -tree 2>/dev/null | grep -i 'chrome' | grep -E '[0-9]{3,}x[0-9]{3,}' | head -1)
  if [ -n "$w" ]; then echo "  window after $((i*2))s: $w"; break; fi
done
echo "  procs: $(pgrep -fc "$LAB/chrome/chrome" 2>/dev/null || echo 0)"

# is it actually viewable now?
for id in $(xwininfo -root -tree 2>/dev/null | grep -i 'chrome' | grep -oE '0x[0-9a-f]+' | sort -u); do
  ms=$(xwininfo -id "$id" 2>/dev/null | grep -i 'Map State' | head -1 | awk '{print $NF}')
  wh=$(xwininfo -id "$id" 2>/dev/null | grep -E '^  Width|^  Height' | awk '{print $2}' | tr '\n' 'x')
  echo "  $id map=$ms size=$wh"
done

import -window root -display :9 "$OUT/live_browser.png" 2>/dev/null \
  && echo "  shot: results/vm-display/live_browser.png"

echo
echo ">>> LOOK AT YOUR VNC WINDOW NOW (workspace 1): http://localhost:6080/vnc.html"
echo ">>> keeping it open"

# keep it alive and keep refreshing the proof shot
for i in $(seq 1 120); do
  sleep 30
  import -window root -display :9 "$OUT/live_browser.png" 2>/dev/null
  # if it died, say so instead of pretending
  p=$(pgrep -fc "$LAB/chrome/chrome" 2>/dev/null || echo 0)
  [ "$p" = "0" ] && { echo "browser exited at $((i*30))s"; break; }
done
