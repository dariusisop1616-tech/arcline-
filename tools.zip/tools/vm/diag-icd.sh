#!/bin/bash
echo "== lvp ICD exports (vk_icd / instance entry points) =="
nm -D /usr/lib/x86_64-linux-gnu/libvulkan_lvp.so 2>/dev/null | grep " T " | grep -E "vk_icd|vkCreateInstance|vkEnumerateInstance|vkGetInstanceProcAddr|vkGetPhysicalDeviceProcAddr"
echo
echo "== which Edge process maps libvulkan_lvp =="
for p in $(pgrep -f msedge); do
  if grep -q libvulkan_lvp /proc/$p/maps 2>/dev/null; then
    echo "pid $p ($(tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null | cut -c1-60))"
  fi
done
GP=$(pgrep -f "type=gpu-process" | head -1)
echo
echo "== host loader mapped in gpu process $GP? =="
grep -c "libvulkan.so.1" /proc/$GP/maps 2>/dev/null || echo "no gpu proc"