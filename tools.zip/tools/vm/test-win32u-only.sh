#!/bin/bash
# Single-variable test: is the win32u.so string patch really what breaks Edge?
# Previous run was blind (poll only matched the post-WebGL title). This one
# observes EVERYTHING: full window list, process counts, log tail, every 4s.
export DISPLAY=:9
export PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml="
export WINEDEBUG="-all"
OUT=/root/winelab/out
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
WT=/opt/wine-staging/lib/wine/x86_64-unix/win32u.so

restore() { for F in \
  /opt/wine-staging/lib/wine/x86_64-unix/win32u.so \
  /opt/wine-staging/lib/wine/x86_64-windows/wined3d.dll \
  /opt/wine-staging/lib/wine/i386-windows/wined3d.dll; do
  B="$F.orig-rx480"; [ -f "$B" ] && cp -a "$B" "$F.t" && mv -f "$F.t" "$F"
done; }
kill_wine() { wineserver -k 2>/dev/null; sleep 1; pkill -9 -x wineserver 2>/dev/null; pkill -9 -f msedge 2>/dev/null; sleep 2; }
launch_edge() {
  rm -rf /root/.wine/drive_c/t13 2>/dev/null
  wine reg add "HKCU\\Software\\Wine\\Direct3D" /v "VideoDescription_1002_67df" \
    /t REG_SZ /d "Radeon (TM) RX 580 Series" /f >/dev/null 2>&1
  ( export VK_DRIVER_FILES="/root/vkicd/rx580_icd.json" \
      VK_ICD_FILENAMES="/root/vkicd/rx580_icd.json" RX580_LOG=1
    setsid nohup wine "$EDGE" \
      --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
      --disable-sync --disable-component-update --renderer-process-limit=1 \
      --use-angle=vulkan --window-size=1200,700 --window-position=60,60 \
      --user-data-dir='C:\t13' --new-window \
      "file:///Z:/root/linuxlab/rx580-check.html#rx580" >"$OUT/edge11.log" 2>&1 & )
}
poll() { # $1 = label, $2 = seconds
  for i in $(seq 1 $(( $2 / 4 ))); do
    t=$(wmctrl -l 2>/dev/null | grep -iE "microsoft|identity|rx580" | tail -1 | cut -c1-240)
    echo "  [poll $((i*4))s] procs=$(pgrep -fc msedge 2>/dev/null || echo 0) win=${t:-NONE}"
    case "$t" in *RX580CHECK*) return 0 ;; esac
    sleep 4
  done
  return 1
}

echo "== A) baseline restore, kill wine, launch UNPATCHED =="
restore; kill_wine
launch_edge
if poll 100; then echo "  >>> A OK (unpatched maps)"; else echo "  >>> A FAILED - environment issue, aborting"; exit 1; fi

echo
echo "== B) kill wine, patch ONLY win32u.so (atomic), relaunch =="
kill_wine
cp -a "$WT.orig-rx480" "$WT.t"
python3 - "$WT.t" <<'EOF'
import sys
f = sys.argv[1]
d = bytearray(open(f,'rb').read())
n = d.count(b"Radeon (TM) RX 480 Graphics")
open(f,'wb').write(d.replace(b"Radeon (TM) RX 480 Graphics", b"Radeon (TM) RX 580 Series\x00\x00"))
print(f"  patched {n} in win32u.so (atomic)")
EOF
mv -f "$WT.t" "$WT"
launch_edge
if poll 120; then
  echo "  >>> B OK: win32u.so patch does NOT break Edge"
  echo "  >>> final title:"; wmctrl -l 2>/dev/null | grep rx580 | cut -c1-260
else
  echo "  >>> B FAILED: win32u.so patch breaks Edge -> reverting to baseline"
  kill_wine; restore
  launch_edge
  poll 100 && echo "  >>> baseline restored (480)" || echo "  >>> baseline STILL broken!"
fi