#!/bin/bash
# Only revisions whose Win_x64 build succeeded are in the bucket, and they are spaced
# irregularly (~25-30 apart). So find the highest revision that actually exists at or
# below the M110 stable branch position (1084008), then confirm its zip.
set -u
B=https://commondatastorage.googleapis.com/chromium-browser-snapshots
OUT=/root/winelab/old
mkdir -p "$OUT"

list_revs() {  # list_revs <prefix>
  curl -s --max-time 25 "$B?prefix=Win_x64/$1&delimiter=/&max-keys=1000" \
    | grep -oE '<Prefix>Win_x64/[0-9]+/</Prefix>' \
    | grep -oE '[0-9]{7}' | sort -n | uniq
}

echo "=== revisions that exist, by leading digits ==="
for p in 105 106 107 108; do
  revs=$(list_revs "$p")
  n=$(echo "$revs" | grep -c . || echo 0)
  echo "  Win_x64/$p* : $n revisions"
  echo "$revs" | sed 's/^/    /'
done > "$OUT/revs.txt" 2>&1
sed -n '1,60p' "$OUT/revs.txt"
echo

echo "=== highest revision <= 1084008 (that is milestone 110) ==="
best=$(cat "$OUT/revs.txt" | grep -oE '^    [0-9]{7}$' | tr -d ' ' | sort -n | awk '$1<=1084008' | tail -1)
echo "  candidate: ${best:-none}"

echo
echo "=== does its archive exist? ==="
for cand in "$best" 1058933 1060000; do
  [ -z "$cand" ] && continue
  for name in chrome-win.zip chrome-win32.zip; do
    url="$B/Win_x64/$cand/$name"
    printf '  %-7s %-16s -> ' "$cand" "$name"
    curl -sI --max-time 20 "$url" | head -1 | tr -d '\r'
  done
done

echo
echo "=== for the winner, list the directory contents ==="
if [ -n "$best" ]; then
  curl -s --max-time 25 "$B?prefix=Win_x64/$best/&max-keys=50" \
    | grep -oE '<Key>[^<]*</Key>' | sed 's/^/  /'
fi
