#!/bin/bash
# Wine's Windows Chrome creates a real top-level window (0x2800005, 1192x726) but the
# earlier finding was that it never maps. Hypothesis worth testing now, which the RX 580
# work enables: Chrome does not map its window until the compositor can produce a frame.
# If the GPU process never comes up, the window stays unmapped forever.
#
# Previous attempts used --use-angle=d3d11 (crashed) and --use-angle=gl (WGL_NV_DX_interop2
# missing). The one combination never tried is --use-angle=vulkan, which routes through
# Wine's Vulkan -> external lavapipe, and which today proved to be the working backend.
export DISPLAY=:9
W=/root/winelab
EXE="$W/chrome/chrome.exe"

state() {  # state <label>
  echo "--- $label ---"
  for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]+ "Untitled[^"]*"' | grep -oE '^0x[0-9a-f]+'); do
    echo "  window $w:"
    xwininfo -id "$w" 2>/dev/null | grep -E 'Map State|Width|Height|Absolute upper-left' | sed 's/^/    /'
  done
  echo "  chrome.exe procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
}

kill_wine() { pkill -9 -f chrome.exe 2>/dev/null; sleep 3; }

echo "=== [A] current run: what is the map state of that window? ==="
state "default flags (as launched)"
echo

echo "=== [B] relaunch with --use-angle=vulkan (Wine Vulkan -> external lavapipe) ==="
kill_wine
rm -rf "$W/cd_vk" 2>/dev/null
VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json \
setsid nohup wine "$EXE" \
  --no-sandbox --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1200,760 --window-position=60,80 \
  --user-data-dir='C:\cd_vk' --new-window "about:blank" \
  >"$W/out/vk.log" 2>&1 &
sleep 22
state "with --use-angle=vulkan"
echo "  GL/vulkan errors: $(grep -icE 'vulkan|egl|gl_' "$W/out/vk.log" 2>/dev/null)"
echo

echo "=== [C] relaunch with --disable-gpu (can it paint at all in software?) ==="
kill_wine
rm -rf "$W/cd_nogpu" 2>/dev/null
setsid nohup wine "$EXE" \
  --no-sandbox --disable-gpu \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1200,760 --window-position=60,80 \
  --user-data-dir='C:\cd_nogpu' --new-window "about:blank" \
  >"$W/out/nogpu.log" 2>&1 &
sleep 22
state "with --disable-gpu"
echo

echo "=== [D] screenshot of whatever is up ==="
command -v import >/dev/null && import -window root "$W/out/wine-state.png" 2>/dev/null \
  && cp "$W/out/wine-state.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-chrome-state.png" \
  && echo "  saved results/wine-chrome-state.png"
echo
echo "=== [E] all mapped (IsViewable) windows ==="
for w in $(xwininfo -root -children 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -25); do
  xwininfo -id "$w" 2>/dev/null | grep -q 'IsViewable' && \
    echo "  $w : $(xwininfo -id "$w" 2>/dev/null | grep -oE '"[^"]*"' | head -1) $(xwininfo -id "$w" 2>/dev/null | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)"
done
