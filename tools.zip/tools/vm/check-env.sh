#!/bin/bash
# What does the WSL-side lab actually have right now?
echo "=== screenshot / window tools ==="
for t in xdotool xwininfo xlsclients import xwd convert scrot; do
  p=$(command -v "$t" 2>/dev/null)
  if [ -n "$p" ]; then printf '%-10s %s\n' "$t" "$p"; else printf '%-10s MISSING\n' "$t"; fi
done

echo
echo "=== wine prefix: dxgi / d3d overrides ==="
P="$HOME/winelab/prefix/drive_c/windows/system32"
ls -la "$P/dxgi.dll" 2>/dev/null || echo "  dxgi.dll: stock (no override)"
ls "$P" | grep -iE 'dxgi|d3d1' | sed 's/^/  /'

echo
echo "=== wine GPU-name db override state ==="
grep -rn 'GTX 470\|GTX470' "$HOME/winelab/prefix" 2>/dev/null | head -5 || echo "  (none found in prefix)"

echo
echo "=== wine version ==="
wine --version 2>&1

echo
echo "=== any leftover display servers / browsers ==="
pgrep -fa 'Xvfb|x11vnc|websockify|fluxbox' | sed 's/^/  /' || echo "  none"
pgrep -fc chrome.exe 2>/dev/null | sed 's/^/  chrome.exe procs: /' || echo "  chrome.exe procs: 0"
