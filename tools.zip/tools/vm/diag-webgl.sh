#!/bin/bash
# The window title carries the WebGL result, so it can be read with wmctrl - no pixels,
# no devtools. Compare: does the preload break WebGL, or was it already broken?
LAB=/root/linuxlab
DIR=/root/vklayer
CHROME="$LAB/chrome/chrome"
export DISPLAY=:9
PAGE="file://$LAB/rx580-check.html"

launch() {  # launch <tag> <extra flags...> ; PRELOAD set by caller
  local tag="$1"; shift
  pkill -f "cd_$tag" 2>/dev/null
  sleep 1
  env LD_PRELOAD="$PRELOAD" RX580_LOG=1 \
      VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json \
      setsid nohup "$CHROME" \
        --no-sandbox --disable-dev-shm-usage \
        --no-first-run --no-default-browser-check \
        --window-size=1200,700 --window-position=60,80 \
        --user-data-dir="$LAB/cd_$tag" \
        --enable-logging=stderr --v=1 \
        "$@" "$PAGE" >"$LAB/out/$tag.log" 2>&1 &
  sleep 11
}

title() {
  wmctrl -l 2>/dev/null | grep -o 'RX580CHECK[^|]*\(|[^|]*\)\{0,6\}' | head -1 \
    || echo "(no RX580CHECK window)"
}

echo "############ V1: preload, --use-angle=vulkan ############"
PRELOAD="$DIR/libvk_rx580_preload.so"
launch v1 --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist
echo "TITLE: $(title)"
echo "GL errors in log:"
grep -iE 'vulkan|angle|swiftshader|gl_?init|Failed to create' "$LAB/out/v1.log" | head -6
echo

echo "############ V2: NO preload, --use-angle=vulkan ############"
PRELOAD=""
launch v2 --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist
echo "TITLE: $(title)"
echo

echo "############ V3: preload, vulkan + gpu sandbox off + verbose GPU ############"
PRELOAD="$DIR/libvk_rx580_preload.so"
launch v3 --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist \
          --disable-gpu-sandbox
echo "TITLE: $(title)"
echo "GL errors in log:"
grep -iE 'vulkan|angle|swiftshader|gl_?init|Failed to create|device' "$LAB/out/v3.log" | head -8
echo

echo "############ interposer call counts (V3) ############"
sort /tmp/rx580_preload.log 2>/dev/null | uniq -c
