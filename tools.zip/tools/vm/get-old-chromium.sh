#!/bin/bash
# Chrome started presenting its window through DirectComposition by default in Chrome 111
# (March 2023), and Wine does not implement it - DCompositionCreateDevice3 returns
# "Not implemented". Wine's own notepad maps fine, so this is a Chrome-vs-Wine limitation.
# A Windows Chrome/Chromium from before that switch should map with the plain X11 driver.
#
# Chrome for Testing only goes back to 113, so this pulls a raw Chromium snapshot instead,
# which goes much further back. chromiumdash gives the revision for a milestone.
set -u
W=/root/winelab
OUT="$W/old"

echo "=== [1] clear the stuck Wine runs ==="
pkill -9 -f 'bash /root/wdm.sh' 2>/dev/null
pkill -9 -f chrome.exe 2>/dev/null
pkill -9 -f wineserver 2>/dev/null
sleep 3
echo "  stuck scripts: $(pgrep -fc 'wdm.sh' 2>/dev/null || echo 0)"
echo "  chrome.exe   : $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
echo

echo "=== [2] can we reach the network? ==="
curl -s -o /dev/null -w '  chromiumdash http %{http_code}\n' --max-time 15 \
  "https://chromiumdash.appspot.com/fetch_milestones" || echo "  (no network)"
echo

echo "=== [3] find revisions for milestones 108-110 ==="
mkdir -p "$OUT"
for ms in 108 109 110; do
  json=$(curl -s --max-time 20 \
    "https://chromiumdash.appspot.com/fetch_releases?platform=Windows&channel=Stable&milestone=$ms&num=1" 2>/dev/null)
  ver=$(echo "$json" | grep -oE '"version": *"[^"]*"' | head -1 | grep -oE '[0-9][^"]*')
  rev=$(echo "$json" | grep -oE '"chromium_main_branch_position": *[0-9]+' | head -1 | grep -oE '[0-9]+')
  echo "  milestone $ms : version=${ver:-?} revision=${rev:-?}"
  [ -n "${rev:-}" ] && echo "$rev" > "$OUT/rev_$ms.txt"
done
echo

echo "=== [4] candidate download URLs ==="
for ms in 110 109 108; do
  r=$(cat "$OUT/rev_$ms.txt" 2>/dev/null)
  [ -z "$r" ] && continue
  url="https://commondatastorage.googleapis.com/chromium-browser-snapshots/Win_x64/$r/chrome-win.zip"
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 -r 0-100 "$url" 2>/dev/null)
  echo "  ms$ms rev$r -> http $code"
  echo "  $url" >> "$OUT/urls.txt"
done
sort -u "$OUT/urls.txt" -o "$OUT/urls.txt" 2>/dev/null
echo
echo "=== urls saved to $OUT/urls.txt ==="
cat "$OUT/urls.txt" 2>/dev/null | sed 's/^/  /'
