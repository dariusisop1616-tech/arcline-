#!/bin/bash
# WineHQ publishes for this distro (suite "resolute"), so a newer Wine than Ubuntu's 10.0 is
# installable - and WineHQ has been actively fixing Chromium window handling. Add the repo and
# see what versions are on offer before installing anything.
set -u
. /etc/os-release
SUITE="${VERSION_CODENAME:-resolute}"
echo "=== [1] probe the WineHQ Packages index for suite '$SUITE' ==="
BASE="https://dl.winehq.org/wine-builds/ubuntu/dists/$SUITE/main/binary-amd64"
for f in Packages Packages.gz Packages.xz; do
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 25 "$BASE/$f")
  echo "  $f -> http $code"
done
echo

echo "=== [2] available winehq-staging / winehq-devel versions ==="
for f in Packages.gz Packages.xz Packages; do
  data=$(curl -s --max-time 40 "$BASE/$f" 2>/dev/null)
  case "$f" in
    *.gz)  data=$(curl -s --max-time 40 "$BASE/$f" | gunzip 2>/dev/null) ;;
    *.xz)  data=$(curl -s --max-time 40 "$BASE/$f" | xz -dc 2>/dev/null) ;;
  esac
  if [ -n "$data" ]; then
    echo "  (from $f)"
    echo "$data" | awk '/^Package: winehq-staging$/{p=1} p&&/^Version:/{print "    winehq-staging "$2; p=0}' | head -3
    echo "$data" | awk '/^Package: winehq-devel$/{p=1} p&&/^Version:/{print "    winehq-devel   "$2; p=0}' | head -3
    break
  fi
done
echo

echo "=== [3] add the repo ==="
mkdir -p /etc/apt/keyrings
if [ ! -f /etc/apt/keyrings/winehq-archive.key ]; then
  curl -fsSL --max-time 60 -o /etc/apt/keyrings/winehq-archive.key \
    https://dl.winehq.org/wine-builds/winehq.key \
    && echo "  key installed ($(stat -c%s /etc/apt/keyrings/winehq-archive.key) bytes)"
else
  echo "  key already present"
fi
echo "deb [signed-by=/etc/apt/keyrings/winehq-archive.key] https://dl.winehq.org/wine-builds/ubuntu/ $SUITE main" \
  > /etc/apt/sources.list.d/winehq.list
echo "  source: $(cat /etc/apt/sources.list.d/winehq.list)"
echo

echo "=== [4] apt update and policy ==="
apt-get update -o Dir::Etc::sourcelist=/etc/apt/sources.list.d/winehq.list \
               -o Dir::Etc::sourceparts=/dev/null \
               -o APT::Get::List-Cleanup=0 2>&1 | tail -6 | sed 's/^/  /'
echo
apt-cache policy winehq-staging winehq-devel wine-staging 2>/dev/null \
  | grep -E '^[a-z-]+:|Candidate:' | sed 's/^/  /'
echo
echo "=== [5] dependencies that may be missing for resolute ==="
apt-cache showpkg winehq-staging 2>/dev/null | sed -n '/Dependencies:/,/Provides:/p' | head -12 | sed 's/^/  /'
