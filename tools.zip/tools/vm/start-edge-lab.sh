#!/bin/bash
# Restart the whole lab after a WSL shutdown and put REAL WINDOWS EDGE on screen.
#
# Why: Wine 11.18 staging was the breakthrough - Chromium/Edge MAP their windows
# (Wine 10.0 created them but never mapped). This script rebuilds the display stack
# (Xvfb -> fluxbox -> x11vnc -> noVNC), launches Edge under Wine 11, proves the
# window is mapped, then supervises everything.
#
# Failure history, all measured 2026-09-27:
# - vmmem at the VM memory ceiling crashed the WSL service  -> .wslconfig 6GB+4GB swap
# - Edge's renderer under Wine reserves ~1.6TB virtual and gets OOM-killed at
#   window-map time (~t=10s) -> renderer-process-limit=1 + supervisor oom-protected
# - a stale /tmp/.X11-unix socket made the NEXT Xvfb fail to bind -> clean + verify
# - plain `&` daemons die with the driver script -> everything is setsid nohup
export LC_ALL=C.UTF-8
export DISPLAY=:9
export PATH="/opt/wine-staging/bin:$PATH"
# mscoree = Wine Mono installer prompt, mshtml = Gecko prompt. Edge needs neither,
# and the prompts block unattended startup.
export WINEDLLOVERRIDES="mscoree,mshtml="
export WINEDEBUG="-all"
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe

LAB=/root/winelab
OUT="$LAB/out"
mkdir -p "$OUT"
exec > >(tee -a "$OUT/lab.log") 2>&1
echo "########## lab start $(date) ##########"
# keep this supervisor alive through memory storms so it can revive the stack
echo -1000 > /proc/self/oom_score_adj 2>/dev/null
trap 'echo "### script EXITING line=$LINENO status=$? ###"' EXIT

REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUTDIR="$REPO/results/vm-display"
mkdir -p "$OUTDIR"

EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

shoot() { # screenshot the display, save into the repo results dir
  command -v import >/dev/null 2>&1 || return 1
  DISPLAY=:9 import -window root "$1" 2>/dev/null
}

clean_x_sockets() { # a killed Xvfb leaves a stale socket that blocks the next bind
  rm -f /tmp/.X11-unix/X9 /tmp/.X1-lock /tmp/.X9-lock 2>/dev/null
  chmod 1777 /tmp/.X11-unix 2>/dev/null
}

start_xvfb() { # start and VERIFY the display; retry once after a socket cleanup
  local tries=0
  while [ $tries -lt 3 ]; do
    if xdpyinfo >/dev/null 2>&1; then return 0; fi
    clean_x_sockets
    setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 &
    sleep 3
    if xdpyinfo >/dev/null 2>&1; then
      echo "    Xvfb up (try $((tries+1)))"
      return 0
    fi
    tries=$((tries+1))
  done
  echo "    Xvfb FAILED to start:"; tail -4 "$OUT/xvfb.log" | sed 's/^/      /'
  return 1
}

start_stack() { # start every daemon DETACHED; safe to call again (checks first)
  if ! xdpyinfo >/dev/null 2>&1; then
    start_xvfb || return 1
  fi
  pgrep -x fluxbox >/dev/null || {
    ( DISPLAY=:9 setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & )
    sleep 2
  }
  pgrep -x x11vnc >/dev/null || {
    ( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR PULSE_SERVER DISPLAY_WAYLAND
      setsid nohup x11vnc -display :9 -forever -shared -nopw -quiet -rfbport 5901 \
        -noxdamage -xkb -o "$OUT/x11vnc.log" >/dev/null 2>&1 & )
    sleep 2
  }
  pgrep -f websockify >/dev/null || {
    ( setsid nohup websockify --web=/usr/share/novnc 6080 localhost:5901 \
        >"$OUT/websockify.log" 2>&1 & )
    sleep 2
  }
}

start_edge() { # fresh profile; Vulkan backend: Wine's winevulkan reaches the HOST
  # loader, which we steer to our RX580 ICD wrapper (/root/vkicd - build-icd.sh).
  # The check page puts vendor/renderer in the window title -> readable via wmctrl.
  rm -rf /root/.wine/drive_c/t13 2>/dev/null
  # wined3d MUST run on Vulkan: that routes Wine's dxgi/GPUInfo through our ICD.
  # The gl backend leaks the host GPU, and test-rtx.sh flips it to gl - reset it.
  wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d vulkan /f >/dev/null 2>&1
  ( export DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH" \
      WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all" \
      VK_DRIVER_FILES="/root/vkicd/rx580_icd.json" \
      VK_ICD_FILENAMES="/root/vkicd/rx580_icd.json" RX580_LOG=1
    setsid nohup wine "$EDGE" \
      --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
      --disable-sync --disable-component-update \
      --renderer-process-limit=1 \
      --use-angle=vulkan \
      --window-size=1200,700 --window-position=60,60 \
      --user-data-dir='C:\t13' --new-window \
      "file:///Z:/root/linuxlab/rx580-check.html#rx580" >"$OUT/edge11.log" 2>&1 & )
}

echo "=== [0] clean slate ==="
# -9 everywhere: a TERM'd x11vnc prints "caught signal: 15" then HANGS in its
# shutdown path still holding :5901 (measured 2026-09-27) - every later restart
# fails with "could not obtain listening port". SIGKILL only.
pkill -9 -f 'Xvfb :9'   2>/dev/null
pkill -9 -x x11vnc      2>/dev/null
pkill -9 -f websockify  2>/dev/null
pkill -9 -x fluxbox     2>/dev/null
pkill -9 -f msedge      2>/dev/null
pkill -9 -f chrome.exe  2>/dev/null
rm -rf /root/.wine/drive_c/t14 2>/dev/null   # leftover d3d11 test profile
wineserver -k 2>/dev/null
sleep 3
clean_x_sockets

echo "=== [1] display stack, every daemon detached ==="
start_stack
echo "    Xvfb=$(pgrep -fc 'Xvfb :9') fluxbox=$(pgrep -xc fluxbox) x11vnc=$(pgrep -xc x11vnc) websockify=$(pgrep -fc websockify)"
(ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null) | grep -E ':6080|:5901' | sed 's/^/    /'

echo "=== [2] real Windows Edge 154 under Wine 11 ==="
echo "    wine: $(wine --version 2>/dev/null)"
start_edge

# probe every 2s via wmctrl - the WM's view IS the success criterion (mapped+managed),
# and the title carries the WebGL identity from rx580-check.html. The old xwininfo
# tree-grep hung the whole loop on a bogus 0x00000000 id: gone entirely.
prev=""
for i in $(seq 1 90); do
  line=$(wmctrl -l 2>/dev/null | grep -iE "microsoft|rx580check" | tail -1 | cut -c1-200)
  if [ -n "$line" ]; then cur="EDGE: $line"
  else cur="no-window procs=$(pgrep -fc msedge 2>/dev/null || echo 0) mem=$(free -m | awk 'NR==2{print $3}')MB"
  fi
  [ "$cur" != "$prev" ] && printf '    t=%-3ss %s\n' "$((i*2))" "$cur"
  prev="$cur"
  case "$cur" in *RX580CHECK*) echo "    >>> WEBGL IDENTITY IN TITLE at t=$((i*2))s"; break;; esac
  sleep 2
done

echo "=== [3] map check: the WM's managed windows (title = WebGL identity) ==="
wmctrl -lp 2>/dev/null | cut -c1-220 | sed 's/^/    /'

echo "=== [4] screenshot NOW ==="
sleep 4
if shoot "$OUTDIR/edge-live.png"; then
  echo "    saved results/vm-display/edge-live.png ($(stat -c%s "$OUTDIR/edge-live.png" 2>/dev/null) bytes)"
else
  echo "    capture FAILED"
fi

echo
echo "==================================================================="
echo ">>> OPEN IN YOUR WINDOWS BROWSER:  http://localhost:6080/vnc.html"
echo ">>> click 'Connect' - no password. Real Windows Edge under Wine 11."
echo "==================================================================="

# supervisor: revive anything that dies, keep a rolling capture, hold WSL open
for i in $(seq 1 240); do
  sleep 60
  dmesg 2>/dev/null | grep -iE 'oom|killed process' | tail -2 \
    | sed 's/^/    [kernel] /'
  live="Xvfb=$(pgrep -fc 'Xvfb :9') fluxbox=$(pgrep -xc fluxbox) x11vnc=$(pgrep -xc x11vnc) websockify=$(pgrep -fc websockify) edge=$(pgrep -fc msedge 2>/dev/null || echo 0)"
  mem=$(free -m | awk 'NR==2{printf "%s/%sMB", $3, $2}')
  echo "[sup $i] $(date +%H:%M:%S) mem=$mem $live"
  # process liveness is NOT health: x11vnc once sat wedged (accept backlog
  # full, no RFB answer) while pgrep happily counted it. Probe the protocol.
  rfb=$(timeout 2 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 7 <&3' 2>/dev/null)
  case "$rfb" in
    RFB*) : ;;
    *) echo "    -> x11vnc alive but not serving (no RFB banner); kill -9 + restart"
       pkill -9 -x x11vnc 2>/dev/null; sleep 1
       ( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR
         setsid nohup x11vnc -display :9 -forever -shared -nopw -quiet -rfbport 5901 \
           -noxdamage -xkb -o "$OUT/x11vnc.log" >/dev/null 2>&1 & ) ;;
  esac
  case "$live" in
    *Xvfb=0*)
      echo "    -> display lost; restarting the whole stack"
      pkill -x fluxbox 2>/dev/null; pkill -x x11vnc 2>/dev/null
      start_stack ;;
    *fluxbox=0*|*x11vnc=0*|*websockify=0*)
      echo "    -> restarting dead stack parts"; start_stack ;;
    *edge=0*)
      echo "    -> Edge died; relaunching"; start_edge ;;
  esac
  shoot "$OUTDIR/edge-live.png"
done
echo "4h elapsed - relaunch to continue."