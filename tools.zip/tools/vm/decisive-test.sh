#!/bin/bash
# Decisive test on the two remaining unknowns:
#   1. Is the file URL even valid inside Wine?  (check with winepath)
#   2. Exactly the variant-D flags, long wait, real map state, real screenshot.
export LC_ALL=C.UTF-8
LAB="$HOME/winelab"
export WINEPREFIX="$LAB/prefix"
export WINEDEBUG="-all"
export PATH="$PATH:/usr/lib/x86_64-linux-gnu/wine"
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe
export DISPLAY=:9

REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT="$REPO/results/vm-display"
mkdir -p "$OUT" "$LAB/out"
pkill -x xmessage 2>/dev/null

echo "=== [1] does the page file exist and what is its Windows path? ==="
ls -la "$LAB/show.html"
winepath -w "$LAB/show.html" 2>/dev/null | sed 's/^/  winepath: /'

echo
echo "=== [2] is the wine Z: drive mapped to / ? ==="
ls -la "$LAB/prefix/dosdevices/" 2>/dev/null | grep -E '^l' | sed 's/^/  /'

echo
echo "=== [3] launching exactly variant D, waiting 60s ==="
pkill -f chrome.exe 2>/dev/null; sleep 3
wine "$LAB/chrome/chrome.exe" \
  --no-sandbox --disable-dev-shm-usage \
  --use-gl=angle --use-angle=gl --ignore-gpu-blocklist \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1280,800 --window-position=20,20 \
  --user-data-dir="$LAB/cd_decisive" \
  "file:///Z:/root/winelab/show.html" >"$LAB/out/dec.log" 2>&1 &
sleep 60

echo "--- chrome.exe procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
echo "--- FULL window tree, chrome/wine only:"
xwininfo -root -tree 2>/dev/null | grep -iE 'chrome' | sed 's/^/    /'
echo "--- map state of each chrome window:"
for id in $(xwininfo -root -tree 2>/dev/null | grep -i 'chrome' | grep -oE '0x[0-9a-f]+' | sort -u); do
  st=$(xwininfo -id "$id" 2>/dev/null | grep -i 'Map State' | head -1)
  geo=$(xwininfo -id "$id" 2>/dev/null | grep -iE 'Width:|Height:' | tr '\n' ' ')
  echo "    $id  $st  $geo"
done
echo "--- taskbar/root children that are viewable:"
xwininfo -root -tree 2>/dev/null | grep -E '[0-9]+x[0-9]+\+' | grep -viE '1x1|2x2|113x2' | sed 's/^/    /' | head -12

echo "--- log:"
cat "$LAB/out/dec.log" 2>/dev/null | grep -viE 'alsa|pcm|conf' | tail -12 | sed 's/^/    /'

echo
echo "=== [4] screenshot ==="
import -window root -display :9 "$OUT/decisive.png" 2>/dev/null \
  && echo "    results/vm-display/decisive.png ($(stat -c%s "$OUT/decisive.png") bytes)"

echo
echo "=== [5] does the page's own JS run? check the user-data-dir for a title ==="
find "$LAB/cd_decisive" -maxdepth 1 -name 'Current Tabs' -o -maxdepth 1 -name 'Last Tabs' 2>/dev/null | sed 's/^/    /'
echo "=== DONE ==="
