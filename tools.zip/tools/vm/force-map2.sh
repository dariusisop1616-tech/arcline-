#!/bin/bash
# Edge is now stable (7 procs, window tree alive for 44s+) but every window is IsUnMapped.
# That is Chromium's WS_EX_NOREDIRECTIONBITMAP window: Wine builds it but has no redirection
# surface, so it never maps. Earlier the force-map attempt ran after Edge had already died.
# Now that it survives, force-map the whole msedge window set and screenshot to see whether
# anything actually renders. If it renders, this is a usable workaround; if it is black,
# Wine fundamentally cannot present Chromium.
export DISPLAY=:9
W=/root/winelab
OUT="$W/out"
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 4
rm -rf "$W/t7" 2>/dev/null
setsid nohup wine "$EDGE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-sync --disable-component-update \
  --window-size=1200,700 --window-position=60,60 \
  --user-data-dir='C:\t7' --new-window "about:blank" >"$OUT/t7.log" 2>&1 &

echo "=== waiting for Edge windows ==="
for i in $(seq 1 15); do
  n=$(xwininfo -root -tree 2>/dev/null | grep -ci 'msedge\.exe')
  echo "  t=$((i*2))s msedge windows=$n procs=$(pgrep -fc msedge 2>/dev/null || echo 0)"
  [ "$n" -gt 2 ] && break
  sleep 2
done
echo

command -v xdotool >/dev/null || apt-get install -y xdotool >/dev/null 2>&1

echo "=== all msedge windows, with state before ==="
IDS=$(xwininfo -root -tree 2>/dev/null | grep -i 'msedge\.exe' | grep -oE '0x[0-9a-f]{4,}')
for w in $IDS; do
  st=$(xwininfo -id "$w" 2>/dev/null | grep -oE 'Map State: [A-Za-z]+' | head -1)
  geo=$(xwininfo -id "$w" 2>/dev/null | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
  printf '  %-12s %-24s %s\n' "$w" "$st" "$geo"
done
echo

echo "=== force-map every one of them ==="
# map the small ones first, then the content child, then the main window
for w in $IDS; do
  xdotool windowmap "$w" 2>&1 | sed "s/^/    $w: /"
done
sleep 3
echo "  --- state after ---"
for w in $IDS; do
  st=$(xwininfo -id "$w" 2>/dev/null | grep -oE 'Map State: [A-Za-z]+' | head -1)
  printf '  %-12s %s\n' "$w" "$st"
done
echo

echo "=== raise + screenshot ==="
for w in $IDS; do xdotool windowraise "$w" 2>/dev/null; done
sleep 2
command -v import >/dev/null && import -window root "$OUT/t7-mapped.png" 2>/dev/null \
  && cp "$OUT/t7-mapped.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-t7-mapped.png" \
  && echo "  saved results/wine-t7-mapped.png"
echo
echo "=== managed list (does the WM see them now?) ==="
wmctrl -lp 2>/dev/null | sed 's/^/  /'
echo
echo "=== edge still alive? ==="
echo "  procs=$(pgrep -fc msedge 2>/dev/null || echo 0)"
tail -6 "$OUT/t7.log" 2>/dev/null | sed 's/^/    /'
