#!/bin/bash
# What real-GPU plumbing does this WSL2 have? (RTX 3060 Ti via /dev/dxg)
# GL:     Mesa gallium "d3d12" driver  -> D3D12 -> /dev/dxg -> real GPU
# Vulkan: Mesa "dozen" (dzn) ICD       -> D3D12 -> /dev/dxg -> real GPU
export DISPLAY=:9
echo "== kernel side =="
ls -l /dev/dxg 2>&1
ls /usr/lib/wsl/lib 2>&1 | head -20
echo
echo "== Mesa / ICDs =="
dpkg -l | grep -E "mesa-vulkan|libgl1-mesa-dri|mesa-libgallium" | awk '{print $2, $3}'
ls /usr/share/vulkan/icd.d/ 2>&1
find / -xdev -name "libvulkan_dzn.so" 2>/dev/null | head
find / -xdev -name "d3d12_dri.so" -o -xdev -name "libgallium*.so" 2>/dev/null | head
echo
echo "== X up? =="
pgrep -a Xvfb | head -2
echo
echo "== GL on :9 with d3d12 =="
which glxinfo >/dev/null 2>&1 || echo "(no glxinfo - mesa-utils missing)"
GALLIUM_DRIVER=d3d12 glxinfo -B 2>&1 | grep -E "OpenGL (vendor|renderer|core profile version|version)|Accelerated|error" | head
echo
echo "== Vulkan with dzn =="
which vulkaninfo >/dev/null 2>&1 || echo "(no vulkaninfo)"
J=$(ls /usr/share/vulkan/icd.d/dzn_icd*.json 2>/dev/null | head -1)
echo "dzn json: ${J:-NONE}"
[ -n "$J" ] && VK_DRIVER_FILES="$J" vulkaninfo --summary 2>&1 | grep -E "deviceName|vendorID|deviceID|driverName|driverInfo|apiVersion|ERROR" | head
echo
echo "== Wine / free mem =="
free -m | head -2
pgrep -fc msedge
