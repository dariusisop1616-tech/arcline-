#!/bin/bash
# Wine's virtual desktop makes Wine own a real top-level window and reparent the app's
# window into it. That is the standard answer when an app's window is created but never
# mapped, so test it with Edge and the reliable detection (match the msedge.exe class).
export DISPLAY=:9
W=/root/winelab
OUT="$W/out"
EXE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

probe() {
  local tag="$1" line wid info map geo procs
  line=$(xwininfo -root -tree 2>/dev/null | grep -i 'msedge\.exe' | head -1)
  wid=$(echo "$line" | grep -oE '0x[0-9a-f]{4,}' | head -1)
  procs=$(pgrep -fc msedge 2>/dev/null || echo 0)
  if [ -n "$wid" ]; then
    info=$(xwininfo -id "$wid" 2>/dev/null)
    map=$(echo "$info" | grep -oE 'Map State: [A-Za-z]+' | head -1)
    geo=$(echo "$line" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
    printf '  %-12s procs=%-3s win=%s %s %s\n' "$tag" "$procs" "$wid" "$map" "$geo"
  else
    printf '  %-12s procs=%-3s NO msedge WINDOW IN TREE\n' "$tag" "$procs"
  fi
}

echo "=== [1] what did the earlier dcomp/dll probe find? ==="
echo "  dcomp.dll shipped by wine:"
find / -iname 'dcomp*' -path '*wine*' 2>/dev/null | head -5 | sed 's/^/    /'
echo

echo "=== [2] enable Wine virtual desktop, launch Edge inside it ==="
pkill -9 -f msedge 2>/dev/null; pkill -9 -f wineserver 2>/dev/null
pkill -9 -f explorer.exe 2>/dev/null
sleep 4
wine reg add "HKCU\\Software\\Wine\\Explorer" /v Desktop /d edge /f >/dev/null 2>&1
wine reg add "HKCU\\Software\\Wine\\Explorer\\Desktops" /v edge /d 1280x800 /f >/dev/null 2>&1
echo "  registry set: $(wine reg query 'HKCU\Software\Wine\Explorer' /v Desktop 2>/dev/null | grep Desktop | head -1)"
rm -rf "$W/m_vd" 2>/dev/null
setsid nohup wine "$EXE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-sync --disable-component-update \
  --window-size=1200,700 --user-data-dir='C:\m_vd' --new-window "about:blank" \
  >"$OUT/m_vd.log" 2>&1 &
for i in 1 2 3 4; do probe vdesk; sleep 5; done
echo

echo "=== [3] the Wine desktop window itself ==="
for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]{4,}' | head -40); do
  info=$(xwininfo -id "$w" 2>/dev/null) || continue
  case "$info" in *"Wine desktop"*|*explorer*) echo "  $w $(echo "$info" | grep -oE 'Map State: [A-Za-z]+' | head -1)";; esac
done
echo

echo "=== [4] managed + screenshot ==="
wmctrl -lp 2>/dev/null | grep -viE 'Chrome for Testing|RX580' | sed 's/^/  /'
command -v import >/dev/null && import -window root "$OUT/edge-vdesk.png" 2>/dev/null \
  && cp "$OUT/edge-vdesk.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-edge-vdesk.png" \
  && echo "  saved results/wine-edge-vdesk.png"
echo
echo "=== [5] log tail ==="
tail -12 "$OUT/m_vd.log" 2>/dev/null | sed 's/^/  /'
