#!/bin/bash
# Resume the Edge fetch: the enterprise view is a list of {Product, Releases}; the consumer
# view 404s and returns a dict, which made the first parser iterate string keys. Guard types.
set -u
W=/root/winelab
EDGE="$W/edge"
mkdir -p "$EDGE"

echo "=== [1] pick the newest stable Windows x64 MSI ==="
python3 - "$EDGE" <<'PY'
import json, sys, os
d = sys.argv[1]
cands = []
for view in ("enterprise", "consumer"):
    p = os.path.join(d, f"api-{view}.json")
    if not os.path.exists(p): continue
    try: data = json.load(open(p))
    except Exception as e:
        print(f"  {view}: unreadable ({e})"); continue
    if not isinstance(data, list):
        print(f"  {view}: not a product list - skipping"); continue
    for prod in data:
        if not isinstance(prod, dict): continue
        pname = str(prod.get("Product", "")).lower()
        print(f"  {view}: product={prod.get('Product')} releases={len(prod.get('Releases', []))}")
        if pname != "stable": continue
        for rel in prod.get("Releases", []):
            if not isinstance(rel, dict): continue
            ver = rel.get("ProductVersion", "?")
            for art in rel.get("Artifacts", []):
                if not isinstance(art, dict): continue
                if art.get("Platform") != "Windows": continue
                if "msi" not in str(art.get("ArtifactType", "")).lower(): continue
                arch = art.get("Architecture", "")
                if arch not in ("x64", "x86"): continue
                url = art.get("Location", "")
                if url:
                    cands.append((ver, arch, url))
if not cands:
    print("  NO MSI CANDIDATES"); raise SystemExit(1)
# newest version, x64 preferred
cands.sort(key=lambda c: (c[0], c[1] == "x64"), reverse=True)
ver, arch, url = cands[0]
print(f"\n  PICKED version={ver} arch={arch}")
print(f"  URL {url}")
open(os.path.join(d, "msi_url.txt"), "w").write(url + "\n")
open(os.path.join(d, "msi_ver.txt"), "w").write(ver + "\n")
PY
echo

echo "=== [2] download ==="
URL=$(cat "$EDGE/msi_url.txt" 2>/dev/null)
[ -z "$URL" ] && { echo "  no url"; exit 1; }
curl -L --retry 3 --max-time 1800 -o "$EDGE/edge.msi" "$URL" -w '  http %{http_code}  %{size_download} bytes\n'
ls -la "$EDGE/edge.msi" | sed 's/^/  /'
echo

echo "=== [3] extract MSI (do not install - Edge's custom actions do not survive Wine) ==="
command -v msiextract >/dev/null || apt-get install -y msitools >/dev/null 2>&1
rm -rf "$EDGE/x"; mkdir -p "$EDGE/x"
(cd "$EDGE/x" && msiextract "$EDGE/edge.msi" >/dev/null 2>&1)
echo "  files extracted: $(find "$EDGE/x" -type f 2>/dev/null | wc -l)"
EXE=$(find "$EDGE/x" -iname msedge.exe | head -1)
echo "  msedge.exe: ${EXE:-NOT FOUND}"
if [ -n "$EXE" ]; then
  echo "$EXE" > "$EDGE/exe.txt"
  echo "  --- where it landed ---"
  echo "  $(dirname "$EXE")"
  echo "  --- sibling binaries ---"
  ls "$(dirname "$EXE")" 2>/dev/null | head -14 | sed 's/^/    /'
fi
echo
echo "EDGE READY ver=$(cat "$EDGE/msi_ver.txt" 2>/dev/null) exe=${EXE:-none}"
