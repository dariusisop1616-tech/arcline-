#!/bin/bash
# Isolate ONE question: does the Wine browser actually put a WINDOW on the X display?
# The display (Xvfb :9 + x11vnc + noVNC) is already up and must stay up.
# We only test the browser here.

export LC_ALL=C.UTF-8
LAB="$HOME/winelab"
export WINEPREFIX="$LAB/prefix"
export WINEDEBUG="-all"
export PATH="$PATH:/usr/lib/x86_64-linux-gnu/wine"
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe
export DISPLAY=:9

REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT="$REPO/results/vm-display"
mkdir -p "$OUT" "$LAB/out"

# clear the wallpaper-error dialog that fluxbox leaves in the middle of the screen
pkill -x xmessage 2>/dev/null
xsetroot -solid '#101418' 2>/dev/null

probe() {
  local tag="$1"
  sleep 1
  local n_chrome n_win
  n_chrome=$(pgrep -fc chrome.exe 2>/dev/null)
  n_win=$(xwininfo -root -tree 2>/dev/null | grep -c '": (' )

  echo "  chrome.exe procs : ${n_chrome:-0}"
  echo "  X windows total  : $n_win"
  # show windows that are NOT the fluxbox desktop / taskbar
  xwininfo -root -tree 2>/dev/null \
    | grep -iE 'chrome|wine|Chrome_WidgetWin' | sed 's/^/    /' | head -8

  if command -v import >/dev/null 2>&1; then
    import -window root -display :9 "$OUT/try_$tag.png" 2>/dev/null \
      && echo "    shot: results/vm-display/try_$tag.png"
  fi
}

killall_chrome() {
  pkill -f chrome.exe 2>/dev/null
  sleep 3
}

echo "###############################################################"
echo "# CONTROL: can Wine map ANY window on :9?  (notepad)"
echo "###############################################################"
killall_chrome
wine notepad >"$LAB/out/notepad.log" 2>&1 &
sleep 10
xwininfo -root -tree 2>/dev/null | grep -iE 'notepad|wine' | sed 's/^/    /' | head -5
probe "control_notepad"
pkill -f notepad 2>/dev/null
sleep 2

echo
echo "###############################################################"
echo "# A: chrome, no GPU flags at all (pure software)"
echo "###############################################################"
killall_chrome
wine "$LAB/chrome/chrome.exe" \
  --no-sandbox --disable-dev-shm-usage --disable-gpu \
  --no-first-run --no-default-browser-check --disable-extensions \
  --disable-direct-composition \
  --window-size=1280,800 --window-position=20,20 \
  --user-data-dir="$LAB/cd_w_a" \
  "file:///Z:/root/winelab/show.html" >"$LAB/out/w_a.log" 2>&1 &
sleep 22
probe "A_nogpu"
tail -4 "$LAB/out/w_a.log" 2>/dev/null | sed 's/^/    [log] /'

echo
echo "###############################################################"
echo "# B: current flag set (d3d11 + in-process-gpu)"
echo "###############################################################"
killall_chrome
wine "$LAB/chrome/chrome.exe" \
  --no-sandbox --disable-dev-shm-usage \
  --disable-direct-composition --disable-gpu-compositing --in-process-gpu \
  --use-angle=d3d11 \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1280,800 --window-position=20,20 \
  --user-data-dir="$LAB/cd_w_b" \
  "file:///Z:/root/winelab/show.html" >"$LAB/out/w_b.log" 2>&1 &
sleep 22
probe "B_d3d11"
tail -4 "$LAB/out/w_b.log" 2>/dev/null | sed 's/^/    [log] /'

echo
echo "###############################################################"
echo "# C: d3d11 but WITHOUT the compositing overrides"
echo "###############################################################"
killall_chrome
wine "$LAB/chrome/chrome.exe" \
  --no-sandbox --disable-dev-shm-usage \
  --use-angle=d3d11 --ignore-gpu-blocklist \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1280,800 --window-position=20,20 \
  --user-data-dir="$LAB/cd_w_c" \
  "file:///Z:/root/winelab/show.html" >"$LAB/out/w_c.log" 2>&1 &
sleep 22
probe "C_plain_d3d11"
tail -4 "$LAB/out/w_c.log" 2>/dev/null | sed 's/^/    [log] /'

echo
echo "###############################################################"
echo "# D: software GL via Wine's own opengl32 (no ANGLE backend forced)"
echo "###############################################################"
killall_chrome
GALLIUM_DRIVER=llvmpipe LIBGL_ALWAYS_SOFTWARE=1 \
wine "$LAB/chrome/chrome.exe" \
  --no-sandbox --disable-dev-shm-usage \
  --use-gl=angle --use-angle=gl --ignore-gpu-blocklist \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1280,800 --window-position=20,20 \
  --user-data-dir="$LAB/cd_w_d" \
  "file:///Z:/root/winelab/show.html" >"$LAB/out/w_d.log" 2>&1 &
sleep 22
probe "D_angleGL"
tail -4 "$LAB/out/w_d.log" 2>/dev/null | sed 's/^/    [log] /'

echo
echo "=== every window on :9 right now (full tree) ==="
xwininfo -root -tree 2>/dev/null | head -30 | sed 's/^/  /'
echo "=== DONE ==="
