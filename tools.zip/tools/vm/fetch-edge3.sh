#!/bin/bash
# Resolve the Edge MSI URL (release-level Platform/Architecture, artifact is just a URL),
# download it, and extract it rather than installing - Edge's installer custom actions do
# not survive Wine, but the extracted tree runs msedge.exe directly.
set -u
EDGE=/root/winelab/edge
mkdir -p "$EDGE"

echo "=== [1] resolve the MSI url ==="
python3 "$EDGE/edge-msi-url.py" || python3 /root/edge-msi-url.py
echo

URL=$(cat "$EDGE/msi_url.txt" 2>/dev/null)
[ -z "$URL" ] && { echo "no url - stopping"; exit 1; }
echo "  url: $URL"
echo

echo "=== [2] download ==="
curl -L --retry 3 --max-time 1800 -o "$EDGE/edge.msi" "$URL" \
  -w '  http %{http_code}  %{size_download} bytes  %{speed_download} B/s\n'
ls -la "$EDGE/edge.msi" | sed 's/^/  /'
echo

echo "=== [3] extract the MSI ==="
command -v msiextract >/dev/null || apt-get install -y msitools >/dev/null 2>&1
rm -rf "$EDGE/x"; mkdir -p "$EDGE/x"
(cd "$EDGE/x" && msiextract "$EDGE/edge.msi" >/dev/null 2>&1)
echo "  files: $(find "$EDGE/x" -type f 2>/dev/null | wc -l)"
EXE=$(find "$EDGE/x" -iname msedge.exe | head -1)
echo "  msedge.exe: ${EXE:-NOT FOUND}"
if [ -n "$EXE" ]; then
  echo "$EXE" > "$EDGE/exe.txt"
  echo "  dir: $(dirname "$EXE")"
  ls "$(dirname "$EXE")" 2>/dev/null | head -15 | sed 's/^/    /'
fi
echo
echo "EDGE READY ver=$(cat "$EDGE/msi_ver.txt" 2>/dev/null) exe=${EXE:-none}"
