#!/bin/bash
# The Wine virtual desktop MAPS and PAINTS (proven: solid blue 1440x900 "lab - Wine Desktop").
# Now put Chrome inside it, using --use-angle=swiftshader (the backend that kept Chrome
# alive with 8 procs) and NOT --disable-gpu (which killed it).
# Watch proc count over time so we can see whether it survives.

export LC_ALL=C.UTF-8
LAB="$HOME/winelab"
export WINEPREFIX="$LAB/prefix"
export WINEDEBUG="-all"
export PATH="$PATH:/usr/lib/x86_64-linux-gnu/wine"
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe
export DISPLAY=:9

REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT="$REPO/results/vm-display"
mkdir -p "$OUT" "$LAB/out"
pkill -f chrome.exe 2>/dev/null; pkill -f msedge.exe 2>/dev/null; sleep 3

wine reg add 'HKCU\Software\Wine\Explorer' /v Desktop /d lab /f >/dev/null 2>&1
wine reg add 'HKCU\Software\Wine\Explorer\Desktops' /v lab /d 1440x900 /f >/dev/null 2>&1
echo "virtual desktop enabled"

wine "$LAB/chrome/chrome.exe" \
  --no-sandbox --disable-dev-shm-usage \
  --use-angle=swiftshader --ignore-gpu-blocklist \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1360,820 --window-position=20,20 \
  --user-data-dir="$LAB/cd_vdc" \
  'file:///Z:/root/winelab/show.html' >"$LAB/out/vdc.log" 2>&1 &

echo "watching chrome.exe process count:"
for i in $(seq 1 12); do
  sleep 5
  printf "  t=%02ds  chrome.exe=%s\n" "$((i*5))" "$(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
done

echo
echo "=== windows inside the wine desktop ==="
for id in $(xwininfo -root -tree 2>/dev/null | grep -iE 'chrome|explorer|wine' | grep -oE '0x[0-9a-f]+' | sort -u); do
  ms=$(xwininfo -id "$id" 2>/dev/null | grep -i 'Map State' | head -1 | awk '{print $NF}')
  wh=$(xwininfo -id "$id" 2>/dev/null | grep -E '^  Width|^  Height' | awk '{print $2}' | tr '\n' 'x')
  nm=$(xwininfo -id "$id" 2>/dev/null | grep -oP '(?<=")[^"]*(?=")' | head -1)
  echo "  $id  map=$ms size=$wh  \"$nm\""
done

echo
echo "=== screenshot ==="
import -window root -display :9 "$OUT/vdc.png" 2>/dev/null \
  && echo "  results/vm-display/vdc.png"
echo "=== log ==="
grep -viE 'alsa|pcm|conf' "$LAB/out/vdc.log" 2>/dev/null | tail -8 | sed 's/^/  /'
echo "=== DONE ==="
