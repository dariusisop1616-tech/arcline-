import json
d = json.load(open("/root/winelab/edge/api-enterprise.json"))
stable = [p for p in d if p.get("Product") == "Stable"][0]
rels = stable["Releases"]
print("release keys:", list(rels[0].keys()))
print("release count:", len(rels))
print("latest version:", rels[0].get("ProductVersion"))
for r in rels[:3]:
    arts = r.get("Artifacts", [])
    print("--- version %s : %d artifacts" % (r.get("ProductVersion"), len(arts)))
    for a in arts:
        print("    type=%s platform=%s arch=%s size=%s" % (
            a.get("ArtifactType"), a.get("Platform"),
            a.get("Architecture"), a.get("SizeInBytes")))
        print("      %s" % str(a.get("Location"))[:150])
