#!/bin/bash
# The classic chromium-browser-snapshots path 404'd. Confirm whether the bucket layout
# changed, whether the revision exists at all, and what the real zip name is.
set -u
B=https://commondatastorage.googleapis.com/chromium-browser-snapshots

echo "=== [1] does the bucket list at all? ==="
curl -s --max-time 20 "$B" | head -c 600
echo; echo

echo "=== [2] list platform prefixes ==="
curl -s --max-time 20 "$B?delimiter=/" | grep -oE '<Prefix>[^<]*</Prefix>' | head -20
echo

echo "=== [3] does revision 1084008 exist, and what is in it? ==="
curl -s --max-time 20 "$B?prefix=Win_x64/1084008/&delimiter=/" | head -c 900
echo; echo

echo "=== [4] HEAD the zip directly, no Range ==="
for u in \
  "$B/Win_x64/1084008/chrome-win.zip" \
  "$B/Win_x64/1084008/chrome-win32.zip" \
  "$B/Win_x64/1084008/mini_installer.exe" ; do
  printf '  %s\n    -> ' "${u##*/}"
  curl -sI --max-time 20 "$u" | head -1 || echo "(fail)"
done
echo

echo "=== [5] what does a recent, known-good revision look like? ==="
curl -s --max-time 20 "$B?prefix=Win_x64/&delimiter=/&max-keys=5" | grep -oE '<Prefix>[^<]*</Prefix>' | head -5
echo

echo "=== [6] LAST_CHANGE marker ==="
curl -s --max-time 20 "$B/Win_x64/LAST_CHANGE"; echo
