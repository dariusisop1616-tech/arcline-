#!/bin/bash
# apt rejected the key: "the file has an unsupported filetype" - the downloaded winehq.key is
# ASCII-armored, apt needs a binary keyring. Dearmor it, refresh, and show what is installable.
set -u
echo "=== [1] what is the key file? ==="
head -c 60 /etc/apt/keyrings/winehq-archive.key 2>/dev/null | sed 's/^/  /'
echo
echo "  looks armored: $(grep -c 'BEGIN PGP PUBLIC KEY BLOCK' /etc/apt/keyrings/winehq-archive.key 2>/dev/null)"
echo

echo "=== [2] dearmor it ==="
curl -fsSL --max-time 60 https://dl.winehq.org/wine-builds/winehq.key \
  | gpg --dearmor --yes -o /etc/apt/keyrings/winehq-archive.key 2>/dev/null
echo "  now: $(stat -c%s /etc/apt/keyrings/winehq-archive.key) bytes"
file /etc/apt/keyrings/winehq-archive.key 2>/dev/null | sed 's/^/  /'
echo

echo "=== [3] apt update ==="
apt-get update -o Dir::Etc::sourcelist=/etc/apt/sources.list.d/winehq.list \
               -o Dir::Etc::sourceparts=/dev/null -o APT::Get::List-Cleanup=0 2>&1 \
  | tail -8 | sed 's/^/  /'
echo

echo "=== [4] installable versions now ==="
apt-cache policy winehq-staging winehq-devel 2>/dev/null | grep -E '^[a-z-]+:|Candidate:' | sed 's/^/  /'
echo
echo "=== [5] what would installing staging do to the distro wine? ==="
apt-get install -s --install-recommends winehq-staging 2>&1 | tail -20 | sed 's/^/  /'
