#!/bin/bash
# The wined3d.dll ASCII entry was patched, but the WebGL string still shows
# "Radeon (TM) RX 480 Graphics" - so another copy of that string is being
# served somewhere. Scan every likely binary for the string, ASCII and UTF-16.
EDGE_DIR="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37"

echo "== ASCII scan (wine libs + edge app dir + host libs) =="
grep -rl --binary-files=text "Radeon (TM) RX 480 Graphics" \
  /opt/wine-staging/lib "$EDGE_DIR" /usr/lib/x86_64-linux-gnu 2>/dev/null | head -12

echo "== UTF-16LE scan (same roots) =="
python3 - <<'EOF'
import os
needle = "Radeon (TM) RX 480 Graphics".encode('utf-16-le')
roots = ["/opt/wine-staging/lib",
         "/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37",
         "/usr/lib/x86_64-linux-gnu"]
for root in roots:
    for dp, dn, fn in os.walk(root):
        for f in fn:
            p = os.path.join(dp, f)
            try:
                if os.path.getsize(p) > 300_000_000:
                    continue
                with open(p, 'rb') as fh:
                    if needle in fh.read():
                        print("WIDE:", p)
            except Exception:
                pass
EOF
echo "== scan done =="