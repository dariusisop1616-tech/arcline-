#!/bin/bash
# Patch Wine's GPU database string: "Radeon (TM) RX 480 Graphics" ->
# "Radeon (TM) RX 580 Series" inside wined3d.dll. 0x67DF is Polaris 10, which
# IS both cards, but the db only contains the 480 wording - and the registry
# has no VideoDescription override in this Wine build (checked 2026-09-27:
# only VideoPciVendorID/VideoPciDeviceID exist). The db entry is one
# NUL-terminated ASCII string, so an in-place same-length patch is safe.
# Wine is our layer (not the browser), so patching it is within the rules.
set -e
F=/opt/wine-staging/lib/wine/x86_64-windows/wined3d.dll
BAK="$F.orig-rx480"
OLD="Radeon (TM) RX 480 Graphics"
NEW="Radeon (TM) RX 580 Series"    # 25 chars; old is 27 -> pad with 2 NULs

if [ ! -f "$BAK" ]; then
  cp -a "$F" "$BAK"
  echo "backup: $BAK"
else
  echo "backup already exists: $BAK"
fi

python3 - "$F" <<'EOF'
import sys
f = sys.argv[1]
data = bytearray(open(f, 'rb').read())
old = b"Radeon (TM) RX 480 Graphics"
new = b"Radeon (TM) RX 580 Series\x00\x00"
assert len(old) == len(new), (len(old), len(new))
n = data.count(old)
print("occurrences found:", n)
if n:
    data = data.replace(old, new)
    open(f, 'wb').write(data)
    print("patched")
else:
    already = data.count(b"Radeon (TM) RX 580 Series")
    print("already patched?" if already else "STRING NOT FOUND - no change")
EOF

echo "== verify (must show RX 580, one line, clean) =="
strings "$F" | grep -E "Radeon .TM. RX (48|58)0" | head -4
echo "== size unchanged? =="
stat -c "%s bytes  %n" "$F" "$BAK"

echo "== restart Edge so a fresh process maps the patched dll =="
# the lab supervisor (running) revives Edge within 60s and gives it a fresh profile
pkill -9 -f msedge 2>/dev/null || true
sleep 2
echo "edge procs now: $(pgrep -fc msedge 2>/dev/null || echo 0)"

echo "== poll the title (identity appears when the new Edge renders WebGL) =="
for i in $(seq 1 45); do
  line=$(DISPLAY=:9 wmctrl -l 2>/dev/null | grep -iE "rx580check" | tail -1 | cut -c1-260)
  if [ -n "$line" ]; then
    printf '    t=%-3ss %s\n' "$((i*2))" "$line"
    case "$line" in *RX580CHECK*580*) echo "    >>> 580 NAME IS THROUGH"; break;; esac
  fi
  sleep 2
done