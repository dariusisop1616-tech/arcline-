#!/bin/bash
# Test whether ANGLE's native D3D11 backend survives under Wine 11 - the path to
# the real-Windows WebGL string ("...Direct3D11 vs_5_0 ps_5_0, D3D11") instead of
# the "Vulkan ..." tell. The GPU identity must come from OUR ICD, so first point
# Wine's wined3d at its Vulkan backend (registry renderer=vulkan); then dxgi's
# adapter enumeration flows through winevulkan -> host loader -> rx580 ICD and
# the D3D11 string is built from the 0x67DF identity, not from the host NVIDIA.
# A second profile (C:\t14) keeps the running Vulkan-ANGLE session untouched.
export LC_ALL=C.UTF-8
export DISPLAY=:9
export PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml="
export WINEDEBUG="-all"
OUT=/root/winelab/out
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

echo "== [1] wined3d backend -> vulkan (so dxgi sees OUR device) =="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d vulkan /f 2>&1 | grep -v "^$" | head -2

echo "== [2] launch Edge on ANGLE-D3D11, fresh profile t14 =="
rm -rf /root/.wine/drive_c/t14 2>/dev/null
( export VK_DRIVER_FILES="/root/vkicd/rx580_icd.json" \
    VK_ICD_FILENAMES="/root/vkicd/rx580_icd.json" RX580_LOG=1
  setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update \
    --renderer-process-limit=1 \
    --disable-gpu-sandbox --disable-gpu-watchdog \
    --use-angle=d3d11 \
    --window-size=1200,700 --window-position=120,120 \
    --user-data-dir='C:\t14' --new-window \
    "file:///Z:/root/linuxlab/rx580-check.html#d3d11" >"$OUT/edge-d3d11.log" 2>&1 & )

echo "== [3] probe the window title (identity appears there) =="
for i in $(seq 1 45); do
  line=$(wmctrl -l 2>/dev/null | grep -iE "rx580check" | tail -1 | cut -c1-260)
  if [ -n "$line" ]; then
    printf '    t=%-3ss %s\n' "$((i*2))" "$line"
    case "$line" in *RX580CHECK*) break;; esac
  fi
  sleep 2
done

echo "== [4] gpu-process health (crash-loop check) =="
grep -oE "exit_code=0x[0-9a-f]+|Failed to create [^\"]*|Terminating GPU process[^\"]*" \
  "$OUT/edge-d3d11.log" 2>/dev/null | sort | uniq -c | head -8
echo "    edge procs: $(pgrep -fc msedge 2>/dev/null || echo 0)"

echo "== [5] verdict =="
title=$(wmctrl -l 2>/dev/null | grep -iE "rx580check" | tail -1)
case "$title" in
  *Direct3D11*)  echo "    >>> WIN: native Direct3D11 string with our device" ;;
  *RX580CHECK*Vulkan*) echo "    >>> fell back to Vulkan path (title has Vulkan)" ;;
  *RX580CHECK*)  echo "    >>> page loaded; check renderer line in title above" ;;
  *)             echo "    >>> no window title - GPU process likely crash-looped" ;;
esac