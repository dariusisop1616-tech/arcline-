#!/bin/bash
# Launch a VISIBLE Linux display (Xvfb) with the native Windows Chrome under Wine on it,
# and expose it to the Windows host as a web page on http://localhost:6080/vnc.html
#
# Why Xvfb and not WSLg: on this machine WSLg creates windows but never paints them
# ([WARN:COPY MODE]). Xvfb renders correctly - proven by a captured wallpaper+taskbar.

export LC_ALL=C.UTF-8
LAB="$HOME/winelab"
export WINEPREFIX="$LAB/prefix"
export WINEDEBUG="-all"
export PATH="$PATH:/usr/lib/x86_64-linux-gnu/wine"
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe

REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUTDIR="$REPO/results/vm-display"
mkdir -p "$LAB/out" "$OUTDIR"
cp "$REPO/tools/show-gpu.html" "$LAB/show.html" 2>/dev/null

DISP=:9
PORT_RFB=5901
PORT_WEB=6080

# ---------------------------------------------------------------- clean slate
pkill -f "Xvfb $DISP" 2>/dev/null
pkill -x x11vnc       2>/dev/null
pkill -f websockify   2>/dev/null
pkill -x fluxbox      2>/dev/null
pkill -f chrome.exe   2>/dev/null
sleep 2

# ---------------------------------------------------------------- 1. display
echo "[1] virtual display"
Xvfb $DISP -screen 0 1440x900x24 -ac >"$LAB/out/xvfb.log" 2>&1 &
sleep 3
echo "    Xvfb procs: $(pgrep -fc 'Xvfb' 2>/dev/null)"
DISPLAY=$DISP xdpyinfo 2>&1 | head -2 | sed 's/^/    /'

export DISPLAY=$DISP

# ---------------------------------------------------------------- 2. WM
echo "[2] window manager"
fluxbox >"$LAB/out/fluxbox.log" 2>&1 &
sleep 2
echo "    fluxbox procs: $(pgrep -xc fluxbox 2>/dev/null)"

# ---------------------------------------------------------------- 3. VNC server
# CRITICAL: WSLg exports WAYLAND_DISPLAY / XDG_RUNTIME_DIR; x11vnc sees WAYLAND_DISPLAY
# and refuses to start ("Wayland display server detected ... Exiting").
echo "[3] vnc server on $DISP"
unset WAYLAND_DISPLAY
unset XDG_RUNTIME_DIR
unset PULSE_SERVER
unset DISPLAY_WAYLAND

x11vnc -display $DISP -forever -shared -nopw -quiet -rfbport $PORT_RFB \
       -noxdamage -xkb -bg -o "$LAB/out/x11vnc.log" >/dev/null 2>&1
sleep 3
N=$(pgrep -xc x11vnc 2>/dev/null)
echo "    x11vnc procs: $N"
if [ "$N" = "0" ]; then
  echo "    --- x11vnc.log ---"; tail -6 "$LAB/out/x11vnc.log" 2>/dev/null | sed 's/^/    /'
fi

# ---------------------------------------------------------------- 4. noVNC
echo "[4] web client on port $PORT_WEB"
websockify --web=/usr/share/novnc $PORT_WEB localhost:$PORT_RFB >"$LAB/out/websockify.log" 2>&1 &
sleep 3
echo "    websockify procs: $(pgrep -fc websockify 2>/dev/null)"
(ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null) | grep -E ":$PORT_WEB|:$PORT_RFB" | sed 's/^/    /'

# ---------------------------------------------------------------- 5. the browser
# The browser stays NATIVE and UNPATCHED. Everything changed is underneath it.
# --disable-direct-composition is the fix for the blank white window: Wine has no
# DirectComposition, so let it software-composite while keeping the d3d11 render path.
echo "[5] native Windows Chrome under Wine on $DISP"
wine "$LAB/chrome/chrome.exe" \
  --no-sandbox --disable-dev-shm-usage \
  --disable-direct-composition \
  --disable-gpu-compositing --in-process-gpu \
  --use-angle=d3d11 \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1380,840 --window-position=30,30 \
  --user-data-dir="$LAB/cd_vnc2" \
  "file:///Z:/root/winelab/show.html" >"$LAB/out/vnc2.log" 2>&1 &
sleep 25

echo "    chrome.exe procs: $(pgrep -fc chrome.exe 2>/dev/null)"
echo "    X clients:"
xlsclients -a 2>/dev/null | sed 's/^/      /'
echo "    --- last wine log lines ---"
tail -6 "$LAB/out/vnc2.log" 2>/dev/null | sed 's/^/      /'

# ---------------------------------------------------------------- 6. prove it painted
echo "[6] capture the display"
shoot() {
  local f="$1"
  if command -v import >/dev/null 2>&1; then
    import -window root -display $DISP "$f" 2>/dev/null && return 0
  fi
  if command -v xwd >/dev/null 2>&1; then
    xwd -root -display $DISP -silent > "${f%.png}.xwd" 2>/dev/null && return 0
  fi
  return 1
}
if shoot "$OUTDIR/display.png"; then
  echo "    saved results/vm-display/display.png ($(stat -c%s "$OUTDIR/display.png" 2>/dev/null) bytes)"
else
  echo "    capture FAILED"
fi

echo
echo "==================================================================="
echo ">>> OPEN THIS IN YOUR WINDOWS BROWSER:  http://localhost:6080/vnc.html"
echo ">>> (click 'Connect' - no password)"
echo "==================================================================="
echo
echo "keeping everything open. re-capturing the display every 60s."
echo "screenshots land in: results/vm-display/display.png"

# keep alive + keep capturing, so we can always see the current state
for i in $(seq 1 60); do
  sleep 60
  shoot "$OUTDIR/display.png"
  cp "$OUTDIR/display.png" "$OUTDIR/frame_$i.png" 2>/dev/null
  rm -f "$OUTDIR/frame_$((i-1)).png" 2>/dev/null
done
echo "60 minutes elapsed."
