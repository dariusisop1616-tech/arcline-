#!/bin/bash
# Final check: one clean Chrome instance, --use-angle=vulkan (the flag combo the earlier
# work proved puts Chrome on external Mesa instead of its bundled SwiftShader), with the
# interposer now resolving the real function properly. The Rx 580 must appear in WebGL
# AND the canvas must still work - a renderer string the page cannot actually draw with
# would be worse than no rename at all.
LAB=/root/linuxlab
DIR=/root/vklayer
SRC="/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/vulkan-layer"
CHROME="$LAB/chrome/chrome"
export DISPLAY=:9

echo "=== rebuild the interposer ==="
cp "$SRC/preload_rx580.c" "$DIR/"
gcc -shared -fPIC -O2 -o "$DIR/libvk_rx580_preload.so" "$DIR/preload_rx580.c" -ldl || exit 1
echo "  $(stat -c%s "$DIR/libvk_rx580_preload.so") bytes"
echo

echo "=== clean slate ==="
pkill -9 -f "$CHROME" 2>/dev/null; sleep 3
rm -f /tmp/rx580_preload.log
echo "  chrome procs: $(pgrep -fc "$CHROME" 2>/dev/null || echo 0)"
echo

echo "=== launch: --use-angle=vulkan + interposer ==="
env LD_PRELOAD="$DIR/libvk_rx580_preload.so" \
    RX580_LOG=1 \
    VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json \
    setsid nohup "$CHROME" \
      --no-sandbox --disable-dev-shm-usage \
      --no-first-run --no-default-browser-check --disable-extensions \
      --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist \
      --window-size=1200,680 --window-position=60,80 \
      --user-data-dir="$LAB/cd_rx" \
      --enable-logging=stderr \
      "file://$LAB/rx580-check.html#rx580" >"$LAB/out/rx.log" 2>&1 &
sleep 14

echo
echo "=== RESULT (window title carries the live WebGL strings) ==="
wmctrl -l 2>/dev/null | grep -o 'RX580CHECK\[#rx580\][^|]*\(|[^|]*\)\{0,6\}' | tr '|' '\n' | sed 's/^ */  /'
echo
echo "=== GL errors? ==="
grep -iE 'ANGLE Requires|Internal Vulkan error|EGL_NOT_INITIALIZED' "$LAB/out/rx.log" | head -3 | sed 's/^/  /' || echo "  (none)"
echo
echo "=== interposer resolution ==="
sort /tmp/rx580_preload.log 2>/dev/null | uniq -c | sed 's/^/  /'
echo
echo "=== screenshot ==="
command -v import >/dev/null && import -window root "$LAB/out/rx.png" 2>/dev/null \
  && cp "$LAB/out/rx.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/rx580-final.png" \
  && echo "  saved results/rx580-final.png"
echo
echo "=== kept open for you to navigate ==="
echo "  http://localhost:6080/vnc.html   ($(pgrep -fc "$CHROME" 2>/dev/null) procs)"
