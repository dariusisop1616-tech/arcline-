#!/bin/bash
# Where things stand: is the flag test still running, is the Linux browser alive, what is
# mapped on the display right now.
export DISPLAY=:9

echo "=== flag test / wine still running? ==="
ps -eo pid,etime,cmd | grep -E 'wdm\.sh|chrome\.exe' | grep -v grep | head -6 || echo "  (nothing)"
echo

echo "=== Linux browser alive? ==="
echo "  procs: $(pgrep -fc '/root/linuxlab/chrome/chrome' 2>/dev/null || echo 0)"
echo

echo "=== dcomp error counts per variant log ==="
for f in dcomp dcompgpu dcompv gpucp live vdesk; do
  L="/root/winelab/out/$f.log"
  if [ -f "$L" ]; then
    printf '  %-10s dcomp=%s  size=%s  modified=%s\n' "$f" \
      "$(grep -c DCompositionCreateDevice "$L" 2>/dev/null)" \
      "$(stat -c%s "$L")" "$(stat -c%y "$L" | cut -c12-19)"
  else
    printf '  %-10s (no log)\n' "$f"
  fi
done
echo

echo "=== mapped windows on $DISPLAY ==="
for w in $(xwininfo -root -children 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -30); do
  info=$(xwininfo -id "$w" 2>/dev/null)
  if echo "$info" | grep -q 'IsViewable'; then
    geo=$(echo "$info" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
    name=$(echo "$info" | grep -oE '"[^"]*"' | head -1)
    echo "  MAP   $w  $geo  $name"
  fi
done
echo

echo "=== all windows incl unmapped chrome.exe ==="
xwininfo -root -tree 2>/dev/null | grep -E 'chrome\.exe|Wine Desktop|xmessage' | head -8 | sed 's/^/  /'
