#!/bin/bash
# Root cause established: this Chrome build allows only (gl=egl-angle,angle=default).
#   d3d11   -> "Failed to create device" (no D3D11 in this prefix)      -> crash
#   gl      -> "WGL_NV_DX_interop2 is required but not present" (Wine)  -> crash
#   vulkan  -> untested
#   swiftshader -> ZERO gl errors in the earlier run
# So: find the backend that keeps the browser ALIVE and PAINTS A WINDOW.
# Deliberately NO --disable-gpu-compositing / --disable-direct-composition here
# (those two flags are what killed the window in variants E/F/G).

export LC_ALL=C.UTF-8
LAB="$HOME/winelab"
export WINEPREFIX="$LAB/prefix"
export WINEDEBUG="-all"
export PATH="$PATH:/usr/lib/x86_64-linux-gnu/wine"
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe
export DISPLAY=:9

REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT="$REPO/results/vm-display"
mkdir -p "$OUT" "$LAB/out"
pkill -x xmessage 2>/dev/null

# does Wine see a Vulkan driver at all?
echo "=== Wine Vulkan check ==="
ls /usr/share/vulkan/icd.d/ 2>/dev/null | sed 's/^/  /'
wine vulkaninfo --summary 2>&1 | grep -iE 'driverName|deviceName|apiVersion' | head -6 | sed 's/^/  /'
echo

run() {
  local tag="$1"; shift
  echo "=============================================================="
  echo "# $tag     flags: $*"
  echo "=============================================================="
  pkill -f chrome.exe 2>/dev/null; sleep 3

  wine "$LAB/chrome/chrome.exe" \
    --no-sandbox --disable-dev-shm-usage \
    --no-first-run --no-default-browser-check --disable-extensions \
    --window-size=1280,800 --window-position=20,20 \
    --user-data-dir="$LAB/cd_m_$tag" \
    "$@" "file:///Z:/root/winelab/show.html" >"$LAB/out/m_$tag.log" 2>&1 &

  # watch for a real (non-stub) chrome window for up to 45s
  local found=""
  for i in $(seq 1 45); do
    found=$(xwininfo -root -tree 2>/dev/null \
            | grep -i 'chrome' \
            | grep -E '[0-9]{3,}x[0-9]{3,}' | head -1)
    [ -n "$found" ] && break
    sleep 1
  done

  local procs; procs=$(pgrep -fc chrome.exe 2>/dev/null || echo 0)
  echo "  alive at ${i}s : chrome.exe procs = $procs"
  if [ -n "$found" ]; then
    echo "  WINDOW FOUND  : $found"
  else
    echo "  WINDOW        : none (no chrome window larger than 100px)"
  fi
  echo "  all chrome windows:"
  xwininfo -root -tree 2>/dev/null | grep -i 'chrome' | sed 's/^/    /' | head -6
  echo "  gl errors:"
  grep -iE 'WGL_NV|EGL_NOT|EGL display|Failed to create device|Dawn' "$LAB/out/m_$tag.log" 2>/dev/null \
    | tail -2 | sed 's/^/    /' || echo "    (none)"

  if command -v import >/dev/null 2>&1; then
    import -window root -display :9 "$OUT/m_$tag.png" 2>/dev/null \
      && echo "  shot: results/vm-display/m_$tag.png"
  fi
  echo
}

run swiftshader --use-angle=swiftshader --ignore-gpu-blocklist
run nogpu       --disable-gpu
run vulkan      --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist
run swiftshader_plain --use-angle=swiftshader --disable-gpu-compositing

echo "=== FINAL: all chrome windows on :9 ==="
xwininfo -root -tree 2>/dev/null | grep -i 'chrome' | sed 's/^/  /' | head -10
echo "=== DONE ==="
