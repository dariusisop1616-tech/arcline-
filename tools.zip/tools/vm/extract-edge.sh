#!/bin/bash
# msiextract exits 0 on the Edge MSI but yields zero files - Edge's payload is in a CAB
# stream msitools does not follow. Try 7z, which reads the CAB directly; if that also
# fails, hand the MSI to Wine's own msiexec, which is the most faithful reader available.
set -u
EDGE=/root/winelab/edge

echo "=== [1] what streams does the MSI actually contain? ==="
python3 - <<'PY'
import struct, sys
p = "/root/winelab/edge/edge.msi"
d = open(p, "rb").read()
n = len(d)
# CFB: scan for the stream-name directory by searching for known names as UTF-16LE
for name in ("\x05SummaryInformation", "Binary.", "CAB", "Media", "File", "Icon", "Feature"):
    enc = name.encode("utf-16-le")
    idx = d.find(enc)
    print("  %-22s %s" % (name, ("found at 0x%x" % idx) if idx > 0 else "not found"))
print("  size: %d bytes" % n)
PY
echo

echo "=== [2] try 7z ==="
command -v 7z >/dev/null || 7z >/dev/null 2>&1 || apt-get install -y p7zip-full >/dev/null 2>&1
if command -v 7z >/dev/null; then
  rm -rf "$EDGE/z"; mkdir -p "$EDGE/z"
  7z x -y -o"$EDGE/z" "$EDGE/edge.msi" >/dev/null 2>&1
  echo "  files: $(find "$EDGE/z" -type f 2>/dev/null | wc -l)"
  find "$EDGE/z" -maxdepth 1 -type f 2>/dev/null | head -12 | sed 's/^/    /'
  CAB=$(find "$EDGE/z" -maxdepth 1 -iname '*.cab' | head -1)
  if [ -n "$CAB" ]; then
    echo "  cab: $CAB"
    rm -rf "$EDGE/zc"; mkdir -p "$EDGE/zc"
    7z x -y -o"$EDGE/zc" "$CAB" >/dev/null 2>&1
    echo "  files after cab: $(find "$EDGE/zc" -type f 2>/dev/null | wc -l)"
    EXE=$(find "$EDGE/zc" -iname msedge.exe | head -1)
    echo "  msedge.exe: ${EXE:-NOT FOUND}"
    [ -n "$EXE" ] && echo "$EXE" > "$EDGE/exe.txt"
  fi
else
  echo "  no 7z"
fi
echo

echo "=== [3] if still nothing, let Wine install it ==="
if [ ! -s "$EDGE/exe.txt" ]; then
  echo "  extracting msitools payload to temp, then wine msiexec..."
  command -v msiextract >/dev/null || apt-get install -y msitools >/dev/null 2>&1
  rm -rf "$EDGE/y"; mkdir -p "$EDGE/y"
  (cd "$EDGE/y" && msiextract "$EDGE/edge.msi" >/dev/null 2>&1)
  echo "  msiextract landed: $(find "$EDGE/y" -type f 2>/dev/null | wc -l) files"
  echo "  running: wine msiexec /i edge.msi /qn"
  setsid nohup wine msiexec /i "$EDGE/edge.msi" /qn /norestart \
    >"$EDGE/msiexec.log" 2>&1 &
  echo "  msiexec launched, pid $!"
  sleep 60
  echo "  --- msiexec log tail ---"
  tail -12 "$EDGE/msiexec.log" 2>/dev/null | sed 's/^/    /'
  echo "  --- installed tree ---"
  find /root/.wine/drive_c -iname msedge.exe 2>/dev/null | head -3 | sed 's/^/    /'
  FOUND=$(find /root/.wine/drive_c -iname msedge.exe 2>/dev/null | head -1)
  [ -n "$FOUND" ] && echo "$FOUND" > "$EDGE/exe.txt"
fi
echo
echo "EDGE EXE: $(cat "$EDGE/exe.txt" 2>/dev/null || echo none)"
