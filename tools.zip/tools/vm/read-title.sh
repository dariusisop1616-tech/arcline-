#!/bin/bash
# Read the WebGL result from a throwaway instance on its own profile, tagged #v2, so the
# window the user is navigating is left alone. The page puts the strings in the window
# title, so the answer can be read without pixels.
LAB=/root/linuxlab
DIR=/root/vklayer
CHROME="$LAB/chrome/chrome"
export DISPLAY=:9

pkill -9 -f "cd_verify" 2>/dev/null; sleep 1

env LD_PRELOAD="$DIR/libvk_rx580_preload.so" \
    RX580_LOG=1 \
    VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json \
    setsid nohup "$CHROME" \
      --no-sandbox --disable-dev-shm-usage \
      --no-first-run --no-default-browser-check --disable-extensions \
      --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist \
      --window-size=1150,650 --window-position=90,110 \
      --user-data-dir="$LAB/cd_verify" \
      --enable-logging=stderr \
      "file://$LAB/rx580-check.html#v2" >"$LAB/out/verify.log" 2>&1 &
sleep 14

echo "=== WebGL as this browser reports it ==="
wmctrl -l 2>/dev/null | grep -o "RX580CHECK\[#v2\][^|]*\(|[^|]*\)\{0,8\}" \
  | tr '|' '\n' | sed 's/^ */  /' | grep -v '^  $'
echo
echo "=== GL errors ==="
grep -iE 'ANGLE Requires|Internal Vulkan error|EGL_NOT_INITIALIZED' "$LAB/out/verify.log" \
  2>/dev/null | head -3 | sed 's/^/  /' || true
grep -qiE 'ANGLE Requires|Internal Vulkan error' "$LAB/out/verify.log" 2>/dev/null \
  || echo "  (none - ANGLE accepted the device)"
echo
echo "=== screenshot ==="
command -v import >/dev/null && import -window root "$LAB/out/verify.png" 2>/dev/null \
  && cp "$LAB/out/verify.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/rx580-verified.png" \
  && echo "  saved results/rx580-verified.png"
pkill -9 -f "cd_verify" 2>/dev/null
