import json, sys, os

d = "/root/winelab/edge"
best = None
for view in ("enterprise",):
    p = os.path.join(d, "api-%s.json" % view)
    if not os.path.exists(p):
        continue
    data = json.load(open(p))
    if not isinstance(data, list):
        continue
    for prod in data:
        if not isinstance(prod, dict):
            continue
        if str(prod.get("Product", "")).lower() != "stable":
            continue
        for rel in prod.get("Releases", []):
            if not isinstance(rel, dict):
                continue
            # Platform/Architecture are on the RELEASE, not on each artifact
            if rel.get("Platform") != "Windows":
                continue
            arch = rel.get("Architecture")
            if arch not in ("x64", "x86"):
                continue
            for art in rel.get("Artifacts", []):
                if not isinstance(art, dict):
                    continue
                loc = art.get("Location", "") or ""
                if not loc.lower().endswith(".msi"):
                    continue
                ver = rel.get("ProductVersion", "0")
                score = (ver, 1 if arch == "x64" else 0)
                if best is None or score > best[0]:
                    best = (score, ver, arch, loc)

if not best:
    print("NO WINDOWS MSI FOUND")
    # report what Windows releases do exist, so we can adapt
    data = json.load(open(os.path.join(d, "api-enterprise.json")))
    for prod in data:
        if not isinstance(prod, dict) or str(prod.get("Product", "")).lower() != "stable":
            continue
        seen = {}
        for rel in prod.get("Releases", []):
            if not isinstance(rel, dict):
                continue
            k = "%s/%s" % (rel.get("Platform"), rel.get("Architecture"))
            seen[k] = seen.get(k, 0) + 1
        for k, v in sorted(seen.items()):
            print("   windows release group: %-24s %d releases" % (k, v))
    sys.exit(1)

print("PICKED version=%s arch=%s" % (best[1], best[2]))
print("URL %s" % best[3])
open(os.path.join(d, "msi_url.txt"), "w").write(best[3] + "\n")
open(os.path.join(d, "msi_ver.txt"), "w").write(best[1] + "\n")
