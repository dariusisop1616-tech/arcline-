#!/bin/bash
# Put the RX 580 on the visible display: same native Linux Chrome for Testing, same
# external Mesa driver, but with the LD_PRELOAD interposer in front of the Vulkan loader.
# Nothing is injected into the page and nothing in the browser is patched - the browser
# asks the driver what it is, and the answer is an RX 580.
LAB=/root/linuxlab
DIR=/root/vklayer
CHROME="$LAB/chrome/chrome"
export DISPLAY=:9
mkdir -p "$LAB/out"

echo "=== [0] does the layer work if its .so lives where system layers live? ==="
# The loader recorded its OWN path for our layer when the .so sat in /root/vklayer.
# Every system layer's .so lives in /usr/lib/x86_64-linux-gnu - worth one test.
mkdir -p /usr/share/vulkan/explicit_layer.d
cp "$DIR/librx580.so" /usr/lib/x86_64-linux-gnu/libVkLayer_fake_rx580.so
sed -e 's#/root/vklayer/librx580.so#/usr/lib/x86_64-linux-gnu/libVkLayer_fake_rx580.so#' \
    -e 's/"file_format_version":"1.1.2"/"file_format_version":"1.1.2"/' \
    "/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/vulkan-layer/VK_LAYER_FAKE_rx580.json" \
    > /usr/share/vulkan/explicit_layer.d/VK_LAYER_FAKE_rx580.json
if VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json \
   VK_INSTANCE_LAYERS=VK_LAYER_FAKE_rx580 NODEVICE_SELECT=1 \
   timeout 8 "$DIR/vulkan_probe" 2>&1 | grep -q 'RX 580'; then
  echo "  -> layer path works from /usr/lib: $(VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json VK_INSTANCE_LAYERS=VK_LAYER_FAKE_rx580 NODEVICE_SELECT=1 timeout 8 "$DIR/vulkan_probe" 2>&1 | grep deviceName | head -1)"
else
  echo "  -> still broken from /usr/lib (loader bug independent of location); using the interposer"
fi
echo

echo "=== [1] launch Chrome with the RX 580 interposer ==="
cp "/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/vm/rx580-check.html" "$LAB/rx580-check.html"

pkill -f "cd_rx580" 2>/dev/null
sleep 1

# New profile dir so it does not fight the already-open window for the profile lock.
LD_PRELOAD="$DIR/libvk_rx580_preload.so" \
RX580_LOG=1 \
VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json \
setsid nohup "$CHROME" \
  --no-sandbox --disable-dev-shm-usage \
  --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1360,780 --window-position=40,60 \
  --user-data-dir="$LAB/cd_rx580" \
  "file://$LAB/rx580-check.html" \
  >"$LAB/out/chrome-rx580.log" 2>&1 &
echo "  launched, pid $!"
sleep 12

echo
echo "=== [2] what the window says (title carries the WebGL strings) ==="
for t in $(command -v wmctrl >/dev/null && wmctrl -l | sed 's/^[^ ]* *[^ ]* *[^ ]* *//' || true); do :; done
wmctrl -l 2>/dev/null | grep -i 'RX580CHECK' | sed 's/.*RX580CHECK/RX580CHECK/' | tr '|' '\n' | sed 's/^ *//' \
  || echo "(no wmctrl / no titled window)"
echo
echo "--- all windows ---"
wmctrl -l 2>/dev/null || xwininfo -root -children 2>/dev/null | grep -i '0x' | head -8

echo
echo "=== [3] did the browser process actually load the interposer? ==="
cat /tmp/rx580_preload.log 2>/dev/null | sort | uniq -c || echo "(no trace yet)"
echo "--- chrome log tail ---"
tail -5 "$LAB/out/chrome-rx580.log" 2>/dev/null

echo
echo "=== [4] screenshot for the live display ==="
if command -v import >/dev/null; then
  import -window root "$LAB/out/rx580.png" 2>/dev/null && echo "  saved $LAB/out/rx580.png ($(stat -c%s "$LAB/out/rx580.png") bytes)"
elif command -v xwd >/dev/null; then
  xwd -root -silent > "$LAB/out/rx580.xwd" 2>/dev/null && echo "  saved xwd"
else
  echo "  (no screenshot tool)"
fi

echo
echo "=== [5] keep it open ==="
echo "  Chrome is detached and stays open on the display at http://localhost:6080/vnc.html"
echo "  open items: $(pgrep -fc "$CHROME" 2>/dev/null) chrome processes"
