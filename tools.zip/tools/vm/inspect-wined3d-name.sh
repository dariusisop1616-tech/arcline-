#!/bin/bash
# Inspect how the Polaris name sits inside wined3d.dll before patching it.
F=/opt/wine-staging/lib/wine/x86_64-windows/wined3d.dll

echo "== offsets of the 480 string =="
grep -abo "Radeon (TM) RX 480 Graphics" "$F"

echo "== hex context around the first hit =="
OFF=$(grep -abo "Radeon (TM) RX 480 Graphics" "$F" | head -1 | cut -d: -f1)
if [ -n "$OFF" ]; then
  START=$((OFF - 32)); [ $START -lt 0 ] && START=0
  xxd -s $START -l 128 "$F"
fi

echo "== does a 580 entry already exist in the db? =="
grep -c "RX 580" "$F" || true
echo "== all Radeon (TM) RX names in the dll =="
strings "$F" | grep "Radeon (TM) RX" | head -12