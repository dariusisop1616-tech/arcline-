#!/bin/bash
# List the NVIDIA GTX identities that exist in Wine's live GPU database
# (win32u.so, the unix side that actually serves the descriptions) and try to
# read each entry's (vendor, device) pair from the surrounding table bytes.
F=/opt/wine-staging/lib/wine/x86_64-unix/win32u.so

echo "== GTX names in the db =="
strings "$F" | grep -E "^NVIDIA GeForce" | sort -u | head -25

echo
echo "== entries near each GTX string: u32 pairs at string start -8/-16 =="
python3 - "$F" <<'EOF'
import re, struct, sys
f = sys.argv[1]
data = open(f, 'rb').read()
names = set()
for m in re.finditer(rb"NVIDIA GeForce GTX [0-9]+[A-Za-z ]{0,6}\x00", data):
    names.add(m.group(0)[:-1].decode())
for name in sorted(names):
    b = name.encode() + b"\x00"
    off = data.find(b)
    # scan back a bit for a plausible (vendor 0x10de, device) u32 pair
    found = ""
    for back in range(4, 80, 4):
        if off - back - 8 < 0:
            break
        v, d = struct.unpack_from("<II", data, off - back - 8)
        if v == 0x10DE and 0x0100 <= d <= 0xFFFF:
            found = f"  vendor=0x10de device=0x{d:04X} (at -{back+8})"
            break
    print(f"{name}{found}")
EOF