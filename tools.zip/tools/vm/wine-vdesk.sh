#!/bin/bash
# Wine's Chrome never maps its own X window (Map State: IsUnMapped), confirmed again with
# --use-angle=vulkan and --disable-gpu. But Wine has one construct that DID render to X in
# earlier work: the virtual desktop. With it, Wine creates a single mapped X window and
# composites every Windows window INSIDE it - so Chrome appearing depends on the desktop
# window, not on Chrome's own window being mapped.
#
# Registry is the route that worked before; `wine explorer /desktop=` with a Linux path
# gave 0 processes.
export DISPLAY=:9
W=/root/winelab
EXE="$W/chrome/chrome.exe"

echo "=== [1] set the virtual desktop in the registry ==="
wine reg add "HKCU\\Software\\Wine\\Explorer" /v Desktop /d lab /f 2>&1 | tail -1
wine reg add "HKCU\\Software\\Wine\\Explorer\\Desktops" /v lab /d 1440x900 /f 2>&1 | tail -1
echo "  verify:"
wine reg query "HKCU\\Software\\Wine\\Explorer" 2>/dev/null | grep -iE 'Desktop' | sed 's/^/    /'
wine reg query "HKCU\\Software\\Wine\\Explorer\\Desktops" 2>/dev/null | grep -iE 'lab' | sed 's/^/    /'
echo

pkill -9 -f chrome.exe 2>/dev/null; sleep 3
rm -rf "$W/cd_vdesk" 2>/dev/null

echo "=== [2] launch Windows Chrome inside the virtual desktop ==="
setsid nohup wine "$EXE" \
  --no-sandbox \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1200,700 \
  --user-data-dir='C:\cd_vdesk' --new-window "about:blank" \
  >"$W/out/vdesk.log" 2>&1 &
sleep 25

echo "=== [3] is the Wine desktop window mapped? ==="
for w in $(xwininfo -root -children 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -25); do
  info=$(xwininfo -id "$w" 2>/dev/null)
  name=$(echo "$info" | grep -oE '"[^"]*"' | head -1)
  geo=$(echo "$info" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
  if echo "$info" | grep -q 'IsViewable'; then
    echo "  MAP  $w $geo $name"
  elif echo "$info" | grep -q 'IsUnMapped'; then
    echo "  unmap $w $geo $name"
  fi
done
echo "  chrome.exe procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
echo

echo "=== [4] screenshot ==="
command -v import >/dev/null && import -window root "$W/out/vdesk.png" 2>/dev/null \
  && cp "$W/out/vdesk.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-vdesk.png" \
  && echo "  saved results/wine-vdesk.png"
echo
echo "=== [5] log tail ==="
grep -iE 'error|fail|desktop' "$W/out/vdesk.log" 2>/dev/null | tail -6 | sed 's/^/  /'
