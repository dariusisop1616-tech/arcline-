#!/bin/bash
# Where is the lab script stuck? Report main pid, its state, and live children.
P=$(pgrep -f "start-edge-lab.sh" | head -1)
echo "main pid: $P"
for pid in $(pgrep -f "start-edge-lab.sh"); do
  echo "--- $pid state=$(awk '{print $3}' /proc/$pid/stat 2>/dev/null) wchan=$(cat /proc/$pid/wchan 2>/dev/null)"
  ps --ppid "$pid" -o pid=,stat=,etimes=,cmd= 2>/dev/null | cut -c1-90 | sed 's/^/    child: /'
done
echo "== now =="
date
tail -3 /root/winelab/out/lab.log