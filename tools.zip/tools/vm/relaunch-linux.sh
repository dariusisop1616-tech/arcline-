#!/bin/bash
# Put a working browser back on the display while the Wine flag test finishes. This is the
# known-good combination: native Linux Chrome for Testing on external Mesa with the RX 580
# interposer, so browserleaks shows the AMD card.
export DISPLAY=:9
LAB=/root/linuxlab
DIR=/root/vklayer
CHROME="$LAB/chrome/chrome"

echo "=== clear the leftovers from the virtual-desktop experiment ==="
pkill -9 -f explorer.exe 2>/dev/null
pkill -9 -f xmessage 2>/dev/null
# Drop the virtual-desktop registry value so it does not wrap every future Wine launch.
wine reg delete "HKCU\\Software\\Wine\\Explorer" /v Desktop /f 2>/dev/null | tail -1
wine reg delete "HKCU\\Software\\Wine\\Explorer\\Desktops" /v lab /f 2>/dev/null | tail -1
sleep 1
echo

echo "=== relaunch Linux Chrome + RX 580 interposer ==="
env LD_PRELOAD="$DIR/libvk_rx580_preload.so" \
    RX580_LOG=1 \
    VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json \
    setsid nohup "$CHROME" \
      --no-sandbox --disable-dev-shm-usage \
      --no-first-run --no-default-browser-check --disable-extensions \
      --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist \
      --window-size=1360,820 --window-position=20,20 \
      --user-data-dir="$LAB/cd_rx" \
      "file://$LAB/rx580-check.html#rx580" >"$LAB/out/relaunch.log" 2>&1 &
sleep 12

echo "  procs: $(pgrep -fc "$CHROME" 2>/dev/null || echo 0)"
echo "  title: $(wmctrl -l 2>/dev/null | grep -o 'RX580CHECK[^|]*\(|[^|]*\)\{0,5\}' | head -1)"
echo
echo "=== display check ==="
echo -n "  localhost:6080 -> "
curl -s -o /dev/null -w '%{http_code}\n' --max-time 5 http://localhost:6080/vnc.html
echo "  windows:"
wmctrl -l 2>/dev/null | sed 's/^/    /'
