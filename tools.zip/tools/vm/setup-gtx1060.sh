#!/bin/bash
# Switch the lab identity to GTX 1060: restore the original Wine binaries
# (the RX 580 string patch is abandoned - the db has no 580 entry), clean the
# leftover override key, rebuild the ICD with the new identity, and prove it
# with the standalone probe before touching Edge.
set -e
export DISPLAY=:9
export PATH="/opt/wine-staging/bin:$PATH"

echo "== [1] restore original Wine binaries (atomic) =="
for F in \
  /opt/wine-staging/lib/wine/x86_64-unix/win32u.so \
  /opt/wine-staging/lib/wine/x86_64-windows/wined3d.dll \
  /opt/wine-staging/lib/wine/i386-windows/wined3d.dll; do
  B="$F.orig-rx480"
  if [ -f "$B" ]; then cp -a "$B" "$F.t" && mv -f "$F.t" "$F" && echo "  restored $(basename $F)"
  else echo "  (no backup for $F)"; fi
done
strings /opt/wine-staging/lib/wine/x86_64-unix/win32u.so | grep -oE "Radeon .TM. RX 48[08] Graphics" | head -1

echo "== [2] clean leftover registry override =="
wine reg delete "HKCU\\Software\\Wine\\Direct3D" /v "VideoDescription_1002_67df" /f 2>/dev/null \
  | head -1 || true
echo "  renderer=$(wine reg query 'HKCU\\Software\\Wine\\Direct3D' /v renderer 2>/dev/null | grep -oE 'vulkan|gl' | head -1)"

echo "== [3] rebuild ICD with the GTX 1060 identity + standalone probe =="
bash "/mnt/c/Users/Darkking1/Desktop/similar to gologin/tools/vulkan-layer/build-icd.sh" 2>&1 | head -24