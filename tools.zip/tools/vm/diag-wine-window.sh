#!/bin/bash
# Chromium 110 and 154 both fail to map, while Wine's own notepad maps. So it is not the
# Chromium version and not DirectComposition. Two possibilities remain:
#   (a) Chrome never creates its X toplevel -> its browser process stalls before CreateWindow
#   (b) the X toplevel exists but Chrome never ShowWindow()s it
# These need different fixes, so find out which. Dump every window WITH its owning pid, and
# relaunch with verbose Chromium logging so we can see where it stops.
export DISPLAY=:9
W=/root/winelab
OLD="$W/old"
EXE=$(find "$OLD/c110" -maxdepth 3 -name chrome.exe | head -1)
OUT="$W/out"
mkdir -p "$OUT"

echo "=== [1] every X window, with owning pid and class ==="
printf '  %-4s %-10s %-24s %-7s %s\n' ST WIN GEOM PID NAME
for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -60); do
  info=$(xwininfo -id "$w" 2>/dev/null) || continue
  geo=$(echo "$info" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
  nm=$(echo "$info" | grep -oE '"[^"]*"' | head -1)
  st=unmapped; echo "$info" | grep -q IsViewable && st=MAP
  pid=$(xprop -id "$w" _NET_WM_PID 2>/dev/null | grep -oE '[0-9]+$' | head -1)
  printf '  %-4s %-10s %-24s %-7s %s\n' "$st" "$w" "$geo" "${pid:-?}" "$nm"
done
echo

echo "=== [2] chrome.exe processes right now ==="
ps -eo pid,etime,stat,wchan:20,cmd 2>/dev/null | grep -i chrome.exe | grep -v grep | head -6 | cut -c1-150 | sed 's/^/  /'
echo
echo "  --- do any chrome.exe pids own an X window? ---"
for pid in $(pgrep -f chrome.exe 2>/dev/null | head -8); do
  owned=0
  for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -60); do
    p=$(xprop -id "$w" _NET_WM_PID 2>/dev/null | grep -oE '[0-9]+$' | head -1)
    [ "$p" = "$pid" ] && { owned=$((owned+1)); echo "    pid $pid owns $w"; }
  done
  [ "$owned" = 0 ] && echo "    pid $pid owns NO X window"
done
echo

echo "=== [3] relaunch c110 with verbose logging ==="
pkill -9 -f chrome.exe 2>/dev/null
pkill -9 -f wineserver 2>/dev/null
sleep 3
rm -rf "$W/cd_c110v" 2>/dev/null
setsid nohup wine "$EXE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1200,700 --user-data-dir='C:\cd_c110v' --new-window "about:blank" \
  --enable-logging=stderr --v=1 \
  >"$OUT/c110-verbose.log" 2>&1 &
sleep 22
echo "  log bytes: $(stat -c%s "$OUT/c110-verbose.log" 2>/dev/null)"
echo "  --- window/visibility related lines ---"
grep -iE 'showwindow|creatwindow|createwindow|widget|visible|aura|x11|window' "$OUT/c110-verbose.log" 2>/dev/null | head -25 | sed 's/^/  /'
echo "  --- errors ---"
grep -iE 'ERROR|FATAL|Check failed|fail' "$OUT/c110-verbose.log" 2>/dev/null | head -20 | sed 's/^/  /'
echo
echo "  --- last 25 lines of the log ---"
tail -25 "$OUT/c110-verbose.log" 2>/dev/null | sed 's/^/  /'
