#!/bin/bash
# Root cause candidate: WSL ships eight ICD manifests (asahi, gfxstream, intel, intel_hasvk,
# nouveau, radeon, virtio, lvp) and there is no hardware behind seven of them. ANGLE's Vulkan
# backend does its own ICD enumeration and prefers an ICD by vendor, so it can hand the loader
# an ICD that yields no device or a broken one - which is what "Preferred device ICD not found.
# Using default physicalDevice instead." plus "minimum Vulkan device version of 1.1" looks like.
#
# Force the whole system to see lavapipe and nothing else, then re-test. Reversible: the
# manifests are moved, not deleted.
set -u
BK=/root/icd-backup
mkdir -p "$BK"
D=/usr/share/vulkan/icd.d

echo "=== hiding the seven unusable ICD manifests ==="
for f in "$D"/*.json; do
  b=$(basename "$f")
  [ "$b" = "lvp_icd.json" ] && continue
  mv -f "$f" "$BK/" && echo "  moved out: $b"
done
ls "$D"
echo

# Remove the leftover explicit-layer manifest from the earlier experiment.
rm -f /usr/share/vulkan/explicit_layer.d/VK_LAYER_FAKE_rx580.json \
      /usr/share/vulkan/implicit_layer.d/VK_LAYER_FAKE_rx580.json

LAB=/root/linuxlab
DIR=/root/vklayer
CHROME="$LAB/chrome/chrome"
export DISPLAY=:9

echo "=== [1] loader now sees only: ==="
VK_LOADER_DEBUG=driver timeout 8 "$DIR/vulkan_probe" 2>&1 | grep -iE 'Found ICD manifest|driver manifest files' | head -6
echo

echo "=== [2] does ANGLE accept Vulkan now? (no interposer, no VK_ICD_FILENAMES needed) ==="
pkill -f cd_fix 2>/dev/null; sleep 1
env -u LD_PRELOAD -u VK_ICD_FILENAMES setsid nohup "$CHROME" \
  --no-sandbox --disable-dev-shm-usage \
  --no-first-run --no-default-browser-check \
  --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist \
  --window-size=1100,650 --window-position=60,80 \
  --user-data-dir="$LAB/cd_fix" \
  --enable-logging=stderr \
  "file://$LAB/rx580-check.html" >"$LAB/out/fix.log" 2>&1 &
sleep 12
echo "TITLE: $(wmctrl -l 2>/dev/null | grep -o 'webgl[^|]*|[^|]*renderer[^|]*' | head -1)"
echo
echo "--- GL errors ---"
grep -iE 'ANGLE Requires|Internal Vulkan error|EGL_NOT_INITIALIZED|ChoosePhysicalDevice|SwiftShader' \
  "$LAB/out/fix.log" | head -6 || echo "  (none)"
echo
echo "=== [3] screenshot ==="
command -v import >/dev/null && import -window root "$LAB/out/fix.png" 2>/dev/null \
  && cp "$LAB/out/fix.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/rx580-fix.png" \
  && echo "  saved results/rx580-fix.png"
