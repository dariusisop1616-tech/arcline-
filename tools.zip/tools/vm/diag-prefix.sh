#!/bin/bash
# The dcomp.dll swap and repeated `pkill -9 wineserver` may have left the prefix inconsistent
# (everything now shows procs=1, where Edge previously gave 7 processes and a real window).
# Check the prefix, restore Wine's own dcomp.dll, prove Wine still maps notepad, then launch
# Edge and probe CONTINUOUSLY - the window was transient before, so single samples miss it.
export DISPLAY=:9
W=/root/winelab
OUT="$W/out"
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

echo "=== [1] prefix health ==="
echo "  system32/dcomp.dll: $(stat -c%s /root/.wine/drive_c/windows/system32/dcomp.dll 2>/dev/null) bytes"
echo "  builtin dcomp.dll : $(stat -c%s /usr/lib/x86_64-linux-gnu/wine/x86_64-windows/dcomp.dll 2>/dev/null) bytes"
echo "  leftover .winebak : $(ls /root/.wine/drive_c/windows/system32/dcomp.dll.winebak 2>/dev/null || echo none)"
SZ=$(stat -c%s /root/.wine/drive_c/windows/system32/dcomp.dll 2>/dev/null)
if [ "${SZ:-0}" -gt 500000 ]; then
  echo "  -> native dcomp.dll is still installed; restoring Wine's builtin"
  cp -f /usr/lib/x86_64-linux-gnu/wine/x86_64-windows/dcomp.dll \
        /root/.wine/drive_c/windows/system32/dcomp.dll 2>/dev/null
  echo "     now: $(stat -c%s /root/.wine/drive_c/windows/system32/dcomp.dll) bytes"
fi
echo

echo "=== [2] shut the prefix down cleanly, then sanity-test notepad ==="
pkill -9 -f msedge 2>/dev/null; pkill -9 -f 'chrome\.exe' 2>/dev/null
wineserver -k 2>/dev/null; sleep 4
pkill -9 -f explorer.exe 2>/dev/null
wine reg delete "HKCU\\Software\\Wine\\Explorer" /v Desktop /f >/dev/null 2>&1
setsid nohup wine notepad >"$OUT/sanity.log" 2>&1 &
sleep 10
line=$(xwininfo -root -tree 2>/dev/null | grep -i 'notepad' | head -1)
echo "  notepad window line: ${line:-NONE}"
wid=$(echo "$line" | grep -oE '0x[0-9a-f]{4,}' | head -1)
[ -n "$wid" ] && xwininfo -id "$wid" 2>/dev/null | grep -oE 'Map State: [A-Za-z]+' | sed 's/^/    /'
pkill -9 -f notepad.exe 2>/dev/null; sleep 2
echo

echo "=== [3] launch Edge, probe every 2s for 44s, log every distinct state ==="
rm -rf "$W/t6" 2>/dev/null
setsid nohup wine "$EDGE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-sync --disable-component-update \
  --window-size=1200,700 --window-position=60,60 \
  --user-data-dir='C:\t6' --new-window "about:blank" >"$OUT/t6.log" 2>&1 &
prev=""
for i in $(seq 1 22); do
  line=$(xwininfo -root -tree 2>/dev/null | grep -i 'msedge\.exe' | head -1)
  wid=$(echo "$line" | grep -oE '0x[0-9a-f]{4,}' | head -1)
  procs=$(pgrep -fc msedge 2>/dev/null || echo 0)
  if [ -n "$wid" ]; then
    st=$(xwininfo -id "$wid" 2>/dev/null | grep -oE 'Map State: [A-Za-z]+' | head -1)
    geo=$(echo "$line" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
  else
    st="no-window"; geo=""
  fi
  cur="procs=$procs $st $geo"
  [ "$cur" != "$prev" ] && printf '  t=%-3ss %s\n' "$((i*2))" "$cur"
  prev="$cur"
  sleep 2
done
echo

echo "=== [4] every msedge/Edge line in the tree right now ==="
xwininfo -root -tree 2>/dev/null | grep -iE 'msedge|Edge' | head -10 | sed 's/^/  /'
echo
echo "=== [5] log: DComp / deadlock / errors ==="
printf '  DComp=%s deadlock=%s bytes=%s\n' \
  "$(grep -c DCompositionCreateDevice "$OUT/t6.log" 2>/dev/null)" \
  "$(grep -c loader_section "$OUT/t6.log" 2>/dev/null)" \
  "$(stat -c%s "$OUT/t6.log" 2>/dev/null)"
grep -iE 'ERROR|unimplemented|abort|wine:' "$OUT/t6.log" 2>/dev/null | head -10 | sed 's/^/    /'
echo
echo "=== [6] screenshot ==="
command -v import >/dev/null && import -window root "$OUT/t6.png" 2>/dev/null \
  && cp "$OUT/t6.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-t6.png" \
  && echo "  saved results/wine-t6.png"
