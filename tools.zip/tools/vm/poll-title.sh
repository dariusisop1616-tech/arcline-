#!/bin/bash
# Poll the X window list until the rx580-check page title lands, then judge
# whether the device name is single ("NVIDIA GeForce GTX 1060") or still
# doubled ("NVIDIA NVIDIA ...") after the ICD-name fix.
export DISPLAY=:9
for i in $(seq 1 60); do
  t=$(wmctrl -l 2>/dev/null | grep -iE "microsoft|rx580|identity" | tail -1 | cut -c1-320)
  if [ -n "$t" ]; then printf '  t=%-4ss %s\n' "$((i*6))" "$t"; fi
  case "$t" in *RX580CHECK*) break ;; esac
  sleep 6
done
echo "== final title =="
wmctrl -l 2>/dev/null | grep -i rx580 | cut -c1-340
case "$(wmctrl -l 2>/dev/null)" in
  *"Vulkan 1.3.303 (NVIDIA GeForce GTX 1060"*) echo ">>> SINGLE NAME - DOUBLING FIXED" ;;
  *"NVIDIA NVIDIA"*) echo ">>> still doubled" ;;
  *) echo ">>> pattern not matched yet" ;;
esac