#!/bin/bash
# Wine 11.18 staging MAPPED Chromium's window: "Map State: IsViewable" at t=14s.
# Confirm it is genuinely on screen right now and keep it up. Probe the LARGEST msedge window
# (the previous probe used head -1 and started matching 1x1 helper windows instead).
export DISPLAY=:9
export PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml="
OUT=/root/winelab/out
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

echo "=== [1] every msedge window right now, largest last ==="
for w in $(xwininfo -root -tree 2>/dev/null | grep -i 'msedge\.exe' | grep -oE '0x[0-9a-f]{4,}'); do
  info=$(xwininfo -id "$w" 2>/dev/null) || continue
  st=$(echo "$info" | grep -oE 'Map State: [A-Za-z]+' | head -1)
  geo=$(echo "$info" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
  printf '  %-12s %-24s %s\n' "$w" "$geo" "$st"
done
echo

echo "=== [2] the WM's view (only mapped+managed windows appear) ==="
wmctrl -lp 2>/dev/null | cut -c1-100 | sed 's/^/  /'
echo

echo "=== [3] is Edge alive? ==="
echo "  msedge procs: $(pgrep -fc msedge 2>/dev/null || echo 0)"
echo

echo "=== [4] screenshot the display NOW ==="
command -v import >/dev/null && import -window root "$OUT/wine11-live.png" 2>/dev/null \
  && cp "$OUT/wine11-live.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine11-live.png" \
  && echo "  saved results/wine11-live.png"

echo
echo "=== [5] if nothing is up, relaunch and hold it, probing the main window ==="
if ! wmctrl -lp 2>/dev/null | grep -qi edge; then
  echo "  no Edge window managed -> relaunching"
  pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 4
  rm -rf /root/winelab/t13 2>/dev/null
  setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update \
    --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t13' --new-window "about:blank" >"$OUT/t13.log" 2>&1 &
  prev=""
  for i in $(seq 1 20); do
    # main window = the widest msedge window
    best=""; bestw=0
    for w in $(xwininfo -root -tree 2>/dev/null | grep -i 'msedge\.exe' | grep -oE '0x[0-9a-f]{4,}'); do
      info=$(xwininfo -id "$w" 2>/dev/null) || continue
      geo=$(echo "$info" | grep -oE '[0-9]+x[0-9]+' | head -1)
      wd=${geo%%x*}
      if [ "${wd:-0}" -gt "$bestw" ] 2>/dev/null; then bestw=$wd; best=$w; bestinfo="$info"; fi
    done
    if [ -n "$best" ]; then
      st=$(echo "$bestinfo" | grep -oE 'Map State: [A-Za-z]+' | head -1)
      geo=$(echo "$bestinfo" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
    else
      st="no-window"; geo=""
    fi
    cur="$(pgrep -fc msedge 2>/dev/null || echo 0) procs | main=$best $geo $st"
    [ "$cur" != "$prev" ] && printf '  t=%-3ss %s\n' "$((i*2))" "$cur"
    prev="$cur"
    sleep 2
  done
  echo
  echo "  --- managed now ---"
  wmctrl -lp 2>/dev/null | cut -c1-100 | sed 's/^/    /'
  command -v import >/dev/null && import -window root "$OUT/wine11-visible.png" 2>/dev/null \
    && cp "$OUT/wine11-visible.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine11-visible.png" \
    && echo "  saved results/wine11-visible.png"
fi
