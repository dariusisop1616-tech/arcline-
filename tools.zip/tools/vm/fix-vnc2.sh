#!/bin/bash
# Round 2: x11vnc STILL not accepting after a restart, and websockify process
# count is churning (4->3->10 in the supervisor log). This script:
#   1. captures hard evidence (pids, ages, socket owners, queue depth, logs)
#   2. kills the whole VNC chain to stop any retry storm
#   3. starts ONE clean x11vnc with an EMPTY queue and tests the RFB banner
#      (with zero pending connects, an empty banner = x11vnc itself is broken)
#   4. starts ONE websockify and re-tests through it
export DISPLAY=:9
OUT=/root/winelab/out

echo "== [1] evidence =="
ps -C x11vnc -o pid,etime,args --no-headers 2>/dev/null | cut -c1-100
ss -ltnp 2>/dev/null | grep -E ':5901|:6080' | sed 's/^/  /'
pgrep -a websockify 2>/dev/null | sed 's/^/  ws: /'
echo "  -- x11vnc.log tail:"; tail -4 "$OUT/x11vnc.log" 2>/dev/null | sed 's/^/    /'
echo "  -- oom check:"; dmesg 2>/dev/null | grep -iE 'oom|killed process' | tail -3 | sed 's/^/    /'

echo "== [2] stop everything in the VNC chain =="
pkill -f websockify 2>/dev/null; pkill -x x11vnc 2>/dev/null
sleep 2
ss -ltn 2>/dev/null | grep -E ':5901|:6080' || echo "  both ports clear"

echo "== [3] one clean x11vnc, empty queue =="
( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR
  setsid nohup x11vnc -display :9 -forever -shared -nopw -quiet -rfbport 5901 \
    -noxdamage -xkb -o "$OUT/x11vnc.log" >/dev/null 2>&1 & )
sleep 3
ss -ltn 2>/dev/null | grep 5901 | sed 's/^/  /'
echo -n "  RFB banner: "
timeout 3 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 12 <&3' 2>&1
echo
echo "  -- x11vnc.log now:"; tail -4 "$OUT/x11vnc.log" 2>/dev/null | sed 's/^/    /'

echo "== [4] one websockify, re-test through it =="
( setsid nohup websockify --web=/usr/share/novnc 6080 localhost:5901 \
    >"$OUT/websockify.log" 2>&1 & )
sleep 2
echo -n "  WS upgrade via 6080: "
curl -s -i --max-time 4 \
  -H "Connection: Upgrade" -H "Upgrade: websocket" \
  -H "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==" -H "Sec-WebSocket-Version: 13" \
  http://127.0.0.1:6080/websockify 2>&1 | head -1
ss -ltnp 2>/dev/null | grep -E ':5901|:6080' | sed 's/^/  /'