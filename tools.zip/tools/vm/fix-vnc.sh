#!/bin/bash
# Repair a wedged noVNC chain. Symptom (2026-09-27): websockify answers the WS
# upgrade fine (HTTP 101), but x11vnc sits with a full accept backlog
# (`ss -ltn` shows LISTEN 5 32 on :5901) and never accept()s - the browser hangs
# at "Connecting...". x11vnc's process is alive, so the lab supervisor's
# pgrep-based health check can't see the problem.
#
# HARD LESSON (measured twice): a TERM'd x11vnc can print "caught signal: 15"
# and then HANG in its shutdown path while still holding :5901. Every restart
# then fails with "Error: could not obtain listening port." and the wedged
# zombie keeps the port forever. SIGTERM is not enough - it must be SIGKILL,
# and the repair must PROVE the RFB handshake answers, not trust pgrep.
export DISPLAY=:9
OUT=/root/winelab/out

echo "== before =="
ps -C x11vnc -o pid,etime --no-headers 2>/dev/null | sed 's/^/  x11vnc /'
ss -ltn 2>/dev/null | grep 5901 || echo "  (no 5901 listener!)"

pkill -9 -x x11vnc 2>/dev/null
sleep 2
pkill -9 -x x11vnc 2>/dev/null   # second pass: first may have been mid-shutdown
( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR
  setsid nohup x11vnc -display :9 -forever -shared -nopw -quiet -rfbport 5901 \
    -noxdamage -xkb -o "$OUT/x11vnc.log" >/dev/null 2>&1 & )
sleep 2

echo "== after =="
ss -ltn 2>/dev/null | grep 5901
echo "== RFB banner (must print RFB 003.008) =="
timeout 3 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 12 <&3' 2>&1
echo
echo "== display + Edge still alive? =="
xdpyinfo >/dev/null 2>&1 && echo "  Xvfb :9 OK" || echo "  Xvfb :9 DEAD"
echo "  fluxbox=$(pgrep -xc fluxbox) edge=$(pgrep -fc msedge 2>/dev/null || echo 0)"
free -m | awk 'NR==2{print "  mem used/total:", $3"/"$2"MB"}'