#!/bin/bash
# Round 3: after the win32u.so patch, Edge stuck at 1 process, empty log, no
# window - a wine client waiting on a wedged wineserver. Cause: the patch was
# written IN PLACE while wine processes had the file mapped (running wineserver
# can fault a page mid-rewrite). Fix: hard-reset wine, re-apply the patch
# atomically (write temp + rename - a mapped ELF must never be rewritten in
# place), and if Edge still will not map, revert every patch automatically.
set -e
export DISPLAY=:9

FILES="/opt/wine-staging/lib/wine/x86_64-unix/win32u.so \
/opt/wine-staging/lib/wine/x86_64-windows/wined3d.dll \
/opt/wine-staging/lib/wine/i386-windows/wined3d.dll"

apply_patch() { # $1 = target file (must already have .orig-rx480 beside it)
  F="$1"; B="$F.orig-rx480"
  [ -f "$B" ] || { echo "  no backup for $F - skip"; return; }
  cp -a "$B" "$F.tmp-patch"
  python3 - "$F.tmp-patch" <<'EOF'
import sys
f = sys.argv[1]
data = bytearray(open(f, 'rb').read())
old = b"Radeon (TM) RX 480 Graphics"
new = b"Radeon (TM) RX 580 Series\x00\x00"
n = data.count(old)
open(f, 'wb').write(data.replace(old, new) if n else data)
print(f"  {f}: {n} patched")
EOF
  mv -f "$F.tmp-patch" "$F"   # atomic: running processes keep the old inode
  echo -n "  verify $(basename $F): "
  strings "$F" | grep -oE "Radeon .TM. RX 58[0-9] [A-Za-z]+" | head -1
}

revert_all() {
  echo "== REVERTING all name patches (atomic) =="
  for F in $FILES; do B="$F.orig-rx480"; [ -f "$B" ] && cp -a "$B" "$F.tmp-r" && mv -f "$F.tmp-r" "$F" && echo "  reverted $F"; done
}

kill_wine() {
  wineserver -k 2>/dev/null || true
  sleep 1
  pkill -9 -x wineserver 2>/dev/null || true
  pkill -9 -f msedge 2>/dev/null || true
  sleep 2
}

echo "== [1] wineserver state before reset =="
pgrep -a wineserver 2>/dev/null | head -2 || echo "  (no wineserver!)"
P=$(pgrep -f msedge 2>/dev/null | head -1)
[ -n "$P" ] && awk '{print "  edge pid state:", $3}' /proc/$P/stat

echo "== [2] kill ALL wine processes, then re-apply patches ATOMICALLY =="
kill_wine
for F in $FILES; do apply_patch "$F"; done

echo "== [3] wait for the supervisor to relaunch Edge, poll the title =="
ok=""
for i in $(seq 1 50); do
  line=$(DISPLAY=:9 wmctrl -l 2>/dev/null | grep -iE "rx580check" | tail -1 | cut -c1-260)
  if [ -n "$line" ]; then
    printf '    t=%-3ss %s\n' "$((i*2))" "$line"
    case "$line" in
      *RX580CHECK*"RX 580 Series"*) ok="580"; break ;;
      *RX580CHECK*)                 ok="480"; break ;;
    esac
  fi
  sleep 2
done

if [ "$ok" = "580" ]; then
  echo "    >>> RX 580 NAME IS THROUGH"
elif [ -z "$ok" ]; then
  echo "    >>> Edge still will not map with the patches - auto-reverting"
  kill_wine
  for F in $FILES; do
    B="$F.orig-rx480"
    [ -f "$B" ] && cp -a "$B" "$F.tmp-r" && mv -f "$F.tmp-r" "$F" && echo "  reverted $(basename $F)"
  done
  echo "== final poll after revert (baseline must come back, name will read 480) =="
  for i in $(seq 1 40); do
    line=$(DISPLAY=:9 wmctrl -l 2>/dev/null | grep -iE "rx580check" | tail -1 | cut -c1-260)
    if [ -n "$line" ]; then printf '    t=%-3ss %s\n' "$((i*2))" "$line"; break; fi
    sleep 2
  done
fi