#!/bin/bash
# Root cause is Wine's loader deadlock ("RtlpWaitForCriticalSection ... loader_section wait
# timed out"), not DirectComposition - the DComp error is incidental. Chromium's multi-process
# startup is what trips it, so --single-process should sidestep it. Detection is now reliable:
# locate the window by WM_CLASS=msedge.exe and read its Map State (the old wmctrl/xwininfo-tree
# greps gave false negatives).
export DISPLAY=:9
W=/root/winelab
OUT="$W/out"
EXE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

probe() {  # probe <tag>  -> prints map state / procs / deadlock
  local tag="$1" wid="" info=""
  for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]{4,}' | head -50); do
    i=$(xwininfo -id "$w" 2>/dev/null) || continue
    case "$i" in *'Microsoft. Edge'*) wid="$w"; info="$i"; break;; esac
  done
  local procs; procs=$(pgrep -fc msedge 2>/dev/null || echo 0)
  local map="no-window"
  if [ -n "$wid" ]; then
    map=$(echo "$info" | grep -oE 'Map State: [A-Za-z]+' | head -1)
    geo=$(echo "$info" | grep -oE 'Width: [0-9]+' -A0 | head -1)
    map="$map win=$wid $(echo "$info" | grep -oE 'Width: [0-9]+|Height: [0-9]+' | tr '\n' ' ')"
  fi
  local dead="no"
  grep -q 'loader_section' "$OUT/m_$tag.log" 2>/dev/null && dead="YES"
  printf '  %-14s procs=%-3s deadlock=%-4s %s\n' "$tag" "$procs" "$dead" "$map"
}

run() {  # run <tag> <flags...>
  local tag="$1"; shift
  pkill -9 -f msedge 2>/dev/null
  pkill -9 -f wineserver 2>/dev/null
  sleep 4
  rm -rf "$W/m_$tag" 2>/dev/null
  setsid nohup wine "$EXE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update \
    --window-size=1200,700 --window-position=70,70 \
    --user-data-dir="C:\\m_$tag" --new-window "about:blank" \
    "$@" >"$OUT/m_$tag.log" 2>&1 &
  sleep 22
  probe "$tag"
}

echo "=== Edge flag matrix (window map state, procs, loader deadlock) ==="
run baseline
run nodcomp   --disable-direct-composition
run single    --single-process
run singlegpu --single-process --disable-gpu --disable-direct-composition
run nogpu     --disable-gpu --disable-direct-composition
echo

echo "=== leaving the most promising variant up for 25s to watch it ==="
pkill -9 -f msedge 2>/dev/null; pkill -9 -f wineserver 2>/dev/null; sleep 4
rm -rf "$W/m_live" 2>/dev/null
setsid nohup wine "$EXE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-sync --disable-component-update --disable-direct-composition \
  --window-size=1200,700 --window-position=70,70 \
  --user-data-dir='C:\m_live' --new-window "about:blank" \
  >"$OUT/m_live.log" 2>&1 &
for i in 1 2 3 4 5; do
  probe live
  sleep 5
done
echo
echo "  managed windows on :9:"
wmctrl -lp 2>/dev/null | sed 's/^/    /'
command -v import >/dev/null && import -window root "$OUT/edge-matrix.png" 2>/dev/null \
  && cp "$OUT/edge-matrix.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-edge-matrix.png" \
  && echo "  saved results/wine-edge-matrix.png"
