#!/bin/bash
# Who eats the memory when Edge runs on the RTX (Mesa d3d12)? Per-process RSS by
# Chromium process type, GPU-process PIDs over time (crash-loop = new PIDs), and
# a native (non-Wine) d3d12 control to separate Mesa from Wine/Edge.
export LC_ALL=C.UTF-8 DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all" GALLIUM_DRIVER=d3d12
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
OUT=/root/winelab/out
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
ANGLE="${1:-gl}"

echo "== control: native glxgears on d3d12 for 6s, RSS =="
if command -v glxgears >/dev/null; then
  glxgears >/dev/null 2>&1 & G=$!; sleep 6
  echo "  glxgears RSS=$(( $(awk '/VmRSS/{print $2}' /proc/$G/status) / 1024 ))MB  total used=$(free -m | awk 'NR==2{print $3}')MB"
  kill -9 $G
fi

pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
rm -rf /root/.wine/drive_c/t15
echo "== Edge --use-angle=$ANGLE : top RSS every 3s =="
( setsid nohup wine "$EDGE" --no-sandbox --no-first-run --no-default-browser-check \
    --disable-extensions --disable-sync --disable-component-update --renderer-process-limit=1 \
    --use-angle="$ANGLE" --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t15' --new-window \
    "file:///Z:/root/linuxlab/rx580-check.html#rx580" >"$OUT/edge-rtx.log" 2>&1 & )
declare -A seen
for i in $(seq 1 14); do
  sleep 3
  used=$(free -m | awk 'NR==2{print $3}')
  echo "-- t=$((i*3))s used=${used}MB"
  ps -eo pid,rss,args --sort=-rss | grep -E "msedge|wine" | grep -v grep | head -6 | \
    awk '{t="browser"; for(k=3;k<=NF;k++) if($k ~ /^--type=/){t=substr($k,8)}
          n=$3; sub(/.*[\\\/]/,"",n); printf "   pid=%-7s %6dMB %-12s %s\n",$1,$2/1024,t,n}'
  for p in $(pgrep -f -- "--type=gpu-process"); do
    [ -z "${seen[$p]}" ] && { seen[$p]=1; echo "   NEW gpu-process pid=$p"; }
  done
  if [ "$used" -gt 4200 ]; then echo "  !!! cap - kill"; break; fi
done
pkill -9 -f msedge; wineserver -k 2>/dev/null
echo "== gpu-process launches: ${#seen[@]} =="
echo "== edge log tail =="; tail -15 "$OUT/edge-rtx.log" | cut -c1-200
echo "== dmesg =="; dmesg | tail -5 | cut -c1-200
