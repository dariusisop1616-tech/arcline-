#!/bin/bash
# State of everything, unambiguously. Written as a file because inlining these loops
# through `wsl -- bash -lc "..."` keeps getting its $() expanded by the Windows shell first.
export DISPLAY=:9

echo "=== displays ==="
for d in :0 :9 :10; do
  if xdpyinfo -display "$d" >/dev/null 2>&1; then echo "  $d  UP"; else echo "  $d  down"; fi
done
echo

echo "=== wine / browser / installer processes ==="
ps -eo pid,etime,cmd 2>/dev/null \
  | grep -E 'chrome\.exe|msiexec|wineserver|Xvfb|msedge' \
  | grep -v grep | cut -c1-140 | sed 's/^/  /'
echo

echo "=== mapped windows on :9 (with owning pid) ==="
for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -40); do
  info=$(xwininfo -id "$w" 2>/dev/null) || continue
  echo "$info" | grep -q IsViewable || continue
  geo=$(echo "$info" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
  nm=$(echo "$info" | grep -oE '"[^"]*"' | head -1)
  pid=$(xprop -id "$w" _NET_WM_PID 2>/dev/null | grep -oE '[0-9]+$' | head -1)
  cls=$(xprop -id "$w" WM_CLASS 2>/dev/null | cut -d= -f2)
  printf '  %-10s %-22s pid=%-7s %-24s class=%s\n' "$w" "$geo" "${pid:-?}" "$nm" "$cls"
done
echo

echo "=== any chrome.exe / msedge names in the whole tree, mapped or not ==="
xwininfo -root -tree 2>/dev/null | grep -iE 'chrome|msedge|edge|wine' | head -15 | sed 's/^/  /'
echo

echo "=== logs ==="
for f in xvfb10.log lab10.png nowm.log wm.log msiexec.log; do
  p="/root/winelab/out/$f"
  [ -f "$p" ] && echo "  $f: $(stat -c%s "$p") bytes, $(stat -c%y "$p" | cut -c12-19)"
done
[ -f /root/winelab/edge/msiexec.log ] && echo "  edge/msiexec.log: $(stat -c%s /root/winelab/edge/msiexec.log) bytes"
echo
echo "  --- xvfb10.log tail (why did :10 die?) ---"
tail -8 /root/winelab/out/xvfb10.log 2>/dev/null | sed 's/^/    /'
echo
echo "  --- edge msiexec.log tail ---"
tail -12 /root/winelab/edge/msiexec.log 2>/dev/null | sed 's/^/    /'
echo
echo "=== edge extracted yet? ==="
echo "  exe.txt: $(cat /root/winelab/edge/exe.txt 2>/dev/null || echo none)"
echo "  7z out:  $(find /root/winelab/edge/z /root/winelab/edge/zc -type f 2>/dev/null | wc -l) files"
echo "  wine C:  $(find /root/.wine/drive_c -iname 'msedge.exe' 2>/dev/null | head -1 || echo none)"
