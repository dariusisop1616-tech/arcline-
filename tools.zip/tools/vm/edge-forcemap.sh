#!/bin/bash
# Edge creates a real top-level X window but it never gets MAPped, and its processes do not
# survive long. Bundle relaunch + force-map + watch into one script so there is no race, and
# clear the stale Wine processes first because they pushed the VM load average to ~9.
export DISPLAY=:9
W=/root/winelab
OUT="$W/out"
EXE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

echo "=== [1] clear stale wine load ==="
pkill -9 -f chrome.exe 2>/dev/null
pkill -9 -f msedge 2>/dev/null
pkill -9 -f msiexec 2>/dev/null
pkill -9 -f EdgeUpdate 2>/dev/null
pkill -9 -f MicrosoftEdgeUpdate 2>/dev/null
pkill -9 -f wineserver 2>/dev/null
sleep 5
echo "  load: $(cut -d' ' -f1 /proc/loadavg)"
echo "  remaining wine-ish procs: $(pgrep -fc 'wine|msedge|chrome.exe' 2>/dev/null || echo 0)"
echo

echo "=== [2] launch Edge ==="
rm -rf "$W/edge2" 2>/dev/null
setsid nohup wine "$EXE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-sync --disable-component-update \
  --window-size=1200,700 --window-position=70,70 \
  --user-data-dir='C:\edge2' --new-window "about:blank" \
  >"$OUT/edge2.log" 2>&1 &
sleep 18
echo "  msedge procs: $(pgrep -fc msedge 2>/dev/null || echo 0)"
echo

echo "=== [3] find Edge's X window and report its map state ==="
WID=""
for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]{4,}' | head -40); do
  info=$(xwininfo -id "$w" 2>/dev/null) || continue
  if echo "$info" | grep -q 'Microsoft. Edge'; then WID="$w"; break; fi
done
echo "  window: ${WID:-NOT FOUND}"
if [ -z "$WID" ]; then
  echo "  tree (first 25):"; xwininfo -root -tree 2>/dev/null | head -25 | sed 's/^/    /'
else
  xwininfo -id "$WID" 2>/dev/null | grep -iE 'absolute upper-left|width|height|map state|override-redirect' | sed 's/^/    /'
  echo "    --- xprop ---"
  xprop -id "$WID" WM_CLASS WM_STATE _NET_WM_STATE _NET_WM_WINDOW_TYPE _NET_WM_PID 2>/dev/null | sed 's/^/      /'
  echo
  echo "=== [4] force map it ==="
  command -v xdotool >/dev/null || apt-get install -y xdotool >/dev/null 2>&1
  if command -v xdotool >/dev/null; then
    xdotool windowmap --sync "$WID" 2>&1 | sed 's/^/    /'
    sleep 3
    echo "    --- map state after ---"
    xwininfo -id "$WID" 2>/dev/null | grep -iE 'map state' | sed 's/^/      /'
    xdotool windowraise "$WID" 2>/dev/null
    xdotool set_window --urgency 0 "$WID" 2>/dev/null
    sleep 2
    echo "    --- managed list ---"
    wmctrl -lp 2>/dev/null | sed 's/^/      /'
  else
    echo "    xdotool unavailable"
  fi
fi
echo

echo "=== [5] watch 20s: does it survive now? ==="
for i in 1 2 3 4 5; do
  echo "  t=$((i*4))s msedge=$(pgrep -fc msedge 2>/dev/null || echo 0) load=$(cut -d' ' -f1 /proc/loadavg)"
  sleep 4
done
echo

echo "=== [6] final: managed windows + screenshot ==="
wmctrl -lp 2>/dev/null | sed 's/^/  /'
command -v import >/dev/null && import -window root "$OUT/edge2.png" 2>/dev/null \
  && cp "$OUT/edge2.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-edge2.png" \
  && echo "  saved results/wine-edge2.png"
echo
echo "=== [7] log tail ==="
tail -18 "$OUT/edge2.log" 2>/dev/null | sed 's/^/  /'
