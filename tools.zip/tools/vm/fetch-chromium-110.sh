#!/bin/bash
# Milestone 110 of Windows Chromium - the last milestone before Chrome 111 made
# DirectComposition the default window-presentation path, which Wine does not implement.
# Revision 1083966 is the highest Win_x64 snapshot revision at or below the M110 stable
# branch position (1084008) that actually has a compiled archive in the bucket.
set -u
REV=1083966
B=https://commondatastorage.googleapis.com/chromium-browser-snapshots
OLD=/root/winelab/old
mkdir -p "$OLD"

echo "=== download Win_x64/$REV (milestone 110) ==="
curl -L --retry 3 --max-time 1800 \
  -o "$OLD/chrome-win.zip" \
  "$B/Win_x64/$REV/chrome-win.zip" \
  -w '  http %{http_code}  %{size_download} bytes  %{speed_download} B/s\n'
rc=$?
echo "  curl exit: $rc"
ls -la "$OLD/chrome-win.zip" 2>/dev/null | sed 's/^/  /'
if [ "$rc" != 0 ]; then echo "DOWNLOAD FAILED"; exit 1; fi

echo
echo "=== unzip ==="
rm -rf "$OLD/c110"
mkdir -p "$OLD/c110"
command -v unzip >/dev/null || { apt-get install -y unzip >/dev/null 2>&1 || true; }
unzip -q -o "$OLD/chrome-win.zip" -d "$OLD/c110" 2>&1 | tail -3
echo "  extracted: $(find "$OLD/c110" -maxdepth 2 -name chrome.exe | head -1)"

EXE=$(find "$OLD/c110" -maxdepth 3 -name chrome.exe | head -1)
if [ -z "$EXE" ]; then echo "NO chrome.exe IN ARCHIVE"; find "$OLD/c110" -maxdepth 2 | head -20; exit 1; fi
echo
echo "=== version stamp ==="
ls "$(dirname "$EXE")" | grep -iE 'chrome\.(exe|dll)|\.manifest$' | head -10 | sed 's/^/  /'
strings "$(dirname "$EXE")/chrome.dll" 2>/dev/null | grep -oE '1(0[89]|10)\.0\.[0-9]+\.[0-9]+' | sort -u | head -5 | sed 's/^/  version: /'
echo
echo "DOWNLOAD READY  exe=$EXE"
