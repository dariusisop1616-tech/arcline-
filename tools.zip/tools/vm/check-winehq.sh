#!/bin/bash
# Determine whether WineHQ ships a newer Wine we can install on this distro, since the
# distro build cannot map Chromium's window.
set -u
. /etc/os-release
echo "=== distro ==="
echo "  PRETTY_NAME    = ${PRETTY_NAME:-?}"
echo "  VERSION_CODENAME = ${VERSION_CODENAME:-?}"
echo "  UBUNTU_CODENAME  = ${UBUNTU_CODENAME:-?}"
echo "  arch = $(dpkg --print-architecture)"
echo

echo "=== wine packages currently installed ==="
dpkg -l | grep -i '^ii  wine' | awk '{print "  "$2"  "$3}' | head -12
echo "  wine --version: $(wine --version 2>/dev/null)"
echo

echo "=== WineHQ suites published ==="
curl -s --max-time 25 https://dl.winehq.org/wine-builds/ubuntu/dists/ \
  | grep -oE 'href="[a-z-]+/"' | sed 's/href="//; s#/"##' | sort -u | sed 's/^/  /'
echo

echo "=== does WineHQ have this distro's codename? ==="
CN="${VERSION_CODENAME:-}"
if [ -n "$CN" ]; then
  if curl -s --max-time 25 https://dl.winehq.org/wine-builds/ubuntu/dists/ | grep -q "/$CN/"; then
    echo "  YES - winehq publishes for '$CN'"
  else
    echo "  NO - winehq does not publish for '$CN'"
  fi
fi
echo

echo "=== what wine versions does WineHQ offer for focal/plucky/noble (for reference)? ==="
for s in noble plucky oracular; do
  v=$(curl -s --max-time 20 "https://dl.winehq.org/wine-builds/ubuntu/dists/$s/main/binary-amd64/Packages" 2>/dev/null \
      | grep -A1 '^Package: winehq-staging$' | grep '^Version:' | head -1)
  echo "  $s: ${v:-not published}"
done
echo

echo "=== does this box already have the WineHQ key/repo? ==="
echo "  /etc/apt/sources.list.d entries mentioning wine: $(grep -rl wine /etc/apt/sources.list.d/ 2>/dev/null | head -3)"
echo "  keyrings: $(ls /etc/apt/keyrings 2>/dev/null | grep -i wine | head -3 || echo none)"
