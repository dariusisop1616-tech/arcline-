#!/bin/bash
# Get the real Microsoft Edge for Windows (stable, x64) and unpack it - no old builds.
# Microsoft publishes the enterprise MSI through a stable JSON API, so this is scriptable
# and versioned rather than scraping a download page. The MSI is extracted rather than
# installed: Edge's installer runs custom actions that do not survive Wine, but the
# extracted tree runs msedge.exe directly.
set -u
W=/root/winelab
EDGE="$W/edge"
mkdir -p "$EDGE"

echo "=== [1] query the Edge update API ==="
for view in enterprise consumer; do
  echo "--- view=$view ---"
  curl -s --max-time 30 "https://edgeupdates.microsoft.com/api/products?view=$view" \
    -o "$EDGE/api-$view.json" -w '  http %{http_code}  %{size_download} bytes\n'
done
ls -la "$EDGE"/*.json 2>/dev/null | sed 's/^/  /'
echo

echo "=== [2] find the stable Windows x64 MSI ==="
python3 - "$EDGE" <<'PY'
import json, sys, os
d = sys.argv[1]
best = None
for view in ("enterprise", "consumer"):
    p = os.path.join(d, f"api-{view}.json")
    if not os.path.exists(p): continue
    try: data = json.load(open(p))
    except Exception as e: print(f"  {view}: parse error {e}"); continue
    for prod in data:
        if str(prod.get("Product","")).lower() != "stable": continue
        for rel in prod.get("Releases", []):
            ver = rel.get("ProductVersion","?")
            for art in rel.get("Artifacts", []):
                if art.get("Platform") != "Windows": continue
                if art.get("Architecture") not in ("x64","x86"): continue
                if "msi" not in str(art.get("ArtifactType","")).lower(): continue
                url = art.get("Location","")
                if not url: continue
                # prefer x64
                score = (1 if art.get("Architecture")=="x64" else 0)
                if best is None or score > best[0] or (score==best[0]):
                    if best is None or score > best[0]:
                        best = (score, ver, art.get("Architecture"), url, view)
if best:
    print(f"  VERSION {best[1]}  arch={best[2]}  view={best[4]}")
    print(f"  URL {best[3]}")
    open(os.path.join(d,"msi_url.txt"),"w").write(best[3]+"\n")
    open(os.path.join(d,"msi_ver.txt"),"w").write(best[1]+"\n")
else:
    print("  NO MSI FOUND IN API RESPONSE")
    # show what products/versions exist to adapt
    for view in ("enterprise","consumer"):
        p = os.path.join(d, f"api-{view}.json")
        if not os.path.exists(p): continue
        try: data = json.load(open(p))
        except Exception: continue
        for prod in data[:3]:
            rels = prod.get("Releases", [])
            print(f"   {view}: product={prod.get('Product')} releases={len(rels)} "
                  f"latest={rels[0].get('ProductVersion') if rels else '?'}")
            if rels:
                for art in rels[0].get("Artifacts", [])[:6]:
                    print(f"      {art.get('Platform')}/{art.get('Architecture')}/"
                          f"{art.get('ArtifactType')}")
PY
echo

echo "=== [3] download the MSI ==="
URL=$(cat "$EDGE/msi_url.txt" 2>/dev/null)
if [ -z "$URL" ]; then echo "  no url - stopping"; exit 1; fi
curl -L --retry 3 --max-time 1200 -o "$EDGE/edge.msi" "$URL" \
  -w '  http %{http_code}  %{size_download} bytes\n'
ls -la "$EDGE/edge.msi" | sed 's/^/  /'
echo

echo "=== [4] extract the MSI ==="
command -v msiextract >/dev/null || apt-get install -y msitools >/dev/null 2>&1
if command -v msiextract >/dev/null; then
  rm -rf "$EDGE/x"; mkdir -p "$EDGE/x"
  (cd "$EDGE/x" && msiextract "$EDGE/edge.msi" >/dev/null 2>&1)
  echo "  extracted entries: $(find "$EDGE/x" -type f 2>/dev/null | wc -l)"
  EXE=$(find "$EDGE/x" -iname msedge.exe | head -1)
  echo "  msedge.exe: ${EXE:-NOT FOUND}"
  find "$EDGE/x" -maxdepth 3 -type d 2>/dev/null | head -12 | sed 's/^/    /'
  [ -n "$EXE" ] && echo "$EXE" > "$EDGE/exe.txt"
else
  echo "  msitools unavailable"
fi
echo
echo "EDGE READY ver=$(cat "$EDGE/msi_ver.txt" 2>/dev/null) exe=$(cat "$EDGE/exe.txt" 2>/dev/null)"
