#!/bin/bash
# Edge creates its top-level X window ("Untitled - Profile 1 - Microsoft Edge") and stays
# alive with 7 processes, but the window never appears in the managed list - i.e. it is
# created and possibly painted, just never MAPped. If so, mapping it ourselves should make
# it visible, which would be a real workaround rather than a flag guess.
export DISPLAY=:9
OUT=/root/winelab/out

find_edge_win() {
  for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]{4,}' | head -40); do
    info=$(xwininfo -id "$w" 2>/dev/null) || continue
    case "$info" in *"Microsoft​ Edge"*|*"Microsoft Edge"*) echo "$w"; return;; esac
  done
}

W=$(find_edge_win)
echo "### edge window: ${W:-NOT FOUND}"
[ -z "$W" ] && { echo "  full tree:"; xwininfo -root -tree 2>/dev/null | head -30 | sed 's/^/    /'; exit 1; }
echo

echo "=== [1] its current state ==="
xwininfo -id "$W" 2>/dev/null | sed 's/^/  /'
echo
echo "  --- WM_CLASS / WM_STATE / type ---"
xprop -id "$W" WM_CLASS WM_STATE _NET_WM_STATE _NET_WM_WINDOW_TYPE _NET_WM_PID 2>/dev/null | sed 's/^/  /'
echo
echo "  --- geometry in detail ---"
xwininfo -id "$W" -stats 2>/dev/null | grep -iE 'absolute|relative|width|height|map state|override' | sed 's/^/  /'
echo

echo "=== [2] does the X server think it has content? (attributes) ==="
xwininfo -id "$W" -bits -events 2>/dev/null | head -20 | sed 's/^/  /'
echo

echo "=== [3] force-map it and see what happens ==="
command -v xdotool >/dev/null || apt-get install -y xdotool >/dev/null 2>&1
if command -v xdotool >/dev/null; then
  echo "  xdotool windowmap $W"
  xdotool windowmap "$W" 2>&1 | sed 's/^/    /'
  sleep 3
  echo "  --- state after windowmap ---"
  xwininfo -id "$W" 2>/dev/null | grep -iE 'map state|width|height|absolute upper-left' | sed 's/^/    /'
  echo "  --- now raise it and give it focus ---"
  xdotool windowraise "$W" 2>/dev/null
  xdotool windowactivate "$W" 2>/dev/null || echo "    (activate failed - no WM hint)"
  sleep 2
  echo "  --- managed list now ---"
  wmctrl -lp 2>/dev/null | sed 's/^/    /'
else
  echo "  xdotool unavailable"
fi
echo

echo "=== [4] screenshot after force-map ==="
command -v import >/dev/null && import -window root "$OUT/edge-mapped.png" 2>/dev/null \
  && cp "$OUT/edge-mapped.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-edge-mapped.png" \
  && echo "  saved results/wine-edge-mapped.png"
echo
echo "=== [5] is edge still alive? ==="
echo "  msedge procs: $(pgrep -fc msedge 2>/dev/null || echo 0)"
echo "  log tail:"
tail -6 "$OUT/edge.log" 2>/dev/null | sed 's/^/    /'
