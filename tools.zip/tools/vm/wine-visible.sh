#!/bin/bash
# Put the WINDOWS build of Chrome on the visible display under Wine, and check whether its
# window actually maps this time. Earlier attempts ran against WSLg, which renders nothing;
# this display is real Xvfb + fluxbox, where a native Linux Chrome maps fine - so the
# question is whether Wine's Windows Chrome can too.
export DISPLAY=:9
LAB=/root/linuxlab
W=/root/winelab
EXE="$W/chrome/chrome.exe"
PROF="$W/cd_visible"

echo "=== [1] what are we launching ==="
ls -la "$EXE" 2>&1 | head -2
wine --version 2>&1 | head -1
echo "  chrome.exe version:"
wine "$EXE" --version 2>/dev/null | tail -1 || true
echo

echo "=== [2] launch under Wine on DISPLAY=:9 ==="
pkill -9 -f chrome.exe 2>/dev/null
rm -rf "$PROF" 2>/dev/null
sleep 2
setsid nohup wine "$EXE" \
  --no-sandbox \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1200,760 --window-position=60,80 \
  --user-data-dir='C:\cd_visible' \
  --new-window "about:blank" \
  >"$W/out/visible.log" 2>&1 &
sleep 22

echo "=== [3] did a window map? ==="
echo "--- wmctrl (window manager's client list) ---"
wmctrl -l 2>/dev/null | sed 's/^/  /' || echo "  (empty)"
echo "--- xwininfo tree, chrome/wine ---"
xwininfo -root -tree 2>/dev/null | grep -iE 'chrome|wine|desktop' | head -10 | sed 's/^/  /'
echo
echo "--- process count ---"
echo "  chrome.exe procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
echo
echo "=== [4] any map-state detail ==="
for w in $(xwininfo -root -children 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -12); do
  n=$(xwininfo -id "$w" 2>/dev/null | grep -c 'IsViewable')
  if [ "$n" = "1" ]; then
    echo "  $w -> IsViewable : $(xwininfo -id "$w" 2>/dev/null | grep -oE '"[^"]*"' | head -1)"
  fi
done
echo
echo "=== [5] screenshot ==="
command -v import >/dev/null && import -window root "$W/out/visible.png" 2>/dev/null \
  && cp "$W/out/visible.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-chrome-visible.png" \
  && echo "  saved results/wine-chrome-visible.png"
echo
echo "=== [6] log tail ==="
tail -8 "$W/out/visible.log" 2>/dev/null | sed 's/^/  /'
