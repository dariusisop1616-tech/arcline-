#!/bin/bash
# Two things:
#  [A] confirm the chrome window's real MAP STATE (unmapped == drawn nowhere, no WM frame)
#  [B] test Wine's VIRTUAL DESKTOP: one X window that Wine owns and renders the whole
#      Windows session into. This is the classic fix when an app's own window never maps.

export LC_ALL=C.UTF-8
LAB="$HOME/winelab"
export WINEPREFIX="$LAB/prefix"
export WINEDEBUG="-all"
export PATH="$PATH:/usr/lib/x86_64-linux-gnu/wine"
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe
export DISPLAY=:9

REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT="$REPO/results/vm-display"
mkdir -p "$OUT" "$LAB/out"
pkill -x xmessage 2>/dev/null

CHROME_ARGS=(--no-sandbox --disable-dev-shm-usage
  --use-angle=swiftshader --ignore-gpu-blocklist
  --no-first-run --no-default-browser-check --disable-extensions
  --window-size=1280,800)

echo "################ [A] map state of a plain run ################"
pkill -f chrome.exe 2>/dev/null; sleep 3
wine "$LAB/chrome/chrome.exe" "${CHROME_ARGS[@]}" \
  --user-data-dir="$LAB/cd_map" \
  "file:///Z:/root/winelab/show.html" >"$LAB/out/map.log" 2>&1 &
sleep 25
echo "--- chrome procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
for id in $(xwininfo -root -tree 2>/dev/null | grep -i chrome | grep -oE '0x[0-9a-f]+' | sort -u); do
  ms=$(xwininfo -id "$id" 2>/dev/null | grep -i 'Map State' | head -1 | sed 's/^ *//')
  nm=$(xwininfo -id "$id" 2>/dev/null | grep -i 'Width\|Height' | tr -d '\n' | sed 's/  */ /g')
  echo "  $id | $ms | $nm"
done
echo "--- what the WM knows about (_NET_CLIENT_LIST):"
xprop -root _NET_CLIENT_LIST 2>/dev/null | sed 's/^/  /'
xprop -root _NET_CLIENT_LIST_STACKING 2>/dev/null | sed 's/^/  /'
echo "--- every mapped window on :9 (IsViewable):"
for id in $(xwininfo -root -children 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -40); do
  xwininfo -id "$id" 2>/dev/null | grep -q 'IsViewable' && \
    xwininfo -id "$id" 2>/dev/null | awk -v i="$id" '/Window id/{n=$0} /Width:/{w=$2} /Height:/{h=$2} END{print "    "i" "w"x"h" "n}'
done

echo
echo "################ [B] Wine VIRTUAL DESKTOP ################"
pkill -f chrome.exe 2>/dev/null; sleep 3
wine explorer /desktop=lab,1440x900 "$LAB/chrome/chrome.exe" "${CHROME_ARGS[@]}" \
  --user-data-dir="$LAB/cd_vd" \
  "file:///Z:/root/winelab/show.html" >"$LAB/out/vd.log" 2>&1 &
sleep 35
echo "--- chrome procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
echo "--- all windows:"
xwininfo -root -tree 2>/dev/null | grep -iE 'chrome|explorer|lab|desktop' | sed 's/^/  /' | head -10
echo "--- mapped/viewable windows:"
for id in $(xwininfo -root -children 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -40); do
  xwininfo -id "$id" 2>/dev/null | grep -q 'IsViewable' && \
    xwininfo -id "$id" 2>/dev/null | awk -v i="$id" '/Window id/{n=$0} /Width:/{w=$2} /Height:/{h=$2} END{print "    "i" "w"x"h" "n}'
done
import -window root -display :9 "$OUT/vdesktop.png" 2>/dev/null \
  && echo "--- shot: results/vm-display/vdesktop.png ($(stat -c%s "$OUT/vdesktop.png") bytes)"
echo "--- log:"; grep -viE 'alsa|pcm|conf' "$LAB/out/vd.log" 2>/dev/null | tail -5 | sed 's/^/    /'
echo "=== DONE ==="
