#!/bin/bash
# Why does Wine Chrome create a window but never PAINT on :9?
# Variant D proved: --use-angle=d3d11 CRASHES (no D3D11 device in this prefix);
# --use-gl=angle --use-angle=gl SURVIVES and allocates a real 1272x766 window,
# but nothing appears. Test the surviving backend plus compositing overrides,
# with a long wait, and inspect the window's real map state.

export LC_ALL=C.UTF-8
LAB="$HOME/winelab"
export WINEPREFIX="$LAB/prefix"
export WINEDEBUG="-all"
export PATH="$PATH:/usr/lib/x86_64-linux-gnu/wine"
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe
export DISPLAY=:9

REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT="$REPO/results/vm-display"
mkdir -p "$OUT" "$LAB/out"
pkill -x xmessage 2>/dev/null
xsetroot -solid '#101418' 2>/dev/null

inspect() {
  local tag="$1"
  echo "  -- chrome.exe procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
  echo "  -- real chrome windows & MAP STATE:"
  for id in $(xwininfo -root -tree 2>/dev/null | grep -i 'chrome.exe' | grep -oP '0x[0-9a-f]+' ); do
    xwininfo -id "$id" 2>/dev/null | awk -v id="$id" '
      /Window id/ {w=$0}
      /Map State/ {m=$3}
      /Width|Height/ {next}
      /Absolute upper-left X/ {ax=$NF}
      /Absolute upper-left Y/ {ay=$NF}
      /^  Width/ {wd=$2}
      /^  Height/ {ht=$2; printf "     %s map=%s size=%sx%s at=%s,%s\n", id, m, wd, ht, ax, ay}'
  done
  if command -v import >/dev/null 2>&1; then
    import -window root -display :9 "$OUT/paint_$tag.png" 2>/dev/null \
      && echo "     shot: results/vm-display/paint_$tag.png"
  fi
}

run() {
  local tag="$1"; shift
  local url="$1"; shift
  echo
  echo "=============================================================="
  echo "# $tag"
  echo "=============================================================="
  pkill -f chrome.exe 2>/dev/null; sleep 3
  wine "$LAB/chrome/chrome.exe" \
    --no-sandbox --disable-dev-shm-usage \
    --no-first-run --no-default-browser-check --disable-extensions \
    --window-size=1280,800 --window-position=20,20 \
    --user-data-dir="$LAB/cd_p_$tag" \
    "$@" "$url" >"$LAB/out/p_$tag.log" 2>&1 &
  sleep 40
  inspect "$tag"
  echo "  -- log (errors):"
  grep -iE 'error|fail|crash' "$LAB/out/p_$tag.log" 2>/dev/null | tail -4 | sed 's/^/     /'
  echo "  -- log (last 3):"
  tail -3 "$LAB/out/p_$tag.log" 2>/dev/null | sed 's/^/     /'
}

# E: surviving backend + force software compositing AND no direct composition
run E "file:///Z:/root/winelab/show.html" \
  --use-gl=angle --use-angle=gl --ignore-gpu-blocklist \
  --disable-gpu-compositing --disable-direct-composition

# F: Chrome's OWN SwiftShader through ANGLE (known deterministic under Wine)
run F "file:///Z:/root/winelab/show.html" \
  --use-gl=angle --use-angle=swiftshader --disable-gpu-compositing --disable-direct-composition

# G: about:blank - removes the page-load variable entirely
run G "about:blank" \
  --use-gl=angle --use-angle=swiftshader --disable-gpu-compositing --disable-direct-composition

# H: Wine's own opengl32 as the GL implementation (no ANGLE)
run H "about:blank" \
  --use-gl=desktop --disable-gpu-compositing --disable-direct-composition

echo
echo "=== ALL WINDOWS ON :9 (mapped, with geometry) ==="
xwininfo -root -tree 2>/dev/null | grep -E 'chrome|notepad' | sed 's/^/  /' | head -20
echo "=== DONE ==="
