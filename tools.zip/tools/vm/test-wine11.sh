#!/bin/bash
# After upgrading to winehq-staging 11.18, migrate the prefix and retest Edge with continuous
# probing (the window was transient before, so single samples missed it).
export DISPLAY=:9
# WineHQ's staging installs under /opt and does not put `wine` on PATH (the distro package
# that owned /usr/bin/wine is gone), so point at it explicitly.
export PATH="/opt/wine-staging/bin:$PATH"
W=/root/winelab
OUT="$W/out"
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

echo "=== [1] which wine are we on now? ==="
command -v wine | sed 's/^/  resolved: /'
wine --version 2>&1 | sed 's/^/  version:  /'
echo "  dcomp.dll builtin size: $(stat -c%s /usr/lib/x86_64-linux-gnu/wine/x86_64-windows/dcomp.dll 2>/dev/null || echo 'n/a')"
echo

echo "=== [2] stop everything and migrate the prefix ==="
pkill -9 -f msedge 2>/dev/null; pkill -9 -f 'chrome\.exe' 2>/dev/null
wineserver -k 2>/dev/null; sleep 4
echo "  wineboot -u ..."
timeout 120 wineboot -u >"$OUT/wineboot.log" 2>&1
echo "  exit=$? (0 or 124-timeout are both informative)"
tail -5 "$OUT/wineboot.log" 2>/dev/null | sed 's/^/    /'
echo

echo "=== [3] launch Edge, probe every 2s for 44s ==="
rm -rf "$W/t11" 2>/dev/null
setsid nohup wine "$EDGE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-sync --disable-component-update \
  --window-size=1200,700 --window-position=60,60 \
  --user-data-dir='C:\t11' --new-window "about:blank" >"$OUT/t11.log" 2>&1 &
prev=""
for i in $(seq 1 22); do
  line=$(xwininfo -root -tree 2>/dev/null | grep -i 'msedge\.exe' | head -1)
  wid=$(echo "$line" | grep -oE '0x[0-9a-f]{4,}' | head -1)
  procs=$(pgrep -fc msedge 2>/dev/null || echo 0)
  if [ -n "$wid" ]; then
    st=$(xwininfo -id "$wid" 2>/dev/null | grep -oE 'Map State: [A-Za-z]+' | head -1)
    geo=$(echo "$line" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
  else
    st="no-window"; geo=""
  fi
  cur="procs=$procs $st $geo"
  [ "$cur" != "$prev" ] && printf '  t=%-3ss %s\n' "$((i*2))" "$cur"
  prev="$cur"
  sleep 2
done
echo

echo "=== [4] managed windows (would prove the WM accepted it) ==="
wmctrl -lp 2>/dev/null | grep -viE 'Chrome for Testing|RX580' | sed 's/^/  /'
echo "  (if Edge appears above, it is mapped and visible)"
echo

echo "=== [5] log: DComp / deadlock / errors ==="
printf '  DComp=%s deadlock=%s bytes=%s\n' \
  "$(grep -c DCompositionCreateDevice "$OUT/t11.log" 2>/dev/null)" \
  "$(grep -c loader_section "$OUT/t11.log" 2>/dev/null)" \
  "$(stat -c%s "$OUT/t11.log" 2>/dev/null)"
grep -iE 'ERROR|unimplemented|abort|wine:' "$OUT/t11.log" 2>/dev/null | head -10 | sed 's/^/    /'
echo
echo "=== [6] screenshot ==="
command -v import >/dev/null && import -window root "$OUT/t11.png" 2>/dev/null \
  && cp "$OUT/t11.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine11-edge.png" \
  && echo "  saved results/wine11-edge.png"
