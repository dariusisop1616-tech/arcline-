#!/bin/bash
# 1. Is the display stack still healthy? (fluxbox alive? WM present?)
# 2. --disable-gpu  -- I checked its window SIZE earlier but never its MAP STATE.
#    Pure software compositing blits through GDI, so it is the best candidate to map.
# 3. Wine REGISTRY-level virtual desktop (more reliable than `explorer /desktop`).

export LC_ALL=C.UTF-8
LAB="$HOME/winelab"
export WINEPREFIX="$LAB/prefix"
export WINEDEBUG="-all"
export PATH="$PATH:/usr/lib/x86_64-linux-gnu/wine"
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe
export DISPLAY=:9

REPO="/mnt/c/Users/Darkking1/Desktop/similar to gologin"
OUT="$REPO/results/vm-display"
mkdir -p "$OUT" "$LAB/out"

show_windows() {
  local viewable=0
  for id in $(xwininfo -root -tree 2>/dev/null | grep -iE 'chrome|msedge|explorer|wine' | grep -oE '0x[0-9a-f]+' | sort -u); do
    ms=$(xwininfo -id "$id" 2>/dev/null | grep -i 'Map State' | head -1 | awk '{print $NF}')
    wh=$(xwininfo -id "$id" 2>/dev/null | grep -E '^  Width|^  Height' | awk '{print $2}' | tr '\n' 'x')
    nm=$(xwininfo -id "$id" 2>/dev/null | grep -oP '(?<=")[^"]*(?=")' | head -1)
    echo "      $id  map=$ms size=$wh  \"$nm\""
    [ "$ms" = "IsViewable" ] && viewable=$((viewable+1))
  done
  echo "      >>> VIEWABLE: $viewable"
}

echo "=== display stack health ==="
for p in Xvfb fluxbox x11vnc websockify; do
  echo "  $p: $(pgrep -xc "$p" 2>/dev/null)"
done
echo "  WM check:"; xprop -root _NET_SUPPORTING_WM_CHECK 2>/dev/null | sed 's/^/    /'

echo
echo "################ [2] --disable-gpu, map state ################"
pkill -f chrome.exe 2>/dev/null; pkill -f msedge.exe 2>/dev/null; sleep 3
wine "$LAB/chrome/chrome.exe" \
  --no-sandbox --disable-dev-shm-usage --disable-gpu \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1280,800 \
  --user-data-dir="$LAB/cd_ng2" \
  'file:///Z:/root/winelab/show.html' >"$LAB/out/ng2.log" 2>&1 &
sleep 35
echo "  chrome procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
show_windows
import -window root -display :9 "$OUT/ng2.png" 2>/dev/null && echo "  shot: results/vm-display/ng2.png"

echo
echo "################ [3] registry virtual desktop ################"
wine reg add 'HKCU\Software\Wine\Explorer' /v Desktop /d lab /f >/dev/null 2>&1
wine reg add 'HKCU\Software\Wine\Explorer\Desktops' /v lab /d 1440x900 /f >/dev/null 2>&1
pkill -f chrome.exe 2>/dev/null; sleep 3
wine "$LAB/chrome/chrome.exe" \
  --no-sandbox --disable-dev-shm-usage --disable-gpu \
  --no-first-run --no-default-browser-check --disable-extensions \
  --window-size=1280,800 \
  --user-data-dir="$LAB/cd_regvd" \
  'file:///Z:/root/winelab/show.html' >"$LAB/out/regvd.log" 2>&1 &
sleep 35
echo "  chrome procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
show_windows
import -window root -display :9 "$OUT/regvd.png" 2>/dev/null && echo "  shot: results/vm-display/regvd.png"

echo
echo "  --- undo registry change ---"
wine reg delete 'HKCU\Software\Wine\Explorer\Desktops' /v lab /f >/dev/null 2>&1
wine reg delete 'HKCU\Software\Wine\Explorer' /v Desktop /f >/dev/null 2>&1
echo "=== DONE ==="
