#!/bin/bash
# Root cause found: Chrome presents its window through DirectComposition
#   ui\gl\direct_composition_support.cc:767 DCompositionCreateDevice3 failed: Not implemented (0x80004001)
# Wine does not implement that API, so Chrome builds its window (1192x726) and never maps it.
# Chrome exposes --disable-direct-composition for exactly this. Test that, and the
# compositing/gpu fallbacks, and report Map State for each.
export DISPLAY=:9
W=/root/winelab
EXE="$W/chrome/chrome.exe"

kill_wine() { pkill -9 -f chrome.exe 2>/dev/null; sleep 3; }

check() {  # check <tag>
  local found=0
  for w in $(xwininfo -root -tree 2>/dev/null | grep -oE '0x[0-9a-f]+' | head -30); do
    info=$(xwininfo -id "$w" 2>/dev/null)
    geo=$(echo "$info" | grep -oE '[0-9]+x[0-9]+\+[-0-9]+\+[-0-9]+' | head -1)
    # only care about big chrome.exe windows
    if echo "$info" | grep -q 'chrome.exe' && echo "$geo" | grep -qE '^(1[0-9]{3}|[6-9][0-9]{2})x'; then
      if echo "$info" | grep -q 'IsViewable'; then
        echo "    *** MAPPED *** $w $geo $(echo "$info" | grep -oE '"[^"]*"' | head -1)"
        found=1
      else
        echo "    unmapped      $w $geo"
      fi
    fi
  done
  [ "$found" = 0 ] && echo "    (no chrome.exe window mapped)"
  echo "    procs: $(pgrep -fc chrome.exe 2>/dev/null || echo 0)"
}

run() {  # run <tag> <flags...>
  local tag="$1"; shift
  kill_wine
  rm -rf "$W/cd_$tag" 2>/dev/null
  echo "=== $tag : $* ==="
  setsid nohup wine "$EXE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --window-size=1200,700 \
    --user-data-dir="C:\\cd_$tag" --new-window "about:blank" \
    "$@" >"$W/out/$tag.log" 2>&1 &
  sleep 20
  check "$tag"
  echo "    dcomp errors: $(grep -c 'DCompositionCreateDevice' "$W/out/$tag.log" 2>/dev/null)"
  echo
}

run dcomp    --disable-direct-composition
run dcompgpu --disable-direct-composition --disable-gpu
run dcompv   --disable-direct-composition --use-angle=vulkan --enable-features=Vulkan
run gpucp    --disable-gpu-compositing

echo "=== leave the most promising one running and screenshot ==="
kill_wine
setsid nohup wine "$EXE" \
  --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
  --disable-direct-composition \
  --window-size=1200,700 --window-position=50,70 \
  --user-data-dir='C:\cd_live' --new-window "about:blank" \
  >"$W/out/live.log" 2>&1 &
sleep 22
check live
command -v import >/dev/null && import -window root "$W/out/live.png" 2>/dev/null \
  && cp "$W/out/live.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/wine-chrome-live.png" \
  && echo "  screenshot: results/wine-chrome-live.png"
