#!/bin/bash
# WebGL is reporting "no context" even with no interposer at all, so --use-angle=vulkan
# is not viable here: ANGLE rejects the lavapipe device with
#   "ANGLE Requires a minimum Vulkan device version of 1.1" / Internal Vulkan error (-9)
# Sweep the backends and find one that actually yields a WebGL context on this display.
# The window title carries the renderer string, so results are readable without pixels.
LAB=/root/linuxlab
DIR=/root/vklayer
CHROME="$LAB/chrome/chrome"
export DISPLAY=:9
PAGE="file://$LAB/rx580-check.html"

try() {  # try <tag> <flags...>
  local tag="$1"; shift
  pkill -f "cd_$tag" 2>/dev/null
  sleep 1
  env -u LD_PRELOAD \
      VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json \
      setsid nohup "$CHROME" \
        --no-sandbox --disable-dev-shm-usage \
        --no-first-run --no-default-browser-check \
        --window-size=1100,650 --window-position=60,80 \
        --user-data-dir="$LAB/cd_$tag" \
        --enable-logging=stderr \
        "$@" "$PAGE" >"$LAB/out/$tag.log" 2>&1 &
  sleep 10
  local t
  t=$(wmctrl -l 2>/dev/null | grep -o 'RX580CHECK[^|]*|[^|]*renderer[^|]*' | head -1)
  [ -z "$t" ] && t=$(wmctrl -l 2>/dev/null | grep -o 'webgl[^|]*' | head -1)
  printf '  %-46s %s\n' "$tag" "${t:-<no window>}"
  pkill -f "cd_$tag" 2>/dev/null
  sleep 1
}

echo "=== what does lavapipe actually claim? ==="
VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json "$DIR/vulkan_probe" 2>&1 \
  | grep -E 'deviceName|vendorID|deviceID|driverName' | head -4
echo

echo "=== backend sweep (fresh profile each, 10s settle) ==="
try bk_default
try bk_gl        --use-angle=gl
try bk_gl_ig     --use-gl=angle --use-angle=gl --ignore-gpu-blocklist
try bk_vulkan    --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist
try bk_sw        --use-angle=swiftshader --enable-unsafe-swiftshader
try bk_d3d11     --use-angle=d3d11

echo
echo "=== key errors per backend ==="
for t in bk_default bk_gl bk_gl_ig bk_vulkan bk_sw bk_d3d11; do
  echo "--- $t ---"
  grep -iE 'ANGLE Requires|Internal Vulkan error|EGL_NOT_INITIALIZED|WGL_|gl_display|SwiftShader|GLDisplay|Failed to create' \
    "$LAB/out/$t.log" 2>/dev/null | head -3 || echo "  (no GL errors)"
done
