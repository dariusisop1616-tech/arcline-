#!/bin/bash
# Real-GPU WebGL: Edge's own Windows default backend on the host RTX 3060 Ti.
#   ANGLE-D3D11 -> Wine d3d11/dxgi -> wined3d (renderer=gl) -> Wine GLX
#   -> Mesa gallium d3d12 -> /dev/dxg -> RTX 3060 Ti
# The earlier D3D11 memory bomb ran on llvmpipe (software); this one runs on the
# GPU. A watchdog still kills Edge before vmmem can take WSL down.
export LC_ALL=C.UTF-8
export DISPLAY=:9
export PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml="
export WINEDEBUG="-all"
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
export GALLIUM_DRIVER=d3d12
OUT=/root/winelab/out; mkdir -p "$OUT"
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
ANGLE="${1:-d3d11}"
EXTRA="${2:-}"   # extra Chromium flags (process-count reduction experiments)
PROFILE='C:\t15'
HEADROOM=1200 # MB of RAM-available + swap-free we never go below (VM: 5925 RAM + 4096 swap)

echo "== [0] clean slate =="
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 1
pkill -9 -x wineserver 2>/dev/null; sleep 1
rm -rf /root/.wine/drive_c/t15 2>/dev/null

echo "== [1] display stack =="
if ! xdpyinfo >/dev/null 2>&1; then
  pkill -9 -f 'Xvfb :9' 2>/dev/null; pkill -9 -x x11vnc 2>/dev/null
  pkill -9 -f websockify 2>/dev/null; pkill -9 -x fluxbox 2>/dev/null
  rm -f /tmp/.X11-unix/X9 /tmp/.X9-lock; sleep 1
  setsid nohup Xvfb :9 -screen 0 1440x900x24 -ac >"$OUT/xvfb.log" 2>&1 &
  sleep 3
fi
pgrep -x fluxbox >/dev/null || { setsid nohup fluxbox >"$OUT/fluxbox.log" 2>&1 & sleep 2; }
pgrep -x x11vnc >/dev/null || { ( unset WAYLAND_DISPLAY XDG_RUNTIME_DIR
  setsid nohup x11vnc -display :9 -forever -shared -nopw -quiet -rfbport 5901 \
    -noxdamage -xkb -o "$OUT/x11vnc.log" >/dev/null 2>&1 & ); sleep 2; }
pgrep -f websockify >/dev/null || { setsid nohup websockify --web=/usr/share/novnc 6080 \
  localhost:5901 >"$OUT/websockify.log" 2>&1 & sleep 2; }
echo "  X=$(xdpyinfo >/dev/null 2>&1 && echo up || echo DOWN) rfb=$(timeout 2 bash -c 'exec 3<>/dev/tcp/127.0.0.1/5901; head -c 7 <&3' 2>/dev/null)"

echo "== [2] host GL on the display must be the RTX =="
glxinfo -B 2>&1 | grep -E "OpenGL (vendor|renderer|core profile version)|Accelerated|rror" | sed 's/^/  /'

echo "== [3] wined3d backend -> gl (the Vulkan path has no GPU here: no dozen ICD) =="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d gl /f >/dev/null 2>&1
wine reg query "HKCU\\Software\\Wine\\Direct3D" 2>/dev/null | grep -iE "renderer|Video" | sed 's/^/  /'

echo "== [4] launch Edge (--use-angle=$ANGLE $EXTRA) with memory watchdog =="
( setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --use-angle="$ANGLE" $EXTRA --window-size=1200,700 --window-position=60,60 \
    --user-data-dir="$PROFILE" --new-window \
    "file:///Z:/root/linuxlab/rx580-check.html#rx580" >"$OUT/edge-rtx.log" 2>&1 & )
for i in $(seq 1 60); do
  used=$(free -m | awk 'NR==2{print $3}')
  left=$(free -m | awk 'NR==2{a=$7} NR==3{s=$4} END{print a+s}')
  t=$(wmctrl -l 2>/dev/null | grep -iE "microsoft|identity|rx580" | tail -1 | cut -c1-300)
  printf '  t=%-4ss mem=%-5s left=%-5s procs=%-2s %s
' "$((i*3))" "$used" "$left" "$(pgrep -fc msedge)" "${t:-no-window}"
  # the startup spike is normal for Edge-under-Wine (same in the old software
  # config); only a true squeeze of RAM+swap is fatal to WSL
  if [ "$left" -lt "$HEADROOM" ]; then
    echo "  !!! WATCHDOG: only $left MB RAM+swap left - killing Edge to save WSL"
    pkill -9 -f msedge; wineserver -k 2>/dev/null; exit 2
  fi
  case "$t" in *RX580CHECK*) break ;; esac
  sleep 3
done
echo "== verdict =="
wmctrl -l 2>/dev/null | grep -i rx580 | cut -c1-400
tail -5 "$OUT/edge-rtx.log" 2>/dev/null | sed 's/^/  log: /'
