#!/bin/bash
# The earlier sweep was unreliable: titles were grepped across ALL windows and many
# leftover Chrome instances were still on screen, so every row may have read one old
# window. Start from a clean slate, one instance per profile, and identify each result by
# the launch tag embedded in the page title (document.title carries location.hash).
LAB=/root/linuxlab
DIR=/root/vklayer
CHROME="$LAB/chrome/chrome"
export DISPLAY=:9

echo "=== [0] who is running right now ==="
for p in $(pgrep -f "$CHROME" 2>/dev/null); do
  tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null | grep -o 'cd_[a-z0-9_]*' | head -1
done | sort -u | sed 's/^/  profile: /'
echo

echo "=== [0b] leftover layer manifests (must be gone) ==="
rm -f /usr/share/vulkan/explicit_layer.d/VK_LAYER_FAKE_rx580.json \
      /usr/share/vulkan/implicit_layer.d/VK_LAYER_FAKE_rx580.json
ls /usr/share/vulkan/explicit_layer.d/ /usr/share/vulkan/implicit_layer.d/ 2>/dev/null | sed 's/^/  /'

echo
echo "=== [1] kill every Chrome so results cannot be stale ==="
pkill -9 -f "$CHROME" 2>/dev/null
sleep 3
echo "  remaining: $(pgrep -fc "$CHROME" 2>/dev/null || echo 0)"
echo

launch() {  # launch <tag> <preload> <flags...>
  local tag="$1" preload="$2"; shift 2
  env LD_PRELOAD="$preload" \
      VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json \
      RX580_LOG=1 \
      setsid nohup "$CHROME" \
        --no-sandbox --disable-dev-shm-usage \
        --no-first-run --no-default-browser-check --disable-extensions \
        --window-size=1200,680 --window-position=60,80 \
        --user-data-dir="$LAB/cd_$tag" \
        --enable-logging=stderr \
        "$@" "file://$LAB/rx580-check.html#$tag" >"$LAB/out/$tag.log" 2>&1 &
  sleep 13
  echo "  title: $(wmctrl -l 2>/dev/null | grep -o "RX580CHECK\[#$tag\][^|]*|[^|]*renderer[^|]*" | head -1)"
}

echo "=== [2] fresh instance, --use-angle=vulkan, NO preload ==="
launch base "" --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist
echo "  GL errors:"
grep -iE 'ANGLE Requires|Internal Vulkan error|EGL_NOT_INITIALIZED|ChoosePhysicalDevice' \
  "$LAB/out/base.log" | head -3 | sed 's/^/    /' || echo "    (none)"
pkill -9 -f "cd_base" 2>/dev/null; sleep 2

echo
echo "=== [3] fresh instance, --use-angle=vulkan, WITH interposer ==="
launch pre "$DIR/libvk_rx580_preload.so" --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist
echo "  GL errors:"
grep -iE 'ANGLE Requires|Internal Vulkan error|EGL_NOT_INITIALIZED|ChoosePhysicalDevice' \
  "$LAB/out/pre.log" | head -3 | sed 's/^/    /' || echo "    (none)"
echo "  interposer calls: $(sort /tmp/rx580_preload.log 2>/dev/null | uniq -c | tr '\n' ' ')"
echo

echo "=== [4] screenshot of the live window ==="
if command -v import >/dev/null; then
  import -window root "$LAB/out/clean.png" 2>/dev/null \
    && cp "$LAB/out/clean.png" "/mnt/c/Users/Darkking1/Desktop/similar to gologin/results/rx580-clean.png" \
    && echo "  saved results/rx580-clean.png"
fi
echo
echo "=== [5] windows now ==="
wmctrl -l 2>/dev/null | sed 's/^/  /'
