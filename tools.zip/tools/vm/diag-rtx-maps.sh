#!/bin/bash
# What IS the memory? Dump the biggest Rss mappings of the top Edge processes
# a few seconds into a d3d12 (RTX) launch, then kill before the cap.
export LC_ALL=C.UTF-8 DISPLAY=:9 PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml=" WINEDEBUG="-all" GALLIUM_DRIVER=d3d12
unset LIBGL_ALWAYS_SOFTWARE VK_DRIVER_FILES VK_ICD_FILENAMES
OUT=/root/winelab/out
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"
ANGLE="${1:-gl}"
if [ "$BASELINE" = 1 ]; then   # the old, stable software config for comparison
  export LIBGL_ALWAYS_SOFTWARE=1 GALLIUM_DRIVER=llvmpipe
  export VK_DRIVER_FILES=/root/vkicd/rx580_icd.json VK_ICD_FILENAMES=/root/vkicd/rx580_icd.json
  wine reg add "HKCU\Software\Wine\Direct3D" /v renderer /t REG_SZ /d vulkan /f >/dev/null 2>&1
fi
echo "mode: BASELINE=${BASELINE:-0} angle=$ANGLE GALLIUM=$GALLIUM_DRIVER"
pkill -9 -f msedge 2>/dev/null; wineserver -k 2>/dev/null; sleep 2
rm -rf /root/.wine/drive_c/t15
echo "== baseline =="; grep -E "MemTotal|MemFree|Shmem:|Cached" /proc/meminfo
( setsid nohup wine "$EDGE" --no-sandbox --no-first-run --no-default-browser-check \
    --disable-extensions --disable-sync --disable-component-update --renderer-process-limit=1 \
    --use-angle="$ANGLE" --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t15' --new-window \
    "file:///Z:/root/linuxlab/rx580-check.html#rx580" >"$OUT/edge-rtx.log" 2>&1 & )
for i in $(seq 1 20); do
  sleep 1
  used=$(free -m | awk 'NR==2{print $3}')
  [ "$used" -gt 2600 ] && break
done
echo "== at t=${i}s used=${used}MB =="
grep -E "Shmem:|AnonPages|Mapped|Committed_AS" /proc/meminfo
for p in $(ps -eo pid,rss,args --sort=-rss | grep -i msedge | grep -v grep | head -3 | awk '{print $1}'); do
  t=$(tr '\0' ' ' </proc/$p/cmdline | grep -oE -- '--type=[a-z-]+' | head -1)
  echo
  echo "## pid $p ${t:-browser}"
  grep -E "^(Rss|Pss|Anonymous|Shared_Clean|Shared_Dirty|Private_Dirty)" /proc/$p/smaps_rollup
  echo "   top mappings by Rss (kB, name):"
  awk '/^[0-9a-f]+-[0-9a-f]+ /{name=$6; if(name=="") name="[anon]"} /^Rss:/{r[name]+=$2}
       END{for(n in r) printf "%10d %s\n", r[n], n}' /proc/$p/smaps | sort -rn | head -8 | sed 's/^/   /'
done
pkill -9 -f msedge; wineserver -k 2>/dev/null
echo; echo "== after kill =="; free -m | head -2
