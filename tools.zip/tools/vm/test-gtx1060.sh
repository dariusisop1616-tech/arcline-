#!/bin/bash
# Launch Edge with the GTX 1060 identity ICD and observe the WebGL string.
export DISPLAY=:9
export PATH="/opt/wine-staging/bin:$PATH"
export WINEDLLOVERRIDES="mscoree,mshtml="
export WINEDEBUG="-all"
OUT=/root/winelab/out
EDGE="/root/.wine/drive_c/Program Files (x86)/Microsoft/Edge/Application/154.0.4258.37/msedge.exe"

echo "== ensure wined3d backend = vulkan (dxgi must read OUR device, not the host GL) =="
wine reg add "HKCU\\Software\\Wine\\Direct3D" /v renderer /t REG_SZ /d vulkan /f 2>&1 | grep -i success | head -1
wine reg query "HKCU\\Software\\Wine\\Direct3D" /v renderer 2>/dev/null | tail -2

echo "== fresh wine, fresh profile, launch =="
wineserver -k 2>/dev/null; sleep 1
pkill -9 -x wineserver 2>/dev/null; pkill -9 -f msedge 2>/dev/null; sleep 2
rm -rf /root/.wine/drive_c/t13 2>/dev/null
( export VK_DRIVER_FILES="/root/vkicd/rx580_icd.json" \
    VK_ICD_FILENAMES="/root/vkicd/rx580_icd.json" RX580_LOG=1
  setsid nohup wine "$EDGE" \
    --no-sandbox --no-first-run --no-default-browser-check --disable-extensions \
    --disable-sync --disable-component-update --renderer-process-limit=1 \
    --use-angle=vulkan --window-size=1200,700 --window-position=60,60 \
    --user-data-dir='C:\t13' --new-window \
    "file:///Z:/root/linuxlab/rx580-check.html#rx580" >"$OUT/edge11.log" 2>&1 & )

echo "== poll (broad matcher catches the pre-WebGL title too) =="
for i in $(seq 1 40); do
  t=$(wmctrl -l 2>/dev/null | grep -iE "microsoft|identity|rx580" | tail -1 | cut -c1-260)
  if [ -n "$t" ]; then printf '    t=%-3ss %s\n' "$((i*3))" "$t"; fi
  case "$t" in *RX580CHECK*) break ;; esac
  sleep 3
done
echo
echo "== verdict =="
t=$(wmctrl -l 2>/dev/null | grep rx580 | cut -c1-300)
case "$t" in
  *GTX\ 1060*) echo "    >>> GTX 1060 IDENTITY IS THROUGH:"; echo "$t" ;;
  *) echo "    >>> identity not as expected; title:"; echo "${t:-NONE}" ;;
esac