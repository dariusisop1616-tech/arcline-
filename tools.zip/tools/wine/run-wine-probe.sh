#!/bin/bash
# Runs a WINDOWS Chromium under Wine and measures its fingerprint, plus captures
# the API call map (relay trace) for the graphics/font/audio channels.
#
# Everything lives under ~/winelab; nothing outside it is touched.
set -u
LAB="$HOME/winelab"
PREFIX="$LAB/prefix"
CHROME_DIR="$LAB/chrome"
OUT="$LAB/out"
mkdir -p "$LAB" "$OUT"
export WINEPREFIX="$PREFIX"
export WINEDEBUG="-all"          # quiet for setup; tracing turned on only for the traced run

log(){ echo "[$(date +%H:%M:%S)] $*"; }

# --- 1. windows chromium (Chrome for Testing, win64) ---
if [ ! -x "$CHROME_DIR/chrome.exe" ]; then
  log "resolving latest Chrome-for-Testing win64..."
  VER=$(curl -s https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions.json | grep -o '"Stable"[^}]*"version":"[^"]*"' | grep -o '"version":"[^"]*"' | head -1 | cut -d'"' -f4)
  [ -z "$VER" ] && VER="stable"
  URL="https://storage.googleapis.com/chrome-for-testing-public/${VER}/win64/chrome-win64.zip"
  log "downloading chrome $VER"
  curl -s -o "$LAB/chrome.zip" "$URL" || { log "download failed"; exit 1; }
  7z x -o"$LAB" "$LAB/chrome.zip" >/dev/null 2>&1
  mv "$LAB"/chrome-win64/* "$CHROME_DIR" 2>/dev/null || { mkdir -p "$CHROME_DIR"; mv "$LAB"/chrome-win64/* "$CHROME_DIR"; }
fi
log "chrome.exe: $([ -x "$CHROME_DIR/chrome.exe" ] && echo present || echo MISSING)"

# --- 2. wine prefix init ---
if [ ! -d "$PREFIX" ]; then
  log "initializing wine prefix (headless via xvfb)..."
  xvfb-run -a wineboot --init >/dev/null 2>&1
  wineserver -w
fi
log "wine: $(wine --version 2>/dev/null)"

PROBE_WIN='Z:\mnt\c\Users\Darkking1\Desktop\similar to gologin\tools\fingerprint-probe.html'

# --- 3. probe run (capture dump-dom) ---
log "running probe under wine..."
xvfb-run -a wine "$CHROME_DIR/chrome.exe" \
  --headless=new --dump-dom --virtual-time-budget=12000 \
  --no-first-run --no-default-browser-check --disable-extensions \
  --use-angle=d3d11 --user-data-dir="$LAB/cd" \
  "file:///mnt/c/Users/Darkking1/Desktop/similar%20to%20gologin/tools/fingerprint-probe.html" \
  > "$OUT/probe_raw.html" 2>"$OUT/probe_err.txt"
python3 - "$OUT/probe_raw.html" "$OUT/probe.txt" <<'PY'
import sys,re
raw=open(sys.argv[1],encoding='utf-8',errors='replace').read()
m=re.search(r'<pre id="out">(.*?)</pre>',raw,re.S)
open(sys.argv[2],'w',encoding='utf-8').write(m.group(1) if m else '<<no pre; bytes=%d>>'%len(raw))
PY
log "=== PROBE RESULT ==="
grep -iE "UNMASKED_RENDERER|UNMASKED_VENDOR|MAX_TEXTURE|canvas2d.toDataURLHash|audio.sampleRate|hardwareConcurrency|platform " "$OUT/probe.txt" || head -30 "$OUT/probe.txt"

log "DONE"
