# Wine + modern Chromium: the window never maps — measured 2026-09-26

Context: giving the user a **visible, interactive** Linux display with the stock Windows
browser (Chrome for Testing 154 / Edge 153) running under Wine 10.0 on WSL2 Ubuntu.

## The display layer works, and that was the first fight

WSLg on this machine creates windows but never paints them (`[WARN:COPY MODE]` — even
`xeyes` renders white). Replaced it with:

```
Xvfb :9 -screen 0 1440x900x24 -ac
fluxbox
x11vnc -display :9 -forever -shared -nopw -rfbport 5901   # needs WAYLAND_DISPLAY unset
websockify --web=/usr/share/novnc 6080 localhost:5901
```

**Confirmed working** — visible at `http://localhost:6080/vnc.html`: wallpaper, fluxbox
taskbar with a live clock, workspace switching, real window frames. A Wine `notepad`
window maps and paints correctly with full Windows chrome (menu bar, status bar).

`x11vnc` refuses to start while `WAYLAND_DISPLAY` is set in the environment
(`Wayland display server detected ... Exiting`). It must be unset first.

## The blocker: Chrome/Edge windows are created but never MAPPED

Diagnosed with `xwininfo`, not guessed:

```
0x1c00005 | Map State: IsUnMapped | Width: 1272 Height: 766    <- the real browser window
_NET_CLIENT_LIST(WINDOW): window id #                          <- empty: the WM sees no client
```

So Chrome allocates a correctly-sized 1272x766 window, then never maps it. fluxbox draws
no frame for it. Nothing is painted. `notepad` under the same Wine prefix maps fine, so
Wine's X11 driver is healthy — it is Chromium's window handling specifically.

### Every flag combination tried, and what it did

| backend / flag | chrome procs | window | mapped |
|---|---|---|---|
| `--use-angle=d3d11` | 0 (crashes) | — | `Failed to create device` (Dawn/Graphite) |
| `--use-angle=gl` | 1–3 | 1272x766 | **no** — `WGL_NV_DX_interop2 is required but not present` |
| `--use-angle=swiftshader` | 5–8 | 1272x766 | **no** |
| `--use-angle=vulkan` | 7 | 1272x766 | **no** |
| `--disable-gpu` | 0–6 (flaky) | 1272x766 | **no** |
| `+ --disable-gpu-compositing` | 7 | 1272x766 | **no** |
| `+ --disable-direct-composition` | 0–4 | window lost | — |
| `+ --disable-features=CalculateNativeWinOcclusion` | 1 | — | **no** |
| `explorer /desktop=lab,1440x900` | 0 | — | invocation unreliable |
| **Wine registry virtual desktop** | 1–7 | `1440x900 "lab - Wine Desktop"` | **YES** |
| Edge 153 (all of the above) | 1 | — | **no** |

### What actually helped

**Wine's registry-level virtual desktop maps and paints:**

```
wine reg add 'HKCU\Software\Wine\Explorer' /v Desktop /d lab /f
wine reg add 'HKCU\Software\Wine\Explorer\Desktops' /v lab /d 1440x900 /f
```

This produced a genuinely viewable, painted `1440x900 "lab - Wine Desktop"` window — the
first time Wine rendered anything to X in this setup. Chrome inside it, however, still
never appears, and its processes die progressively:

```
t=05s chrome.exe=7   t=10s=3   t=20s=1 ... t=60s=1
```

Only the browser process survives; renderers and GPU process exit.

**Conclusion:** this is a Wine 10.0 vs. Chromium 153/154 incompatibility, not a
configuration problem. Both Chrome and Edge fail identically, so it is not
Chrome-specific, and no flag in the table recovers it.

## What DOES work, and is the thing to build on

1. **Headless Wine Chromium produces a full fingerprint.** `platform: Win32`, Windows UA,
   `canvas2d 41d5bfb9` — the synthetic-Windows illusion holds. Capture works via the
   probe's `?post=` POST-back (a GUI-subsystem binary writes nothing to a pipe).
2. **A visible, navigable browser on the Xvfb display, rendering through OUR driver.**
   Native Linux Chrome for Testing 154 with `--use-angle=vulkan` +
   `VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.json`:

   ```
   ANGLE (Mesa, Vulkan 1.4.335 (llvmpipe (LLVM 21.1.8 256 bits) (0x00000000)), llvmpipe)
   ```

   Window `IsViewable`, 1360x820, page loaded (title set by its own JS). Chrome is on the
   external Mesa driver, NOT its bundled SwiftShader — **the replaceable-driver socket,
   live and visible.** This is the architecture; only the Windows-ness comes from Wine.

## Next step to close the gap

Try an **older Chromium** under Wine. Modern Chromium (153/154) changed its windowing
model and Wine's support lags. Chrome 109–126 class builds are the well-known-good range
under Wine. If an older build maps its window, the Windows-UA + our-driver stack is
complete end to end.

## Reproduce

- `tools/vm/vnc-lab.sh` — display + VNC + noVNC stack
- `tools/vm/browser-window-test.sh` — control (notepad) vs. browser window creation
- `tools/vm/backend-matrix.sh` — the ANGLE backend sweep
- `tools/vm/map-and-desktop.sh` — map-state proof + virtual desktop
- `tools/vm/vdesk-chrome.sh` — Chrome inside the registry virtual desktop
- `tools/vm/show-browser.sh` — the working visible browser on the external driver
