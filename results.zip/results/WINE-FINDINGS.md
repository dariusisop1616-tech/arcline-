# Approach 2 (synthetic Windows / Wine) — measured findings

Environment: WSL2 Ubuntu 26.04, Wine 10.0, Windows Chrome-for-Testing 154 (and copied
Edge 153). All measured 2026-09-26. Raw in results/wine/.

## Proven: a stock Windows browser runs on Wine and returns a full fingerprint

```
userAgent      : Mozilla/5.0 (Windows NT 10.0; Win64; x64) ... HeadlessChrome/154...
platform       : Win32          <- the browser believes it is on Windows
hardwareConcurrency : 8
webgl RENDERER : ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (0xC0DE)), SwiftShader)
canvas2d hash  : 41d5bfb9
fonts.count    : 4              <- Wine ships almost no fonts
audio.sampleRate : 44100
```

Key points:
- **The synthetic-Windows illusion holds.** `platform: Win32` + Windows UA. The browser
  only knows the world through Wine's APIs, and Wine says "Windows". No browser patch,
  no integrity fight.
- **Cost ~1 GB** vs 4 GB for the full VM. No Windows license (Wine is not Windows).
- **fonts.count = 4**: a tell (too few) AND the lever — the font set is entirely ours.
- Canvas hash `41d5bfb9` is SwiftShader-under-Wine's deterministic output; differs from
  Windows SwiftShader (`d8c276e6`), i.e. the environment shifts the software-render hash.

## Not working out of the box: real GPU through Wine

`--use-angle=gl` and the D3D12/EGL path failed: `eglInitialize OpenGL failed
EGL_NOT_INITIALIZED`. Reaching the real RTX 3060 Ti through Wine -> WSL D3D12 needs
several translation layers configured (wined3d/vkd3d + Mesa dozen/d3d12 + Vulkan ICD).
Deferred, because it is not what this approach is for (see roles below).

## The two approaches have distinct roles

| | Approach 1: VM + GPU partition | Approach 2: Wine synthetic Windows |
|---|---|---|
| WebGL realism | REAL hardware (measured: real RTX string) | software renderer we own |
| Per-profile control of pixels | limited to real HW output | ARBITRARY (we own the renderer + Wine DLLs) |
| Windows license | one per profile | none |
| Cost per profile | ~4 GB | ~1 GB |
| Integrity fight | yes (System32 hardening) | none (our own DLLs) |
| Best for | borrowed realism | full control / Task 1 + Task 2 |

## Why control is clean under Wine

To change the WebGL GPU string under Wine, we edit **Wine's own dxgi** (its source is
ours), so Chromium's System32 DLL-search hardening is irrelevant and there is no
signature/ownership fight - the exact wall we hit in Approach 1 does not exist here.
Same for feeding canvas a function: the renderer under Wine is ours.

## Capture method note

chrome.exe/msedge.exe are GUI-subsystem binaries; --dump-dom writes nothing to a plain
pipe (same issue as PowerShell Direct on Windows). Capture is done by having the probe
POST its results to a tiny local collector (fingerprint-probe.html ?post= param).
