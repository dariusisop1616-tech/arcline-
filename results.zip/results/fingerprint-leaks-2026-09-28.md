# Leak census: native Windows Edge vs Wine Edge — 2026-09-28

Same browser build on both sides (**154.0.4258.37**), same probe
(`tools/fingerprint-probe.html`) served over http from one collector in WSL so
both browsers post same-origin (`tools/relay/collect.py`, `fp-wine-side.sh`,
`fp-diff.sh`). **29 signals identical, 35 different.**

Wine side was running the *software* renderer (llvmpipe + our fake-ICD GTX 1060
identity) — not the real GPU — because Edge's GPU process still crashes on the
real-GPU path. That is the single biggest cause below.

## A. The GPU cluster — one root cause: software renderer, not the real GPU

| signal | windows | wine |
|---|---|---|
| webgl/webgl2 UNMASKED_RENDERER | `ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Ti (0x00002489) Direct3D11 vs_5_0 ps_5_0, D3D11)` | `ANGLE (NVIDIA, Vulkan 1.3.303 (...GTX 1060...), NVIDIA proprietary driver)` |
| MAX_VIEWPORT_DIMS | 32767x32767 | 16384x16384 |
| ALIASED_LINE_WIDTH | 1-1 | 1-255 |
| extCount (webgl/webgl2) | 35 / 32 | 34 / 28 |
| extHash, precisionHash, renderHash, toDataURLHash | differ | differ |
| canvas2d toDataURL/imageData/gradient hashes | differ | differ |
| webgpu | vendor nvidia, arch ampere | "no adapter" |

**Why these move together:** the limits, the extension list and the renderer
string are all *the backend's own answers*. `32767` and `ALIASED_LINE_WIDTH 1-1`
are characteristic of ANGLE's **D3D11** backend on a real driver; our Vulkan ICD
necessarily reports llvmpipe's numbers instead. Faking the string alone leaves
the limits wrong, so a string-only spoof is internally inconsistent and
detectable. Running Edge on the real GPU through D3D11 fixes the whole cluster at
once — and the pixels on that path are already proven byte-identical
(see `wine-real-gpu-is-bit-identical`, hashes 5f4c9dc5 / 9d262fa2).

## B. Cheap configuration leaks (no code needed)

| signal | windows | wine | fix |
|---|---|---|---|
| screen | 1920x1080 avail 1920x1040 | 1440x900 avail 1440x878 | Xvfb `-screen 0 1920x1080x24` |
| deviceMemory | 8 | 4 | `.wslconfig memory=8GB` (Chromium buckets physical RAM) |
| languages | fr,fr-FR,en,en-GB,en-US | en-US,en | Wine locale + Chromium `--lang` / Accept-Language |
| audio.sampleRate | 48000 | 44100 | force 48 kHz in the WSL audio stack |
| mediaDevices | 3 (audioinput, videoinput, audiooutput) | 2 (no videoinput) | provide a dummy camera device |

## C. Fonts and text — the hard remainder

| signal | windows | wine |
|---|---|---|
| fonts.count | 45 | 12 |
| fonts.present | Arial, Arial Black, Bahnschrift, Calibri, Cambria, Candara, Comic Sans MS, Consolas, Corbel, Courier New, Ebrima, ... | Arial, Arial Black, Courier New, Marlett, Microsoft YaHei, Tahoma, Times New Roman, Wingdings, **Ubuntu, DejaVu Sans, Liberation Serif, Roboto** |
| canvas2d.textBandHash | c8463bbf | d15c71d3 |
| canvas2d.textMetrics | 295.1220703125/22/6/**27** | 295.1220703125/22/6/**22** |

Two separate problems: the **font set** (fixable by installing the Windows font
files into the prefix, and the Linux names Ubuntu/DejaVu/Liberation/Roboto must
be hidden — they are a direct "this is Linux" tell), and **glyph rasterization**
(Chromium rasterizes text through DirectWrite; under Wine that is Wine's
FreeType-backed DWrite, so anti-aliasing can differ even with identical font
files). Note `textMetrics` already agrees on width (295.1220703125) and differs
only in the last field, so metrics are close; the *pixels* are the risk.

## What matched already (29)

userAgent, platform Win32, hardwareConcurrency, timezone/offset, colorDepth,
devicePixelRatio, maxTouchPoints, uaFullVersionList, canvas2d.textMetrics width,
audio latency/channel fields, offline-audio hashes, and the rest of the platform
block.
