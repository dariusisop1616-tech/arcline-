# Measured findings

All numbers below were measured on one machine (Windows 10 Pro 19045, i3-10105F, RTX 3060 Ti)
on 2026-09-26, not estimated. Raw probe output is in `host/` and `vm/`.

Lab guest: Hyper-V Gen 2, Windows 10 Pro fr-FR, 2 vCPU, 4 GB, stock Chrome 154.

## 1. GPU partitioning works, and leaves no tell in WebGL

`Get-VMPartitionableGpu` reports the RTX 3060 Ti with `ValidPartitionCounts = 32`, on
Windows 10 19045 — not just Windows 11 / Server 2022 as commonly stated.

With a partition attached, the guest's WebGL string is **byte-identical to bare metal**:

```
host   : ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Ti (0x00002489) Direct3D11 vs_5_0 ps_5_0, D3D11)
guest  : ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Ti (0x00002489) Direct3D11 vs_5_0 ps_5_0, D3D11)
```

This matters more than it looks. Windows *inside* the guest enumerates the adapter as
`PCI\VEN_1414&DEV_008E` — Microsoft's paravirtual render device. Chrome still reports
NVIDIA's real vendor and device ID `0x2489`, because ANGLE asks DXGI, which reports the
underlying physical adapter. **The virtualization is not visible at the WebGL layer.**

Capability values match bare metal too: `extHash 298b24e9`, `precisionHash bc7aed29`,
`MAX_TEXTURE_SIZE 16384`, `renderHash 120d1956` — all identical to the host.

## 2. Without a GPU partition, every guest collapses to the same fingerprint

| | renderer | canvas | maxTex |
|---|---|---|---|
| host, bare metal | `NVIDIA ... RTX 3060 Ti (0x2489) D3D11` | `13631a9d` | 16384 |
| guest, no partition | `Microsoft Basic Render Driver (0x8C)` | `fe094356` | 16384 |
| guest, SwiftShader | `SwiftShader Device (0xC0DE)` | `d8c276e6` | 8192 |
| **host** with `--disable-gpu` | `Microsoft Basic Render Driver (0x8C)` | **`fe094356`** | 16384 |

The last row is the important one: a GPU-less *guest* and a GPU-less *host* produce the
**same canvas hash**. Software rasterization is deterministic across machines, so every
profile without a GPU partition is identical to every other one — and to millions of
other VMs. Great for blending in, useless for separating profiles, and a clear "no GPU"
marker. GPU partitioning is therefore mandatory, not optional.

## 3. `--use-angle` is a real lever on bare metal, but NOT inside a guest

On the host, four backends give four distinct identities:

| backend | renderer | maxTex | canvas |
|---|---|---|---|
| d3d11 | `NVIDIA ... RTX 3060 Ti (0x2489) Direct3D11` | 16384 | `13631a9d` |
| gl | `NVIDIA ... RTX 3060 Ti/PCIe/SSE2, OpenGL 4.5.0` | 32768 | `2608bc00` |
| vulkan | `NVIDIA, Vulkan 1.4.325 (... (0x2489))` | 32768 | `ee5b5132` |
| swiftshader | `SwiftShader Device (0xC0DE)` | 8192 | `d8c276e6` |

In the GPU-partitioned guest, only `d3d11` reaches the NVIDIA partition. `gl` and `vulkan`
both fall back to `Microsoft Basic Render Driver` — there is no native GL/Vulkan ICD for
the paravirtual device. So the backend-diversity idea does not survive virtualization.

**Operational consequence:** the launcher must pass `--use-angle=d3d11` explicitly. Without
it (`gpu-default.txt`), WebGL failed to initialize at all — and a browser reporting no
WebGL is a far louder signal than any renderer string. With the flag, 3/3 stability runs
succeeded.

## 4. Canvas 2D does not follow WebGL onto the real GPU

In the GPU-partitioned guest, canvas 2D still hashes `fe094356` / `07732359` — the same
value as a GPU-less VM. Flags did not change it:

| flags | canvas |
|---|---|
| `--enable-accelerated-2d-canvas --ignore-gpu-blocklist` | `fe094356` |
| `+ --enable-gpu-rasterization --enable-zero-copy` | `fe094356` |
| `+ --disable-software-rasterizer` | `fe094356` |

WebGL runs on NVIDIA while canvas 2D stays on the CPU path. **This is the open problem:**
every profile on every host shares one canvas hash, which links them to each other.

What does still vary per guest, and is controlled by OS configuration:

| signal | host | guest | driven by |
|---|---|---|---|
| `hardwareConcurrency` | 8 | 2 | vCPU count |
| `deviceMemory` | 8 | 4 | VM RAM |
| `timezone` | Africa/Lagos | Europe/Berlin | Windows timezone |
| `audio.sampleRate` | 48000 | 44100 | audio endpoint |
| `fonts.count` / hash | 45 / `9e2a1b9b` | 42 / `4a00644c` | installed fonts |
| `canvas2d.textBandHash` | `c8463bbf` | `2fa3e8e1` | fonts + DirectWrite |

Note `textMetrics` is identical (`295.1220703125/22/6/27`) — text *metrics* come from the
font file, while text *rasterization* differs with the graphics path.

## 5. Dead end confirmed

`--gpu-testing-gl-renderer` / `--gpu-testing-vendor-id` are ignored by WebGL. Byte-identical
output with and without. They only feed Chrome's internal GPU-config logic.

## Open questions

- Can canvas 2D be pushed onto the NVIDIA partition (remove the Hyper-V Video adapter so
  NVIDIA is the primary display, or run the guest with a real desktop session rather than
  headless)?
- Does the registry `HardwareInformation.AdapterString` rename change the reported string
  on the D3D11 path, and does the `(0x2489)` suffix betray it? Untested.
- Does WebGL still report NVIDIA when several guests hold partitions simultaneously?
