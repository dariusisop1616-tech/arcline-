# Reporting an RX 580 in WebGL — the method, verified

**Status: working.** A native, unpatched Chrome for Testing 154 renders through external
Mesa and reports:

```
webgl vendor   : Google Inc. (AMD)
webgl renderer : ANGLE (AMD, Vulkan 1.4.335 (AMD Radeon RX 580 Series (RADV POLARIS10) (0x000067DF)), radv)
webgl version  : WebGL 1.0 (OpenGL ES 2.0 Chromium)
```

with **no GL errors** in the browser log, i.e. ANGLE accepted the device and the context
really works — this is not a renamed string on a dead context.

Nothing is injected into the page, no extension is used, and the browser binary is
untouched. The browser asks the driver what it is; the answer is an RX 580.

## How the value gets there

```
   page calls getParameter(UNMASKED_RENDERER_WEBGL)
        │
   ANGLE  ── calls vkGetPhysicalDeviceProperties / …Properties2
        │
   our LD_PRELOAD interposer   ← patches identity, calls the real function through
        │
   Vulkan loader → lavapipe (Mesa llvmpipe)   ← real rasterizer, untouched
```

`ANGLE` assembles the renderer string from what Vulkan answers, as:

```
ANGLE (<vendorID>, Vulkan <apiVersion> (<deviceName> (<0xdeviceID>)), <driverName>)
```

So three fields have to agree, which is why one string patch would not do: `vendorID`
(0x1002 AMD), `deviceID` (0x67DF Polaris 10), `deviceName`, plus `driverName` from
`VkPhysicalDeviceDriverProperties` in the pNext chain (`radv`). `deviceType` is set to
`DISCRETE_GPU` for consistency.

**Limits are deliberately left as the real driver reports them.** The machine really
renders with llvmpipe's limits, so the capability numbers stay self-consistent instead of
claiming RX 580 silicon it does not have.

## Trap 1 — which backend wins decides whether any of this is reachable

Chrome ships **its own software renderer (SwiftShader) inside the binary** and uses it by
default when it sees no GPU. In that mode no external component is in the render path at
all, and nothing on disk can be replaced. Forcing it off is mandatory:

| flags | renderer reported | replaceable? |
|---|---|---|
| (none) | `ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero)…), SwiftShader driver)` | **no** — compiled into Chrome |
| `--use-angle=vulkan` | `ANGLE (Mesa, Vulkan 1.4.335 (llvmpipe…), llvmpipe)` | **yes** — a file on disk |
| `--use-angle=gl` | external Mesa over GL | yes |

`--use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist` is the combination
that puts Chrome on external Mesa. The earlier work reached the same conclusion and proved
it by pixels: canvas hash `46730522` under bundled SwiftShader vs `49972c82` under external
Mesa.

Note the interposer is only *reachable* on the second and third rows. On the default
SwiftShader path the interception never matters.

## Trap 2 — `dlsym(RTLD_NEXT, …)` is not enough, and it fails silently

First version worked in a standalone probe and broke the browser with:

```
vulkan_icd.cpp:389 (ChoosePhysicalDevice): Preferred device ICD not found. Using default physicalDevice instead.
vk_renderer.cpp:2722 (initialize): ANGLE Requires a minimum Vulkan device version of 1.1
Display::initialize error 0: Internal Vulkan error (-9)
eglInitialize Vulkan failed with error EGL_NOT_INITIALIZED
```

Cause: `RTLD_NEXT` resolves the next definition in the **global link scope**. The probe
links `-lvulkan` at load time, so it works there. Chrome's ANGLE **`dlopen`s** libvulkan,
so `RTLD_NEXT` returns `NULL` — our hook never called the real function and returned with
`VkPhysicalDeviceProperties` **uninitialised**. ANGLE then read a garbage `apiVersion` and
rejected the device. The rename looked like it had broken Vulkan; it had actually broken
the call.

The fix is a three-step resolution, rejecting our own symbol (which sits first in
`RTLD_DEFAULT` and would recurse forever):

```c
void *p = dlsym(RTLD_NEXT, name);
if (!p || p == self) p = dlsym(RTLD_DEFAULT, name);
if (!p || p == self) p = dlsym(dlopen("libvulkan.so.1", RTLD_NOW | RTLD_LOCAL), name);
```

Only cache the result when non-NULL: on the first call libvulkan may not be loaded yet,
and caching that NULL would make every later call skip the real function.

## Why not a Vulkan layer (the sanctioned route)

A layer was the first choice — it is the correct place to answer driver queries. It was
abandoned on evidence, not preference. The layer is discovered, loaded, and negotiates
correctly, and then the loader **deadlocks on its own global lock**:

```
#0 futex_wait
#3 ___pthread_mutex_lock (mutex inside libvulkan.so.1)
#4 vkCreateInstance () from libvulkan.so.1
#5 ?? () from libvulkan.so.1
#6 vkCreateInstance () from libvulkan.so.1      ← the loader re-entering itself
#7 main ()
```

`State: S (sleeping)`, `wchan: futex_do_wait`, zero CPU, single thread — a deadlock, not a
loop. The loader's own log shows why:

```
WARNING | Path to given binary /root/vklayer/librx580.so was found to differ
          from OS loaded path /usr/lib/x86_64-linux-gnu/libvulkan.so.1.4.341
INFO    | Insert instance layer "VK_LAYER_FAKE_rx580" (/usr/lib/x86_64-linux-gnu/libvulkan.so.1.4.341)
```

It records **its own library path** as the layer's, so the "layer" it invokes is its own
`vkCreateInstance` → re-enters itself → deadlocks. That is a loader bug, and it is not
about our code:

| test | result |
|---|---|
| no layer | works |
| **a stub layer that returns NULL for everything** | **hangs** |
| system implicit layers | work |
| our layer, manifest `file_format_version` 1.0.0 | hangs |
| our layer, `.so` moved to `/usr/lib/x86_64-linux-gnu` | hangs |
| our layer, implicit manifest with `disable_environment` | hangs |

A layer that does *nothing* still hangs it, and moving the library to where every system
layer lives changes nothing. So the layer route is closed on this loader until the loader
is fixed or replaced; the interposer reaches the same place without that machinery.

## Files

| file | role |
|---|---|
| `tools/vulkan-layer/preload_rx580.c` | **the interposer** — the thing that works |
| `tools/vm/rx580-check.html` | page that prints the strings; puts them in the window title so results are readable without pixels |
| `tools/vm/verify-rx580.sh` | launches Chrome with the interposer and reads the result |
| `tools/vulkan-layer/rx580_layer.c` | the layer (kept for the record; blocked by the loader bug) |
| `tools/vulkan-layer/hang-hunt.sh`, `spin.sh`, `probe-gdb.sh` | the loader-bug evidence above |
| `tools/vulkan-layer/isolate.sh` | proves a no-op layer hangs the loader too |

Reproduce:

```bash
gcc -shared -fPIC -O2 -o librx580_preload.so preload_rx580.c -ldl

LD_PRELOAD=/root/vklayer/libvk_rx580_preload.so RX580_LOG=1 \
  /root/linuxlab/chrome/chrome --no-sandbox --disable-dev-shm-usage \
  --use-angle=vulkan --enable-features=Vulkan --ignore-gpu-blocklist \
  --user-data-dir=/tmp/p file:///root/linuxlab/rx580-check.html
```

`RX580_LOG=1` writes `/tmp/rx580_preload.log`; it should show `(real called)` on every
interception — if it says `REAL MISSING`, Trap 2 has come back.

## Open items

1. **The identity is per-process, not per-profile.** One interposer, one claimed card.
   A per-profile card means one launch environment per profile — the same shape as the
   per-profile display decision.
2. **`--deviceId` / `--use-angle` are launch flags**, so a SaaS must control the launch,
   not just the profile directory.
3. **Windows-ness is still separate.** This makes the *graphics* say AMD RX 580. The
   `platform: Win32` / Windows UA part comes from running the Windows build under Wine,
   where the window still does not map (see `WINE-WINDOW-FINDINGS.md`).
4. **Limits are real llvmpipe limits.** A verifier comparing the renderer string against
   the reported limits will find llvmpipe's numbers, not an RX 580's. That is the honest
   boundary of what is faked today.
