# The driver socket — proven 2026-09-26

**Question:** can a NATIVE, unmodified browser be made to return our engine's pixels
without any JS override, extension, CDP injection, or browser patch?

**Answer: yes — by replacing the graphics driver it renders through.**

## Evidence

Native Linux Chrome 154 (Chrome for Testing), headless, same probe, same payload.
Only the graphics driver changed.

| Renderer | canvas2d.toDataURLHash | External / replaceable? |
|---|---|---|
| Chrome's **bundled SwiftShader** | `46730522` | NO — compiled into the browser |
| **Mesa llvmpipe** via `--use-gl=angle --use-angle=gl` | `33e11e69` | YES |
| **Mesa lavapipe** via `--use-angle=vulkan` | `49972c82` | YES |

Renderer string on the Vulkan run proves Chrome left its own renderer:
`ANGLE (Mesa, Vulkan 1.4.335 (llvmpipe (LLVM 21.1.8 256 bits)...))`

Mesa verified working standalone: `llvmpipe (LLVM 21.1.8, 256 bits)`, `softpipe`,
Mesa 26.0.8, OpenGL 4.5.

Inconclusive row: the `softpipe` run returned `46730522`, identical to the bundled
SwiftShader, which suggests a fallback rather than softpipe actually rendering. Not
counted as evidence.

## The critical requirement

**Chrome uses its OWN bundled SwiftShader by default when no usable GPU is present.**
In that mode NO external driver is in the path and replacing Mesa does nothing — this
is why an earlier run showed four different `GALLIUM_DRIVER` settings all producing the
identical hash `46730522`.

The browser must be forced onto an external driver:
- `--use-angle=vulkan` (worked here), or
- `--use-gl=angle --use-angle=gl`

That flag is the difference between the socket existing and not existing.

## Why this beats the JS-override path

| | JS override (extension / CDP) | Engine as Mesa driver |
|---|---|---|
| DataDome-class detection | **yes** (toString, Workers, iframes) | **nothing to detect** |
| Browser patched | no | no |
| JS prototypes modified | yes | **none** |
| Arbitrary page content | only captured payloads | **any content** |
| Need to precompute unknown payloads | yes — unsolvable | **no** — the engine IS the rasterizer |

## Architecture

```
Windows browser (native, unpatched)      <- Windows-ness: platform Win32, Windows UA
        | Windows graphics APIs
        v
Wine                                      <- proven earlier: browser reports Win32
        | Linux GL / Vulkan
        v
OUR DRIVER  (engine packaged as a Mesa/Gallium driver or Vulkan ICD)
        v
   RTX 3060 Ti pixels
```

## Engineering ahead

1. **Port engine JS -> C.** `fingerprint.mjs` warns `Math.sin/cos/exp` are V8-defined;
   port fdlibm exactly and re-verify against the replay fingerprint hash or bytes drift.
2. **Fork a working driver** (llvmpipe / lavapipe), replace its rasterization with the
   engine's measured units — do not write a driver from scratch.
3. **Keep canvas GPU-accelerated**, else Skia rasterizes inside the browser and never
   reaches the driver.
4. The engine's existing units (texture filter, blend, interpolator, output converter,
   MSAA resolve, shader math) ARE rasterizer components — this is a natural fit.

## Bench note

WSLg is a bad bench: non-standard GLVND dispatch, d3d12-backed Mesa, fragile software
D3D. Earlier failures there (Vulkan renderer, glReadPixels hook, PCI-ID config) were
bench artifacts, not architectural limits. Normal Mesa behaved correctly.
